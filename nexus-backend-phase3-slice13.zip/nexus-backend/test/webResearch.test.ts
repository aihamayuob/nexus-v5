import './helpers/setFallbackTestEnv.js';
import { test, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { createServer, type Server } from 'node:http';
import { openTestDb } from '../src/persistence/db.js';
import { buildRepos, resetReposSingletonForTests, getRepos } from '../src/persistence/repos.js';
import { runWebResearch } from '../src/research/webResearch.js';
import type { GatewayContext } from '../src/capability/permissionModel.js';

const ctx: GatewayContext = { authenticated: true, clientKey: 'test', projectId: null, userId: null };

function freshDb() {
  resetReposSingletonForTests(buildRepos(openTestDb()));
}

let fakeGemini: Server;

function listen(server: Server): Promise<string> {
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => {
      const addr = server.address();
      resolve(`http://127.0.0.1:${typeof addr === 'object' && addr ? addr.port : 0}`);
    });
  });
}

before(async () => {
  // Exact same fake-Gemini response shape as the pre-existing, proven
  // test/googleGrounding.test.ts fixture from Phase 1 — not reinvented.
  fakeGemini = createServer(async (req, res) => {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(
      JSON.stringify({
        candidates: [
          {
            content: { parts: [{ text: 'الذهب يُتداول حالياً بالقرب من مستويات مرتفعة تاريخياً.' }] },
            finishReason: 'STOP',
            groundingMetadata: {
              webSearchQueries: ['gold price today'],
              groundingChunks: [
                { web: { uri: 'https://example.com/gold-analysis', title: 'Gold Analysis' } },
                { web: { uri: 'https://example.org/market-news' } },
              ],
            },
          },
        ],
        usageMetadata: { promptTokenCount: 10, candidatesTokenCount: 12 },
      })
    );
  });
  process.env.NEXUS_GEMINI_BASE_URL = await listen(fakeGemini);
  process.env.NEXUS_GEMINI_API_KEY = 'fake-gemini-key';
});

after(async () => {
  await new Promise((r) => fakeGemini.close(r));
});

beforeEach(() => {
  freshDb();
});

test('runWebResearch rejects an empty question', async () => {
  await assert.rejects(() => runWebResearch('', ctx), /السؤال مطلوب/);
});

test("runWebResearch degrades gracefully (ran:false, no throw) when Gemini is not configured — mirrors verifier.ts's pattern", async () => {
  const savedKey = process.env.NEXUS_GEMINI_API_KEY;
  delete process.env.NEXUS_GEMINI_API_KEY;
  try {
    const result = await runWebResearch('سؤال بلا Gemini', ctx);
    assert.equal(result.ran, false);
    assert.equal(result.answer, '');
    assert.equal(result.sources.length, 0);
  } finally {
    process.env.NEXUS_GEMINI_API_KEY = savedKey;
  }
});

test('runWebResearch produces a real grounded answer with real webSearchQueries and correctly-extracted source domains', async () => {
  const result = await runWebResearch('ما هو سعر الذهب اليوم؟', ctx, { persistToMemory: false });
  assert.equal(result.ran, true);
  assert.match(result.answer, /الذهب/);
  assert.deepEqual(result.webSearchQueries, ['gold price today']);
  assert.equal(result.sources.length, 2);
  assert.equal(result.sources[0]!.domain, 'example.com');
  assert.equal(result.sources[1]!.domain, 'example.org');
});

test('a citation whose follow-up fetch genuinely fails (real SSRF/network constraint in this environment) is recorded with fetchOk:false, not silently dropped', async () => {
  const result = await runWebResearch('سؤال آخر', ctx, { persistToMemory: false });
  assert.equal(result.sources.length, 2);
  for (const s of result.sources) {
    assert.equal(s.fetchOk, false);
    assert.equal(s.contentPreview, '');
    assert.equal(s.contentHash, '');
  }
  assert.equal(result.ran, true, 'a failed follow-up fetch must not fail the whole research call');
});

test('runWebResearch persists a real Memory item by default, with real provenance included', async () => {
  const result = await runWebResearch('ما هو سعر الذهب اليوم؟', ctx);
  assert.ok(result.memoryItemId);
  const items = getRepos().memory.listForProject(null, 'knowledge');
  assert.equal(items.length, 1);
  assert.equal(items[0]!.id, result.memoryItemId);
  assert.match(items[0]!.content, /example\.com/);
  assert.match(items[0]!.content, /الذهب/);
});

test('runWebResearch skips Memory persistence when explicitly told to', async () => {
  const result = await runWebResearch('سؤال بلا حفظ', ctx, { persistToMemory: false });
  assert.equal(result.memoryItemId, null);
  assert.equal(getRepos().memory.listForProject(null, 'knowledge').length, 0);
});
