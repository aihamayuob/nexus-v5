import { randomUUID } from 'node:crypto';
import { runAgentTask } from '../agents/agentRunner.js';
import { AgentRegistry } from '../agents/agentRegistry.js';
import { Verifier } from '../orchestrator/verifier.js';
import { getRepos } from '../persistence/repos.js';
import type { GatewayContext } from '../capability/permissionModel.js';
import type { CreateCouncilSessionInput, CouncilSession } from './councilTypes.js';
import { logger } from '../core/logger.js';

/** In-memory cancellation registry, scoped to this process — same "fire, then let the caller cancel by id" shape as taskManager.ts's abort-signal map, kept local here because a council session is not a DAG-tracked task. */
const abortControllers = new Map<string, AbortController>();

export function cancelCouncilSession(sessionId: string): boolean {
  const ctrl = abortControllers.get(sessionId);
  if (!ctrl) return false;
  ctrl.abort();
  return true;
}

function resolveSupervisorId(supervisorAgentId: string | undefined): string {
  const id = supervisorAgentId ?? 'supervisor';
  if (!AgentRegistry.has(id)) throw new Error(`وكيل الإشراف غير معروف: ${id}`);
  return id;
}

export async function runCouncilSession(input: CreateCouncilSessionInput, gwCtx: GatewayContext): Promise<{ sessionId: string }> {
  if (input.mode === 'situation_room') return startSituationRoom(input, gwCtx);
  return startCrossExam(input, gwCtx);
}

// ---------------------------------------------------------------------
// cross_exam (Slice 1) — unchanged behavior, only re-homed into this
// dispatch structure so both modes share one create/cancel/get surface.
// ---------------------------------------------------------------------

async function startCrossExam(input: Extract<CreateCouncilSessionInput, { mode?: 'cross_exam' }>, gwCtx: GatewayContext): Promise<{ sessionId: string }> {
  if (!AgentRegistry.has(input.proposerAgentId)) throw new Error(`وكيل الاقتراح غير معروف: ${input.proposerAgentId}`);
  if (!AgentRegistry.has(input.criticAgentId)) throw new Error(`وكيل النقد غير معروف: ${input.criticAgentId}`);
  if (input.proposerAgentId === input.criticAgentId) throw new Error('يجب أن يكون وكيل الاقتراح ووكيل النقد مختلفين.');
  const supervisorAgentId = resolveSupervisorId(input.supervisorAgentId);

  const id = `council_${Date.now()}_${randomUUID().slice(0, 8)}`;
  getRepos().council.create({
    id,
    mode: 'cross_exam',
    topic: input.topic,
    proposerAgentId: input.proposerAgentId,
    criticAgentId: input.criticAgentId,
    supervisorAgentId,
  });

  const controller = new AbortController();
  abortControllers.set(id, controller);
  void executeCrossExam(id, input, supervisorAgentId, gwCtx, controller.signal).finally(() => abortControllers.delete(id));
  return { sessionId: id };
}

/**
 * Runs one bounded cross-examination round: Proposal -> Critique -> Rebuttal
 * -> independent Verification -> Supervisor Synthesis. Every text-producing
 * step goes through runAgentTask() (Slice 2) — this file adds ZERO new
 * provider-calling code; it only sequences existing, tested calls and
 * persists the transcript. Mirrors the frontend's runCrossExamination()
 * round-by-round (see councilTypes.ts's file doc comment).
 */
async function executeCrossExam(
  sessionId: string,
  input: Extract<CreateCouncilSessionInput, { mode?: 'cross_exam' }>,
  supervisorAgentId: string,
  gwCtx: GatewayContext,
  signal: AbortSignal
): Promise<void> {
  const repos = getRepos();
  const ctxBase = { missionId: sessionId, gwCtx, signal };

  try {
    // Round 1 — Proposal
    const proposal = await runAgentTask(input.proposerAgentId, {
      ...ctxBase,
      agentId: input.proposerAgentId,
      taskNodeId: 'proposal',
      taskDescription: input.topic,
      upstreamOutputs: {},
    });
    repos.council.appendRound(sessionId, 'proposal', input.proposerAgentId, proposal.output, proposal.providerUsed, proposal.modelUsed);

    // Round 2 — Critique (attacks the actual proposal, not an independent view)
    const critique = await runAgentTask(input.criticAgentId, {
      ...ctxBase,
      agentId: input.criticAgentId,
      taskNodeId: 'critique',
      taskDescription:
        `السؤال الأصلي: ${input.topic}\n\n` +
        'مهمتك تحديداً الآن: هاجم الاقتراح التالي بصرامة وموضوعية من زاوية تخصصك، واكشف كل ثغرة أو خطر أو نقطة ضعف فيه. لا تطرح حلاً بديلاً كاملاً، ركّز فقط على النقد المحدد.',
      upstreamOutputs: { proposal: proposal.output },
    });
    repos.council.appendRound(sessionId, 'critique', input.criticAgentId, critique.output, critique.providerUsed, critique.modelUsed);

    // Round 3 — Rebuttal
    const rebuttal = await runAgentTask(input.proposerAgentId, {
      ...ctxBase,
      agentId: input.proposerAgentId,
      taskNodeId: 'rebuttal',
      taskDescription: 'مهمتك تحديداً الآن: رد على نقد زميلك لاقتراحك — دافع عن النقاط الصحيحة، وعدّل اقتراحك بما يعالج أي ثغرة حقيقية أثارها.',
      upstreamOutputs: { proposal: proposal.output, critique: critique.output },
    });
    repos.council.appendRound(sessionId, 'rebuttal', input.proposerAgentId, rebuttal.output, rebuttal.providerUsed, rebuttal.modelUsed);

    // Round 4 — independent Verification (existing Verifier module, hardcoded to anthropic — pre-existing, documented limitation, not addressed by this slice)
    const verdict = await Verifier.verify(input.topic, rebuttal.output);
    repos.council.appendRound(
      sessionId,
      'verification',
      null,
      verdict.ran ? `verdict=${verdict.verdict}; issues=${JSON.stringify(verdict.issues)}` : 'verification did not run (judge provider not configured)',
      'anthropic',
      null
    );

    // Round 5 — Supervisor Synthesis
    const verifierNote = verdict.ran && verdict.issues.length ? `\n\nملاحظات مراجع مستقل (${verdict.verdict}): ${verdict.issues.join('؛ ')}` : '';
    const synthesis = await runAgentTask(supervisorAgentId, {
      ...ctxBase,
      agentId: supervisorAgentId,
      taskNodeId: 'synthesis',
      taskDescription:
        'بناءً على المناظرة الكاملة (اقتراح ← نقد ← رد)، اصغ الحل النهائي الأمتن: ادمج أفضل ما في الاقتراح الأصلي مع معالجة كل ثغرة حقيقية كشفها النقد. كن حاسماً وعملياً، ونظّم ردّك بعناوين واضحة.' +
        verifierNote,
      upstreamOutputs: { proposal: proposal.output, critique: critique.output, rebuttal: rebuttal.output },
    });
    repos.council.appendRound(sessionId, 'synthesis', supervisorAgentId, synthesis.output, synthesis.providerUsed, synthesis.modelUsed);

    repos.council.complete(sessionId, synthesis.output, verdict.ran ? verdict.verdict : 'unavailable', verdict.ran ? verdict.issues.length : null);
  } catch (e) {
    const err = e as Error;
    if (signal.aborted) {
      repos.council.fail(sessionId, 'تم إلغاء الجلسة يدويًا.');
      logger.info('Council session cancelled', { sessionId });
      return;
    }
    repos.council.fail(sessionId, err.message);
    logger.warn('Council session failed', { sessionId, message: err.message });
  }
}

// ---------------------------------------------------------------------
// situation_room (Slice 4) — N parallel specialists -> supervisor tension
// analysis + per-agent follow-up -> targeted round 2 -> verification ->
// unified synthesis. See councilTypes.ts's file doc comment for the exact
// frontend pattern this ports (runSituationRoom()). The humanitarian-veto
// review pass is explicitly NOT ported in this slice — see
// PHASE3_SLICE4_REPORT.md.
// ---------------------------------------------------------------------

async function startSituationRoom(input: Extract<CreateCouncilSessionInput, { mode: 'situation_room' }>, gwCtx: GatewayContext): Promise<{ sessionId: string }> {
  const ids = input.participantAgentIds;
  if (!Array.isArray(ids) || ids.length < 2) throw new Error('غرفة العمليات تحتاج اختيار خبيرين متخصصين على الأقل.');
  if (new Set(ids).size !== ids.length) throw new Error('لا يمكن تكرار نفس الوكيل أكثر من مرة ضمن المشاركين.');
  const supervisorAgentId = resolveSupervisorId(input.supervisorAgentId);
  if (ids.includes(supervisorAgentId)) throw new Error('لا يمكن أن يكون المشرف نفسه أحد المشاركين المتخصصين.');
  for (const id of ids) {
    if (!AgentRegistry.has(id)) throw new Error(`وكيل متخصص غير معروف: ${id}`);
  }
  if (input.humanitarianVeto === true && !resolveVetoReviewerAgentId()) {
    throw new Error('تم طلب مراجعة الفيتو الإنساني لكن لا يوجد وكيل humanitarian_aid أو conflict_resolution مسجّل على هذا الخادم.');
  }

  const id = `council_${Date.now()}_${randomUUID().slice(0, 8)}`;
  getRepos().council.create({
    id,
    mode: 'situation_room',
    topic: input.topic,
    participantAgentIds: ids,
    supervisorAgentId,
  });

  const controller = new AbortController();
  abortControllers.set(id, controller);
  void executeSituationRoom(id, input.topic, ids, supervisorAgentId, gwCtx, controller.signal, input.humanitarianVeto === true).finally(() => abortControllers.delete(id));
  return { sessionId: id };
}

interface SpecialistTurn {
  agentId: string;
  output: string;
}

/** Mirrors the frontend's own tolerance for partial round failures (Promise.allSettled, continue with whoever succeeded) rather than an all-or-nothing Promise.all — a genuinely different, deliberate reliability choice from cross_exam's strict sequential chain, ported faithfully rather than simplified away. */
async function runParallelSpecialists(
  ids: string[],
  buildTask: (agentId: string) => { taskNodeId: string; taskDescription: string; upstreamOutputs: Record<string, string> },
  ctxBase: { missionId: string; gwCtx: GatewayContext; signal: AbortSignal }
): Promise<SpecialistTurn[]> {
  const settled = await Promise.allSettled(
    ids.map((agentId) => {
      const t = buildTask(agentId);
      return runAgentTask(agentId, { ...ctxBase, agentId, ...t });
    })
  );
  const results: SpecialistTurn[] = [];
  settled.forEach((r, i) => {
    if (r.status === 'fulfilled') results.push({ agentId: ids[i]!, output: r.value.output });
    else logger.warn('Situation room: a specialist turn failed, continuing with the rest', { agentId: ids[i], message: (r.reason as Error)?.message });
  });
  return results;
}

function parseSupervisorAnalysis(raw: string): { tensionSummary: string; followups: Record<string, string> } {
  try {
    const match = raw.match(/\{[\s\S]*\}/);
    const parsed = JSON.parse(match ? match[0] : raw) as { tension_summary?: string; followups?: Record<string, string> };
    return { tensionSummary: parsed.tension_summary ?? '', followups: parsed.followups ?? {} };
  } catch {
    return { tensionSummary: '', followups: {} };
  }
}

/** Ported EXACTLY from the frontend's parseVetoRejectedItems() (same regex, same group order) so a raw review generated by either the frontend's client-side flow or this server-side flow parses identically. */
function parseVetoRejectedItems(reviewText: string): { item: string; reason: string }[] {
  if (!reviewText) return [];
  const items: { item: string; reason: string }[] = [];
  const re = /❌\s*مرفوض:\s*(.+?)\s*—\s*السبب:\s*(.+)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(reviewText))) {
    items.push({ item: m[1]!.trim(), reason: m[2]!.trim() });
  }
  return items;
}

/** Same fallback precedence as the frontend: humanitarian_aid first, conflict_resolution second. Returns null (not a throw) when neither exists, so the caller can decide how to degrade — see the humanitarianVeto branch in executeSituationRoom(), which fails the whole session rather than silently skipping the review a caller explicitly asked for. */
function resolveVetoReviewerAgentId(): string | null {
  if (AgentRegistry.has('humanitarian_aid')) return 'humanitarian_aid';
  if (AgentRegistry.has('conflict_resolution')) return 'conflict_resolution';
  return null;
}

async function executeSituationRoom(
  sessionId: string,
  topic: string,
  participantIds: string[],
  supervisorAgentId: string,
  gwCtx: GatewayContext,
  signal: AbortSignal,
  humanitarianVeto: boolean
): Promise<void> {
  const repos = getRepos();
  const ctxBase = { missionId: sessionId, gwCtx, signal };

  try {
    // Round 1 — independent opinions, genuinely in parallel
    const round1 = await runParallelSpecialists(participantIds, () => ({ taskNodeId: 'round1', taskDescription: topic, upstreamOutputs: {} }), ctxBase);
    for (const r of round1) repos.council.appendRound(sessionId, 'round1_opinion', r.agentId, r.output, null, null);
    if (round1.length === 0) {
      repos.council.fail(sessionId, 'فشل كل المشاركين في الجولة الأولى — لا يمكن المتابعة.');
      return;
    }
    const round1Combined = round1.map((r) => `[${r.agentId}]: ${r.output}`).join('\n\n');

    // Supervisor analyzes Round 1: tensions + targeted per-agent follow-ups
    const analysisRaw = await runAgentTask(supervisorAgentId, {
      ...ctxBase,
      agentId: supervisorAgentId,
      taskNodeId: 'supervisor_analysis',
      taskDescription:
        'أنت تدير "غرفة عمليات" بين عدة خبراء حول موضوع المستخدم. اقرأ آراءهم الأولية أدناه، وحدد: (1) أي تعارض أو نقطة تحتاج توضيح أو تكامل بين آرائهم، (2) سؤال متابعة قصير ومحدد لكل خبير (بمعرّفه) ليتعمّق أو يعلّق على رأي غيره. ' +
        `أجب حصراً بصيغة JSON صالحة بدون أي نص إضافي، بهذا الشكل بالضبط: {"tension_summary": "...", "followups": {${participantIds.map((id) => `"${id}": "..."`).join(', ')}}}\n\nالموضوع الأصلي: ${topic}\n\nآراء الجولة الأولى:\n${round1Combined}`,
      upstreamOutputs: {},
    });
    repos.council.appendRound(sessionId, 'supervisor_analysis', supervisorAgentId, analysisRaw.output, analysisRaw.providerUsed, analysisRaw.modelUsed);
    const analysis = parseSupervisorAnalysis(analysisRaw.output);

    // Round 2 — each specialist answers THEIR OWN targeted follow-up, seeing every round-1 opinion
    const round2 = await runParallelSpecialists(
      participantIds,
      (agentId) => ({
        taskNodeId: 'round2',
        taskDescription:
          `الموضوع الأصلي: ${topic}\n\nآراء كل الخبراء في الجولة الأولى:\n${round1Combined}\n\n` +
          `سؤال المشرف الموجّه لك تحديداً: ${analysis.followups[agentId] ?? 'راجع آراء بقية الخبراء أعلاه وأضف أي تعديل أو تأكيد على رأيك الأولي إن وجد.'}`,
        upstreamOutputs: {},
      }),
      ctxBase
    );
    for (const r of round2) repos.council.appendRound(sessionId, 'round2_followup', r.agentId, r.output, null, null);
    const round2Combined = round2.map((r) => `[${r.agentId}]: ${r.output}`).join('\n\n');

    // Optional humanitarian-veto review (Slice 5b) — a real server-side
    // port of the frontend's opt-in review pass. Runs AFTER round 2 (so
    // the reviewer sees the fully-developed discussion, not just initial
    // opinions) and BEFORE synthesis (so its findings can actually gate
    // what the final report is allowed to recommend).
    let vetoInstruction = '';
    if (humanitarianVeto) {
      const reviewerAgentId = resolveVetoReviewerAgentId()!; // already validated to exist in startSituationRoom()
      const vetoReview = await runAgentTask(reviewerAgentId, {
        ...ctxBase,
        agentId: reviewerAgentId,
        taskNodeId: 'humanitarian_veto',
        taskDescription:
          'راجع النقاش الكامل أدناه من منظورك الإنساني/الأخلاقي البحت. لأي بند أو توصية تراها ضارة أو غير مقبولة إنسانياً، اكتب سطراً بهذه الصيغة الحرفية بالضبط (لكل بند مرفوض سطر منفصل): "❌ مرفوض: <وصف مختصر للبند> — السبب: <السبب>". إن لم يكن هناك أي بند مرفوض، اذكر ذلك صراحة بدون استخدام هذه الصيغة.\n\n' +
          `الموضوع: ${topic}\n\nالجولة 1:\n${round1Combined}\n\nالجولة 2:\n${round2Combined}`,
        upstreamOutputs: {},
      });
      repos.council.appendRound(sessionId, 'humanitarian_veto', reviewerAgentId, vetoReview.output, vetoReview.providerUsed, vetoReview.modelUsed);

      const rejectedItems = parseVetoRejectedItems(vetoReview.output);
      // Real integration with pre-existing, previously-uncalled infrastructure (routes/legacy/auditVeto.ts + AuditRepo.logVeto()) — a direct repo call server-side rather than an HTTP round-trip to itself, since this now runs in the same process that owns that table.
      repos.audit.logVeto(topic, reviewerAgentId, rejectedItems, vetoReview.output);

      if (rejectedItems.length) {
        vetoInstruction =
          '\n\nإلزامي: لا تُدرج أي بند وُسم بـ"❌ مرفوض" في مراجعة الفيتو الإنساني التالية ضمن الحل/التوصية النهائية تحت أي صياغة، حتى لو بدا مفيداً من زوايا أخرى. أضف قسماً منفصلاً وواضحاً بعنوان "🕊️ بنود مستبعدة (فيتو إنساني)" يسرد كل بند مرفوض وسببه كما ورد أدناه حرفياً:\n\n' +
          vetoReview.output;
      }
    }

    // Independent Verification (same pre-existing anthropic-only limitation as cross_exam)
    const verdict = await Verifier.verify(topic, round2Combined || round1Combined);
    repos.council.appendRound(
      sessionId,
      'verification',
      null,
      verdict.ran ? `verdict=${verdict.verdict}; issues=${JSON.stringify(verdict.issues)}` : 'verification did not run (judge provider not configured)',
      'anthropic',
      null
    );

    // Final unified synthesis
    const verifierNote = verdict.ran && verdict.issues.length ? `\n\nملاحظات مراجع مستقل (${verdict.verdict}): ${verdict.issues.join('؛ ')}` : '';
    const synthesis = await runAgentTask(supervisorAgentId, {
      ...ctxBase,
      agentId: supervisorAgentId,
      taskNodeId: 'synthesis',
      taskDescription:
        'بناءً على نقاش غرفة العمليات الكامل (جولتين من الخبراء المشاركين فعلاً)، اكتب تقريراً تنفيذياً واحداً موحداً بأقسام واضحة حسب تخصصات الخبراء الذين شاركوا فعلاً، ثم قسم أخير بعنوان "التوصية التنفيذية" يلخص الموقف بخطوات عملية قابلة للتنفيذ. لا تخترع تخصصات لم تشارك.' +
        verifierNote +
        vetoInstruction,
      upstreamOutputs: { round1: round1Combined, round2: round2Combined },
    });
    repos.council.appendRound(sessionId, 'synthesis', supervisorAgentId, synthesis.output, synthesis.providerUsed, synthesis.modelUsed);

    repos.council.complete(sessionId, synthesis.output, verdict.ran ? verdict.verdict : 'unavailable', verdict.ran ? verdict.issues.length : null);
  } catch (e) {
    const err = e as Error;
    if (signal.aborted) {
      repos.council.fail(sessionId, 'تم إلغاء الجلسة يدويًا.');
      logger.info('Council session cancelled', { sessionId });
      return;
    }
    repos.council.fail(sessionId, err.message);
    logger.warn('Council session failed', { sessionId, message: err.message });
  }
}

export function getCouncilSession(id: string): CouncilSession | null {
  return getRepos().council.get(id);
}
