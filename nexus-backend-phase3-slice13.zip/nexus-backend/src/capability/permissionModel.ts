import type { ProviderId } from '../config/providerRegistry.js';
import { CapabilityGraph } from './capabilityGraph.js';
import { BudgetGuard } from '../orchestrator/budget.js';
import { Errors } from '../core/errors.js';
import { auditSecurityEvent } from '../security/audit.js';

export interface GatewayContext {
  authenticated: boolean;
  clientKey: string; // gateway key or IP, used for rate limiting/ownership scoping
  projectId: string | null;
  userId: string | null;
}

/**
 * The one place a request's "am I actually allowed to do this" question
 * gets answered, combining: (1) CapabilityGraph's provider/tool
 * eligibility, (2) budget status, (3) gateway auth context. Every route
 * that dispatches to a tool or an image-bearing chat call goes through
 * this — not just the fast auto-route path, which was the gap the
 * frontend audit found in the old CapabilityGraph usage.
 */
export const PermissionModel = {
  assertToolAllowed(providerId: ProviderId, toolName: string, _ctx: GatewayContext): void {
    const check = CapabilityGraph.checkToolEligible(providerId, toolName);
    if (!check.allowed) {
      auditSecurityEvent('warn', 'Tool permission denied', { providerId, toolName, reason: check.reason });
      throw Errors.toolPermissionDenied(check.reason!);
    }
  },

  assertImageAllowed(providerId: ProviderId, _ctx: GatewayContext): void {
    const check = CapabilityGraph.checkImageEligible(providerId);
    if (!check.allowed) throw Errors.capabilityDenied(check.reason!);
  },

  assertEmbeddingAllowed(providerId: ProviderId, _ctx: GatewayContext): void {
    const check = CapabilityGraph.checkEmbeddingEligible(providerId);
    if (!check.allowed) throw Errors.capabilityDenied(check.reason!);
  },

  assertBudgetAllowed(): void {
    BudgetGuard.assertWithinBudget();
  },
};
