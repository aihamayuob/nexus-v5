import type { IncomingMessage } from 'node:http';
import { ServerConfig } from '../../config/env.js';
import { Errors } from '../../core/errors.js';

export async function readJsonBody<T = unknown>(req: IncomingMessage, maxBytes = ServerConfig.maxBodyBytes): Promise<T> {
  const chunks: Buffer[] = [];
  let total = 0;
  for await (const chunk of req) {
    total += (chunk as Buffer).length;
    if (total > maxBytes) {
      req.destroy();
      throw Errors.payloadTooLarge();
    }
    chunks.push(chunk as Buffer);
  }
  if (total === 0) return {} as T;
  const text = Buffer.concat(chunks).toString('utf-8');
  try {
    return JSON.parse(text) as T;
  } catch {
    throw Errors.validation('جسم الطلب ليس JSON صالحاً.');
  }
}
