import type { Router, RouteContext } from '../../gateway/router.js';
import { readJsonBody } from '../../gateway/middleware/bodyLimit.js';
import { runBenchmarkSuiteAndCompare } from '../../evaluation/benchmarkRunner.js';
import { getRepos } from '../../persistence/repos.js';
import { Errors } from '../../core/errors.js';

export function registerEvaluationRoutes(router: Router) {
  router.post('/v2/evaluation/run', async (ctx: RouteContext) => {
    const body = await readJsonBody<{ releaseLabel?: string }>(ctx.req);
    const releaseLabel = body.releaseLabel || `run_${new Date().toISOString()}`;
    const { results, summary, regression, runId } = await runBenchmarkSuiteAndCompare(releaseLabel);
    ctx.res.writeHead(200, { 'Content-Type': 'application/json' });
    ctx.res.end(JSON.stringify({ runId, releaseLabel, results, summary, regression }));
  });

  router.get('/v2/evaluation/latest', async (ctx: RouteContext) => {
    const latest = getRepos().benchmarkRuns.latest();
    if (!latest) throw Errors.notFound('لا توجد نتائج تقييم بعد — شغّل POST /v2/evaluation/run أولاً.');
    ctx.res.writeHead(200, { 'Content-Type': 'application/json' });
    ctx.res.end(JSON.stringify(latest));
  });

  router.get('/v2/evaluation/history', async (ctx: RouteContext) => {
    const limit = Math.min(50, Number(ctx.query.get('limit') || '20') || 20);
    const runs = getRepos().benchmarkRuns.list(limit);
    ctx.res.writeHead(200, { 'Content-Type': 'application/json' });
    ctx.res.end(JSON.stringify({ runs }));
  });
}
