import { runPlan } from '../src/runtime/executor.js';
import { DEFAULT_RUNTIME_CONFIG } from '../src/runtime/types.js';
import type { RuntimeEvent } from '../src/runtime/types.js';
import { createMockAdapter } from './mockAdapter.js';

let passed = 0, failed = 0;
function ok(cond: boolean, label: string) {
  if (cond) { passed++; console.log(`  ok   ${label}`); }
  else { failed++; console.log(`  FAIL ${label}`); }
}

async function collectEvents(gen: AsyncGenerator<RuntimeEvent>): Promise<RuntimeEvent[]> {
  const out: RuntimeEvent[] = [];
  for await (const ev of gen) out.push(ev);
  return out;
}

async function run() {
  console.log('Executor: two independent tasks actually run in parallel, not sequentially');
  {
    const callTimestamps: Record<string, number> = {};
    const { adapter } = createMockAdapter('anthropic', async (call) => {
      callTimestamps[call.userContent] = Date.now();
      await new Promise((r) => setTimeout(r, 150)); // simulate a slow LLM call
      return `result for ${call.userContent}`;
    });
    const plan = {
      goal: 'test parallelism',
      tasks: [
        { id: 'a', description: 'task A', dependsOn: [] },
        { id: 'b', description: 'task B', dependsOn: [] },
      ],
    };
    const start = Date.now();
    const events = await collectEvents(runPlan(plan, { adapters: new Map([['anthropic', adapter]]), config: DEFAULT_RUNTIME_CONFIG }, new AbortController().signal));
    const elapsed = Date.now() - start;
    const done = events.filter((e) => e.type === 'task_done');
    ok(done.length === 2, 'both independent tasks completed');
    // If run sequentially, this would take >300ms (150ms each + synthesis).
    // Running in parallel, task A and B overlap, so total should be well
    // under 150ms*2 for JUST the two tasks (synthesis adds its own time on top).
    const aStart = callTimestamps['task A'];
    const bStart = callTimestamps['task B'];
    const startGapMs = Math.abs(aStart - bStart);
    ok(startGapMs < 50, `tasks A and B started within ${startGapMs}ms of each other (genuinely concurrent, not sequential)`);
    console.log(`       (total elapsed: ${elapsed}ms, start gap: ${startGapMs}ms)`);
  }

  console.log('\nExecutor: a dependent task only starts AFTER its dependency reaches done, and sees its output as context');
  {
    const order: string[] = [];
    const { adapter } = createMockAdapter('anthropic', async (call) => {
      order.push(call.userContent);
      if (call.userContent === 'produce a number') return '42';
      // The dependent task's system prompt should include the dependency's output as context.
      if (call.userContent === 'use the number') {
        return call.system?.includes('42') ? 'used 42 correctly' : 'MISSING CONTEXT — BUG';
      }
      return 'ok';
    });
    const plan = {
      goal: 'test dependency ordering',
      tasks: [
        { id: 'producer', description: 'produce a number', dependsOn: [] },
        { id: 'consumer', description: 'use the number', dependsOn: ['producer'] },
      ],
    };
    const events = await collectEvents(runPlan(plan, { adapters: new Map([['anthropic', adapter]]), config: { ...DEFAULT_RUNTIME_CONFIG, reflectionEnabled: false } }, new AbortController().signal));
    const producerIdx = order.indexOf('produce a number');
    const consumerIdx = order.indexOf('use the number');
    ok(producerIdx !== -1 && consumerIdx !== -1 && producerIdx < consumerIdx, 'producer task genuinely ran before consumer task');
    const consumerDone = events.find((e) => e.type === 'task_done' && e.taskId === 'consumer');
    ok(consumerDone?.type === 'task_done' && consumerDone.output === 'used 42 correctly', 'dependent task correctly received the producer\'s actual output as context');
  }

  console.log('\nExecutor: a task that fails all retries causes its dependent to be SKIPPED, not silently run with missing context');
  {
    const { adapter } = createMockAdapter('anthropic', async (call) => {
      if (call.userContent === 'will always fail') throw new Error('simulated permanent failure');
      return 'should never run';
    });
    const plan = {
      goal: 'test failure propagation',
      tasks: [
        { id: 'failer', description: 'will always fail', dependsOn: [] },
        { id: 'dependent', description: 'depends on failer', dependsOn: ['failer'] },
      ],
    };
    const events = await collectEvents(runPlan(plan, { adapters: new Map([['anthropic', adapter]]), config: { ...DEFAULT_RUNTIME_CONFIG, maxRetriesPerTask: 1, reflectionEnabled: false } }, new AbortController().signal));
    const failedEvent = events.find((e) => e.type === 'task_failed' && e.taskId === 'failer');
    const skippedEvent = events.find((e) => e.type === 'task_skipped' && e.taskId === 'dependent');
    ok(!!failedEvent, 'failer task correctly marked as failed after exhausting retries');
    ok(!!skippedEvent, 'dependent task correctly SKIPPED rather than run with missing/broken context');
    const retryEvents = events.filter((e) => e.type === 'task_retry' && e.taskId === 'failer');
    ok(retryEvents.length === 1, `exactly 1 retry attempted (maxRetriesPerTask=1), got ${retryEvents.length}`);
  }

  console.log('\nExecutor: transient failure recovers via retry (task eventually succeeds, not marked failed)');
  {
    let attemptCount = 0;
    const { adapter } = createMockAdapter('anthropic', async () => {
      attemptCount++;
      if (attemptCount < 3) throw new Error('transient network blip');
      return 'succeeded on 3rd attempt';
    });
    const plan = { goal: 'test retry recovery', tasks: [{ id: 'flaky', description: 'flaky task', dependsOn: [] }] };
    const events = await collectEvents(runPlan(plan, { adapters: new Map([['anthropic', adapter]]), config: { ...DEFAULT_RUNTIME_CONFIG, maxRetriesPerTask: 3, reflectionEnabled: false } }, new AbortController().signal));
    const doneEvent = events.find((e) => e.type === 'task_done' && e.taskId === 'flaky');
    ok(doneEvent?.type === 'task_done' && doneEvent.output === 'succeeded on 3rd attempt', 'task recovered and succeeded after 2 transient failures');
    ok(!events.some((e) => e.type === 'task_failed'), 'task is NOT marked failed since it ultimately succeeded');
  }

  console.log('\nExecutor: reflection "revise" verdict triggers exactly one revision attempt with the critique fed back');
  {
    let taskCallCount = 0;
    const { adapter } = createMockAdapter('anthropic', async (call) => {
      if (call.system?.includes('مراجع صارم')) {
        // this is the reflection call itself
        return taskCallCount === 1 ? '{"verdict":"revise","reason":"لم يذكر السعر"}' : '{"verdict":"pass"}';
      }
      taskCallCount++;
      if (taskCallCount === 1) return 'إجابة ناقصة بدون سعر';
      return call.system?.includes('لم يذكر السعر') ? 'إجابة محسّنة تتضمن السعر' : 'إجابة أخرى';
    });
    const plan = { goal: 'test reflection', tasks: [{ id: 'priced', description: 'اذكر السعر', dependsOn: [] }] };
    const events = await collectEvents(runPlan(plan, { adapters: new Map([['anthropic', adapter]]), config: { ...DEFAULT_RUNTIME_CONFIG, reflectionEnabled: true, maxRetriesPerTask: 1 } }, new AbortController().signal));
    const reflectionEvents = events.filter((e) => e.type === 'task_reflection');
    const doneEvent = events.find((e) => e.type === 'task_done' && e.taskId === 'priced');
    ok(reflectionEvents.length === 1, `exactly one reflection pass ran, got ${reflectionEvents.length}`);
    ok((reflectionEvents[0] as any).verdict === 'revise', 'reflection correctly flagged the first (incomplete) attempt for revision');
    ok(doneEvent?.type === 'task_done' && doneEvent.output === 'إجابة محسّنة تتضمن السعر', 'final output is the REVISED answer, incorporating the critique — not the original flawed one');
  }

  console.log('\nExecutor: final synthesis combines only successful task outputs into one coherent answer');
  {
    const { adapter } = createMockAdapter('anthropic', async (call) => {
      if (call.system?.includes('اجمع نتائج المهام')) return 'التوليف النهائي يجمع أ و ب معاً';
      if (call.userContent === 'task a') return 'نتيجة أ';
      if (call.userContent === 'task b') return 'نتيجة ب';
      return 'unexpected';
    });
    const plan = {
      goal: 'test synthesis',
      tasks: [{ id: 'a', description: 'task a', dependsOn: [] }, { id: 'b', description: 'task b', dependsOn: [] }],
    };
    const events = await collectEvents(runPlan(plan, { adapters: new Map([['anthropic', adapter]]), config: { ...DEFAULT_RUNTIME_CONFIG, reflectionEnabled: false } }, new AbortController().signal));
    const planDone = events.find((e) => e.type === 'plan_done');
    ok(planDone?.type === 'plan_done' && planDone.finalOutput === 'التوليف النهائي يجمع أ و ب معاً', 'plan_done carries the synthesized final answer');
    ok(events[0].type === 'plan_start', 'first event is plan_start');
    ok(events[events.length - 1].type === 'plan_done', 'last event is plan_done');
  }

  console.log('\nExecutor: maxConcurrency actually bounds simultaneous execution');
  {
    let concurrentCount = 0;
    let maxObservedConcurrency = 0;
    const { adapter } = createMockAdapter('anthropic', async () => {
      concurrentCount++;
      maxObservedConcurrency = Math.max(maxObservedConcurrency, concurrentCount);
      await new Promise((r) => setTimeout(r, 80));
      concurrentCount--;
      return 'done';
    });
    const plan = {
      goal: 'test concurrency limit',
      tasks: Array.from({ length: 6 }, (_, i) => ({ id: `t${i}`, description: `task ${i}`, dependsOn: [] })),
    };
    await collectEvents(runPlan(plan, { adapters: new Map([['anthropic', adapter]]), config: { ...DEFAULT_RUNTIME_CONFIG, maxConcurrency: 2, reflectionEnabled: false } }, new AbortController().signal));
    ok(maxObservedConcurrency <= 2, `max observed concurrency was ${maxObservedConcurrency}, expected <= 2`);
    ok(maxObservedConcurrency > 1, 'at least some real parallelism happened (not accidentally fully sequential)');
  }

  console.log(`\n${passed} passed, ${failed} failed`);
  if (failed > 0) process.exit(1);
}
run().catch((e) => { console.error('FATAL:', e); process.exit(1); });
