import { AccountsStore } from '../src/accounts/store.js';

let passed = 0, failed = 0;
function ok(cond: boolean, label: string) {
  if (cond) { passed++; console.log(`  ok   ${label}`); }
  else { failed++; console.log(`  FAIL ${label}`); }
}

console.log('users: findOrCreateUserByGoogle is idempotent for the same google_sub');
{
  const store = new AccountsStore(':memory:');
  const u1 = store.findOrCreateUserByGoogle('sub-1', 'a@b.com', 'Alice', null);
  const u2 = store.findOrCreateUserByGoogle('sub-1', 'a@b.com', 'Alice', null);
  ok(u1.id === u2.id, 'same google_sub returns the SAME user, not a duplicate');
}

console.log('\nsessions: valid session resolves to the correct user, expired session does not');
{
  const store = new AccountsStore(':memory:');
  const user = store.findOrCreateUserByGoogle('sub-2', 'b@c.com', 'Bob', null);
  store.createSession(user.id, 'hash-valid', 60_000); // 1 minute TTL
  store.createSession(user.id, 'hash-expired', -1000); // already expired
  ok(store.getSessionUser('hash-valid')?.id === user.id, 'valid session resolves correctly');
  ok(store.getSessionUser('hash-expired') === null, 'expired session returns null (and is cleaned up)');
  ok(store.getSessionUser('hash-never-existed') === null, 'unknown session hash returns null');
}

console.log('\nworkspaces: creating a workspace automatically makes the creator its owner member');
{
  const store = new AccountsStore(':memory:');
  const user = store.findOrCreateUserByGoogle('sub-3', 'c@d.com', 'Carol', null);
  const ws = store.createWorkspace('My Workspace', user.id);
  const membership = store.getMembership(ws.id, user.id);
  ok(membership?.role === 'owner', 'creator is automatically the owner');
  ok(ws.plan === 'free' && ws.planStatus === 'active', 'new workspace defaults to free/active');
}

console.log('\nworkspaces: listWorkspacesForUser only returns workspaces the user actually belongs to');
{
  const store = new AccountsStore(':memory:');
  const alice = store.findOrCreateUserByGoogle('sub-4', 'alice@x.com', 'Alice', null);
  const bob = store.findOrCreateUserByGoogle('sub-5', 'bob@x.com', 'Bob', null);
  const wsA = store.createWorkspace('Alice Workspace', alice.id);
  store.createWorkspace('Bob Workspace', bob.id);
  const aliceWorkspaces = store.listWorkspacesForUser(alice.id);
  ok(aliceWorkspaces.length === 1 && aliceWorkspaces[0].id === wsA.id, 'Alice only sees her own workspace, not Bob\'s');
}

console.log('\nmembers: addMember + listMembers + removeMember round-trip correctly');
{
  const store = new AccountsStore(':memory:');
  const owner = store.findOrCreateUserByGoogle('sub-6', 'owner@x.com', 'Owner', null);
  const member = store.findOrCreateUserByGoogle('sub-7', 'member@x.com', 'Member', null);
  const ws = store.createWorkspace('Team', owner.id);
  store.addMember(ws.id, member.id, 'member');
  const members = store.listMembers(ws.id);
  ok(members.length === 2, 'both owner and new member listed');
  ok(members.some((m) => m.userId === member.id && m.role === 'member'), 'new member has correct role and email joined in');
  store.removeMember(ws.id, member.id);
  ok(store.listMembers(ws.id).length === 1, 'member correctly removed');
}

console.log('\nmembers: addMember upserts role on conflict (used for role changes)');
{
  const store = new AccountsStore(':memory:');
  const owner = store.findOrCreateUserByGoogle('sub-8', 'o2@x.com', 'O', null);
  const member = store.findOrCreateUserByGoogle('sub-9', 'm2@x.com', 'M', null);
  const ws = store.createWorkspace('Team2', owner.id);
  store.addMember(ws.id, member.id, 'viewer');
  store.addMember(ws.id, member.id, 'admin'); // "role change" is really just addMember again
  ok(store.getMembership(ws.id, member.id)?.role === 'admin', 'role correctly updated via upsert, not duplicated');
}

console.log('\ninvites: create, lookup by token hash, and accept correctly');
{
  const store = new AccountsStore(':memory:');
  const owner = store.findOrCreateUserByGoogle('sub-10', 'o3@x.com', 'O', null);
  const ws = store.createWorkspace('Team3', owner.id);
  const invite = store.createInvite(ws.id, 'newperson@x.com', 'member', owner.id, 'invite-token-hash', 60_000);
  const found = store.getInviteByTokenHash('invite-token-hash');
  ok(found?.email === 'newperson@x.com', 'invite found by token hash');
  ok(found?.acceptedAt === null, 'not yet accepted');
  store.acceptInvite(invite.id);
  ok(store.getInviteByTokenHash('invite-token-hash')?.acceptedAt !== null, 'accepted_at set after acceptance');
}

console.log('\napi keys: create, lookup by hash, revoked keys are not returned');
{
  const store = new AccountsStore(':memory:');
  const owner = store.findOrCreateUserByGoogle('sub-11', 'o4@x.com', 'O', null);
  const ws = store.createWorkspace('Team4', owner.id);
  const key = store.createApiKey(ws.id, 'CI key', 'key-hash-abc', 'nxk_live_abc…', owner.id);
  ok(store.getApiKeyByHash('key-hash-abc')?.id === key.id, 'key found by hash');
  store.revokeApiKey(key.id);
  ok(store.getApiKeyByHash('key-hash-abc') === null, 'revoked key no longer resolves (even though the row still exists for audit purposes)');
}

console.log('\nbilling: updateWorkspaceBilling and findWorkspaceByPaddleSubscription round-trip correctly');
{
  const store = new AccountsStore(':memory:');
  const owner = store.findOrCreateUserByGoogle('sub-12', 'o5@x.com', 'O', null);
  const ws = store.createWorkspace('Team5', owner.id);
  store.updateWorkspaceBilling(ws.id, 'pro', 'active', 'sub_paddle_123', 'cus_paddle_456');
  const updated = store.getWorkspace(ws.id);
  ok(updated?.plan === 'pro' && updated?.planStatus === 'active', 'plan/status updated');
  const foundBySub = store.findWorkspaceByPaddleSubscription('sub_paddle_123');
  ok(foundBySub?.id === ws.id, 'workspace findable by its Paddle subscription id (used by the webhook handler)');
}

console.log('\naudit log: entries recorded and retrievable in reverse-chronological order');
{
  const store = new AccountsStore(':memory:');
  const owner = store.findOrCreateUserByGoogle('sub-13', 'o6@x.com', 'O', null);
  const ws = store.createWorkspace('Team6', owner.id);
  store.logAudit(ws.id, owner.id, 'workspace.create', { name: 'Team6' });
  store.logAudit(ws.id, owner.id, 'members.invite', { email: 'x@y.com' });
  const log = store.listAuditLog(ws.id);
  ok(log.length === 2, 'both entries recorded');
  ok(log[0].action === 'members.invite', 'most recent entry first');
  ok((log[0].details as any).email === 'x@y.com', 'details JSON round-trips correctly');
}

console.log(`\n${passed} passed, ${failed} failed`);
if (failed > 0) process.exit(1);
