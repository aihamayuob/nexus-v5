import type { ChatRequest, ProviderAdapter, StreamEvent, AnthropicStyleResponse } from '../src/providers/types.js';

export interface MockCall {
  system?: string;
  userContent: string;
  timestamp: number;
}

/**
 * A scriptable mock adapter: `responder(call, callIndex)` decides what
 * happens for each call — return a string to succeed with that text,
 * or throw to simulate a failure (used to test the executor's retry
 * logic without any real network dependency).
 */
export function createMockAdapter(
  name: string,
  responder: (call: MockCall, callIndexForThisAdapter: number) => string | Promise<string>
): { adapter: ProviderAdapter; calls: MockCall[] } {
  const calls: MockCall[] = [];

  const adapter: ProviderAdapter = {
    name,
    async *streamChat(req: ChatRequest, signal: AbortSignal): AsyncGenerator<StreamEvent> {
      const userContent = typeof req.messages[req.messages.length - 1]?.content === 'string'
        ? (req.messages[req.messages.length - 1].content as string)
        : JSON.stringify(req.messages[req.messages.length - 1]?.content);
      const call: MockCall = { system: req.system, userContent, timestamp: Date.now() };
      calls.push(call);
      if (signal.aborted) {
        const err = new Error('aborted');
        err.name = 'AbortError';
        throw err;
      }
      const text = await responder(call, calls.length - 1);
      // Emit token-by-token to exercise the same streaming path real adapters use.
      for (const chunk of text.match(/.{1,20}/g) ?? [text]) {
        yield { type: 'token', text: chunk };
      }
      yield { type: 'usage', inputTokens: 10, outputTokens: text.length };
      yield { type: 'done', stopReason: 'end_turn' };
    },
    async chat(req: ChatRequest, signal: AbortSignal): Promise<AnthropicStyleResponse> {
      const userContent = typeof req.messages[req.messages.length - 1]?.content === 'string'
        ? (req.messages[req.messages.length - 1].content as string)
        : JSON.stringify(req.messages[req.messages.length - 1]?.content);
      const call: MockCall = { system: req.system, userContent, timestamp: Date.now() };
      calls.push(call);
      const text = await responder(call, calls.length - 1);
      return { content: [{ type: 'text', text }], stop_reason: 'end_turn', usage: { input_tokens: 10, output_tokens: text.length } };
    },
  };

  return { adapter, calls };
}
