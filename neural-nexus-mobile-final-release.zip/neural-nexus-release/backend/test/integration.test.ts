import { createServer } from 'node:http';
import { createApp } from '../src/app.js';
import { loadEnv } from '../src/config/env.js';
import { createLogger } from '../src/lib/logger.js';

let passed = 0;
let failed = 0;
function ok(cond: boolean, label: string) {
  if (cond) { passed++; console.log(`  ok   ${label}`); }
  else { failed++; console.log(`  FAIL ${label}`); }
}

function sseBody(frames: string[]): string {
  return frames.map((f) => f + '\n\n').join('');
}

async function run() {
  const gatewayKey = 'test-gateway-key-0123456789abcdef0123456789';
  process.env.GATEWAY_API_KEY = gatewayKey;
  process.env.ANTHROPIC_API_KEY = 'fake-anthropic-key';
  process.env.RATE_LIMIT_MAX_REQUESTS = '1000';
  process.env.RATE_LIMIT_WINDOW_MS = '60000';

  const env = loadEnv();
  const log = createLogger('error'); // quiet during tests
  const handler = createApp(env, log);
  const server = createServer((req, res) => { handler(req, res); });

  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve));
  const address = server.address();
  if (typeof address !== 'object' || address === null) throw new Error('server failed to bind');
  const base = `http://127.0.0.1:${address.port}`;

  // Mock the upstream Anthropic call this process's Anthropic adapter will make.
  const realFetch = globalThis.fetch;
  (globalThis as any).fetch = async (url: string, opts?: any) => {
    if (String(url).includes('api.anthropic.com')) {
      return new Response(
        sseBody([
          'event: message_start\ndata: {"type":"message_start","message":{"usage":{"input_tokens":11}}}',
          'event: content_block_delta\ndata: {"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":"Hi"}}',
          'event: content_block_delta\ndata: {"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":" there"}}',
          'event: message_delta\ndata: {"type":"message_delta","delta":{"stop_reason":"end_turn"},"usage":{"output_tokens":3}}',
          'event: message_stop\ndata: {"type":"message_stop"}',
        ]),
        { status: 200 }
      );
    }
    return realFetch(url as any, opts);
  };

  console.log('End-to-end: full streaming chat over a real HTTP connection');
  {
    const res = await fetch(`${base}/api/chat`, {
      method: 'POST',
      headers: { authorization: `Bearer ${gatewayKey}`, 'content-type': 'application/json' },
      body: JSON.stringify({
        provider: 'anthropic',
        model: 'claude-x',
        stream: true,
        messages: [{ role: 'user', content: 'hi' }],
      }),
    });
    ok(res.status === 200, `status 200 (got ${res.status})`);
    ok(res.headers.get('content-type')?.includes('text/event-stream') === true, 'content-type is text/event-stream');

    const text = await res.text();
    const frames = text.trim().split('\n\n');
    ok(frames[0].includes('event: start'), 'first frame is "start" with requestId');
    ok(frames.some((f) => f.includes('event: token') && f.includes('"text":"Hi"')), 'received token frame "Hi"');
    ok(frames.some((f) => f.includes('event: token') && f.includes('"text":" there"')), 'received token frame " there"');
    ok(frames.some((f) => f.includes('event: usage') && f.includes('"inputTokens":11')), 'usage frame has correct input token count');
    ok(frames.some((f) => f.includes('event: done') && f.includes('"stopReason":"end_turn"')), 'done frame present with correct stop reason');

    // Extract the requestId to test resume-after-disconnect below.
    const startData = JSON.parse(frames[0].split('data: ')[1]);
    console.log(`       (requestId: ${startData.requestId})`);

    console.log('End-to-end: resume with afterId replays only the missed tail');
    const resumeRes = await fetch(`${base}/api/chat/resume/${startData.requestId}?afterId=2`, {
      headers: { authorization: `Bearer ${gatewayKey}` },
    });
    ok(resumeRes.status === 200, `resume status 200 (got ${resumeRes.status})`);
    const resumeText = await resumeRes.text();
    const resumeFrames = resumeText.trim().split('\n\n').filter(Boolean);
    ok(!resumeFrames.some((f) => f.includes('"text":"Hi"')), 'replay excludes events at/before afterId');
    ok(resumeFrames.some((f) => f.includes('event: done')), 'replay includes the tail (usage/done) that came after afterId');
  }

  console.log('End-to-end: non-streaming path returns Anthropic-shaped JSON unchanged');
  {
    (globalThis as any).fetch = async (url: string, opts?: any) => {
      if (String(url).includes('api.anthropic.com')) {
        return new Response(
          JSON.stringify({
            content: [{ type: 'text', text: 'plain reply' }],
            stop_reason: 'end_turn',
            usage: { input_tokens: 4, output_tokens: 2 },
          }),
          { status: 200 }
        );
      }
      return realFetch(url as any, opts);
    };
    const res = await fetch(`${base}/api/chat`, {
      method: 'POST',
      headers: { authorization: `Bearer ${gatewayKey}`, 'content-type': 'application/json' },
      body: JSON.stringify({ provider: 'anthropic', model: 'claude-x', messages: [{ role: 'user', content: 'hi' }] }),
    });
    const json = await res.json();
    ok(res.status === 200, 'non-streaming status 200');
    ok(json.content?.[0]?.text === 'plain reply', 'exact pass-through response body the existing frontend already parses');
  }

  console.log('End-to-end: cancellation actually aborts the in-flight upstream fetch');
  {
    let upstreamAborted = false;
    (globalThis as any).fetch = async (url: string, opts: any) => {
      if (String(url).includes('api.anthropic.com')) {
        return new Promise((_, reject) => {
          opts.signal.addEventListener('abort', () => {
            upstreamAborted = true;
            const err = new Error('aborted');
            (err as any).name = 'AbortError';
            reject(err);
          });
        });
      }
      return realFetch(url as any, opts);
    };

    const controller = new AbortController();
    const fetchPromise = fetch(`${base}/api/chat`, {
      method: 'POST',
      signal: controller.signal,
      headers: { authorization: `Bearer ${gatewayKey}`, 'content-type': 'application/json' },
      body: JSON.stringify({ provider: 'anthropic', model: 'claude-x', stream: true, messages: [{ role: 'user', content: 'hi' }] }),
    }).catch(() => null);

    await new Promise((r) => setTimeout(r, 100));
    controller.abort(); // client closes the connection mid-stream
    await fetchPromise;
    await new Promise((r) => setTimeout(r, 100));
    ok(upstreamAborted, 'closing the client connection propagated an abort to the upstream provider fetch (no orphaned billing)');
  }

  globalThis.fetch = realFetch;
  server.close();
  console.log(`\n${passed} passed, ${failed} failed`);
  if (failed > 0) process.exit(1);
}

run();
