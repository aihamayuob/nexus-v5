import { createServer } from 'node:http';
import { createApp } from '../src/app.js';
import { loadEnv } from '../src/config/env.js';
import { createLogger } from '../src/lib/logger.js';

let passed = 0, failed = 0;
function ok(cond: boolean, label: string) {
  if (cond) { passed++; console.log(`  ok   ${label}`); }
  else { failed++; console.log(`  FAIL ${label}`); }
}

async function run() {
  const gatewayKey = 'tools-test-gateway-key-0123456789abcdef01234';
  process.env.GATEWAY_API_KEY = gatewayKey;
  process.env.ANTHROPIC_API_KEY = 'fake-key';
  process.env.RATE_LIMIT_MAX_REQUESTS = '1000';
  process.env.SYNC_DB_PATH = ':memory:';

  const env = loadEnv();
  const log = createLogger('error');
  const handler = createApp(env, log);
  const server = createServer((req, res) => { handler(req, res); });
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve));
  const address = server.address();
  if (typeof address !== 'object' || address === null) throw new Error('bind failed');
  const base = `http://127.0.0.1:${address.port}`;
  const authHeaders = { authorization: `Bearer ${gatewayKey}`, 'content-type': 'application/json' };

  console.log('POST /api/tools/fetch blocks an SSRF attempt end-to-end over real HTTP');
  {
    const res = await fetch(`${base}/api/tools/fetch`, { method: 'POST', headers: authHeaders, body: JSON.stringify({ url: 'http://169.254.169.254/latest/meta-data/' }) });
    const json = await res.json();
    ok(res.status === 400, `status 400 (got ${res.status})`);
    ok(json.error?.code === 'blocked_target', `error code is blocked_target (got ${json.error?.code})`);
  }

  console.log('POST /api/tools/fetch blocks localhost');
  {
    const res = await fetch(`${base}/api/tools/fetch`, { method: 'POST', headers: authHeaders, body: JSON.stringify({ url: 'http://localhost:22/' }) });
    ok(res.status === 400, `status 400 (got ${res.status})`);
  }

  console.log('POST /api/tools/fetch blocks a private LAN address');
  {
    const res = await fetch(`${base}/api/tools/fetch`, { method: 'POST', headers: authHeaders, body: JSON.stringify({ url: 'http://192.168.1.1/admin' }) });
    ok(res.status === 400, `status 400 (got ${res.status})`);
  }

  console.log('POST /api/tools/fetch without auth -> 401 (same gateway auth as everything else)');
  {
    const res = await fetch(`${base}/api/tools/fetch`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ url: 'http://example.com' }) });
    ok(res.status === 401, `status 401 (got ${res.status})`);
  }

  console.log('POST /api/tools/fetch missing url -> 400');
  {
    const res = await fetch(`${base}/api/tools/fetch`, { method: 'POST', headers: authHeaders, body: JSON.stringify({}) });
    ok(res.status === 400, `status 400 (got ${res.status})`);
  }

  server.close();
  console.log(`\n${passed} passed, ${failed} failed`);
  if (failed > 0) process.exit(1);
}
run().catch((e) => { console.error('FATAL:', e); process.exit(1); });
