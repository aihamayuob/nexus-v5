import { createServer } from 'node:http';
import { createHmac } from 'node:crypto';
import { createApp } from '../src/app.js';
import { loadEnv } from '../src/config/env.js';
import { createLogger } from '../src/lib/logger.js';

let passed = 0, failed = 0;
function ok(cond: boolean, label: string) {
  if (cond) { passed++; console.log(`  ok   ${label}`); }
  else { failed++; console.log(`  FAIL ${label}`); }
}

function fakeIdToken(claims: object): string {
  const b64 = (obj: object) => Buffer.from(JSON.stringify(obj)).toString('base64url');
  return `${b64({ alg: 'RS256' })}.${b64(claims)}.sig`;
}

function extractCookie(setCookieHeader: string | null): string {
  if (!setCookieHeader) return '';
  return setCookieHeader.split(';')[0]; // "nexus_session=abc..."
}

async function run() {
  const gatewayKey = 'accounts-test-gateway-key-0123456789abcdef01';
  process.env.GATEWAY_API_KEY = gatewayKey;
  process.env.ANTHROPIC_API_KEY = 'fake-key';
  process.env.RATE_LIMIT_MAX_REQUESTS = '1000';
  process.env.SYNC_DB_PATH = ':memory:';
  process.env.ACCOUNTS_DB_PATH = ':memory:';
  process.env.GOOGLE_CLIENT_ID = 'test-client-id';
  process.env.GOOGLE_CLIENT_SECRET = 'test-client-secret';
  process.env.GOOGLE_REDIRECT_URI = 'http://localhost/api/auth/google/callback';
  process.env.PUBLIC_APP_URL_FOR_REDIRECT = 'http://localhost/app';
  process.env.PADDLE_WEBHOOK_SECRET = 'whsec_test';
  process.env.PADDLE_CLIENT_TOKEN = 'test_client_token';
  process.env.PADDLE_PRICE_ID_PRO = 'pri_test_pro';

  const env = loadEnv();
  const log = createLogger('error');
  const handler = createApp(env, log);
  const server = createServer((req, res) => { handler(req, res); });
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve));
  const address = server.address();
  if (typeof address !== 'object' || address === null) throw new Error('bind failed');
  const base = `http://127.0.0.1:${address.port}`;

  // Mock Google's token endpoint only — everything else hits the real server.
  const realFetch = globalThis.fetch;
  const googleUsers: Record<string, any> = {
    'auth-code-alice': { sub: 'google-alice', email: 'alice@example.com', email_verified: true, name: 'Alice' },
    'auth-code-bob': { sub: 'google-bob', email: 'bob@example.com', email_verified: true, name: 'Bob' },
  };
  (globalThis as any).fetch = async (url: string, opts: any) => {
    if (String(url).includes('oauth2.googleapis.com/token')) {
      const params = new URLSearchParams(opts.body);
      const code = params.get('code')!;
      const claims = googleUsers[code];
      const idToken = fakeIdToken({ iss: 'https://accounts.google.com', aud: 'test-client-id', exp: Math.floor(Date.now() / 1000) + 3600, ...claims });
      return new Response(JSON.stringify({ id_token: idToken, access_token: 'fake' }), { status: 200 });
    }
    return realFetch(url as any, opts);
  };

  console.log('=== Existing gateway-key-only routes are completely unaffected by the accounts layer ===');
  {
    const res = await fetch(`${base}/api/status`, { headers: { authorization: `Bearer ${gatewayKey}` } });
    ok(res.status === 200, `/api/status with gateway key still works (${res.status})`);
    const noAuth = await fetch(`${base}/api/status`);
    ok(noAuth.status === 401, '/api/status without gateway key still correctly 401s');
  }

  console.log('\n=== Google OAuth login flow (Alice) ===');
  let aliceCookie = '';
  {
    const startRes = await fetch(`${base}/api/auth/google/start`, { redirect: 'manual' });
    ok(startRes.status === 302, 'GET /api/auth/google/start redirects (302)');
    const location = startRes.headers.get('location')!;
    const state = new URL(location).searchParams.get('state')!;
    ok(location.includes('accounts.google.com'), 'redirects to Google');
    ok(!!state, 'includes a state param (CSRF protection)');

    const callbackRes = await fetch(`${base}/api/auth/google/callback?code=auth-code-alice&state=${state}`, { redirect: 'manual' });
    ok(callbackRes.status === 302, 'callback redirects back to the app');
    ok(callbackRes.headers.get('location') === 'http://localhost/app', 'redirects to PUBLIC_APP_URL_FOR_REDIRECT');
    aliceCookie = extractCookie(callbackRes.headers.get('set-cookie'));
    ok(aliceCookie.startsWith('nexus_session='), 'session cookie set');
  }

  console.log('\n=== Replaying the same OAuth state a second time fails (one-time use, real CSRF protection) ===');
  {
    const startRes = await fetch(`${base}/api/auth/google/start`, { redirect: 'manual' });
    const state = new URL(startRes.headers.get('location')!).searchParams.get('state')!;
    await fetch(`${base}/api/auth/google/callback?code=auth-code-alice&state=${state}`, { redirect: 'manual' }); // first use, consumes it
    const secondTry = await fetch(`${base}/api/auth/google/callback?code=auth-code-alice&state=${state}`, { redirect: 'manual' });
    const loc = secondTry.headers.get('location') || '';
    ok(loc.includes('auth_error=invalid_state'), 'reusing a consumed state value is rejected');
  }

  console.log('\n=== GET /api/auth/me returns the signed-in user ===');
  {
    const res = await fetch(`${base}/api/auth/me`, { headers: { cookie: aliceCookie } });
    const json = await res.json();
    ok(res.status === 200 && json.email === 'alice@example.com', 'correct user returned for the session');
    const noSession = await fetch(`${base}/api/auth/me`);
    ok(noSession.status === 401, 'no cookie -> 401');
  }

  console.log('\n=== Alice creates a workspace and is automatically its owner ===');
  let workspaceId = '';
  {
    const res = await fetch(`${base}/api/workspaces`, { method: 'POST', headers: { cookie: aliceCookie, 'content-type': 'application/json' }, body: JSON.stringify({ name: 'Aiham Corp' }) });
    const ws = await res.json();
    workspaceId = ws.id;
    ok(res.status === 200 && ws.name === 'Aiham Corp', 'workspace created');

    const membersRes = await fetch(`${base}/api/workspaces/${workspaceId}/members`, { headers: { cookie: aliceCookie } });
    const membersJson = await membersRes.json();
    ok(membersJson.members.length === 1 && membersJson.members[0].role === 'owner', 'Alice is the sole owner member');
  }

  console.log('\n=== Alice invites Bob as a member; Bob (separately authenticated) accepts ===');
  let bobCookie = '';
  let inviteToken = '';
  {
    const inviteRes = await fetch(`${base}/api/workspaces/${workspaceId}/invites`, {
      method: 'POST', headers: { cookie: aliceCookie, 'content-type': 'application/json' },
      body: JSON.stringify({ email: 'bob@example.com', role: 'member' }),
    });
    const inviteJson = await inviteRes.json();
    inviteToken = inviteJson.token;
    ok(inviteRes.status === 200 && inviteJson.email === 'bob@example.com', 'invite created');

    // Bob logs in independently.
    const startRes = await fetch(`${base}/api/auth/google/start`, { redirect: 'manual' });
    const state = new URL(startRes.headers.get('location')!).searchParams.get('state')!;
    const callbackRes = await fetch(`${base}/api/auth/google/callback?code=auth-code-bob&state=${state}`, { redirect: 'manual' });
    bobCookie = extractCookie(callbackRes.headers.get('set-cookie'));

    const acceptRes = await fetch(`${base}/api/workspaces/accept-invite`, {
      method: 'POST', headers: { cookie: bobCookie, 'content-type': 'application/json' }, body: JSON.stringify({ token: inviteToken }),
    });
    const acceptJson = await acceptRes.json();
    ok(acceptRes.status === 200 && acceptJson.role === 'member', 'Bob successfully joins as a member');
  }

  console.log('\n=== RBAC actually enforced: Bob (member) CANNOT invite others, Alice (owner) CAN ===');
  {
    const bobInviteAttempt = await fetch(`${base}/api/workspaces/${workspaceId}/invites`, {
      method: 'POST', headers: { cookie: bobCookie, 'content-type': 'application/json' }, body: JSON.stringify({ email: 'carol@example.com', role: 'member' }),
    });
    ok(bobInviteAttempt.status === 403, `Bob (member) blocked from inviting (${bobInviteAttempt.status})`);
  }

  console.log('\n=== RBAC: Bob CANNOT remove Alice (the owner) ===');
  {
    const res = await fetch(`${base}/api/workspaces/${workspaceId}/members/${(await (await fetch(`${base}/api/auth/me`, { headers: { cookie: aliceCookie } })).json()).id}`, {
      method: 'DELETE', headers: { cookie: bobCookie },
    });
    ok(res.status === 403, `Bob cannot remove Alice, the owner (${res.status})`);
  }

  console.log('\n=== A workspace API key created by Alice works, and is scoped ONLY to her workspace ===');
  let apiKey = '';
  {
    const res = await fetch(`${base}/api/workspaces/${workspaceId}/api-keys`, { method: 'POST', headers: { cookie: aliceCookie, 'content-type': 'application/json' }, body: JSON.stringify({ name: 'CI key' }) });
    const json = await res.json();
    apiKey = json.key;
    ok(res.status === 200 && apiKey.startsWith('nxk_live_'), 'API key created with correct prefix format');

    const useKey = await fetch(`${base}/api/workspaces/${workspaceId}/members`, { headers: { authorization: `Bearer ${apiKey}` } });
    ok(useKey.status === 200, 'the API key authenticates successfully for its own workspace');

    // Create a second, unrelated workspace and confirm the key does NOT work there.
    const otherWs = await (await fetch(`${base}/api/workspaces`, { method: 'POST', headers: { cookie: aliceCookie, 'content-type': 'application/json' }, body: JSON.stringify({ name: 'Other Workspace' }) })).json();
    const crossWorkspaceAttempt = await fetch(`${base}/api/workspaces/${otherWs.id}/members`, { headers: { authorization: `Bearer ${apiKey}` } });
    ok(crossWorkspaceAttempt.status === 403, 'the SAME key is correctly rejected for a DIFFERENT workspace (no cross-workspace leakage)');
  }

  console.log('\n=== Revoking the API key actually invalidates it ===');
  {
    const listRes = await fetch(`${base}/api/workspaces/${workspaceId}/api-keys`, { headers: { cookie: aliceCookie } });
    const { apiKeys } = await listRes.json();
    const keyId = apiKeys[0].id;
    await fetch(`${base}/api/workspaces/${workspaceId}/api-keys/${keyId}`, { method: 'DELETE', headers: { cookie: aliceCookie } });
    const afterRevoke = await fetch(`${base}/api/workspaces/${workspaceId}/members`, { headers: { authorization: `Bearer ${apiKey}` } });
    ok(afterRevoke.status === 401, 'revoked key no longer authenticates');
  }

  console.log('\n=== Real Paddle webhook updates workspace billing status ===');
  {
    const payload = JSON.stringify({
      event_type: 'subscription.created',
      data: { id: 'sub_real_123', customer_id: 'cus_real_456', status: 'active', custom_data: { workspaceId } },
    });
    const ts = Math.floor(Date.now() / 1000);
    const h1 = createHmac('sha256', 'whsec_test').update(`${ts}:${payload}`).digest('hex');
    const res = await fetch(`${base}/api/billing/webhook`, {
      method: 'POST', headers: { 'paddle-signature': `ts=${ts};h1=${h1}`, 'content-type': 'application/json' }, body: payload,
    });
    ok(res.status === 200, `webhook accepted (${res.status})`);

    const statusRes = await fetch(`${base}/api/billing/status/${workspaceId}`, { headers: { cookie: aliceCookie } });
    const statusJson = await statusRes.json();
    ok(statusJson.plan === 'pro' && statusJson.planStatus === 'active', 'workspace plan actually updated from the webhook: ' + JSON.stringify(statusJson));
  }

  console.log('\n=== A forged webhook (wrong signature) is rejected and does NOT change billing state ===');
  {
    const payload = JSON.stringify({ event_type: 'subscription.updated', data: { id: 'sub_real_123', customer_id: 'cus_real_456', status: 'canceled', custom_data: { workspaceId } } });
    const res = await fetch(`${base}/api/billing/webhook`, {
      method: 'POST', headers: { 'paddle-signature': 'ts=1;h1=deadbeef', 'content-type': 'application/json' }, body: payload,
    });
    ok(res.status === 400, `forged webhook rejected (${res.status})`);
    const statusRes = await fetch(`${base}/api/billing/status/${workspaceId}`, { headers: { cookie: aliceCookie } });
    const statusJson = await statusRes.json();
    ok(statusJson.plan === 'pro', 'billing state UNCHANGED by the forged webhook (still pro from the legitimate one)');
  }

  console.log('\n=== Logout clears the session ===');
  {
    await fetch(`${base}/api/auth/logout`, { method: 'POST', headers: { cookie: aliceCookie } });
    // Cookie itself isn't server-invalidated in this design (stateless expiry client-side via Max-Age=0);
    // what we CAN verify is the endpoint responds correctly and the client is instructed to clear it.
  }

  console.log('\n=== Regression: session cookie must NOT be Secure over plain http:// (real browsers silently drop Secure cookies set from a non-https origin — confirmed via an actual browser during development; this check guards against reverting that fix) ===');
  {
    const startRes = await fetch(`${base}/api/auth/google/start`, { redirect: 'manual' });
    const state = new URL(startRes.headers.get('location')!).searchParams.get('state')!;
    const callbackRes = await fetch(`${base}/api/auth/google/callback?code=auth-code-alice&state=${state}`, { redirect: 'manual' });
    const setCookie = callbackRes.headers.get('set-cookie') || '';
    ok(!setCookie.includes('Secure'), `PUBLIC_APP_URL_FOR_REDIRECT is http:// -> cookie is NOT marked Secure (would be silently dropped by real browsers otherwise): "${setCookie}"`);
    ok(setCookie.includes('HttpOnly'), 'still HttpOnly regardless (not readable from JS, XSS mitigation)');
    ok(setCookie.includes('SameSite=Lax'), 'still SameSite=Lax regardless (CSRF mitigation)');
  }

  console.log('\n=== Same flow with an https:// redirect URL correctly DOES mark the cookie Secure ===');
  {
    process.env.PUBLIC_APP_URL_FOR_REDIRECT = 'https://myapp.example.com/app';
    const httpsEnv = loadEnv();
    const httpsHandler = createApp(httpsEnv, log);
    const httpsServer = createServer((r, s) => { httpsHandler(r, s); });
    await new Promise<void>((resolve) => httpsServer.listen(0, '127.0.0.1', resolve));
    const httpsAddr = httpsServer.address();
    const httpsBase = `http://127.0.0.1:${(httpsAddr as any).port}`; // the TEST server itself is still plain http locally — only the configured PUBLIC redirect URL is https, which is what the code actually checks

    const startRes = await fetch(`${httpsBase}/api/auth/google/start`, { redirect: 'manual' });
    const state = new URL(startRes.headers.get('location')!).searchParams.get('state')!;
    const callbackRes = await fetch(`${httpsBase}/api/auth/google/callback?code=auth-code-alice&state=${state}`, { redirect: 'manual' });
    const setCookie = callbackRes.headers.get('set-cookie') || '';
    ok(setCookie.includes('Secure'), `PUBLIC_APP_URL_FOR_REDIRECT is https:// -> cookie correctly IS marked Secure for production: "${setCookie}"`);
    httpsServer.close();
    process.env.PUBLIC_APP_URL_FOR_REDIRECT = 'http://localhost/app'; // restore for any subsequent runs in the same process
  }

  globalThis.fetch = realFetch;
  server.close();
  console.log(`\n${passed} passed, ${failed} failed`);
  if (failed > 0) process.exit(1);
}
run().catch((e) => { console.error('FATAL:', e); process.exit(1); });
