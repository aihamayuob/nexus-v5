import { parseSSEStream, parseNDJSONStream } from '../src/lib/streamParsers.js';

let passed = 0;
let failed = 0;

function assertEqual(actual: unknown, expected: unknown, label: string) {
  const a = JSON.stringify(actual);
  const e = JSON.stringify(expected);
  if (a === e) {
    passed++;
    console.log(`  ok   ${label}`);
  } else {
    failed++;
    console.log(`  FAIL ${label}\n       expected: ${e}\n       actual:   ${a}`);
  }
}

/** Turns an array of raw text chunks into a ReadableStream<Uint8Array>,
 *  simulating network packets arriving in arbitrary, possibly
 *  mid-line, boundaries — exactly the case that breaks naive parsers. */
function streamFromChunks(chunks: string[]): ReadableStream<Uint8Array> {
  const encoder = new TextEncoder();
  let i = 0;
  return new ReadableStream({
    pull(controller) {
      if (i < chunks.length) {
        controller.enqueue(encoder.encode(chunks[i++]));
      } else {
        controller.close();
      }
    },
  });
}

async function collect<T>(gen: AsyncGenerator<T>): Promise<T[]> {
  const out: T[] = [];
  for await (const v of gen) out.push(v);
  return out;
}

async function run() {
  console.log('SSE parser: basic single-frame data');
  {
    const stream = streamFromChunks(['data: {"a":1}\n\n']);
    const frames = await collect(parseSSEStream(stream));
    assertEqual(frames, [{ event: null, data: '{"a":1}', id: null }], 'single data-only frame');
  }

  console.log('SSE parser: event + id + multi-line data');
  {
    const stream = streamFromChunks(['event: token\nid: 5\ndata: line1\ndata: line2\n\n']);
    const frames = await collect(parseSSEStream(stream));
    assertEqual(
      frames,
      [{ event: 'token', data: 'line1\nline2', id: '5' }],
      'multi-line data joined with \\n, event+id captured'
    );
  }

  console.log('SSE parser: frame split across chunk boundary (mid-line)');
  {
    const stream = streamFromChunks(['event: tok', 'en\ndata: {"x":', 'true}\n\n']);
    const frames = await collect(parseSSEStream(stream));
    assertEqual(frames, [{ event: 'token', data: '{"x":true}', id: null }], 'reassembled across chunk boundary');
  }

  console.log('SSE parser: frame split exactly at the \\n\\n separator');
  {
    const stream = streamFromChunks(['data: hello\n', '\ndata: world\n\n']);
    const frames = await collect(parseSSEStream(stream));
    assertEqual(
      frames,
      [
        { event: null, data: 'hello', id: null },
        { event: null, data: 'world', id: null },
      ],
      'separator split across two chunks still yields two frames'
    );
  }

  console.log('SSE parser: comment / keep-alive lines ignored');
  {
    const stream = streamFromChunks([': keep-alive\n\ndata: real\n\n']);
    const frames = await collect(parseSSEStream(stream));
    assertEqual(frames, [{ event: null, data: 'real', id: null }], 'comment-only frame dropped');
  }

  console.log('SSE parser: CRLF line endings normalized');
  {
    const stream = streamFromChunks(['event: token\r\ndata: hi\r\n\r\n']);
    const frames = await collect(parseSSEStream(stream));
    assertEqual(frames, [{ event: 'token', data: 'hi', id: null }], 'CRLF handled like LF');
  }

  console.log('SSE parser: trailing frame with no final blank line is still flushed');
  {
    const stream = streamFromChunks(['data: no-trailing-newline']);
    const frames = await collect(parseSSEStream(stream));
    assertEqual(frames, [{ event: null, data: 'no-trailing-newline', id: null }], 'flush on stream end');
  }

  console.log('NDJSON parser: multiple lines, split mid-line across chunks');
  {
    const stream = streamFromChunks(['{"a":1}\n{"b":', '2}\n{"c":3}']);
    const lines = await collect(parseNDJSONStream(stream));
    assertEqual(lines, ['{"a":1}', '{"b":2}', '{"c":3}'], 'NDJSON reassembled and final unterminated line flushed');
  }

  console.log(`\n${passed} passed, ${failed} failed`);
  if (failed > 0) process.exit(1);
}

run();
