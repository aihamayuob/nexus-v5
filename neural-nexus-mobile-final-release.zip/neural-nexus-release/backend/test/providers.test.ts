import { createAnthropicAdapter } from '../src/providers/anthropic.js';
import { createGeminiAdapter } from '../src/providers/gemini.js';
import { createOpenAICompatAdapter } from '../src/providers/openaiCompat.js';
import type { StreamEvent } from '../src/providers/types.js';

let passed = 0;
let failed = 0;

function assertEqual(actual: unknown, expected: unknown, label: string) {
  const a = JSON.stringify(actual);
  const e = JSON.stringify(expected);
  if (a === e) {
    passed++;
    console.log(`  ok   ${label}`);
  } else {
    failed++;
    console.log(`  FAIL ${label}\n       expected: ${e}\n       actual:   ${a}`);
  }
}

function sseBody(frames: string[]): string {
  return frames.map((f) => f + '\n\n').join('');
}

function mockFetchOnce(status: number, body: string) {
  (globalThis as any).fetch = async () =>
    new Response(body, { status, headers: { 'content-type': 'text/event-stream' } });
}

async function collect(gen: AsyncGenerator<StreamEvent>): Promise<StreamEvent[]> {
  const out: StreamEvent[] = [];
  for await (const v of gen) out.push(v);
  return out;
}

async function run() {
  console.log('Anthropic adapter: text streaming + usage + done');
  {
    mockFetchOnce(
      200,
      sseBody([
        'event: message_start\ndata: {"type":"message_start","message":{"usage":{"input_tokens":12}}}',
        'event: content_block_start\ndata: {"type":"content_block_start","index":0,"content_block":{"type":"text","text":""}}',
        'event: content_block_delta\ndata: {"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":"Hello"}}',
        'event: content_block_delta\ndata: {"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":", world"}}',
        'event: content_block_stop\ndata: {"type":"content_block_stop","index":0}',
        'event: message_delta\ndata: {"type":"message_delta","delta":{"stop_reason":"end_turn"},"usage":{"output_tokens":5}}',
        'event: message_stop\ndata: {"type":"message_stop"}',
      ])
    );
    const adapter = createAnthropicAdapter('fake-key');
    const events = await collect(
      adapter.streamChat({ provider: 'anthropic', model: 'claude-x', messages: [{ role: 'user', content: 'hi' }] }, new AbortController().signal)
    );
    assertEqual(
      events,
      [
        { type: 'token', text: 'Hello' },
        { type: 'token', text: ', world' },
        { type: 'usage', inputTokens: 12, outputTokens: 5 },
        { type: 'done', stopReason: 'end_turn' },
      ],
      'text tokens + correct usage + done'
    );
  }

  console.log('Anthropic adapter: tool_use streaming (incremental partial JSON)');
  {
    mockFetchOnce(
      200,
      sseBody([
        'event: message_start\ndata: {"type":"message_start","message":{"usage":{"input_tokens":20}}}',
        'event: content_block_start\ndata: {"type":"content_block_start","index":0,"content_block":{"type":"tool_use","id":"tool_1","name":"web_search"}}',
        'event: content_block_delta\ndata: {"type":"content_block_delta","index":0,"delta":{"type":"input_json_delta","partial_json":"{\\"query\\":"}}',
        'event: content_block_delta\ndata: {"type":"content_block_delta","index":0,"delta":{"type":"input_json_delta","partial_json":"\\"gold price\\"}"}}',
        'event: message_delta\ndata: {"type":"message_delta","delta":{"stop_reason":"tool_use"},"usage":{"output_tokens":8}}',
        'event: message_stop\ndata: {"type":"message_stop"}',
      ])
    );
    const adapter = createAnthropicAdapter('fake-key');
    const events = await collect(
      adapter.streamChat({ provider: 'anthropic', model: 'claude-x', messages: [{ role: 'user', content: 'search gold price' }] }, new AbortController().signal)
    );
    assertEqual(
      events,
      [
        { type: 'tool_use_start', id: 'tool_1', name: 'web_search' },
        { type: 'tool_use_delta', id: 'tool_1', partialJson: '{"query":' },
        { type: 'tool_use_delta', id: 'tool_1', partialJson: '"gold price"}' },
        { type: 'usage', inputTokens: 20, outputTokens: 8 },
        { type: 'done', stopReason: 'tool_use' },
      ],
      'tool_use_start once, deltas routed by content-block index, stop_reason=tool_use'
    );
    // Confirm the accumulated partial JSON actually parses to valid input —
    // this is the exact reconstruction the frontend will perform.
    const toolEvents = events.filter((e): e is Extract<StreamEvent, { type: 'tool_use_delta' }> => e.type === 'tool_use_delta');
    const accumulated = toolEvents.map((e) => e.partialJson).join('');
    assertEqual(JSON.parse(accumulated), { query: 'gold price' }, 'accumulated partial_json parses to correct tool input');
  }

  console.log('OpenAI-compatible adapter: text streaming with usage frame');
  {
    mockFetchOnce(
      200,
      sseBody([
        'data: {"choices":[{"delta":{"role":"assistant"},"finish_reason":null}]}',
        'data: {"choices":[{"delta":{"content":"Hel"},"finish_reason":null}]}',
        'data: {"choices":[{"delta":{"content":"lo"},"finish_reason":null}]}',
        'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}',
        'data: {"choices":[],"usage":{"prompt_tokens":10,"completion_tokens":2}}',
        'data: [DONE]',
      ])
    );
    const adapter = createOpenAICompatAdapter('openai', 'https://api.openai.com/v1', 'fake-key');
    const events = await collect(
      adapter.streamChat({ provider: 'openai', model: 'gpt-x', messages: [{ role: 'user', content: 'hi' }] }, new AbortController().signal)
    );
    assertEqual(
      events,
      [
        { type: 'token', text: 'Hel' },
        { type: 'token', text: 'lo' },
        { type: 'usage', inputTokens: 10, outputTokens: 2 },
        { type: 'done', stopReason: 'end_turn' },
      ],
      'delta.content concatenation + finish_reason mapping + separate usage chunk'
    );
  }

  console.log('OpenAI-compatible adapter: streamed tool_calls (arguments fragmented across many deltas)');
  {
    mockFetchOnce(
      200,
      sseBody([
        'data: {"choices":[{"delta":{"tool_calls":[{"index":0,"id":"call_abc","type":"function","function":{"name":"get_price","arguments":""}}]},"finish_reason":null}]}',
        'data: {"choices":[{"delta":{"tool_calls":[{"index":0,"function":{"arguments":"{\\"symbol\\":"}}]},"finish_reason":null}]}',
        'data: {"choices":[{"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\"XAU\\"}"}}]},"finish_reason":null}]}',
        'data: {"choices":[{"delta":{},"finish_reason":"tool_calls"}]}',
        'data: {"choices":[],"usage":{"prompt_tokens":30,"completion_tokens":9}}',
        'data: [DONE]',
      ])
    );
    const adapter = createOpenAICompatAdapter('deepseek', 'https://api.deepseek.com', 'fake-key');
    const events = await collect(
      adapter.streamChat({ provider: 'deepseek', model: 'deepseek-chat', messages: [{ role: 'user', content: 'price?' }] }, new AbortController().signal)
    );
    const toolStart = events.find((e) => e.type === 'tool_use_start');
    assertEqual(toolStart, { type: 'tool_use_start', id: 'call_abc', name: 'get_price' }, 'tool_use_start fires once with real id+name from first fragment');
    const deltas = events.filter((e): e is Extract<StreamEvent, { type: 'tool_use_delta' }> => e.type === 'tool_use_delta');
    const accumulated = deltas.map((d) => d.partialJson).join('');
    assertEqual(JSON.parse(accumulated), { symbol: 'XAU' }, 'fragmented arguments across multiple deltas reassemble correctly');
    assertEqual(events[events.length - 1], { type: 'done', stopReason: 'tool_use' }, 'finish_reason tool_calls maps to tool_use');
  }

  console.log('OpenAI-compatible adapter: non-streaming chat() normalizes to Anthropic shape');
  {
    (globalThis as any).fetch = async () =>
      new Response(
        JSON.stringify({
          choices: [
            {
              message: { role: 'assistant', content: 'The answer is 42.', tool_calls: null },
              finish_reason: 'stop',
            },
          ],
          usage: { prompt_tokens: 7, completion_tokens: 6 },
        }),
        { status: 200 }
      );
    const adapter = createOpenAICompatAdapter('mistral', 'https://api.mistral.ai/v1', 'fake-key');
    const result = await adapter.chat(
      { provider: 'mistral', model: 'mistral-large', messages: [{ role: 'user', content: 'meaning of life' }] },
      new AbortController().signal
    );
    assertEqual(
      result,
      { content: [{ type: 'text', text: 'The answer is 42.' }], stop_reason: 'end_turn', usage: { input_tokens: 7, output_tokens: 6 } },
      'non-streaming response translated to exact Anthropic-shaped envelope the frontend expects'
    );
  }

  console.log('Gemini adapter: text streaming + finishReason + usageMetadata');
  {
    mockFetchOnce(
      200,
      sseBody([
        'data: {"candidates":[{"content":{"parts":[{"text":"Checking"}]}}]}',
        'data: {"candidates":[{"content":{"parts":[{"text":" now..."}]},"finishReason":"STOP"}],"usageMetadata":{"promptTokenCount":15,"candidatesTokenCount":4}}',
      ])
    );
    const adapter = createGeminiAdapter('fake-key');
    const events = await collect(
      adapter.streamChat({ provider: 'gemini', model: 'gemini-x', messages: [{ role: 'user', content: 'hi' }] }, new AbortController().signal)
    );
    assertEqual(
      events,
      [
        { type: 'token', text: 'Checking' },
        { type: 'token', text: ' now...' },
        { type: 'usage', inputTokens: 15, outputTokens: 4 },
        { type: 'done', stopReason: 'end_turn' },
      ],
      'Gemini part-text concatenation + usageMetadata + STOP mapping'
    );
  }

  console.log('Gemini adapter: functionCall part maps to tool_use_start + one delta, and drives stop_reason=tool_use');
  {
    mockFetchOnce(
      200,
      sseBody([
        'data: {"candidates":[{"content":{"parts":[{"functionCall":{"name":"lookup_price","args":{"symbol":"XAU"}}}]},"finishReason":"STOP"}],"usageMetadata":{"promptTokenCount":9,"candidatesTokenCount":3}}',
      ])
    );
    const adapter = createGeminiAdapter('fake-key');
    const events = await collect(
      adapter.streamChat({ provider: 'gemini', model: 'gemini-x', messages: [{ role: 'user', content: 'price?' }] }, new AbortController().signal)
    );
    assertEqual(events[0], { type: 'tool_use_start', id: 'gemini_tool_0', name: 'lookup_price' }, 'tool_use_start synthesized');
    assertEqual(JSON.parse((events[1] as any).partialJson), { symbol: 'XAU' }, 'whole functionCall args delivered as one delta, still valid JSON');
    assertEqual(events[events.length - 1], { type: 'done', stopReason: 'tool_use' }, 'presence of functionCall overrides STOP to tool_use');
  }

  console.log('Anthropic adapter: survives one malformed frame mixed in with valid ones');
  {
    mockFetchOnce(
      200,
      sseBody([
        'event: content_block_delta\ndata: {"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":"A"}}',
        'event: content_block_delta\ndata: {not valid json at all}',
        'event: content_block_delta\ndata: {"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":"B"}}',
        'event: message_stop\ndata: {"type":"message_stop"}',
      ])
    );
    const adapter = createAnthropicAdapter('fake-key');
    const events = await collect(
      adapter.streamChat({ provider: 'anthropic', model: 'claude-x', messages: [{ role: 'user', content: 'hi' }] }, new AbortController().signal)
    );
    assertEqual(
      events,
      [
        { type: 'token', text: 'A' },
        { type: 'token', text: 'B' },
        { type: 'usage', inputTokens: 0, outputTokens: 0 },
        { type: 'done', stopReason: 'end_turn' },
      ],
      'malformed frame skipped without crashing the generator; valid tokens on both sides still delivered'
    );
  }

  console.log(`\n${passed} passed, ${failed} failed`);
  if (failed > 0) process.exit(1);
}

run();
