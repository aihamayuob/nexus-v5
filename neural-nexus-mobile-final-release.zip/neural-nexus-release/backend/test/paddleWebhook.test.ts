import { createHmac } from 'node:crypto';
import { verifyPaddleWebhookSignature, parsePaddleSubscriptionEvent, mapPaddleStatus, PaddleSignatureError } from '../src/accounts/paddleWebhook.js';

let passed = 0, failed = 0;
function ok(cond: boolean, label: string) {
  if (cond) { passed++; console.log(`  ok   ${label}`); }
  else { failed++; console.log(`  FAIL ${label}`); }
}
function throwsWith(fn: () => void, ErrorClass: any, label: string) {
  try { fn(); failed++; console.log(`  FAIL ${label} (did not throw)`); }
  catch (e) {
    if (e instanceof ErrorClass) { passed++; console.log(`  ok   ${label}`); }
    else { failed++; console.log(`  FAIL ${label} (wrong error type: ${(e as Error).message})`); }
  }
}

function makeValidHeader(body: string, secret: string, tsOverride?: number) {
  const ts = tsOverride ?? Math.floor(Date.now() / 1000);
  const h1 = createHmac('sha256', secret).update(`${ts}:${body}`).digest('hex');
  return `ts=${ts};h1=${h1}`;
}

const SECRET = 'whsec_test_secret_12345';
const BODY = JSON.stringify({ event_type: 'subscription.updated', data: { id: 'sub_1', customer_id: 'cus_1', status: 'active' } });

console.log('verifyPaddleWebhookSignature: accepts a genuinely valid signature');
{
  const header = makeValidHeader(BODY, SECRET);
  let threw = false;
  try { verifyPaddleWebhookSignature(BODY, header, SECRET); } catch { threw = true; }
  ok(!threw, 'valid signature over the real body is accepted');
}

console.log('\nverifyPaddleWebhookSignature: rejects a tampered body (the actual point of this whole mechanism)');
{
  const header = makeValidHeader(BODY, SECRET); // signature computed over the ORIGINAL body
  const tamperedBody = JSON.stringify({ event_type: 'subscription.updated', data: { id: 'sub_1', customer_id: 'cus_1', status: 'canceled' } }); // attacker flips active->canceled, or worse
  throwsWith(() => verifyPaddleWebhookSignature(tamperedBody, header, SECRET), PaddleSignatureError, 'tampered body is rejected even though the header "looks" well-formed');
}

console.log('\nverifyPaddleWebhookSignature: rejects a signature computed with the wrong secret');
{
  const header = makeValidHeader(BODY, 'wrong_secret');
  throwsWith(() => verifyPaddleWebhookSignature(BODY, header, SECRET), PaddleSignatureError, 'signature from a different secret is rejected');
}

console.log('\nverifyPaddleWebhookSignature: rejects a re-serialized (JSON.parse then JSON.stringify) body — the classic real-world integration bug');
{
  const header = makeValidHeader(BODY, SECRET);
  const reserialized = JSON.stringify(JSON.parse(BODY)); // same logical content, potentially different bytes
  // This specific test body happens to reserialize identically (no key reordering issue with this simple shape),
  // so we construct a case where key order actually changes to prove the raw-bytes requirement matters:
  const bodyWithOrderSensitivity = '{"b":2,"a":1}';
  const headerForThat = makeValidHeader(bodyWithOrderSensitivity, SECRET);
  const reserializedDifferently = JSON.stringify(JSON.parse(bodyWithOrderSensitivity)); // V8 preserves insertion order for string keys, so this actually stays "b","a" too —
  // demonstrate the real risk more directly: any byte-level change (even whitespace) breaks it:
  const withExtraSpace = bodyWithOrderSensitivity.replace(':', ': ');
  throwsWith(() => verifyPaddleWebhookSignature(withExtraSpace, headerForThat, SECRET), PaddleSignatureError, 'even a single added whitespace byte invalidates the signature (proves this MUST use raw, unmodified bytes)');
}

console.log('\nverifyPaddleWebhookSignature: rejects missing/malformed headers');
{
  throwsWith(() => verifyPaddleWebhookSignature(BODY, undefined, SECRET), PaddleSignatureError, 'missing header entirely');
  throwsWith(() => verifyPaddleWebhookSignature(BODY, 'garbage-not-a-real-header', SECRET), PaddleSignatureError, 'malformed header (no ts/h1 fields)');
  throwsWith(() => verifyPaddleWebhookSignature(BODY, 'ts=notanumber;h1=abc', SECRET), PaddleSignatureError, 'non-numeric timestamp');
}

console.log('\nverifyPaddleWebhookSignature: replay protection — rejects an old (or far-future) timestamp even with a technically-correct signature');
{
  const oldTs = Math.floor(Date.now() / 1000) - 3600; // 1 hour old
  const header = makeValidHeader(BODY, SECRET, oldTs); // signature is internally consistent with the old ts...
  throwsWith(() => verifyPaddleWebhookSignature(BODY, header, SECRET), PaddleSignatureError, 'stale timestamp (1 hour old) rejected as a possible replay, despite a technically valid signature for that timestamp');
}

console.log('\nverifyPaddleWebhookSignature: accepts a signature within the replay window (not overly strict)');
{
  const recentTs = Math.floor(Date.now() / 1000) - 60; // 1 minute old — should still be fine
  const header = makeValidHeader(BODY, SECRET, recentTs);
  let threw = false;
  try { verifyPaddleWebhookSignature(BODY, header, SECRET); } catch { threw = true; }
  ok(!threw, '1-minute-old timestamp is still accepted (window is 5 minutes)');
}

console.log('\nparsePaddleSubscriptionEvent: extracts fields correctly, ignores unrelated event types gracefully');
{
  const event = parsePaddleSubscriptionEvent(JSON.parse(BODY));
  ok(event?.subscriptionId === 'sub_1', 'subscriptionId extracted');
  ok(event?.status === 'active', 'status extracted');

  const unrelated = parsePaddleSubscriptionEvent({ event_type: 'transaction.completed', data: {} });
  ok(unrelated === null, 'non-subscription event type returns null instead of throwing (forward-compatible with new Paddle event types)');

  const malformed = parsePaddleSubscriptionEvent({ event_type: 'subscription.updated', data: {} });
  ok(malformed === null, 'subscription event missing required fields returns null rather than crashing');
}

console.log('\nmapPaddleStatus: maps to the app\'s tri-state correctly, fails toward "needs attention" for unknown statuses');
{
  ok(mapPaddleStatus('active') === 'active', 'active -> active');
  ok(mapPaddleStatus('trialing') === 'active', 'trialing -> active');
  ok(mapPaddleStatus('past_due') === 'past_due', 'past_due -> past_due');
  ok(mapPaddleStatus('canceled') === 'canceled', 'canceled -> canceled');
  ok(mapPaddleStatus('paused') === 'canceled', 'paused -> canceled');
  ok(mapPaddleStatus('some_future_unknown_status') === 'past_due', 'unknown/future status fails toward past_due (needs-attention), never silently "active"');
}

console.log(`\n${passed} passed, ${failed} failed`);
if (failed > 0) process.exit(1);
