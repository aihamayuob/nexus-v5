import { SyncStore } from '../src/sync/store.js';

let passed = 0, failed = 0;
function ok(cond: boolean, label: string) {
  if (cond) { passed++; console.log(`  ok   ${label}`); }
  else { failed++; console.log(`  FAIL ${label}`); }
}

function run() {
  console.log('SyncStore: empty store returns null');
  {
    const store = new SyncStore(':memory:');
    ok(store.get() === null, 'get() on empty store is null');
  }

  console.log('SyncStore: first push (baseVersion 0) succeeds and creates version 1');
  {
    const store = new SyncStore(':memory:');
    const result = store.putIfVersionMatches(0, 'device-A', 'salt1', 'iv1', 'cipher1');
    ok(result.ok === true, 'first push accepted');
    if (result.ok) {
      ok(result.record.version === 1, 'version is 1 after first push');
      ok(result.record.deviceId === 'device-A', 'deviceId recorded correctly');
    }
    const fetched = store.get();
    ok(fetched?.version === 1, 'get() reflects the push');
    ok(fetched?.ciphertextB64 === 'cipher1', 'ciphertext round-trips correctly');
  }

  console.log('SyncStore: sequential push from the SAME device (correct baseVersion) succeeds');
  {
    const store = new SyncStore(':memory:');
    store.putIfVersionMatches(0, 'device-A', 's', 'i', 'v1');
    const second = store.putIfVersionMatches(1, 'device-A', 's', 'i', 'v2');
    ok(second.ok === true, 'second push with correct baseVersion=1 accepted');
    if (second.ok) ok(second.record.version === 2, 'version incremented to 2');
  }

  console.log('SyncStore: CONFLICT — two devices push from the same base version, second is rejected');
  {
    const store = new SyncStore(':memory:');
    store.putIfVersionMatches(0, 'device-A', 's', 'i', 'v1'); // now at version 1
    // Device B never saw this — it still thinks base version is 0 (stale read)
    const deviceBPush = store.putIfVersionMatches(0, 'device-B', 's', 'i', 'v2-from-B');
    ok(deviceBPush.ok === false, 'device B push correctly REJECTED (real conflict)');
    if (!deviceBPush.ok) {
      ok(deviceBPush.current?.version === 1, 'rejected response includes the actual current version');
      ok(deviceBPush.current?.deviceId === 'device-A', 'rejected response shows device A is the actual current writer');
      ok(deviceBPush.current?.ciphertextB64 === 'v1', 'device A\'s data was NOT silently overwritten by B\'s stale push');
    }
    // Device B can now resolve: pull the current record, then push again with the correct baseVersion.
    const deviceBRetry = store.putIfVersionMatches(1, 'device-B', 's', 'i', 'v2-from-B-retried');
    ok(deviceBRetry.ok === true, 'device B succeeds after re-syncing to the correct baseVersion');
  }

  console.log('SyncStore: delete clears the record');
  {
    const store = new SyncStore(':memory:');
    store.putIfVersionMatches(0, 'device-A', 's', 'i', 'v1');
    ok(store.get() !== null, 'record exists before delete');
    store.delete();
    ok(store.get() === null, 'record gone after delete');
    // After delete, a fresh push should succeed at baseVersion 0 again.
    const afterDelete = store.putIfVersionMatches(0, 'device-A', 's', 'i', 'v-fresh');
    ok(afterDelete.ok === true && afterDelete.ok && afterDelete.record.version === 1, 'version resets to 1 after delete + fresh push');
  }

  console.log(`\n${passed} passed, ${failed} failed`);
  if (failed > 0) process.exit(1);
}
run();
