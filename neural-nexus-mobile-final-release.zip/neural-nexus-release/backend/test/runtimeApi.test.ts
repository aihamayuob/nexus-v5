import { createServer } from 'node:http';
import { createApp } from '../src/app.js';
import { loadEnv } from '../src/config/env.js';
import { createLogger } from '../src/lib/logger.js';

let passed = 0, failed = 0;
function ok(cond: boolean, label: string) {
  if (cond) { passed++; console.log(`  ok   ${label}`); }
  else { failed++; console.log(`  FAIL ${label}`); }
}

function sseBody(frames: string[]): string {
  return frames.map((f) => f + '\n\n').join('');
}

async function run() {
  const gatewayKey = 'runtime-test-gateway-key-0123456789abcdef01234';
  process.env.GATEWAY_API_KEY = gatewayKey;
  process.env.ANTHROPIC_API_KEY = 'fake-key';
  process.env.RATE_LIMIT_MAX_REQUESTS = '1000';
  process.env.SYNC_DB_PATH = ':memory:';

  const env = loadEnv();
  const log = createLogger('error');
  const handler = createApp(env, log);
  const server = createServer((req, res) => { handler(req, res); });
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve));
  const address = server.address();
  if (typeof address !== 'object' || address === null) throw new Error('bind failed');
  const base = `http://127.0.0.1:${address.port}`;
  const authHeaders = { authorization: `Bearer ${gatewayKey}`, 'content-type': 'application/json' };

  const realFetch = globalThis.fetch;
  let callIndex = 0;
  (globalThis as any).fetch = async (url: string, opts: any) => {
    if (String(url).includes('api.anthropic.com')) {
      const body = opts?.body ? JSON.parse(opts.body) : {};
      const isPlanCall = body.system?.includes('مخطط مهام');
      const isSynthesisCall = body.system?.includes('اجمع نتائج المهام');
      callIndex++;

      if (!body.stream) {
        // Planner uses non-streaming chat()
        if (isPlanCall) {
          return new Response(JSON.stringify({
            content: [{ type: 'text', text: JSON.stringify({ goal: 'test', tasks: [
              { id: 'research', description: 'ابحث عن معلومة', dependsOn: [] },
              { id: 'summarize', description: 'لخّص النتيجة', dependsOn: ['research'] },
            ] }) }],
            stop_reason: 'end_turn', usage: { input_tokens: 10, output_tokens: 10 },
          }), { status: 200 });
        }
        return new Response(JSON.stringify({ content: [{ type: 'text', text: 'reflection pass' }], stop_reason: 'end_turn', usage: { input_tokens: 1, output_tokens: 1 } }), { status: 200 });
      }

      // Streaming call — used by task execution and synthesis
      const text = isSynthesisCall ? 'الإجابة النهائية الموحدة' : `نتيجة المهمة رقم ${callIndex}`;
      const encoder = new TextEncoder();
      const frames = [
        `event: content_block_delta\ndata: {"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":"${text}"}}`,
        `event: message_delta\ndata: {"type":"message_delta","delta":{"stop_reason":"end_turn"},"usage":{"output_tokens":5}}`,
        `event: message_stop\ndata: {"type":"message_stop"}`,
      ];
      let i = 0;
      const stream = new ReadableStream({
        async pull(controller) {
          if (i < frames.length) { controller.enqueue(encoder.encode(frames[i++] + '\n\n')); }
          else controller.close();
        },
      });
      return new Response(stream, { status: 200, headers: { 'content-type': 'text/event-stream' } });
    }
    return realFetch(url as any, opts);
  };

  console.log('POST /api/runtime/plan returns a validated plan');
  let plan: any;
  {
    const res = await fetch(`${base}/api/runtime/plan`, { method: 'POST', headers: authHeaders, body: JSON.stringify({ goal: 'ابحث ولخّص شيئاً' }) });
    plan = await res.json();
    ok(res.status === 200, `status 200 (got ${res.status})`);
    ok(Array.isArray(plan.tasks) && plan.tasks.length === 2, 'plan has the 2 expected tasks');
    ok(plan.tasks[1].dependsOn.includes('research'), 'dependency structure preserved through the HTTP layer');
  }

  console.log('POST /api/runtime/plan without auth -> 401');
  {
    const res = await fetch(`${base}/api/runtime/plan`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ goal: 'x' }) });
    ok(res.status === 401, `status 401 (got ${res.status})`);
  }

  console.log('POST /api/runtime/plan missing goal -> 400');
  {
    const res = await fetch(`${base}/api/runtime/plan`, { method: 'POST', headers: authHeaders, body: JSON.stringify({}) });
    ok(res.status === 400, `status 400 (got ${res.status})`);
  }

  console.log('POST /api/runtime/run executes the plan over real SSE and reaches plan_done');
  {
    const res = await fetch(`${base}/api/runtime/run`, { method: 'POST', headers: authHeaders, body: JSON.stringify({ plan }) });
    ok(res.status === 200, `status 200 (got ${res.status})`);
    ok(res.headers.get('content-type')?.includes('text/event-stream') === true, 'content-type is SSE');
    const text = await res.text();
    const frames = text.trim().split('\n\n').filter(Boolean);
    ok(frames.some((f) => f.includes('event: plan_start')), 'plan_start present');
    ok(frames.some((f) => f.includes('event: task_start') && f.includes('research')), 'research task started');
    ok(frames.some((f) => f.includes('event: task_done') && f.includes('research')), 'research task completed');
    ok(frames.some((f) => f.includes('event: task_start') && f.includes('summarize')), 'summarize task started (after its dependency)');
    ok(frames.some((f) => f.includes('event: plan_done')), 'plan_done present — full run completed over real HTTP/SSE');
  }

  console.log('POST /api/runtime/run rejects a structurally invalid plan with 400 (not a hang or 500)');
  {
    const badPlan = { goal: 'g', tasks: [{ id: 'a', description: 'x', dependsOn: ['nonexistent'] }] };
    const res = await fetch(`${base}/api/runtime/run`, { method: 'POST', headers: authHeaders, body: JSON.stringify({ plan: badPlan }) });
    ok(res.status === 400, `status 400 (got ${res.status})`);
  }

  globalThis.fetch = realFetch;
  server.close();
  console.log(`\n${passed} passed, ${failed} failed`);
  if (failed > 0) process.exit(1);
}
run().catch((e) => { console.error('FATAL:', e); process.exit(1); });
