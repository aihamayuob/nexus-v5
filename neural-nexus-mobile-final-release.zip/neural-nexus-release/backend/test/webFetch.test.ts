import { isPrivateOrReservedIP, safeFetchText, stripHtmlToText, SSRFBlockedError, FetchToolError } from '../src/tools/webFetch.js';

let passed = 0, failed = 0;
function ok(cond: boolean, label: string) {
  if (cond) { passed++; console.log(`  ok   ${label}`); }
  else { failed++; console.log(`  FAIL ${label}`); }
}
async function throwsWith(fn: () => Promise<any>, ErrorClass: any, label: string) {
  try { await fn(); failed++; console.log(`  FAIL ${label} (did not throw)`); }
  catch (e) {
    if (e instanceof ErrorClass) { passed++; console.log(`  ok   ${label}`); }
    else { failed++; console.log(`  FAIL ${label} (threw ${e?.constructor?.name}, not ${ErrorClass.name}): ${(e as Error).message}`); }
  }
}

function mockDeps(lookupResult: string, fetchResponses: (url: string) => Response) {
  return {
    lookup: async () => ({ address: lookupResult, family: lookupResult.includes(':') ? 6 : 4 }),
    fetchImpl: (async (url: string) => fetchResponses(String(url))) as typeof fetch,
  };
}

async function run() {
  console.log('isPrivateOrReservedIP: real-world attack targets are all blocked');
  {
    ok(isPrivateOrReservedIP('169.254.169.254') === true, 'AWS/GCP/Azure cloud metadata endpoint blocked');
    ok(isPrivateOrReservedIP('127.0.0.1') === true, 'loopback blocked');
    ok(isPrivateOrReservedIP('localhost'.length ? '127.0.0.1' : '') === true, '(loopback, sanity)');
    ok(isPrivateOrReservedIP('10.0.0.1') === true, '10.0.0.0/8 blocked');
    ok(isPrivateOrReservedIP('172.16.0.1') === true, '172.16.0.0/12 range start blocked');
    ok(isPrivateOrReservedIP('172.31.255.255') === true, '172.16.0.0/12 range end blocked');
    ok(isPrivateOrReservedIP('172.32.0.1') === false, '172.32.x.x correctly NOT blocked (just outside the /12 range)');
    ok(isPrivateOrReservedIP('192.168.1.1') === true, '192.168.0.0/16 blocked');
    ok(isPrivateOrReservedIP('0.0.0.0') === true, '0.0.0.0 blocked');
    ok(isPrivateOrReservedIP('100.64.0.1') === true, 'carrier-grade NAT range blocked');
    ok(isPrivateOrReservedIP('::1') === true, 'IPv6 loopback blocked');
    ok(isPrivateOrReservedIP('fe80::1') === true, 'IPv6 link-local blocked');
    ok(isPrivateOrReservedIP('fd00::1') === true, 'IPv6 unique-local blocked');
    ok(isPrivateOrReservedIP('::ffff:169.254.169.254') === true, 'IPv4-mapped IPv6 smuggling cloud metadata is caught (unwrapped and re-checked)');
  }

  console.log('\nisPrivateOrReservedIP: legitimate public IPs are NOT blocked');
  {
    ok(isPrivateOrReservedIP('8.8.8.8') === false, 'public DNS (Google) not blocked');
    ok(isPrivateOrReservedIP('1.1.1.1') === false, 'public DNS (Cloudflare) not blocked');
    ok(isPrivateOrReservedIP('93.184.216.34') === false, 'a normal public web server IP not blocked');
    ok(isPrivateOrReservedIP('2606:4700:4700::1111') === false, 'public IPv6 not blocked');
  }

  console.log('\nisPrivateOrReservedIP: malformed input fails closed (treated as blocked, not silently allowed)');
  {
    ok(isPrivateOrReservedIP('not.an.ip.address') === true, 'garbage input blocked rather than passed through');
    ok(isPrivateOrReservedIP('999.999.999.999') === true, 'out-of-range octets blocked');
  }

  console.log('\nsafeFetchText: blocks a request when the hostname resolves to a private IP');
  {
    const deps = mockDeps('169.254.169.254', () => { throw new Error('fetch should never be called — blocked before this point'); });
    await throwsWith(() => safeFetchText('http://attacker-controlled-domain.com/', { timeoutMs: 5000, maxBytes: 1000, maxRedirects: 3 }, deps), SSRFBlockedError, 'DNS resolving to cloud-metadata IP is blocked BEFORE any request is made');
  }

  console.log('\nsafeFetchText: blocks non-http(s) protocols');
  {
    const deps = mockDeps('8.8.8.8', () => new Response('should not be reached'));
    await throwsWith(() => safeFetchText('file:///etc/passwd', { timeoutMs: 5000, maxBytes: 1000, maxRedirects: 3 }, deps), SSRFBlockedError, 'file:// protocol blocked');
  }

  console.log('\nsafeFetchText: THE key redirect-based bypass — a safe initial host redirecting to a private target is caught');
  {
    let callCount = 0;
    const deps = {
      lookup: async (hostname: string) => {
        callCount++;
        // First hop: public site. Second hop (after redirect): resolves to cloud metadata.
        return { address: hostname === 'safe-looking-site.com' ? '8.8.8.8' : '169.254.169.254', family: 4 };
      },
      fetchImpl: (async (url: string) => {
        if (String(url).includes('safe-looking-site.com')) {
          return new Response(null, { status: 302, headers: { location: 'http://internal-service/steal-secrets' } });
        }
        throw new Error('should never reach the redirect target — must be blocked first');
      }) as typeof fetch,
    };
    await throwsWith(
      () => safeFetchText('http://safe-looking-site.com/', { timeoutMs: 5000, maxBytes: 1000, maxRedirects: 3 }, deps),
      SSRFBlockedError,
      'redirect to a private-IP-resolving host is blocked, not silently followed'
    );
    ok(callCount === 2, `DNS was re-resolved on the redirect hop too (${callCount} lookups — this is the check that actually matters)`);
  }

  console.log('\nsafeFetchText: successful fetch of a safe public URL returns the body text');
  {
    const deps = mockDeps('93.184.216.34', () => new Response('hello world', { status: 200, headers: { 'content-type': 'text/plain' } }));
    const result = await safeFetchText('http://example.com/', { timeoutMs: 5000, maxBytes: 1000, maxRedirects: 3 }, deps);
    ok(result.text === 'hello world', 'body text returned correctly');
    ok(result.truncated === false, 'not marked truncated (well under the limit)');
  }

  console.log('\nsafeFetchText: oversized response is truncated, not silently fully buffered');
  {
    const bigText = 'x'.repeat(5000);
    const deps = mockDeps('93.184.216.34', () => new Response(bigText, { status: 200 }));
    const result = await safeFetchText('http://example.com/', { timeoutMs: 5000, maxBytes: 100, maxRedirects: 3 }, deps);
    ok(result.truncated === true, 'correctly flagged as truncated');
    ok(result.text.length < bigText.length, 'actual returned text is shorter than the full body (stopped reading, not just mislabeled)');
  }

  console.log('\nsafeFetchText: non-2xx status is a clear error, not silently swallowed');
  {
    const deps = mockDeps('93.184.216.34', () => new Response('not found', { status: 404 }));
    await throwsWith(() => safeFetchText('http://example.com/missing', { timeoutMs: 5000, maxBytes: 1000, maxRedirects: 3 }, deps), FetchToolError, '404 raises a clear FetchToolError');
  }

  console.log('\nsafeFetchText: too many redirects is rejected rather than looping forever');
  {
    const deps = {
      lookup: async () => ({ address: '8.8.8.8', family: 4 }),
      fetchImpl: (async () => new Response(null, { status: 302, headers: { location: 'http://example.com/next' } })) as typeof fetch,
    };
    await throwsWith(() => safeFetchText('http://example.com/start', { timeoutMs: 5000, maxBytes: 1000, maxRedirects: 2 }, deps), FetchToolError, 'redirect chain longer than maxRedirects is rejected');
  }

  console.log('\nstripHtmlToText: strips tags, scripts, and styles; decodes basic entities');
  {
    const html = '<html><head><style>.x{color:red}</style></head><body><script>alert(1)</script><h1>Title</h1><p>Hello &amp; welcome</p></body></html>';
    const text = stripHtmlToText(html);
    ok(!text.includes('<'), 'no raw tags left in output');
    ok(!text.includes('alert(1)'), 'script contents removed, not just the tags');
    ok(!text.includes('color:red'), 'style contents removed');
    ok(text.includes('Title'), 'visible text preserved');
    ok(text.includes('Hello & welcome'), 'HTML entity decoded correctly');
  }

  console.log(`\n${passed} passed, ${failed} failed`);
  if (failed > 0) process.exit(1);
}
run().catch((e) => { console.error('FATAL:', e); process.exit(1); });
