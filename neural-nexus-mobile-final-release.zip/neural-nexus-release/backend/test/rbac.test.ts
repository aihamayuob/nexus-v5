import { hasPermission, canActOnMember } from '../src/accounts/rbac.js';

let passed = 0, failed = 0;
function ok(cond: boolean, label: string) {
  if (cond) { passed++; console.log(`  ok   ${label}`); }
  else { failed++; console.log(`  FAIL ${label}`); }
}

console.log('hasPermission: role hierarchy is respected (owner > admin > member > viewer)');
ok(hasPermission('owner', 'workspace.delete'), 'owner can delete workspace');
ok(!hasPermission('admin', 'workspace.delete'), 'admin CANNOT delete workspace');
ok(hasPermission('admin', 'members.invite'), 'admin can invite members');
ok(!hasPermission('member', 'members.invite'), 'member CANNOT invite members');
ok(hasPermission('member', 'app.use'), 'member can use the app');
ok(!hasPermission('viewer', 'app.use'), 'viewer CANNOT use the app (read-only by design)');
ok(hasPermission('viewer', 'members.view'), 'viewer can at least view members');
ok(hasPermission('owner', 'app.use'), 'owner implicitly has every lower permission too');

console.log('\nhasPermission: billing is owner-only to manage, admin-viewable');
ok(hasPermission('owner', 'workspace.billing.manage'), 'owner can manage billing');
ok(!hasPermission('admin', 'workspace.billing.manage'), 'admin CANNOT manage billing (cannot change/cancel subscription)');
ok(hasPermission('admin', 'workspace.billing.view'), 'admin CAN view billing status');
ok(!hasPermission('member', 'workspace.billing.view'), 'member cannot view billing at all');

console.log('\ncanActOnMember: the owner can never be removed or demoted via normal member actions');
ok(!canActOnMember('admin', 'owner', 'remove'), 'admin cannot remove the owner');
ok(!canActOnMember('owner', 'owner', 'remove'), 'not even the owner can remove themselves this way (must be an explicit transfer flow)');
ok(!canActOnMember('admin', 'owner', 'changeRole'), 'admin cannot demote the owner');

console.log('\ncanActOnMember: peers cannot act on each other (rank must be strictly greater)');
ok(!canActOnMember('admin', 'admin', 'remove'), 'an admin cannot remove another admin (peer)');
ok(!canActOnMember('member', 'member', 'remove'), 'a member cannot remove another member');
ok(!canActOnMember('viewer', 'viewer', 'remove'), 'a viewer cannot remove another viewer (also lacks members.remove anyway)');

console.log('\ncanActOnMember: real, permitted actions succeed');
ok(canActOnMember('owner', 'admin', 'remove'), 'owner can remove an admin');
ok(canActOnMember('admin', 'member', 'remove'), 'admin can remove a member');
ok(canActOnMember('admin', 'viewer', 'changeRole'), 'admin can change a viewer\'s role');
ok(canActOnMember('owner', 'admin', 'changeRole'), 'owner can change an admin\'s role');

console.log('\ncanActOnMember: cannot act "upward" even with sufficient base permission');
ok(!canActOnMember('admin', 'owner', 'remove'), 'admin has members.remove permission in general, but still cannot remove the higher-ranked owner');

console.log(`\n${passed} passed, ${failed} failed`);
if (failed > 0) process.exit(1);
