import { buildGoogleAuthUrl, decodeIdToken, exchangeCodeForTokens, GoogleOAuthError } from '../src/accounts/googleOAuth.js';

let passed = 0, failed = 0;
function ok(cond: boolean, label: string) {
  if (cond) { passed++; console.log(`  ok   ${label}`); }
  else { failed++; console.log(`  FAIL ${label}`); }
}
async function throwsWith(fn: () => Promise<any> | any, ErrorClass: any, label: string) {
  try { await fn(); failed++; console.log(`  FAIL ${label} (did not throw)`); }
  catch (e) {
    if (e instanceof ErrorClass) { passed++; console.log(`  ok   ${label}`); }
    else { failed++; console.log(`  FAIL ${label} (wrong type: ${(e as Error).message})`); }
  }
}

function fakeIdToken(claims: object): string {
  const b64 = (obj: object) => Buffer.from(JSON.stringify(obj)).toString('base64url');
  return `${b64({ alg: 'RS256', typ: 'JWT' })}.${b64(claims)}.fakesignature`;
}

const CLIENT_ID = 'test-client-id.apps.googleusercontent.com';

console.log('buildGoogleAuthUrl: produces a well-formed Google authorization URL with required params');
{
  const url = buildGoogleAuthUrl(CLIENT_ID, 'https://myapp.com/callback', 'random-state-123');
  const parsed = new URL(url);
  ok(parsed.origin + parsed.pathname === 'https://accounts.google.com/o/oauth2/v2/auth', 'correct base URL');
  ok(parsed.searchParams.get('client_id') === CLIENT_ID, 'client_id present');
  ok(parsed.searchParams.get('redirect_uri') === 'https://myapp.com/callback', 'redirect_uri present');
  ok(parsed.searchParams.get('state') === 'random-state-123', 'state (CSRF token) present');
  ok(parsed.searchParams.get('scope') === 'openid email profile', 'correct scopes requested');
}

console.log('\ndecodeIdToken: accepts a well-formed, valid token');
{
  const token = fakeIdToken({
    iss: 'https://accounts.google.com', aud: CLIENT_ID, sub: 'google-user-123',
    email: 'user@example.com', email_verified: true, name: 'Test User', picture: 'https://x/pic.jpg',
    exp: Math.floor(Date.now() / 1000) + 3600,
  });
  const claims = decodeIdToken(token, CLIENT_ID);
  ok(claims.sub === 'google-user-123', 'sub extracted');
  ok(claims.email === 'user@example.com', 'email extracted');
  ok(claims.emailVerified === true, 'email_verified extracted');
  ok(claims.name === 'Test User', 'name extracted');
}

console.log('\ndecodeIdToken: rejects wrong audience (this is what stops a token issued for a DIFFERENT app being replayed here)');
{
  const token = fakeIdToken({ iss: 'https://accounts.google.com', aud: 'some-other-app-client-id', sub: 'x', email: 'a@b.com', exp: Math.floor(Date.now()/1000)+3600 });
  await throwsWith(() => decodeIdToken(token, CLIENT_ID), GoogleOAuthError, 'token issued for a different client_id is rejected');
}

console.log('\ndecodeIdToken: rejects wrong/spoofed issuer');
{
  const token = fakeIdToken({ iss: 'https://evil.com', aud: CLIENT_ID, sub: 'x', email: 'a@b.com', exp: Math.floor(Date.now()/1000)+3600 });
  await throwsWith(() => decodeIdToken(token, CLIENT_ID), GoogleOAuthError, 'non-Google issuer is rejected');
}

console.log('\ndecodeIdToken: rejects an expired token');
{
  const token = fakeIdToken({ iss: 'https://accounts.google.com', aud: CLIENT_ID, sub: 'x', email: 'a@b.com', exp: Math.floor(Date.now()/1000) - 3600 });
  await throwsWith(() => decodeIdToken(token, CLIENT_ID), GoogleOAuthError, 'expired token (exp in the past) is rejected');
}

console.log('\ndecodeIdToken: rejects malformed tokens gracefully (not a hard crash)');
{
  await throwsWith(() => decodeIdToken('not.a.validbase64jwt!!!', CLIENT_ID), GoogleOAuthError, 'garbage payload rejected cleanly');
  await throwsWith(() => decodeIdToken('only.two.parts.here', CLIENT_ID), GoogleOAuthError, 'too many segments rejected');
  await throwsWith(() => decodeIdToken('onepart', CLIENT_ID), GoogleOAuthError, 'not a JWT at all rejected');
}

console.log('\ndecodeIdToken: rejects a token missing required claims');
{
  const token = fakeIdToken({ iss: 'https://accounts.google.com', aud: CLIENT_ID, exp: Math.floor(Date.now()/1000)+3600 }); // no sub/email
  await throwsWith(() => decodeIdToken(token, CLIENT_ID), GoogleOAuthError, 'missing sub/email claims rejected');
}

console.log('\nexchangeCodeForTokens: real HTTP call to the mocked token endpoint, correct request shape');
{
  let capturedBody = '';
  let capturedUrl = '';
  const mockFetch = (async (url: string, opts: any) => {
    capturedUrl = String(url);
    capturedBody = opts.body;
    return new Response(JSON.stringify({ id_token: 'fake.id.token', access_token: 'fake-access-token' }), { status: 200 });
  }) as typeof fetch;

  const tokens = await exchangeCodeForTokens('auth-code-abc', CLIENT_ID, 'client-secret-xyz', 'https://myapp.com/callback', mockFetch);
  ok(tokens.idToken === 'fake.id.token', 'id_token returned correctly');
  ok(capturedUrl === 'https://oauth2.googleapis.com/token', 'called the correct Google endpoint');
  const params = new URLSearchParams(capturedBody);
  ok(params.get('code') === 'auth-code-abc', 'authorization code included in request');
  ok(params.get('client_secret') === 'client-secret-xyz', 'client_secret included (never sent to the browser, only server-to-server)');
  ok(params.get('grant_type') === 'authorization_code', 'correct grant_type');
}

console.log('\nexchangeCodeForTokens: surfaces a clear error on a failed exchange (e.g. expired/reused code)');
{
  const mockFetch = (async () => new Response('{"error":"invalid_grant"}', { status: 400 })) as typeof fetch;
  await throwsWith(() => exchangeCodeForTokens('bad-code', CLIENT_ID, 'secret', 'https://myapp.com/callback', mockFetch), GoogleOAuthError, 'HTTP 400 from Google surfaces as a clear GoogleOAuthError');
}

console.log(`\n${passed} passed, ${failed} failed`);
if (failed > 0) process.exit(1);
