import { validatePlan, PlanValidationError, DEFAULT_RUNTIME_CONFIG } from '../src/runtime/types.js';
import { createPlan } from '../src/runtime/planner.js';
import { buildTaskContext } from '../src/runtime/memory.js';
import { runReflection } from '../src/runtime/reflection.js';
import { createMockAdapter } from './mockAdapter.js';

let passed = 0, failed = 0;
function ok(cond: boolean, label: string) {
  if (cond) { passed++; console.log(`  ok   ${label}`); }
  else { failed++; console.log(`  FAIL ${label}`); }
}
function throws(fn: () => void, label: string) {
  try { fn(); failed++; console.log(`  FAIL ${label} (did not throw)`); }
  catch { passed++; console.log(`  ok   ${label}`); }
}

async function run() {
  console.log('validatePlan: accepts a valid DAG');
  {
    ok((() => { validatePlan({ goal: 'g', tasks: [{ id: 'a', description: 'x', dependsOn: [] }, { id: 'b', description: 'y', dependsOn: ['a'] }] }); return true; })(), 'valid plan does not throw');
  }

  console.log('validatePlan: rejects structural problems');
  {
    throws(() => validatePlan({ goal: 'g', tasks: [] }), 'empty task list rejected');
    throws(() => validatePlan({ goal: 'g', tasks: [{ id: 'a', description: 'x', dependsOn: [] }, { id: 'a', description: 'y', dependsOn: [] }] }), 'duplicate id rejected');
    throws(() => validatePlan({ goal: 'g', tasks: [{ id: 'a', description: 'x', dependsOn: ['ghost'] }] }), 'dangling dependency reference rejected');
    throws(() => validatePlan({ goal: 'g', tasks: [{ id: 'a', description: 'x', dependsOn: ['a'] }] }), 'self-dependency rejected');
    throws(() => validatePlan({ goal: 'g', tasks: [{ id: 'a', description: 'x', dependsOn: ['b'] }, { id: 'b', description: 'y', dependsOn: ['a'] }] }), 'simple 2-cycle rejected');
    throws(() => validatePlan({ goal: 'g', tasks: [{ id: 'a', dependsOn: ['b'] } as any, { id: 'b', dependsOn: ['c'] } as any, { id: 'c', dependsOn: ['a'] } as any] }), '3-cycle rejected');
  }

  console.log('planner.createPlan: parses clean JSON on first try');
  {
    const { adapter } = createMockAdapter('anthropic', () =>
      JSON.stringify({ goal: 'اختبار', tasks: [{ id: 't1', description: 'd1', dependsOn: [] }] })
    );
    const plan = await createPlan('اختبار', adapter, 'model', new AbortController().signal);
    ok(plan.tasks.length === 1 && plan.tasks[0].id === 't1', 'plan parsed correctly on first attempt');
  }

  console.log('planner.createPlan: strips markdown code fences');
  {
    const { adapter } = createMockAdapter('anthropic', () =>
      '```json\n' + JSON.stringify({ goal: 'g', tasks: [{ id: 't1', description: 'd', dependsOn: [] }] }) + '\n```'
    );
    const plan = await createPlan('g', adapter, 'model', new AbortController().signal);
    ok(plan.tasks.length === 1, 'fenced JSON extracted and parsed correctly');
  }

  console.log('planner.createPlan: recovers from a malformed first attempt via corrective retry');
  {
    const { adapter, calls } = createMockAdapter('anthropic', (_call, i) =>
      i === 0 ? 'this is not json at all' : JSON.stringify({ goal: 'g', tasks: [{ id: 't1', description: 'd', dependsOn: [] }] })
    );
    const plan = await createPlan('g', adapter, 'model', new AbortController().signal);
    ok(plan.tasks.length === 1, 'second attempt succeeded after first was malformed');
    ok(calls.length === 2, 'exactly 2 calls made (1 failed + 1 corrective retry)');
    ok(calls[1].userContent.includes('محاولتك السابقة فشلت'), 'the retry prompt includes the specific validation error, not just a generic retry');
  }

  console.log('planner.createPlan: gives up after exhausting retries on a persistently broken planner');
  {
    const { adapter } = createMockAdapter('anthropic', () => 'still not json');
    let threw = false;
    try { await createPlan('g', adapter, 'model', new AbortController().signal, 2); }
    catch { threw = true; }
    ok(threw, 'throws PlanValidationError after exhausting maxAttempts instead of hanging or returning garbage');
  }

  console.log('memory.buildTaskContext: under threshold is verbatim, zero LLM calls');
  {
    const { adapter, calls } = createMockAdapter('anthropic', () => 'should not be called');
    const ctx = await buildTaskContext([{ taskId: 'a', output: 'short output' }], DEFAULT_RUNTIME_CONFIG, adapter, new AbortController().signal);
    ok(ctx.includes('short output'), 'verbatim content present');
    ok(calls.length === 0, 'no LLM call made for small context (cost/latency matters)');
  }

  console.log('memory.buildTaskContext: over threshold triggers exactly one compression call');
  {
    const bigOutput = 'x'.repeat(10_000);
    const { adapter, calls } = createMockAdapter('anthropic', () => 'compressed summary here');
    const cfg = { ...DEFAULT_RUNTIME_CONFIG, contextCompressionThresholdChars: 1000 };
    const ctx = await buildTaskContext([{ taskId: 'a', output: bigOutput }], cfg, adapter, new AbortController().signal);
    ok(calls.length === 1, 'exactly one compression call made');
    ok(ctx.includes('compressed summary here'), 'compressed summary present in output');
    ok(ctx.length < bigOutput.length, 'result is actually smaller than the original (compression had an effect)');
    ok(ctx.includes('ملخّص مضغوط'), 'output is honestly labeled as compressed, not silently passed off as complete');
  }

  console.log('reflection.runReflection: parses pass/revise verdicts correctly');
  {
    const { adapter: passAdapter } = createMockAdapter('anthropic', () => '{"verdict": "pass"}');
    const passResult = await runReflection('do X', 'did X', passAdapter, 'model', new AbortController().signal);
    ok(passResult.verdict === 'pass', 'pass verdict parsed correctly');

    const { adapter: reviseAdapter } = createMockAdapter('anthropic', () => '{"verdict": "revise", "reason": "missing Y"}');
    const reviseResult = await runReflection('do X and Y', 'did only X', reviseAdapter, 'model', new AbortController().signal);
    ok(reviseResult.verdict === 'revise' && reviseResult.reason === 'missing Y', 'revise verdict + reason parsed correctly');
  }

  console.log('reflection.runReflection: fails closed (defaults to pass) on malformed critic output');
  {
    const { adapter } = createMockAdapter('anthropic', () => 'the critic rambled instead of returning JSON');
    const result = await runReflection('do X', 'did X', adapter, 'model', new AbortController().signal);
    ok(result.verdict === 'pass', 'malformed critic response defaults to pass rather than blocking the plan');
  }

  console.log(`\n${passed} passed, ${failed} failed`);
  if (failed > 0) process.exit(1);
}
run().catch((e) => { console.error('FATAL:', e); process.exit(1); });
