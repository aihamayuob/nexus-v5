import { AccountsStore } from '../src/accounts/store.js';
import { generatePrefixedToken, hashToken } from '../src/accounts/tokens.js';

let passed = 0;
let failed = 0;
function ok(condition: boolean, label: string) {
  if (condition) { passed++; console.log(`  ok   ${label}`); }
  else { failed++; console.log(`  FAIL ${label}`); }
}

const store = new AccountsStore(':memory:');
const user = store.findOrCreateUserByGoogle('google-mobile-test', 'mobile@example.com', 'Mobile User', null);

console.log('mobile one-time authorization code: one use only');
{
  const code = generatePrefixedToken('nxc_', 24);
  store.createMobileAuthCode(user.id, code.hash, 60_000);
  const first = store.consumeMobileAuthCode(hashToken(code.raw));
  const second = store.consumeMobileAuthCode(hashToken(code.raw));
  ok(first?.id === user.id, 'first exchange resolves the correct user');
  ok(second === null, 'second exchange is rejected');
}

console.log('mobile session: bearer token can be resolved and revoked');
{
  const session = generatePrefixedToken('nxm_live_');
  store.createSession(user.id, session.hash, 60_000);
  ok(store.getSessionUser(hashToken(session.raw))?.id === user.id, 'mobile session resolves');
  store.deleteSession(hashToken(session.raw));
  ok(store.getSessionUser(hashToken(session.raw)) === null, 'mobile session revoke works');
}

store.close();
console.log(`\n${passed} passed, ${failed} failed`);
if (failed > 0) process.exit(1);
