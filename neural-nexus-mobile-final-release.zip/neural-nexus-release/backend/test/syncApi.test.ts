import { createServer } from 'node:http';
import { createApp } from '../src/app.js';
import { loadEnv } from '../src/config/env.js';
import { createLogger } from '../src/lib/logger.js';

let passed = 0, failed = 0;
function ok(cond: boolean, label: string) {
  if (cond) { passed++; console.log(`  ok   ${label}`); }
  else { failed++; console.log(`  FAIL ${label}`); }
}

async function run() {
  const gatewayKey = 'sync-test-gateway-key-0123456789abcdef012345';
  process.env.GATEWAY_API_KEY = gatewayKey;
  process.env.ANTHROPIC_API_KEY = 'fake-key';
  process.env.RATE_LIMIT_MAX_REQUESTS = '1000';
  process.env.SYNC_DB_PATH = ':memory:';

  const env = loadEnv();
  const log = createLogger('error');
  const handler = createApp(env, log);
  const server = createServer((req, res) => { handler(req, res); });
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve));
  const address = server.address();
  if (typeof address !== 'object' || address === null) throw new Error('bind failed');
  const base = `http://127.0.0.1:${address.port}`;
  const authHeaders = { authorization: `Bearer ${gatewayKey}`, 'content-type': 'application/json' };

  console.log('GET /api/sync with nothing pushed yet -> 404');
  {
    const res = await fetch(`${base}/api/sync`, { headers: authHeaders });
    ok(res.status === 404, `status 404 (got ${res.status})`);
  }

  console.log('PUT /api/sync — first device pushes (baseVersion 0) -> 200, version 1');
  {
    const res = await fetch(`${base}/api/sync`, {
      method: 'PUT', headers: authHeaders,
      body: JSON.stringify({ baseVersion: 0, deviceId: 'phone-A', saltB64: 'salt1', ivB64: 'iv1', ciphertextB64: 'encrypted-state-v1' }),
    });
    const json = await res.json();
    ok(res.status === 200, `status 200 (got ${res.status})`);
    ok(json.version === 1, 'version is 1');
    ok(json.deviceId === 'phone-A', 'deviceId recorded');
  }

  console.log('GET /api/sync — second device pulls what was just pushed');
  {
    const res = await fetch(`${base}/api/sync`, { headers: authHeaders });
    const json = await res.json();
    ok(res.status === 200, 'status 200');
    ok(json.ciphertextB64 === 'encrypted-state-v1', 'ciphertext matches what was pushed');
    ok(json.saltB64 === 'salt1', 'salt (non-secret, needed for key derivation) round-trips');
  }

  console.log('PUT /api/sync — second device pushes correctly at baseVersion 1 -> succeeds, version 2');
  {
    const res = await fetch(`${base}/api/sync`, {
      method: 'PUT', headers: authHeaders,
      body: JSON.stringify({ baseVersion: 1, deviceId: 'laptop-B', saltB64: 'salt1', ivB64: 'iv2', ciphertextB64: 'encrypted-state-v2' }),
    });
    const json = await res.json();
    ok(res.status === 200, 'status 200');
    ok(json.version === 2, 'version incremented to 2');
  }

  console.log('PUT /api/sync — CONFLICT: a third device pushes with a stale baseVersion (1, but server is at 2) -> 409');
  {
    const res = await fetch(`${base}/api/sync`, {
      method: 'PUT', headers: authHeaders,
      body: JSON.stringify({ baseVersion: 1, deviceId: 'tablet-C', saltB64: 'salt1', ivB64: 'iv3', ciphertextB64: 'encrypted-state-from-C' }),
    });
    const json = await res.json();
    ok(res.status === 409, `status 409 (got ${res.status})`);
    ok(json.error?.code === 'sync_conflict', 'error code is sync_conflict');
    ok(json.current?.version === 2, 'response includes the real current version so the client can resolve it');
    ok(json.current?.ciphertextB64 === 'encrypted-state-v2', 'response shows what actually won — B\'s data is intact, not silently overwritten by C');
  }

  console.log('PUT /api/sync — without auth -> 401 (sync respects the same gateway auth as everything else)');
  {
    const res = await fetch(`${base}/api/sync`, {
      method: 'PUT', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ baseVersion: 2, deviceId: 'x', saltB64: 's', ivB64: 'i', ciphertextB64: 'c' }),
    });
    ok(res.status === 401, `status 401 (got ${res.status})`);
  }

  console.log('PUT /api/sync — missing field -> 400 validation error');
  {
    const res = await fetch(`${base}/api/sync`, { method: 'PUT', headers: authHeaders, body: JSON.stringify({ baseVersion: 2 }) });
    ok(res.status === 400, `status 400 (got ${res.status})`);
  }

  console.log('DELETE /api/sync -> wipes it, subsequent GET is 404 again');
  {
    const del = await fetch(`${base}/api/sync`, { method: 'DELETE', headers: authHeaders });
    ok(del.status === 200, 'delete status 200');
    const after = await fetch(`${base}/api/sync`, { headers: authHeaders });
    ok(after.status === 404, 'GET after delete is 404 again');
  }

  console.log('Full lifecycle survives after delete: fresh push starts again at version 1');
  {
    const res = await fetch(`${base}/api/sync`, {
      method: 'PUT', headers: authHeaders,
      body: JSON.stringify({ baseVersion: 0, deviceId: 'phone-A', saltB64: 'salt2', ivB64: 'iv1', ciphertextB64: 'fresh-start' }),
    });
    const json = await res.json();
    ok(res.status === 200 && json.version === 1, 'fresh cycle works correctly after a full wipe');
  }

  console.log('OPTIONS preflight for PUT /api/sync includes PUT in Allow-Methods (regression test for a real bug found via manual testing)');
  {
    const res = await fetch(`${base}/api/sync`, { method: 'OPTIONS', headers: { origin: 'http://example.com', 'access-control-request-method': 'PUT' } });
    const allowMethods = res.headers.get('access-control-allow-methods') || '';
    ok(allowMethods.includes('PUT'), `Allow-Methods includes PUT (got: "${allowMethods}")`);
  }

  server.close();
  console.log(`\n${passed} passed, ${failed} failed`);
  if (failed > 0) process.exit(1);
}
run().catch((e) => { console.error('FATAL:', e); process.exit(1); });
