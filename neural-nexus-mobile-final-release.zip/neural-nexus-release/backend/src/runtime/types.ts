/**
 * The Agent Runtime models a goal as a DAG of tasks (a Plan), not a
 * fixed linear script. This is what makes it a genuine "execution
 * graph" rather than the sequential/parallel-batch patterns already
 * used elsewhere in this codebase (cross-examination, situation room,
 * etc. are all hand-written fixed sequences — this runtime instead
 * lets the LLM decide the shape of the graph itself, per goal).
 */

export interface TaskDef {
  id: string;
  description: string;
  /** ids of tasks that must reach 'done' before this one can start. */
  dependsOn: string[];
  /** Optional persona/system-prompt fragment for this specific task. */
  agentPersona?: string;
  provider?: string;
  model?: string;
}

export interface Plan {
  goal: string;
  tasks: TaskDef[];
}

export type TaskStatus = 'pending' | 'running' | 'done' | 'failed' | 'skipped';

export interface TaskResult {
  taskId: string;
  status: TaskStatus;
  output?: string;
  error?: string;
  attempts: number;
}

export interface RuntimeConfig {
  maxConcurrency: number;
  maxRetriesPerTask: number;
  reflectionEnabled: boolean;
  /** Once accumulated dependency context for a task exceeds this many
   *  characters, older entries get compressed via an LLM summarization
   *  call instead of being passed in verbatim. */
  contextCompressionThresholdChars: number;
  defaultProvider: string;
  defaultModel: string;
}

export const DEFAULT_RUNTIME_CONFIG: RuntimeConfig = {
  maxConcurrency: 3,
  maxRetriesPerTask: 2,
  reflectionEnabled: true,
  contextCompressionThresholdChars: 6000,
  defaultProvider: 'anthropic',
  defaultModel: 'claude-sonnet-4-6',
};

/** Normalized progress event stream the executor emits — reuses the
 *  exact same SSE transport (lib/httpUtil.ts, lib/streamBuffer.ts) as
 *  Phase 1's chat streaming, just with a different event vocabulary. */
export type RuntimeEvent =
  | { type: 'plan_start'; totalTasks: number }
  | { type: 'task_start'; taskId: string; description: string }
  | { type: 'task_token'; taskId: string; text: string }
  | { type: 'task_retry'; taskId: string; attempt: number; reason: string }
  | { type: 'task_reflection'; taskId: string; verdict: 'pass' | 'revise'; critique?: string }
  | { type: 'task_done'; taskId: string; output: string }
  | { type: 'task_failed'; taskId: string; error: string }
  | { type: 'task_skipped'; taskId: string; reason: string }
  | { type: 'synthesis_token'; text: string }
  | { type: 'plan_done'; finalOutput: string }
  | { type: 'plan_error'; message: string };

export class PlanValidationError extends Error {}

/**
 * Validates structural integrity of a plan: unique ids, all dependsOn
 * references resolve to real tasks, and the dependency graph is acyclic
 * (a cycle would mean no task in the cycle can ever become "ready" —
 * silently hanging forever, which is a much worse failure mode than
 * rejecting it up front with a clear error).
 */
export function validatePlan(plan: Plan): void {
  if (!plan.tasks || plan.tasks.length === 0) {
    throw new PlanValidationError('Plan has no tasks.');
  }

  const ids = new Set<string>();
  for (const t of plan.tasks) {
    if (!t.id) throw new PlanValidationError('A task is missing an id.');
    if (ids.has(t.id)) throw new PlanValidationError(`Duplicate task id: "${t.id}".`);
    ids.add(t.id);
  }
  for (const t of plan.tasks) {
    for (const dep of t.dependsOn ?? []) {
      if (!ids.has(dep)) {
        throw new PlanValidationError(`Task "${t.id}" depends on unknown task "${dep}".`);
      }
      if (dep === t.id) {
        throw new PlanValidationError(`Task "${t.id}" cannot depend on itself.`);
      }
    }
  }

  // Cycle detection via Kahn's algorithm: repeatedly remove tasks with
  // no remaining unresolved dependencies. If tasks remain after no more
  // can be removed, those remaining tasks form a cycle.
  const remaining = new Map(plan.tasks.map((t) => [t.id, new Set(t.dependsOn ?? [])]));
  let progressed = true;
  while (remaining.size > 0 && progressed) {
    progressed = false;
    for (const [id, deps] of [...remaining]) {
      if (deps.size === 0) {
        remaining.delete(id);
        for (const otherDeps of remaining.values()) otherDeps.delete(id);
        progressed = true;
      }
    }
  }
  if (remaining.size > 0) {
    throw new PlanValidationError(`Plan contains a dependency cycle involving: ${[...remaining.keys()].join(', ')}.`);
  }
}
