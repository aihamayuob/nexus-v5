import type { ProviderAdapter } from '../providers/types.js';

export interface ReflectionVerdict {
  verdict: 'pass' | 'revise';
  reason?: string;
}

const REFLECTION_SYSTEM = `أنت مراجع صارم لمخرجات مهام. ستُعطى وصف مهمة ومخرجاً ناتجاً عن تنفيذها. قيّم فقط: هل المخرج ينفّذ المهمة المطلوبة فعلاً (لا ناقص، لا خارج عن الموضوع، لا رفض غير مبرر)؟ لا تقيّم جودة الأسلوب أو الطول، فقط الالتزام الفعلي بالمهمة.

أجب حصراً بصيغة JSON بدون أي نص إضافي: {"verdict": "pass"} أو {"verdict": "revise", "reason": "سبب محدد وقابل للتنفيذ لما ينقص"}.`;

/**
 * A single bounded critique pass — deliberately narrow in scope (did the
 * output address the task, not "is it good writing") so it fails closed
 * (defaults to 'pass') rather than becoming an infinite nitpicking loop.
 * Any error here is treated as 'pass' by the caller — reflection is a
 * quality improvement, not a correctness gate; a broken critic must
 * never be able to block a plan from completing.
 */
export async function runReflection(
  taskDescription: string,
  output: string,
  adapter: ProviderAdapter,
  model: string,
  signal: AbortSignal
): Promise<ReflectionVerdict> {
  const res = await adapter.chat(
    {
      provider: adapter.name,
      model,
      system: REFLECTION_SYSTEM,
      messages: [{ role: 'user', content: `وصف المهمة:\n${taskDescription}\n\nالمخرج الناتج:\n${output}` }],
      maxTokens: 300,
    },
    signal
  );
  const textBlock = res.content.find((b) => b.type === 'text');
  const raw = textBlock && textBlock.type === 'text' ? textBlock.text : '';
  const firstBrace = raw.indexOf('{');
  const lastBrace = raw.lastIndexOf('}');
  if (firstBrace === -1 || lastBrace <= firstBrace) return { verdict: 'pass' };

  try {
    const parsed = JSON.parse(raw.slice(firstBrace, lastBrace + 1));
    if (parsed.verdict === 'revise') return { verdict: 'revise', reason: String(parsed.reason ?? 'غير محدد') };
    return { verdict: 'pass' };
  } catch {
    return { verdict: 'pass' };
  }
}
