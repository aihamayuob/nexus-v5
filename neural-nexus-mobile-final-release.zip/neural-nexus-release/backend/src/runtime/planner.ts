import type { ProviderAdapter } from '../providers/types.js';
import type { Plan } from './types.js';
import { PlanValidationError, validatePlan } from './types.js';

const PLANNER_SYSTEM_PROMPT = `أنت مخطط مهام (Task Planner) لنظام وكلاء ذكاء اصطناعي. مهمتك الوحيدة: تفكيك هدف المستخدم إلى شبكة مهام فرعية (DAG) قابلة للتنفيذ، كل مهمة تُسند لاحقاً إلى نموذج لغوي واحد ينفذها بمعزل عن غيره (لا يرى إلا مخرجات المهام التي يعتمد عليها).

قواعد صارمة:
- أجب حصراً بكائن JSON صالح واحد، بدون أي نص أو شرح أو Markdown قبله أو بعده.
- كل مهمة لها: "id" (نص قصير فريد بالإنجليزية، مثل "research_market")، "description" (وصف دقيق وقابل للتنفيذ بالعربية لما يجب أن تنتجه هذه المهمة تحديداً)، "dependsOn" (مصفوفة من ids لمهام يجب أن تكتمل أولاً — فارغة [] إذا لا تعتمد على شيء).
- فكك الهدف إلى 2-6 مهام حقيقية ومتمايزة. لا تصنع مهمة واحدة فقط تكرر الهدف حرفياً — هذا فشل بالتخطيط.
- مهام لا تعتمد على بعضها (نفس المستوى) ستُنفَّذ بالتوازي فعلياً — استغل هذا لتوزيع البحث/التحليل المستقل، واستخدم dependsOn فقط عندما تحتاج مهمة لاحقة نتائج مهمة سابقة فعلياً.

الشكل المطلوب بالضبط:
{"goal": "...", "tasks": [{"id": "...", "description": "...", "dependsOn": []}]}`;

function extractJSON(raw: string): string {
  // Models sometimes wrap JSON in ```json fences despite instructions —
  // strip that before parsing rather than failing outright.
  const fenced = raw.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
  if (fenced) return fenced[1];
  const firstBrace = raw.indexOf('{');
  const lastBrace = raw.lastIndexOf('}');
  if (firstBrace !== -1 && lastBrace > firstBrace) return raw.slice(firstBrace, lastBrace + 1);
  return raw;
}

function parseAndValidate(raw: string): Plan {
  let parsed: unknown;
  try {
    parsed = JSON.parse(extractJSON(raw));
  } catch (e: any) {
    throw new PlanValidationError(`Planner output was not valid JSON: ${e.message}`);
  }
  const plan = parsed as Plan;
  if (typeof plan !== 'object' || plan === null || !Array.isArray(plan.tasks)) {
    throw new PlanValidationError('Planner output JSON does not match the expected {goal, tasks[]} shape.');
  }
  for (const t of plan.tasks) {
    if (!Array.isArray(t.dependsOn)) t.dependsOn = [];
  }
  validatePlan(plan);
  return plan;
}

/**
 * Produces a validated Plan for `goal`. If the model's first attempt is
 * malformed (bad JSON, cycle, dangling dependency reference), the exact
 * validation error is fed back to the model for one corrective retry
 * before giving up — LLMs are reliably good at fixing a specific,
 * named JSON error when shown it, much more so than getting it right
 * blind on a second unguided attempt.
 */
export async function createPlan(
  goal: string,
  adapter: ProviderAdapter,
  model: string,
  signal: AbortSignal,
  maxAttempts = 2
): Promise<Plan> {
  let lastError: Error | null = null;
  let userContent = goal;

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    const response = await adapter.chat(
      {
        provider: adapter.name,
        model,
        system: PLANNER_SYSTEM_PROMPT,
        messages: [{ role: 'user', content: userContent }],
        maxTokens: 1500,
      },
      signal
    );
    const textBlock = response.content.find((b) => b.type === 'text');
    const raw = textBlock && textBlock.type === 'text' ? textBlock.text : '';

    try {
      return parseAndValidate(raw);
    } catch (e: any) {
      lastError = e;
      userContent = `${goal}\n\n--- محاولتك السابقة فشلت بهذا الخطأ، صحّحه والتزم حصراً بصيغة JSON المطلوبة: ---\n${e.message}\n\nمخرجك السابق كان:\n${raw.slice(0, 800)}`;
    }
  }
  throw lastError ?? new PlanValidationError('Planning failed for an unknown reason.');
}
