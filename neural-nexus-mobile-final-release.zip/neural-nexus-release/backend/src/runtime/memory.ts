import type { ProviderAdapter } from '../providers/types.js';
import type { RuntimeConfig } from './types.js';

export interface DependencyResult {
  taskId: string;
  output: string;
}

/**
 * Builds the context string passed to a task from its dependencies'
 * outputs. Below the threshold, this is just a verbatim concatenation —
 * no LLM call, no cost, no risk of losing information for the common
 * case. Only once the combined size would genuinely bloat the next
 * call's context does this spend a call compressing it, and it says so
 * explicitly in the output (never silently pretends the full detail is
 * still there).
 */
export async function buildTaskContext(
  depResults: DependencyResult[],
  config: RuntimeConfig,
  adapter: ProviderAdapter,
  signal: AbortSignal
): Promise<string> {
  if (depResults.length === 0) return '';

  const verbatim = depResults.map((d) => `[نتيجة مهمة "${d.taskId}"]:\n${d.output}`).join('\n\n');
  if (verbatim.length <= config.contextCompressionThresholdChars) return verbatim;

  const compressSystem =
    'لخّص نتائج المهام الفرعية التالية بحيث تبقى كل معلومة أو رقم أو حقيقة قد تحتاجها مهمة لاحقة تعتمد عليها، مع حذف الحشو والتكرار والصياغة الزائدة. نظّم الملخص بفقرة قصيرة لكل مهمة، بالعربية.';
  try {
    const res = await adapter.chat(
      {
        provider: adapter.name,
        model: config.defaultModel,
        system: compressSystem,
        messages: [{ role: 'user', content: verbatim }],
        maxTokens: 800,
      },
      signal
    );
    const textBlock = res.content.find((b) => b.type === 'text');
    const summary = textBlock && textBlock.type === 'text' ? textBlock.text : null;
    if (!summary) throw new Error('Compression call returned no text.');
    return `[ملخّص مضغوط لنتائج سابقة — الحجم الأصلي كان كبيراً جداً لإرساله كاملاً]:\n${summary}`;
  } catch {
    // Compression is a cost/context optimization, not a correctness
    // requirement — if it fails, fall back to a hard truncation rather
    // than failing the whole task over what's ultimately an efficiency
    // concern.
    return `[تنبيه: نتائج سابقة طويلة تم اقتطاعها]:\n${verbatim.slice(0, config.contextCompressionThresholdChars)}`;
  }
}
