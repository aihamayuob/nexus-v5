import type { ProviderAdapter } from '../providers/types.js';
import { buildTaskContext } from './memory.js';
import { runReflection } from './reflection.js';
import type { Plan, TaskDef, TaskResult, RuntimeConfig, RuntimeEvent } from './types.js';
import { validatePlan } from './types.js';

export interface ExecutorDeps {
  adapters: Map<string, ProviderAdapter>;
  config: RuntimeConfig;
}

function isAbortError(e: any): boolean {
  return e?.name === 'AbortError';
}

/**
 * Executes `plan` as a real dependency graph: independent tasks run
 * concurrently (bounded by config.maxConcurrency), a task only starts
 * once every task it depends on has reached 'done', and a task whose
 * dependency permanently failed is marked 'skipped' rather than either
 * hanging forever or running with silently-missing context. This is an
 * async generator so the caller (the SSE route) can forward each event
 * to the client as it happens, exactly like Phase 1's chat streaming.
 */
export async function* runPlan(
  plan: Plan,
  deps: ExecutorDeps,
  signal: AbortSignal
): AsyncGenerator<RuntimeEvent> {
  validatePlan(plan); // throws synchronously — caller should also validate before starting, but never trust a plan twice
  const { adapters, config } = deps;
  const results = new Map<string, TaskResult>();

  const eventQueue: RuntimeEvent[] = [];
  let notify: (() => void) | null = null;
  function emit(ev: RuntimeEvent) {
    eventQueue.push(ev);
    if (notify) {
      const n = notify;
      notify = null;
      n();
    }
  }

  emit({ type: 'plan_start', totalTasks: plan.tasks.length });

  let runningCount = 0;
  const started = new Set<string>();
  let planSettled = false;

  function allTerminal(): boolean {
    return plan.tasks.every((t) => {
      const r = results.get(t.id);
      return r && r.status !== 'pending' && r.status !== 'running';
    });
  }

  async function executeTask(task: TaskDef): Promise<void> {
    results.set(task.id, { taskId: task.id, status: 'running', attempts: 0 });
    emit({ type: 'task_start', taskId: task.id, description: task.description });

    const depResults = task.dependsOn.map((dep) => ({ taskId: dep, output: results.get(dep)?.output ?? '' }));
    const providerName = task.provider || config.defaultProvider;
    const adapter = adapters.get(providerName);
    if (!adapter) {
      const error = `Unknown or unconfigured provider "${providerName}"`;
      results.set(task.id, { taskId: task.id, status: 'failed', error, attempts: 0 });
      emit({ type: 'task_failed', taskId: task.id, error });
      return;
    }

    let context: string;
    try {
      context = await buildTaskContext(depResults, config, adapter, signal);
    } catch {
      context = depResults.map((d) => `[${d.taskId}]: ${d.output}`).join('\n\n');
    }

    const model = task.model || config.defaultModel;
    const baseSystem =
      (task.agentPersona ? task.agentPersona + '\n\n' : '') +
      'أنت تنفذ مهمة فرعية واحدة ضمن خطة أكبر لتحقيق هدف: "' + plan.goal + '". مهمتك المحددة تحديداً هي: ' +
      task.description +
      (context ? '\n\nسياق من مهام سابقة اعتمدت عليها هذه المهمة:\n' + context : '') +
      '\n\nنفّذ المهمة مباشرة وبتركيز — لا تشرح أنك تنفذ مهمة، فقط أنتج المطلوب منها تحديداً.';

    let attempts = 0;
    let output = '';
    let lastError: Error | null = null;

    while (attempts < config.maxRetriesPerTask + 1) {
      attempts++;
      if (signal.aborted) {
        lastError = Object.assign(new Error('تم الإلغاء'), { name: 'AbortError' });
        break;
      }
      try {
        let text = '';
        for await (const ev of adapter.streamChat(
          { provider: providerName, model, system: baseSystem, messages: [{ role: 'user', content: task.description }] },
          signal
        )) {
          if (ev.type === 'token') {
            text += ev.text;
            emit({ type: 'task_token', taskId: task.id, text: ev.text });
          } else if (ev.type === 'error') {
            throw new Error(ev.message);
          }
        }
        output = text;
        lastError = null;
        break;
      } catch (e: any) {
        lastError = e;
        if (isAbortError(e)) break; // never retry a deliberate user cancellation
        if (attempts <= config.maxRetriesPerTask) {
          emit({ type: 'task_retry', taskId: task.id, attempt: attempts, reason: String(e.message ?? e) });
          await new Promise((r) => setTimeout(r, Math.min(1000 * 2 ** (attempts - 1), 8000)));
        }
      }
    }

    if (lastError) {
      results.set(task.id, { taskId: task.id, status: 'failed', error: String(lastError.message ?? lastError), attempts });
      emit({ type: 'task_failed', taskId: task.id, error: String(lastError.message ?? lastError) });
      return;
    }

    if (config.reflectionEnabled && !signal.aborted) {
      try {
        const verdict = await runReflection(task.description, output, adapter, config.defaultModel, signal);
        emit({ type: 'task_reflection', taskId: task.id, verdict: verdict.verdict, critique: verdict.reason });
        if (verdict.verdict === 'revise' && attempts <= config.maxRetriesPerTask && !signal.aborted) {
          emit({ type: 'task_retry', taskId: task.id, attempt: attempts + 1, reason: 'مراجعة ذاتية: ' + verdict.reason });
          const revisedSystem = baseSystem + '\n\nملاحظة من مراجعة ذاتية على محاولتك السابقة: ' + verdict.reason + '\nعالج هذه الملاحظة تحديداً في ردك الجديد.';
          let revisedText = '';
          try {
            for await (const ev of adapter.streamChat(
              { provider: providerName, model, system: revisedSystem, messages: [{ role: 'user', content: task.description }] },
              signal
            )) {
              if (ev.type === 'token') {
                revisedText += ev.text;
                emit({ type: 'task_token', taskId: task.id, text: ev.text });
              }
            }
            if (revisedText.trim()) output = revisedText;
          } catch {
            // revision attempt failed — keep the original (already-validated-enough-to-pass-through) output
          }
        }
      } catch {
        // reflection itself is best-effort; never let a broken critic block plan completion
      }
    }

    results.set(task.id, { taskId: task.id, status: 'done', output, attempts });
    emit({ type: 'task_done', taskId: task.id, output });
  }

  function scheduleReady(): void {
    for (const task of plan.tasks) {
      if (started.has(task.id)) continue;

      const blocked = task.dependsOn.some((d) => {
        const r = results.get(d);
        return r && (r.status === 'failed' || r.status === 'skipped');
      });
      if (blocked) {
        started.add(task.id);
        results.set(task.id, { taskId: task.id, status: 'skipped', attempts: 0 });
        emit({ type: 'task_skipped', taskId: task.id, reason: 'اعتمدت على مهمة فشلت أو تم تخطيها.' });
        continue;
      }

      const ready = task.dependsOn.every((d) => results.get(d)?.status === 'done');
      if (!ready) continue;
      if (runningCount >= config.maxConcurrency) continue; // don't break — a later, already-ready task might still fit conceptually next round; but simplest correct behavior is to just wait for a slot, so continue scanning is harmless (no other task will start this pass anyway once at cap, loop below still incurs O(n) scan which is fine at this scale)

      started.add(task.id);
      runningCount++;
      executeTask(task).finally(() => {
        runningCount--;
        if (!planSettled) {
          scheduleReady();
          if (allTerminal()) void finishPlan();
        }
      });
    }
  }

  async function finishPlan(): Promise<void> {
    if (planSettled) return;
    planSettled = true;

    if (signal.aborted) {
      emit({ type: 'plan_error', message: 'تم إلغاء الخطة.' });
      return;
    }

    const successful = plan.tasks.map((t) => results.get(t.id)!).filter((r) => r.status === 'done');
    if (successful.length === 0) {
      emit({ type: 'plan_error', message: 'فشلت جميع المهام — لا توجد نتائج يمكن تجميعها في إجابة نهائية.' });
      return;
    }

    try {
      const adapter = adapters.get(config.defaultProvider);
      if (!adapter) throw new Error(`Default provider "${config.defaultProvider}" is not configured.`);
      const combined = successful.map((r) => `[${r.taskId}]:\n${r.output}`).join('\n\n---\n\n');
      const synthesisSystem =
        'اجمع نتائج المهام الفرعية التالية في إجابة نهائية واحدة متماسكة تحقق الهدف الأصلي: "' + plan.goal +
        '". لا تعرض كل مهمة على حدة بشكل آلي — ألّف إجابة موحدة ومترابطة كأنها كُتبت مرة واحدة.';
      let text = '';
      for await (const ev of adapter.streamChat(
        { provider: config.defaultProvider, model: config.defaultModel, system: synthesisSystem, messages: [{ role: 'user', content: combined }] },
        signal
      )) {
        if (ev.type === 'token') {
          text += ev.text;
          emit({ type: 'synthesis_token', text: ev.text });
        }
      }
      emit({ type: 'plan_done', finalOutput: text });
    } catch (e: any) {
      emit({ type: 'plan_error', message: 'فشل التوليف النهائي: ' + String(e.message ?? e) });
    }
  }

  scheduleReady();

  while (true) {
    while (eventQueue.length > 0) {
      const ev = eventQueue.shift()!;
      yield ev;
      if (ev.type === 'plan_done' || ev.type === 'plan_error') return;
    }
    await new Promise<void>((res) => {
      notify = res;
    });
  }
}
