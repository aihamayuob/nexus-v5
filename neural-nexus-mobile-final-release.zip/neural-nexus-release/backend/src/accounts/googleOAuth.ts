export interface GoogleTokens {
  idToken: string;
  accessToken: string;
}

export interface GoogleClaims {
  sub: string;
  email: string;
  emailVerified: boolean;
  name: string | null;
  picture: string | null;
}

const GOOGLE_AUTH_URL = 'https://accounts.google.com/o/oauth2/v2/auth';
const GOOGLE_TOKEN_URL = 'https://oauth2.googleapis.com/token';
const VALID_ISSUERS = new Set(['https://accounts.google.com', 'accounts.google.com']);

export function buildGoogleAuthUrl(clientId: string, redirectUri: string, state: string): string {
  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri,
    response_type: 'code',
    scope: 'openid email profile',
    state,
    access_type: 'online',
    prompt: 'select_account',
  });
  return `${GOOGLE_AUTH_URL}?${params.toString()}`;
}

export class GoogleOAuthError extends Error {}

export async function exchangeCodeForTokens(
  code: string,
  clientId: string,
  clientSecret: string,
  redirectUri: string,
  fetchImpl: typeof fetch
): Promise<GoogleTokens> {
  const res = await fetchImpl(GOOGLE_TOKEN_URL, {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      code, client_id: clientId, client_secret: clientSecret, redirect_uri: redirectUri, grant_type: 'authorization_code',
    }).toString(),
  });
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new GoogleOAuthError(`Google token exchange failed (${res.status}): ${text.slice(0, 300)}`);
  }
  const data: any = await res.json();
  if (!data.id_token) throw new GoogleOAuthError('Google token response had no id_token.');
  return { idToken: data.id_token, accessToken: data.access_token };
}

/**
 * Decodes the id_token's claims WITHOUT re-verifying its RS256 signature
 * against Google's JWKS. This is deliberate, not a shortcut: the token
 * was obtained by exchanging an authorization code directly with
 * Google's token endpoint over TLS, authenticated with our own
 * client_secret — Google's response IS the trusted source here, unlike
 * the case where a browser-side Google Sign-In SDK hands a token to a
 * backend that has no other reason to trust it (that case genuinely
 * needs local signature verification against Google's JWKS). We still
 * sanity-check `aud` and `iss` as defense-in-depth against a
 * misconfigured proxy or unexpected response shape.
 */
export function decodeIdToken(idToken: string, expectedClientId: string): GoogleClaims {
  const parts = idToken.split('.');
  if (parts.length !== 3) throw new GoogleOAuthError('Malformed id_token (not a JWT).');
  let payload: any;
  try {
    payload = JSON.parse(Buffer.from(parts[1], 'base64url').toString('utf-8'));
  } catch (e: any) {
    throw new GoogleOAuthError(`Could not decode id_token payload: ${e.message}`);
  }
  if (!VALID_ISSUERS.has(payload.iss)) {
    throw new GoogleOAuthError(`Unexpected id_token issuer: "${payload.iss}"`);
  }
  if (payload.aud !== expectedClientId) {
    throw new GoogleOAuthError('id_token audience does not match this app\'s client ID.');
  }
  if (typeof payload.exp === 'number' && payload.exp * 1000 < Date.now()) {
    throw new GoogleOAuthError('id_token has expired.');
  }
  if (!payload.sub || !payload.email) {
    throw new GoogleOAuthError('id_token is missing required claims (sub/email).');
  }
  return {
    sub: payload.sub,
    email: payload.email,
    emailVerified: !!payload.email_verified,
    name: payload.name ?? null,
    picture: payload.picture ?? null,
  };
}
