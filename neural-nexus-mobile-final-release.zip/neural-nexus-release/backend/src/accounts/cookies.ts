export function parseCookies(header: string | undefined): Record<string, string> {
  const out: Record<string, string> = {};
  if (!header) return out;
  for (const part of header.split(';')) {
    const eq = part.indexOf('=');
    if (eq === -1) continue;
    const key = part.slice(0, eq).trim();
    const value = part.slice(eq + 1).trim();
    if (key) out[key] = decodeURIComponent(value);
  }
  return out;
}

export interface CookieOptions {
  maxAgeSeconds?: number;
  path?: string;
  httpOnly?: boolean;
  secure?: boolean;
  sameSite?: 'Strict' | 'Lax' | 'None';
}

export function serializeCookie(name: string, value: string, opts: CookieOptions = {}): string {
  const segments = [`${name}=${encodeURIComponent(value)}`];
  segments.push(`Path=${opts.path ?? '/'}`);
  if (opts.maxAgeSeconds !== undefined) segments.push(`Max-Age=${opts.maxAgeSeconds}`);
  if (opts.httpOnly !== false) segments.push('HttpOnly');
  if (opts.secure !== false) segments.push('Secure');
  segments.push(`SameSite=${opts.sameSite ?? 'Lax'}`);
  return segments.join('; ');
}

export function serializeExpiredCookie(name: string, path = '/', secure = true): string {
  return `${name}=; Path=${path}; Max-Age=0; HttpOnly; ${secure ? 'Secure; ' : ''}SameSite=Lax`;
}
