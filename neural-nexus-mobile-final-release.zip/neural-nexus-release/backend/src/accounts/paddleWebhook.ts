import { createHmac } from 'node:crypto';
import { safeEqual } from './tokens.js';

export class PaddleSignatureError extends Error {}

const MAX_AGE_SECONDS = 300; // reject anything older than 5 minutes — replay protection

/**
 * Paddle's Paddle-Signature header looks like `ts=1717000000;h1=<64 hex chars>`.
 * The signed material is `{ts}:{raw_body}` — NOT the body alone — so the
 * timestamp is itself part of what's authenticated, which is what makes
 * the age check below meaningful rather than cosmetic.
 *
 * Critically, `rawBody` must be the exact, unparsed bytes Paddle sent —
 * JSON.parse() then JSON.stringify()'ing the body before verifying will
 * reliably break this (key order, whitespace, and number formatting all
 * change on re-serialization), which is a well-documented real-world
 * integration bug, not a hypothetical one.
 */
export function verifyPaddleWebhookSignature(rawBody: string, signatureHeader: string | undefined, secret: string): void {
  if (!signatureHeader) throw new PaddleSignatureError('Missing Paddle-Signature header.');

  const parts: Record<string, string> = {};
  for (const segment of signatureHeader.split(';')) {
    const eq = segment.indexOf('=');
    if (eq === -1) continue;
    parts[segment.slice(0, eq).trim()] = segment.slice(eq + 1).trim();
  }
  const ts = parts.ts;
  const h1 = parts.h1;
  if (!ts || !h1) throw new PaddleSignatureError('Malformed Paddle-Signature header (missing ts or h1).');

  const tsNum = Number(ts);
  if (!Number.isFinite(tsNum)) throw new PaddleSignatureError('Non-numeric timestamp in Paddle-Signature header.');
  const ageSeconds = Math.abs(Date.now() / 1000 - tsNum);
  if (ageSeconds > MAX_AGE_SECONDS) {
    throw new PaddleSignatureError(`Webhook timestamp is ${Math.round(ageSeconds)}s old (limit ${MAX_AGE_SECONDS}s) — rejecting as a possible replay.`);
  }

  const expectedHmac = createHmac('sha256', secret).update(`${ts}:${rawBody}`).digest('hex');

  // Deliberately timing-safe: a naive `===`/`==` comparison here is a
  // real, documented vulnerability class (CVE/GHSA-tracked) — an
  // attacker can recover the valid signature byte-by-byte by measuring
  // response-time differences across repeated forged-signature probes.
  if (expectedHmac.length !== h1.length || !safeEqual(expectedHmac, h1)) {
    throw new PaddleSignatureError('Signature mismatch — request did not come from Paddle.');
  }
}

export interface PaddleSubscriptionEvent {
  eventType: string;
  subscriptionId: string;
  customerId: string;
  status: string; // 'active' | 'past_due' | 'canceled' | 'trialing' | ...
  customData: Record<string, unknown> | null; // we pass {workspaceId} through at checkout time
}

/** Parses the fields we actually act on out of a raw Paddle webhook
 *  payload, tolerant of the event types we don't handle (returns null
 *  for those, rather than throwing) — Paddle sends many event types
 *  (transaction.*, customer.*, etc.) and new ones get added over time;
 *  an unrecognized-but-harmless event should never break the endpoint. */
export function parsePaddleSubscriptionEvent(rawPayload: unknown): PaddleSubscriptionEvent | null {
  const payload = rawPayload as any;
  const eventType = payload?.event_type;
  if (typeof eventType !== 'string' || !eventType.startsWith('subscription.')) return null;

  const data = payload.data;
  if (!data?.id || !data?.customer_id || !data?.status) return null;

  return {
    eventType,
    subscriptionId: data.id,
    customerId: data.customer_id,
    status: data.status,
    customData: data.custom_data ?? null,
  };
}

/** Maps Paddle's subscription status vocabulary to this app's simpler
 *  active/past_due/canceled tri-state — Paddle has more granular
 *  statuses (trialing, paused, etc.) that we intentionally collapse. */
export function mapPaddleStatus(paddleStatus: string): 'active' | 'past_due' | 'canceled' {
  switch (paddleStatus) {
    case 'active':
    case 'trialing':
      return 'active';
    case 'past_due':
      return 'past_due';
    case 'canceled':
    case 'paused':
      return 'canceled';
    default:
      return 'past_due'; // unknown status — fail toward "needs attention", not silently "active"
  }
}
