import type { IncomingMessage } from 'node:http';
import { parseCookies } from './cookies.js';
import { hashToken } from './tokens.js';
import type { AccountsStore, User } from './store.js';

export const SESSION_COOKIE_NAME = 'nexus_session';

export interface ResolvedIdentity {
  user: User;
  /** Present only when authenticated via a workspace API key rather
   *  than a browser session — lets routes distinguish "a real logged-in
   *  person" from "an automated integration acting for a workspace". */
  viaApiKeyWorkspaceId: string | null;
  apiKeyId: string | null;
}

/**
 * Two ways to authenticate against the accounts layer:
 *   1. Browser session cookie (set at OAuth login) — normal human usage.
 *   2. `Authorization: Bearer nxk_live_...` workspace API key — for
 *      scripts/integrations acting on behalf of a workspace without a
 *      human in the loop.
 * Neither of these touches or is touched by the existing
 * `Authorization: Bearer <GATEWAY_API_KEY>` scheme from Phase 1/2 — a
 * request can (and for the core /api/chat etc. routes, still does)
 * authenticate with just the gateway key exactly as before.
 */
export function resolveIdentity(req: IncomingMessage, store: AccountsStore): ResolvedIdentity | null {
  const authHeader = req.headers['authorization'];
  if (typeof authHeader === 'string') {
    const mobileMatch = authHeader.match(/^Bearer (nxm_live_\S+)$/);
    if (mobileMatch) {
      const user = store.getSessionUser(hashToken(mobileMatch[1]!));
      if (!user) return null;
      return { user, viaApiKeyWorkspaceId: null, apiKeyId: null };
    }

    const match = authHeader.match(/^Bearer (nxk_live_\S+)$/);
    if (match) {
      const record = store.getApiKeyByHash(hashToken(match[1]!));
      if (!record) return null;
      store.touchApiKey(record.id);
      const ws = store.getWorkspace(record.workspaceId);
      if (!ws) return null;
      const owner = store.getUser(ws.ownerUserId);
      if (!owner) return null;
      return { user: owner, viaApiKeyWorkspaceId: record.workspaceId, apiKeyId: record.id };
    }
  }

  const cookies = parseCookies(req.headers['cookie'] as string | undefined);
  const rawSession = cookies[SESSION_COOKIE_NAME];
  if (!rawSession) return null;
  const user = store.getSessionUser(hashToken(rawSession));
  if (!user) return null;
  return { user, viaApiKeyWorkspaceId: null, apiKeyId: null };
}

export function resolveMobileIdentity(req: IncomingMessage, store: AccountsStore): ResolvedIdentity | null {
  const authHeader = req.headers['authorization'];
  if (typeof authHeader !== 'string') return null;
  const match = authHeader.match(/^Bearer (nxm_live_\S+)$/);
  if (!match) return null;
  const user = store.getSessionUser(hashToken(match[1]!));
  if (!user) return null;
  return { user, viaApiKeyWorkspaceId: null, apiKeyId: null };
}
