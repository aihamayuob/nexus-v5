import type { Role } from './store.js';

/**
 * Every permission check in the codebase goes through hasPermission()
 * rather than comparing role strings inline in route handlers — this is
 * the one place the actual matrix lives, so it can be audited (and
 * tested) as a single source of truth instead of being scattered and
 * potentially inconsistent across a dozen route files.
 */
export type Action =
  | 'workspace.delete'
  | 'workspace.rename'
  | 'workspace.billing.manage'
  | 'workspace.billing.view'
  | 'members.invite'
  | 'members.remove'
  | 'members.changeRole'
  | 'members.view'
  | 'apiKeys.create'
  | 'apiKeys.revoke'
  | 'apiKeys.view'
  | 'auditLog.view'
  | 'app.use'; // chat, sync, runtime, tools — normal day-to-day usage

const ROLE_RANK: Record<Role, number> = { owner: 3, admin: 2, member: 1, viewer: 0 };

const PERMISSION_MIN_ROLE: Record<Action, Role> = {
  'workspace.delete': 'owner',
  'workspace.rename': 'admin',
  'workspace.billing.manage': 'owner',
  'workspace.billing.view': 'admin',
  'members.invite': 'admin',
  'members.remove': 'admin',
  'members.changeRole': 'admin',
  'members.view': 'viewer',
  'apiKeys.create': 'admin',
  'apiKeys.revoke': 'admin',
  'apiKeys.view': 'admin',
  'auditLog.view': 'admin',
  'app.use': 'member',
};

export function hasPermission(role: Role, action: Action): boolean {
  return ROLE_RANK[role] >= ROLE_RANK[PERMISSION_MIN_ROLE[action]];
}

/**
 * One extra rule beyond simple role-rank comparison: even an admin
 * cannot remove or demote the workspace's owner (there must always be
 * exactly one owner, and only the owner can transfer or relinquish that
 * role) — otherwise an admin could lock the owner out of their own
 * workspace, which is a real privilege-escalation bug pattern in RBAC
 * systems that a naive rank check alone doesn't catch.
 */
export function canActOnMember(actorRole: Role, targetRole: Role, action: 'remove' | 'changeRole'): boolean {
  if (targetRole === 'owner') return false; // the owner can only be changed via an explicit ownership-transfer flow, not a normal member action
  if (action === 'remove') return hasPermission(actorRole, 'members.remove') && ROLE_RANK[actorRole] > ROLE_RANK[targetRole];
  return hasPermission(actorRole, 'members.changeRole') && ROLE_RANK[actorRole] > ROLE_RANK[targetRole];
}
