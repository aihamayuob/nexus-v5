import type { IncomingMessage, ServerResponse } from 'node:http';

const MAX_BODY_BYTES = 2 * 1024 * 1024; // 2MB — generous for chat history + a base64 image, bounded against abuse

export class BodyTooLargeError extends Error {}
export class InvalidJSONError extends Error {}

export function readRawBody(req: IncomingMessage): Promise<string> {
  return new Promise((resolve, reject) => {
    let size = 0;
    let tooLarge = false;
    const chunks: Buffer[] = [];
    req.on('data', (chunk: Buffer) => {
      size += chunk.length;
      if (size > MAX_BODY_BYTES) { tooLarge = true; return; }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (tooLarge) { reject(new BodyTooLargeError(`Request body exceeds ${MAX_BODY_BYTES} bytes`)); return; }
      resolve(Buffer.concat(chunks).toString('utf-8'));
    });
    req.on('error', reject);
  });
}

export function readJSONBody<T = unknown>(req: IncomingMessage): Promise<T> {
  return new Promise((resolve, reject) => {
    let size = 0;
    let tooLarge = false;
    const chunks: Buffer[] = [];
    req.on('data', (chunk: Buffer) => {
      size += chunk.length;
      if (size > MAX_BODY_BYTES) {
        // Do NOT destroy the socket here — that would drop the connection
        // before the caller gets a chance to send a proper error response
        // (req/res share one socket in Node's http server; destroying req
        // kills res too, so the client sees a bare dropped connection
        // instead of a clean 413). Instead: stop retaining data (bounds
        // memory) but keep draining the stream so the client's upload
        // completes normally, then reject once on 'end'.
        tooLarge = true;
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (tooLarge) {
        reject(new BodyTooLargeError(`Request body exceeds ${MAX_BODY_BYTES} bytes`));
        return;
      }
      try {
        const text = Buffer.concat(chunks).toString('utf-8');
        resolve(text.length ? JSON.parse(text) : ({} as T));
      } catch {
        reject(new InvalidJSONError('Request body is not valid JSON'));
      }
    });
    req.on('error', reject);
  });
}

export function applyCORS(req: IncomingMessage, res: ServerResponse, allowedOrigins: string[]): void {
  const originHeader = req.headers.origin;
  const origin = Array.isArray(originHeader) ? originHeader[0] : originHeader;
  if (origin && (allowedOrigins.length === 0 || allowedOrigins.includes(origin))) {
    res.setHeader('access-control-allow-origin', origin);
    res.setHeader('vary', 'Origin');
  }
  res.setHeader('access-control-allow-methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('access-control-allow-headers', 'authorization, content-type, last-event-id');
}

export function sendJSON(res: ServerResponse, status: number, body: unknown): void {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': String(Buffer.byteLength(payload)),
  });
  res.end(payload);
}

export function sendError(res: ServerResponse, status: number, message: string, code?: string): void {
  sendJSON(res, status, { error: { message, code: code ?? null } });
}

/** Starts an SSE response with the correct headers. Caller writes frames
 *  with writeSSEFrame() and must call res.end() when the stream is done. */
export function startSSE(res: ServerResponse): void {
  res.writeHead(200, {
    'content-type': 'text/event-stream; charset=utf-8',
    'cache-control': 'no-cache, no-transform',
    connection: 'keep-alive',
    'x-accel-buffering': 'no', // disables nginx response buffering, if ever deployed behind one
  });
}

export function writeSSEFrame(res: ServerResponse, id: number, event: string, data: string): void {
  res.write(`id: ${id}\nevent: ${event}\ndata: ${data}\n\n`);
}
