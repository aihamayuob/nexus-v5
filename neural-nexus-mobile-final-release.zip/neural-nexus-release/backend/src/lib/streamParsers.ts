/**
 * Low-level wire-format parsers shared by every provider adapter.
 *
 * These are intentionally dependency-free (only the standard Web Streams
 * API + TextDecoder, both native in Node 18+) because they are the most
 * failure-prone part of the whole streaming pipeline: a single off-by-one
 * in SSE line framing silently corrupts every provider built on top of it.
 * Keeping them isolated here means they can be unit-tested in complete
 * isolation from Fastify, fetch, or any provider-specific JSON shape.
 */

export interface RawSSEFrame {
  event: string | null;
  data: string;
  id: string | null;
}

/**
 * Parses a raw byte stream as Server-Sent Events per the WHATWG spec
 * (https://html.spec.whatwg.org/multipage/server-sent-events.html),
 * handling the two edge cases that naive "split on \n\n" implementations
 * get wrong:
 *   1. A single SSE frame may carry multiple `data:` lines, which must be
 *      joined with "\n" (not concatenated) before JSON.parse.
 *   2. Frame boundaries can land in the middle of a multi-byte UTF-8
 *      character or in the middle of a "\n\n" separator across two
 *      network chunks — both are handled by buffering.
 */
export async function* parseSSEStream(
  body: ReadableStream<Uint8Array>
): AsyncGenerator<RawSSEFrame> {
  const reader = body.getReader();
  const decoder = new TextDecoder('utf-8');
  let buffer = '';

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      // SSE frames are separated by a blank line. Normalize CRLF/CR to LF
      // first so we don't miss a boundary because a provider used \r\n.
      buffer = buffer.replace(/\r\n/g, '\n').replace(/\r/g, '\n');

      let boundary: number;
      while ((boundary = buffer.indexOf('\n\n')) !== -1) {
        const rawFrame = buffer.slice(0, boundary);
        buffer = buffer.slice(boundary + 2);
        const frame = parseOneFrame(rawFrame);
        if (frame) yield frame;
      }
    }
    // Flush anything left in the decoder + a trailing frame with no final \n\n.
    buffer += decoder.decode();
    if (buffer.trim().length > 0) {
      const frame = parseOneFrame(buffer);
      if (frame) yield frame;
    }
  } finally {
    reader.releaseLock();
  }
}

function parseOneFrame(raw: string): RawSSEFrame | null {
  const lines = raw.split('\n');
  let event: string | null = null;
  let id: string | null = null;
  const dataLines: string[] = [];

  for (const line of lines) {
    if (line === '' || line.startsWith(':')) continue; // comment / keep-alive
    const sep = line.indexOf(':');
    const field = sep === -1 ? line : line.slice(0, sep);
    let value = sep === -1 ? '' : line.slice(sep + 1);
    if (value.startsWith(' ')) value = value.slice(1);

    if (field === 'event') event = value;
    else if (field === 'data') dataLines.push(value);
    else if (field === 'id') id = value;
    // 'retry' field intentionally ignored — we manage reconnection ourselves.
  }

  if (dataLines.length === 0 && event === null) return null;
  return { event, data: dataLines.join('\n'), id };
}

/**
 * Parses a raw byte stream as newline-delimited JSON (Ollama's format —
 * no SSE framing at all, just one JSON object per line).
 */
export async function* parseNDJSONStream(
  body: ReadableStream<Uint8Array>
): AsyncGenerator<string> {
  const reader = body.getReader();
  const decoder = new TextDecoder('utf-8');
  let buffer = '';

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      let newlineIdx: number;
      while ((newlineIdx = buffer.indexOf('\n')) !== -1) {
        const line = buffer.slice(0, newlineIdx).trim();
        buffer = buffer.slice(newlineIdx + 1);
        if (line.length > 0) yield line;
      }
    }
    buffer += decoder.decode();
    if (buffer.trim().length > 0) yield buffer.trim();
  } finally {
    reader.releaseLock();
  }
}
