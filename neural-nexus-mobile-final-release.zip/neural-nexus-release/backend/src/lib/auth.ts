import { timingSafeEqual } from 'node:crypto';
import type { IncomingMessage } from 'node:http';

/**
 * A naive `key === header` comparison leaks timing information about how
 * many leading characters matched, which is a real (if slow) attack
 * vector against a gateway key that gates access to paid provider
 * credentials behind it. timingSafeEqual closes that channel.
 */
export function isAuthorized(req: IncomingMessage, gatewayKey: string): boolean {
  const header = req.headers['authorization'];
  if (!header || Array.isArray(header)) return false;
  const match = header.match(/^Bearer (.+)$/);
  if (!match) return false;

  const provided = Buffer.from(match[1]);
  const expected = Buffer.from(gatewayKey);
  if (provided.length !== expected.length) return false;
  return timingSafeEqual(provided, expected);
}
