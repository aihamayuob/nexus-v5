import type { AccountsStore } from '../accounts/store.js';

interface ExpoMessage {
  to: string;
  sound?: 'default';
  title: string;
  body: string;
  data?: Record<string, unknown>;
}

export async function sendExpoPushToUser(
  store: AccountsStore,
  userId: string,
  message: Omit<ExpoMessage, 'to'>,
  fetchImpl: typeof fetch = fetch,
): Promise<void> {
  const tokens = store.listPushTokens(userId);
  if (!tokens.length) return;
  const messages: ExpoMessage[] = tokens.map((t) => ({ to: t.token, ...message }));
  const response = await fetchImpl('https://exp.host/--/api/v2/push/send', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(messages),
  });
  if (!response.ok) throw new Error(`Expo push API returned HTTP ${response.status}`);
}
