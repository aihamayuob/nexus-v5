type Level = 'debug' | 'info' | 'warn' | 'error';
const LEVEL_ORDER: Record<Level, number> = { debug: 0, info: 1, warn: 2, error: 3 };

const SECRET_KEY_PATTERN = /key|token|secret|authorization|password/i;

/** Recursively strips anything that looks like a secret before it ever
 *  reaches a log line — defense in depth, on top of callers simply not
 *  passing secrets in the first place. */
function redact(value: unknown, depth = 0): unknown {
  if (depth > 4 || value === null || value === undefined) return value;
  if (Array.isArray(value)) return value.map((v) => redact(v, depth + 1));
  if (typeof value === 'object') {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      out[k] = SECRET_KEY_PATTERN.test(k) ? '[redacted]' : redact(v, depth + 1);
    }
    return out;
  }
  return value;
}

export function createLogger(minLevel: Level = 'info') {
  function log(level: Level, msg: string, fields: Record<string, unknown> = {}) {
    if (LEVEL_ORDER[level] < LEVEL_ORDER[minLevel]) return;
    const line = {
      ts: new Date().toISOString(),
      level,
      msg,
      ...(redact(fields) as Record<string, unknown>),
    };
    const stream = level === 'error' || level === 'warn' ? process.stderr : process.stdout;
    stream.write(JSON.stringify(line) + '\n');
  }

  return {
    debug: (msg: string, fields?: Record<string, unknown>) => log('debug', msg, fields),
    info: (msg: string, fields?: Record<string, unknown>) => log('info', msg, fields),
    warn: (msg: string, fields?: Record<string, unknown>) => log('warn', msg, fields),
    error: (msg: string, fields?: Record<string, unknown>) => log('error', msg, fields),
  };
}

export type Logger = ReturnType<typeof createLogger>;
