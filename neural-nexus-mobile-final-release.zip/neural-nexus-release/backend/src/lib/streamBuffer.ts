export interface BufferedEvent {
  id: number;
  event: string;
  data: string;
}

interface StreamState {
  events: BufferedEvent[];
  nextId: number;
  finished: boolean;
  createdAt: number;
  abort: AbortController;
  subscribers: Set<(event: BufferedEvent) => void>;
  onFinish: Set<() => void>;
}

/**
 * Holds a bounded, TTL'd record of every SSE event emitted for a given
 * requestId so a client that drops mid-stream (phone loses signal,
 * app backgrounded, etc.) can reconnect with `?afterId=N` and receive
 * exactly the events it missed, then keep receiving new ones live if
 * generation is still in flight. This directly implements the brief's
 * "handle partial failures" / "reconnect automatically" requirement
 * without needing a database — the buffer only needs to survive a few
 * minutes, not a server restart.
 *
 * The original connection writes straight through (fast path). A
 * *resumed* connection instead replays the buffer and then subscribes
 * to be notified of subsequent events pushed by the still-running
 * original generator — this is what lets a dropped connection catch
 * back up to a generation that never stopped.
 */
export class StreamBuffer {
  private streams = new Map<string, StreamState>();

  constructor(private readonly ttlMs: number, private readonly maxEventsPerStream = 4000) {
    setInterval(() => this.sweep(), Math.max(ttlMs / 4, 15_000)).unref();
  }

  create(requestId: string, abort: AbortController): void {
    this.streams.set(requestId, {
      events: [],
      nextId: 0,
      finished: false,
      createdAt: Date.now(),
      abort,
      subscribers: new Set(),
      onFinish: new Set(),
    });
  }

  append(requestId: string, event: string, data: string): BufferedEvent | null {
    const state = this.streams.get(requestId);
    if (!state) return null;
    const entry: BufferedEvent = { id: state.nextId++, event, data };
    state.events.push(entry);
    if (state.events.length > this.maxEventsPerStream) state.events.shift();
    for (const cb of state.subscribers) cb(entry);
    return entry;
  }

  markFinished(requestId: string): void {
    const state = this.streams.get(requestId);
    if (!state) return;
    state.finished = true;
    for (const cb of state.onFinish) cb();
  }

  subscribe(requestId: string, onEvent: (event: BufferedEvent) => void, onFinish: () => void): () => void {
    const state = this.streams.get(requestId);
    if (!state) return () => {};
    state.subscribers.add(onEvent);
    state.onFinish.add(onFinish);
    return () => {
      state.subscribers.delete(onEvent);
      state.onFinish.delete(onFinish);
    };
  }

  eventsAfter(requestId: string, afterId: number): BufferedEvent[] | null {
    const state = this.streams.get(requestId);
    if (!state) return null;
    return state.events.filter((e) => e.id > afterId);
  }

  isFinished(requestId: string): boolean {
    return this.streams.get(requestId)?.finished ?? true;
  }

  exists(requestId: string): boolean {
    return this.streams.has(requestId);
  }

  abort(requestId: string): boolean {
    const state = this.streams.get(requestId);
    if (!state) return false;
    state.abort.abort();
    return true;
  }

  private sweep() {
    const cutoff = Date.now() - this.ttlMs;
    for (const [id, state] of this.streams) {
      if (state.createdAt < cutoff) this.streams.delete(id);
    }
  }
}
