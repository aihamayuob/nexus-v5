/**
 * In-memory sliding-window rate limiter, keyed by client IP.
 *
 * Known limitation (documented rather than hidden): this state lives in
 * process memory, so it resets on restart and does not share state
 * across multiple backend instances. That's the right tradeoff for a
 * single-instance deployment (which is what this gateway is designed
 * for today) — swapping the Map below for a Redis INCR+EXPIRE pair is
 * the entire migration needed if/when you run more than one instance.
 */
export class RateLimiter {
  private hits = new Map<string, number[]>();

  constructor(
    private readonly maxRequests: number,
    private readonly windowMs: number
  ) {
    // Periodic sweep so memory doesn't grow unbounded from one-off clients.
    setInterval(() => this.sweep(), Math.max(windowMs, 30_000)).unref();
  }

  /** Returns { allowed, remaining, resetMs }. */
  check(key: string): { allowed: boolean; remaining: number; resetMs: number } {
    const now = Date.now();
    const windowStart = now - this.windowMs;
    const timestamps = (this.hits.get(key) ?? []).filter((t) => t > windowStart);

    if (timestamps.length >= this.maxRequests) {
      const resetMs = timestamps[0] + this.windowMs - now;
      this.hits.set(key, timestamps);
      return { allowed: false, remaining: 0, resetMs: Math.max(resetMs, 0) };
    }

    timestamps.push(now);
    this.hits.set(key, timestamps);
    return { allowed: true, remaining: this.maxRequests - timestamps.length, resetMs: this.windowMs };
  }

  private sweep() {
    const cutoff = Date.now() - this.windowMs;
    for (const [key, timestamps] of this.hits) {
      const kept = timestamps.filter((t) => t > cutoff);
      if (kept.length === 0) this.hits.delete(key);
      else this.hits.set(key, kept);
    }
  }
}
