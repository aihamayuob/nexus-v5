export interface ChatMessage {
  role: 'user' | 'assistant';
  /** String for plain text, or an array of content blocks (text/image/tool_result)
   *  mirroring Anthropic's content-block shape, which the request layer normalizes
   *  from/to each provider's native format. */
  content: unknown;
}

export interface ToolDefinition {
  name: string;
  description: string;
  input_schema: Record<string, unknown>;
}

export interface ChatRequest {
  provider: string;
  model: string;
  system?: string;
  messages: ChatMessage[];
  tools?: ToolDefinition[];
  maxTokens?: number;
  temperature?: number;
}

/** Normalized event schema every adapter must emit, regardless of the
 *  upstream provider's actual wire format. The browser only ever needs
 *  to understand this one shape. */
export type StreamEvent =
  | { type: 'start'; requestId: string }
  | { type: 'token'; text: string }
  | { type: 'tool_use_start'; id: string; name: string }
  | { type: 'tool_use_delta'; id: string; partialJson: string }
  | { type: 'usage'; inputTokens: number; outputTokens: number }
  | { type: 'error'; message: string; retryable: boolean; code?: string }
  | { type: 'done'; stopReason: string };

export class UpstreamProviderError extends Error {
  constructor(
    message: string,
    public readonly statusCode: number,
    public readonly retryable: boolean,
    public readonly providerBody?: string
  ) {
    super(message);
    this.name = 'UpstreamProviderError';
  }
}

/** The contract every provider adapter implements. Adding a brand-new
 *  provider means writing exactly one file that satisfies this interface
 *  and registering it in providers/registry.ts — nothing else in the
 *  system needs to change. */
export interface ProviderAdapter {
  readonly name: string;

  /** True streaming — the primary path used by interactive chat. */
  streamChat(req: ChatRequest, signal: AbortSignal): AsyncGenerator<StreamEvent>;

  /** Non-streaming — kept so the existing frontend's `response.json()`
   *  call sites (debate mode, judge, synthesis, etc.) keep working
   *  completely unmodified. Returns the provider's native response shape
   *  translated to Anthropic's Messages API shape, since that's the
   *  contract the existing frontend already expects from /api/chat. */
  chat(req: ChatRequest, signal: AbortSignal): Promise<AnthropicStyleResponse>;
}

/** The response envelope the current frontend already parses
 *  (`data.content`, `data.stop_reason`, `data.usage`). Every adapter's
 *  non-streaming `chat()` normalizes into this shape so /api/chat's
 *  response contract never changes, no matter which provider served it. */
export interface AnthropicStyleResponse {
  content: Array<
    | { type: 'text'; text: string }
    | { type: 'tool_use'; id: string; name: string; input: Record<string, unknown> }
  >;
  stop_reason: string;
  usage: { input_tokens: number; output_tokens: number };
}
