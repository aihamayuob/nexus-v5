import { parseSSEStream } from '../lib/streamParsers.js';
import type {
  AnthropicStyleResponse,
  ChatMessage,
  ChatRequest,
  ProviderAdapter,
  StreamEvent,
} from './types.js';
import { UpstreamProviderError } from './types.js';

/**
 * Every request/response the rest of this system passes around uses
 * Anthropic's message shape (that's what the existing frontend already
 * speaks). OpenAI-family APIs use a materially different shape:
 *   - `system` is a message, not a top-level field
 *   - tool calls live in `tool_calls`, not inline `content` blocks
 *   - tool *results* are their own `role:'tool'` messages, not content
 *     blocks inside a user message
 * These two functions are the full, exact translation in both directions.
 */

function toOpenAIMessages(req: ChatRequest): any[] {
  const out: any[] = [];
  if (req.system) out.push({ role: 'system', content: req.system });

  for (const msg of req.messages as ChatMessage[]) {
    if (typeof msg.content === 'string') {
      out.push({ role: msg.role, content: msg.content });
      continue;
    }

    const blocks = msg.content as any[];
    const toolResultBlocks = blocks.filter((b) => b.type === 'tool_result');
    if (toolResultBlocks.length > 0) {
      // Anthropic groups tool results as content blocks inside one user
      // message; OpenAI wants one standalone role:'tool' message each.
      for (const tr of toolResultBlocks) {
        const content = typeof tr.content === 'string' ? tr.content : JSON.stringify(tr.content);
        out.push({ role: 'tool', tool_call_id: tr.tool_use_id, content });
      }
      const leftoverText = blocks.filter((b) => b.type === 'text');
      if (leftoverText.length > 0) {
        out.push({ role: 'user', content: leftoverText.map((b) => b.text).join('\n') });
      }
      continue;
    }

    const toolUseBlocks = blocks.filter((b) => b.type === 'tool_use');
    if (toolUseBlocks.length > 0) {
      const textBlocks = blocks.filter((b) => b.type === 'text');
      out.push({
        role: 'assistant',
        content: textBlocks.length > 0 ? textBlocks.map((b) => b.text).join('\n') : null,
        tool_calls: toolUseBlocks.map((b) => ({
          id: b.id,
          type: 'function',
          function: { name: b.name, arguments: JSON.stringify(b.input ?? {}) },
        })),
      });
      continue;
    }

    // Plain content array — text and/or images.
    const parts = blocks.map((b) => {
      if (b.type === 'text') return { type: 'text', text: b.text };
      if (b.type === 'image') {
        const url = `data:${b.source.media_type};base64,${b.source.data}`;
        return { type: 'image_url', image_url: { url } };
      }
      return { type: 'text', text: JSON.stringify(b) };
    });
    out.push({ role: msg.role, content: parts });
  }
  return out;
}

function toOpenAITools(req: ChatRequest): any[] | undefined {
  if (!req.tools || req.tools.length === 0) return undefined;
  return req.tools.map((t) => ({
    type: 'function',
    function: { name: t.name, description: t.description, parameters: t.input_schema },
  }));
}

function mapFinishReason(reason: string | null | undefined): string {
  switch (reason) {
    case 'stop': return 'end_turn';
    case 'length': return 'max_tokens';
    case 'tool_calls': return 'tool_use';
    case 'content_filter': return 'content_filter';
    default: return reason ?? 'end_turn';
  }
}

function buildBody(req: ChatRequest, stream: boolean) {
  return {
    model: req.model,
    messages: toOpenAIMessages(req),
    tools: toOpenAITools(req),
    max_tokens: req.maxTokens ?? 1024,
    temperature: req.temperature,
    stream,
    ...(stream ? { stream_options: { include_usage: true } } : {}),
  };
}

async function upstreamFetch(
  baseUrl: string,
  apiKey: string,
  body: unknown,
  signal: AbortSignal,
  extraHeaders?: Record<string, string>
): Promise<Response> {
  const res = await fetch(`${baseUrl}/chat/completions`, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      authorization: `Bearer ${apiKey}`,
      ...extraHeaders,
    },
    body: JSON.stringify(body),
    signal,
  });
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    const retryable = res.status === 429 || res.status >= 500;
    throw new UpstreamProviderError(`${baseUrl} error ${res.status}`, res.status, retryable, text.slice(0, 500));
  }
  return res;
}

export interface OpenAICompatOptions {
  /** e.g. OpenRouter requires these for its leaderboard/analytics. */
  extraHeaders?: Record<string, string>;
}

export function createOpenAICompatAdapter(
  name: string,
  baseUrl: string,
  apiKey: string,
  opts: OpenAICompatOptions = {}
): ProviderAdapter {
  return {
    name,

    async *streamChat(req, signal) {
      const res = await upstreamFetch(baseUrl, apiKey, buildBody(req, true), signal, opts.extraHeaders);
      if (!res.body) {
        yield { type: 'error', message: `${name} returned no response body`, retryable: true };
        return;
      }

      // OpenAI streams tool_call arguments as string fragments keyed by
      // array `index`; we only learn the real tool-call id/name on the
      // first fragment for that index.
      const toolIdByIndex = new Map<number, string>();
      const toolStarted = new Set<number>();
      let inputTokens = 0;
      let outputTokens = 0;
      let stopReason = 'end_turn';

      for await (const frame of parseSSEStream(res.body)) {
        if (!frame.data || frame.data === '[DONE]') continue;
        let payload: any;
        try {
          payload = JSON.parse(frame.data);
        } catch {
          continue;
        }

        if (payload.usage) {
          inputTokens = payload.usage.prompt_tokens ?? inputTokens;
          outputTokens = payload.usage.completion_tokens ?? outputTokens;
        }

        const choice = payload.choices?.[0];
        if (!choice) continue;

        if (choice.finish_reason) stopReason = mapFinishReason(choice.finish_reason);

        const delta = choice.delta;
        if (!delta) continue;

        if (typeof delta.content === 'string' && delta.content.length > 0) {
          yield { type: 'token', text: delta.content };
        }

        if (Array.isArray(delta.tool_calls)) {
          for (const tc of delta.tool_calls) {
            const idx = tc.index ?? 0;
            if (tc.id) toolIdByIndex.set(idx, tc.id);
            const id = toolIdByIndex.get(idx) ?? `tool_${idx}`;

            if (!toolStarted.has(idx) && tc.function?.name) {
              toolStarted.add(idx);
              const ev: StreamEvent = { type: 'tool_use_start', id, name: tc.function.name };
              yield ev;
            }
            if (tc.function?.arguments) {
              yield { type: 'tool_use_delta', id, partialJson: tc.function.arguments };
            }
          }
        }
      }

      yield { type: 'usage', inputTokens, outputTokens };
      yield { type: 'done', stopReason };
    },

    async chat(req, signal): Promise<AnthropicStyleResponse> {
      const res = await upstreamFetch(baseUrl, apiKey, buildBody(req, false), signal, opts.extraHeaders);
      const data: any = await res.json();
      const choice = data.choices?.[0];
      const message = choice?.message ?? {};
      const content: AnthropicStyleResponse['content'] = [];

      if (typeof message.content === 'string' && message.content.length > 0) {
        content.push({ type: 'text', text: message.content });
      }
      for (const tc of message.tool_calls ?? []) {
        let input: Record<string, unknown> = {};
        try { input = JSON.parse(tc.function.arguments || '{}'); } catch { /* leave empty on malformed args */ }
        content.push({ type: 'tool_use', id: tc.id, name: tc.function.name, input });
      }

      return {
        content,
        stop_reason: mapFinishReason(choice?.finish_reason),
        usage: {
          input_tokens: data.usage?.prompt_tokens ?? 0,
          output_tokens: data.usage?.completion_tokens ?? 0,
        },
      };
    },
  };
}
