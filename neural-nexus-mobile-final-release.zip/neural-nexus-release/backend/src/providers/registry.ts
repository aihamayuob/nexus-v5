import { createAnthropicAdapter } from './anthropic.js';
import { createGeminiAdapter } from './gemini.js';
import { createOpenAICompatAdapter } from './openaiCompat.js';
import type { ProviderAdapter } from './types.js';
import type { Env } from '../config/env.js';

/**
 * Every provider the brief asked for, realized with exactly 3 adapter
 * implementations:
 *   - anthropic.ts   (Anthropic's own event-block SSE format)
 *   - gemini.ts       (Google's contents/parts format)
 *   - openaiCompat.ts (everyone else — OpenAI, DeepSeek, OpenRouter,
 *                       Mistral, and Ollama all speak OpenAI's
 *                       chat/completions wire protocol; Ollama exposes
 *                       this natively at /v1, so we get it "for free"
 *                       instead of reimplementing its native NDJSON
 *                       format and its own tool-calling conventions)
 *
 * Adding a genuinely new wire format later (i.e. one that isn't
 * Anthropic-shaped, Gemini-shaped, or OpenAI-shaped) means writing one
 * new file matching ProviderAdapter and adding one line below —
 * nothing else in routes/, lib/, or the frontend needs to change.
 */
export function buildProviderRegistry(env: Env): Map<string, ProviderAdapter> {
  const registry = new Map<string, ProviderAdapter>();

  if (env.ANTHROPIC_API_KEY) {
    registry.set('anthropic', createAnthropicAdapter(env.ANTHROPIC_API_KEY));
  }
  if (env.OPENAI_API_KEY) {
    registry.set('openai', createOpenAICompatAdapter('openai', 'https://api.openai.com/v1', env.OPENAI_API_KEY));
  }
  if (env.DEEPSEEK_API_KEY) {
    registry.set('deepseek', createOpenAICompatAdapter('deepseek', 'https://api.deepseek.com', env.DEEPSEEK_API_KEY));
  }
  if (env.OPENROUTER_API_KEY) {
    registry.set(
      'openrouter',
      createOpenAICompatAdapter('openrouter', 'https://openrouter.ai/api/v1', env.OPENROUTER_API_KEY, {
        extraHeaders: {
          'HTTP-Referer': env.PUBLIC_APP_URL ?? 'https://localhost',
          'X-Title': 'Neural Nexus AI Agents',
        },
      })
    );
  }
  if (env.MISTRAL_API_KEY) {
    registry.set('mistral', createOpenAICompatAdapter('mistral', 'https://api.mistral.ai/v1', env.MISTRAL_API_KEY));
  }
  if (env.GEMINI_API_KEY) {
    registry.set('gemini', createGeminiAdapter(env.GEMINI_API_KEY));
  }
  // Ollama and LM Studio are local-network servers with no real API key;
  // both expose an OpenAI-compatible endpoint. A dummy bearer token is
  // sent since some proxies (e.g. Ollama behind nginx) reject a fully
  // missing Authorization header — the local servers themselves ignore it.
  if (env.OLLAMA_BASE_URL) {
    registry.set('ollama', createOpenAICompatAdapter('ollama', `${env.OLLAMA_BASE_URL}/v1`, 'ollama-local'));
  }
  if (env.LMSTUDIO_BASE_URL) {
    registry.set('lmstudio', createOpenAICompatAdapter('lmstudio', env.LMSTUDIO_BASE_URL, 'lmstudio-local'));
  }

  return registry;
}
