import { parseSSEStream } from '../lib/streamParsers.js';
import type {
  AnthropicStyleResponse,
  ChatRequest,
  ProviderAdapter,
  StreamEvent,
} from './types.js';
import { UpstreamProviderError } from './types.js';

const API_BASE = 'https://api.anthropic.com/v1/messages';
const ANTHROPIC_VERSION = '2023-06-01';

function buildBody(req: ChatRequest, stream: boolean) {
  return {
    model: req.model,
    max_tokens: req.maxTokens ?? 1024,
    system: req.system,
    messages: req.messages,
    tools: req.tools,
    temperature: req.temperature,
    stream,
  };
}

async function upstreamFetch(
  apiKey: string,
  body: unknown,
  signal: AbortSignal
): Promise<Response> {
  const res = await fetch(API_BASE, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': ANTHROPIC_VERSION,
    },
    body: JSON.stringify(body),
    signal,
  });
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    const retryable = res.status === 429 || res.status >= 500;
    throw new UpstreamProviderError(
      `Anthropic API error ${res.status}`,
      res.status,
      retryable,
      text.slice(0, 500)
    );
  }
  return res;
}

export function createAnthropicAdapter(apiKey: string): ProviderAdapter {
  return {
    name: 'anthropic',

    async *streamChat(req, signal) {
      const res = await upstreamFetch(apiKey, buildBody(req, true), signal);
      if (!res.body) {
        yield { type: 'error', message: 'Anthropic returned no response body', retryable: true };
        return;
      }

      // Anthropic streams tool input as incremental partial-JSON deltas
      // scoped to a content-block index; we need the index -> tool_use id
      // mapping to route those deltas correctly.
      const toolIdByIndex = new Map<number, string>();
      let outputTokens = 0;
      let inputTokens = 0;
      let stopReason = 'end_turn';

      for await (const frame of parseSSEStream(res.body)) {
        if (!frame.data) continue;
        let payload: any;
        try {
          payload = JSON.parse(frame.data);
        } catch {
          continue; // malformed frame — skip rather than crash the whole stream
        }

        switch (payload.type) {
          case 'message_start':
            inputTokens = payload.message?.usage?.input_tokens ?? 0;
            break;

          case 'content_block_start': {
            const block = payload.content_block;
            if (block?.type === 'tool_use') {
              toolIdByIndex.set(payload.index, block.id);
              const ev: StreamEvent = { type: 'tool_use_start', id: block.id, name: block.name };
              yield ev;
            }
            break;
          }

          case 'content_block_delta': {
            const delta = payload.delta;
            if (delta?.type === 'text_delta') {
              yield { type: 'token', text: delta.text };
            } else if (delta?.type === 'input_json_delta') {
              const id = toolIdByIndex.get(payload.index);
              if (id) {
                yield { type: 'tool_use_delta', id, partialJson: delta.partial_json ?? '' };
              }
            }
            break;
          }

          case 'message_delta':
            if (payload.delta?.stop_reason) stopReason = payload.delta.stop_reason;
            if (payload.usage?.output_tokens != null) outputTokens = payload.usage.output_tokens;
            break;

          case 'message_stop':
            yield { type: 'usage', inputTokens, outputTokens };
            yield { type: 'done', stopReason };
            return;

          case 'error':
            yield {
              type: 'error',
              message: payload.error?.message ?? 'Unknown Anthropic streaming error',
              retryable: payload.error?.type === 'overloaded_error',
              code: payload.error?.type,
            };
            return;

          case 'ping':
          case 'content_block_stop':
            break; // no-op, expected frames
        }
      }
    },

    async chat(req, signal): Promise<AnthropicStyleResponse> {
      const res = await upstreamFetch(apiKey, buildBody(req, false), signal);
      const data = (await res.json()) as AnthropicStyleResponse;
      return data; // already in the exact shape the frontend expects
    },
  };
}
