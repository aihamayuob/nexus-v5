import { parseSSEStream } from '../lib/streamParsers.js';
import type {
  AnthropicStyleResponse,
  ChatMessage,
  ChatRequest,
  ProviderAdapter,
  StreamEvent,
} from './types.js';
import { UpstreamProviderError } from './types.js';

const API_ROOT = 'https://generativelanguage.googleapis.com/v1beta/models';

function toGeminiContents(messages: ChatMessage[]): any[] {
  return messages.map((msg) => {
    const role = msg.role === 'assistant' ? 'model' : 'user';
    if (typeof msg.content === 'string') {
      return { role, parts: [{ text: msg.content }] };
    }
    const blocks = msg.content as any[];
    const parts = blocks.map((b) => {
      if (b.type === 'text') return { text: b.text };
      if (b.type === 'image') {
        return { inline_data: { mime_type: b.source.media_type, data: b.source.data } };
      }
      if (b.type === 'tool_use') {
        return { functionCall: { name: b.name, args: b.input ?? {} } };
      }
      if (b.type === 'tool_result') {
        const content = typeof b.content === 'string' ? b.content : JSON.stringify(b.content);
        return { functionResponse: { name: b.tool_use_id, response: { result: content } } };
      }
      return { text: JSON.stringify(b) };
    });
    return { role, parts };
  });
}

function toGeminiTools(req: ChatRequest) {
  if (!req.tools || req.tools.length === 0) return undefined;
  return [
    {
      function_declarations: req.tools.map((t) => ({
        name: t.name,
        description: t.description,
        parameters: t.input_schema,
      })),
    },
  ];
}

function buildBody(req: ChatRequest) {
  return {
    system_instruction: req.system ? { parts: [{ text: req.system }] } : undefined,
    contents: toGeminiContents(req.messages),
    tools: toGeminiTools(req),
    generationConfig: {
      maxOutputTokens: req.maxTokens ?? 1024,
      temperature: req.temperature,
    },
  };
}

function mapFinishReason(reason: string | undefined, hadFunctionCall: boolean): string {
  if (hadFunctionCall) return 'tool_use';
  switch (reason) {
    case 'STOP': return 'end_turn';
    case 'MAX_TOKENS': return 'max_tokens';
    default: return 'end_turn';
  }
}

export function createGeminiAdapter(apiKey: string): ProviderAdapter {
  return {
    name: 'gemini',

    async *streamChat(req, signal) {
      const url = `${API_ROOT}/${req.model}:streamGenerateContent?alt=sse&key=${apiKey}`;
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(buildBody(req)),
        signal,
      });
      if (!res.ok) {
        const text = await res.text().catch(() => '');
        const retryable = res.status === 429 || res.status >= 500;
        yield { type: 'error', message: `Gemini API error ${res.status}: ${text.slice(0, 300)}`, retryable };
        return;
      }
      if (!res.body) {
        yield { type: 'error', message: 'Gemini returned no response body', retryable: true };
        return;
      }

      let inputTokens = 0;
      let outputTokens = 0;
      let finishReason: string | undefined;
      let hadFunctionCall = false;
      let toolCounter = 0;

      for await (const frame of parseSSEStream(res.body)) {
        if (!frame.data) continue;
        let payload: any;
        try {
          payload = JSON.parse(frame.data);
        } catch {
          continue;
        }

        if (payload.usageMetadata) {
          inputTokens = payload.usageMetadata.promptTokenCount ?? inputTokens;
          outputTokens = payload.usageMetadata.candidatesTokenCount ?? outputTokens;
        }

        const candidate = payload.candidates?.[0];
        if (!candidate) continue;
        if (candidate.finishReason) finishReason = candidate.finishReason;

        for (const part of candidate.content?.parts ?? []) {
          if (typeof part.text === 'string' && part.text.length > 0) {
            yield { type: 'token', text: part.text };
          } else if (part.functionCall) {
            hadFunctionCall = true;
            const id = `gemini_tool_${toolCounter++}`;
            const startEv: StreamEvent = { type: 'tool_use_start', id, name: part.functionCall.name };
            yield startEv;
            yield { type: 'tool_use_delta', id, partialJson: JSON.stringify(part.functionCall.args ?? {}) };
          }
        }
      }

      yield { type: 'usage', inputTokens, outputTokens };
      yield { type: 'done', stopReason: mapFinishReason(finishReason, hadFunctionCall) };
    },

    async chat(req, signal): Promise<AnthropicStyleResponse> {
      const url = `${API_ROOT}/${req.model}:generateContent?key=${apiKey}`;
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(buildBody(req)),
        signal,
      });
      if (!res.ok) {
        const text = await res.text().catch(() => '');
        const retryable = res.status === 429 || res.status >= 500;
        throw new UpstreamProviderError(`Gemini API error ${res.status}`, res.status, retryable, text.slice(0, 500));
      }
      const data: any = await res.json();
      const candidate = data.candidates?.[0];
      const content: AnthropicStyleResponse['content'] = [];
      let hadFunctionCall = false;
      let toolCounter = 0;

      for (const part of candidate?.content?.parts ?? []) {
        if (typeof part.text === 'string') {
          content.push({ type: 'text', text: part.text });
        } else if (part.functionCall) {
          hadFunctionCall = true;
          content.push({
            type: 'tool_use',
            id: `gemini_tool_${toolCounter++}`,
            name: part.functionCall.name,
            input: part.functionCall.args ?? {},
          });
        }
      }

      return {
        content,
        stop_reason: mapFinishReason(candidate?.finishReason, hadFunctionCall),
        usage: {
          input_tokens: data.usageMetadata?.promptTokenCount ?? 0,
          output_tokens: data.usageMetadata?.candidatesTokenCount ?? 0,
        },
      };
    },
  };
}
