import { createServer } from 'node:http';
import { createApp } from './app.js';
import { loadEnv, redactedSummary } from './config/env.js';
import { createLogger } from './lib/logger.js';

const env = loadEnv();
const log = createLogger(env.LOG_LEVEL);
const handler = createApp(env, log);

log.info('nexus-backend starting', { ...redactedSummary(env) });

const server = createServer((req, res) => {
  handler(req, res).catch((e) => {
    log.error('unhandled request error', { error: String(e?.message ?? e) });
    if (!res.headersSent) res.writeHead(500);
    res.end();
  });
});

server.listen(env.PORT, env.HOST, () => {
  log.info(`nexus-backend listening on http://${env.HOST}:${env.PORT}`);
});

for (const sig of ['SIGTERM', 'SIGINT'] as const) {
  process.on(sig, () => {
    log.info(`${sig} received, shutting down`);
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(1), 10_000).unref();
  });
}

process.on('unhandledRejection', (reason: unknown) => {
  log.error('unhandled promise rejection', { reason: String(reason) });
});
