import type { IncomingMessage, ServerResponse } from 'node:http';
import type { Env } from './config/env.js';
import { isAuthorized } from './lib/auth.js';
import { applyCORS, sendError, sendJSON } from './lib/httpUtil.js';
import type { Logger } from './lib/logger.js';
import { RateLimiter } from './lib/rateLimit.js';
import { StreamBuffer } from './lib/streamBuffer.js';
import { buildProviderRegistry } from './providers/registry.js';
import { handleCancelChat, handlePostChat, handleResumeChat } from './routes/chat.js';
import { handleHealth } from './routes/health.js';
import { handleDeleteSync, handleGetSync, handlePutSync } from './routes/sync.js';
import { handlePostRuntimePlan, handlePostRuntimeRun } from './routes/runtime.js';
import { handlePostToolsFetch } from './routes/tools.js';
import { SyncStore } from './sync/store.js';
import { AccountsStore } from './accounts/store.js';
import { resolveMobileIdentity } from './accounts/authMiddleware.js';
import { handleGetAuthGoogleStart, handleGetAuthGoogleCallback, handleGetAuthMobileGoogleStart, handlePostAuthMobileExchange, handlePostAuthLogout, handleGetAuthMe } from './routes/auth.js';
import {
  handlePostWorkspaces, handleGetWorkspaces, handlePatchWorkspace, handleDeleteWorkspace,
  handleGetMembers, handlePostInvite, handlePostAcceptInvite, handleDeleteMember, handlePatchMemberRole,
  handlePostApiKey, handleGetApiKeys, handleDeleteApiKey, handleGetAuditLog,
} from './routes/workspaces.js';
import { handleGetBillingConfig, handleGetBillingStatus, handlePostBillingWebhook } from './routes/billing.js';
import { handleDeleteNotificationToken, handlePostNotificationToken } from './routes/notifications.js';

export type RequestHandler = (req: IncomingMessage, res: ServerResponse) => Promise<void>;

// Routes under these prefixes authenticate themselves independently
// (Google's OAuth redirect, a browser session cookie, a workspace API
// key, or Paddle's own webhook signature) — none of them can carry the
// gateway-key bearer token, so they're exempt from that check rather
// than trying to layer two unrelated auth schemes on top of each other.
// Every route from Phase 1/2/3/5/6 is untouched: still gateway-key only.
const ACCOUNTS_LAYER_PREFIXES = ['/api/auth/', '/api/workspaces', '/api/billing/'];
function isAccountsLayerRoute(pathname: string): boolean {
  return ACCOUNTS_LAYER_PREFIXES.some((p) => pathname === p.replace(/\/$/, '') || pathname.startsWith(p));
}

/**
 * Builds the request handler with no side effects (no listening socket,
 * no process-level signal handlers) so it can be mounted on a real
 * `http.Server` both by the production entrypoint (server.ts) and by
 * integration tests, identically.
 */
export function createApp(env: Env, log: Logger): RequestHandler {
  const providers = buildProviderRegistry(env);
  const buffer = new StreamBuffer(env.STREAM_BUFFER_TTL_MS);
  const rateLimiter = new RateLimiter(env.RATE_LIMIT_MAX_REQUESTS, env.RATE_LIMIT_WINDOW_MS);
  const syncStore = new SyncStore(env.SYNC_DB_PATH);
  const accountsStore = new AccountsStore(env.ACCOUNTS_DB_PATH);

  function clientIp(req: IncomingMessage): string {
    const fwd = req.headers['x-forwarded-for'];
    if (typeof fwd === 'string' && fwd.length > 0) return fwd.split(',')[0].trim();
    return req.socket.remoteAddress || 'unknown';
  }

  return async function handleRequest(req: IncomingMessage, res: ServerResponse): Promise<void> {
    const start = Date.now();
    applyCORS(req, res, env.ALLOWED_ORIGINS);

    if (req.method === 'OPTIONS') {
      res.writeHead(204);
      res.end();
      return;
    }

    const url = new URL(req.url ?? '/', 'http://internal');
    res.on('finish', () => {
      log.info('request', { method: req.method, path: url.pathname, status: res.statusCode, ms: Date.now() - start });
    });

    if (req.method === 'GET' && url.pathname === '/healthz') {
      sendJSON(res, 200, { status: 'ok' });
      return;
    }

    if (!url.pathname.startsWith('/api/')) {
      sendError(res, 404, 'Not found', 'not_found');
      return;
    }

    const accountsRoute = isAccountsLayerRoute(url.pathname);

    const gatewayAuthorized = isAuthorized(req, env.GATEWAY_API_KEY);
    const mobileAuthorized = !!resolveMobileIdentity(req, accountsStore);
    if (!accountsRoute && !gatewayAuthorized && !mobileAuthorized) {
      sendError(res, 401, 'Missing or invalid Authorization.', 'unauthorized');
      return;
    }

    const rl = rateLimiter.check(clientIp(req));
    res.setHeader('x-ratelimit-remaining', String(rl.remaining));
    if (!rl.allowed) {
      res.setHeader('retry-after', String(Math.ceil(rl.resetMs / 1000)));
      sendError(res, 429, 'Rate limit exceeded', 'rate_limited');
      return;
    }

    try {
      if (req.method === 'GET' && url.pathname === '/api/status') {
        handleHealth(res, env, providers);
        return;
      }

      if (req.method === 'POST' && url.pathname === '/api/chat') {
        await handlePostChat(req, res, { providers, buffer, env, log });
        return;
      }

      const resumeMatch = url.pathname.match(/^\/api\/chat\/resume\/([^/]+)$/);
      if (req.method === 'GET' && resumeMatch) {
        const afterId = Number.parseInt(url.searchParams.get('afterId') ?? '-1', 10);
        await handleResumeChat(req, res, decodeURIComponent(resumeMatch[1]), Number.isNaN(afterId) ? -1 : afterId, { buffer, log });
        return;
      }

      const cancelMatch = url.pathname.match(/^\/api\/chat\/([^/]+)$/);
      if (req.method === 'DELETE' && cancelMatch) {
        await handleCancelChat(res, decodeURIComponent(cancelMatch[1]), { buffer });
        return;
      }

      if (url.pathname === '/api/sync') {
        if (req.method === 'GET') { handleGetSync(req, res, syncStore, accountsStore); return; }
        if (req.method === 'PUT') { await handlePutSync(req, res, syncStore, log, accountsStore); return; }
        if (req.method === 'DELETE') { handleDeleteSync(req, res, syncStore, log, accountsStore); return; }
      }

      if (req.method === 'POST' && url.pathname === '/api/runtime/plan') {
        await handlePostRuntimePlan(req, res, { providers, buffer, log });
        return;
      }
      if (req.method === 'POST' && url.pathname === '/api/runtime/run') {
        const mobileIdentity = resolveMobileIdentity(req, accountsStore);
        await handlePostRuntimeRun(req, res, { providers, buffer, log, accountsStore, mobileUserId: mobileIdentity?.user.id });
        return;
      }

      if (req.method === 'POST' && url.pathname === '/api/tools/fetch') {
        await handlePostToolsFetch(req, res, log);
        return;
      }

      // ── Phase 7: accounts / RBAC / billing layer (additive — see note above) ──
      const accountsCtx = { store: accountsStore, log };

      if (req.method === 'GET' && url.pathname === '/api/auth/google/start') { handleGetAuthGoogleStart(res, env); return; }
      if (req.method === 'GET' && url.pathname === '/api/auth/mobile/google/start') { handleGetAuthMobileGoogleStart(res, env); return; }
      if (req.method === 'GET' && url.pathname === '/api/auth/mobile/google/callback') { await handleGetAuthGoogleCallback(req, res, url, { ...env, GOOGLE_REDIRECT_URI: env.GOOGLE_MOBILE_REDIRECT_URI, PUBLIC_APP_URL_FOR_REDIRECT: env.MOBILE_APP_REDIRECT_URI }, accountsStore, log); return; }
      if (req.method === 'POST' && url.pathname === '/api/auth/mobile/exchange') { handlePostAuthMobileExchange(req, res, accountsStore, env); return; }
      if (req.method === 'POST' && url.pathname === '/api/notifications/token') { await handlePostNotificationToken(req, res, accountsStore); return; }
      if (req.method === 'DELETE' && url.pathname === '/api/notifications/token') { await handleDeleteNotificationToken(req, res, accountsStore); return; }
      if (req.method === 'GET' && url.pathname === '/api/auth/google/callback') { await handleGetAuthGoogleCallback(req, res, url, env, accountsStore, log); return; }
      if (req.method === 'POST' && url.pathname === '/api/auth/logout') { handlePostAuthLogout(req, res, accountsStore, env); return; }
      if (req.method === 'GET' && url.pathname === '/api/auth/me') { handleGetAuthMe(req, res, accountsStore); return; }

      if (req.method === 'POST' && url.pathname === '/api/workspaces') { await handlePostWorkspaces(req, res, accountsCtx); return; }
      if (req.method === 'GET' && url.pathname === '/api/workspaces') { handleGetWorkspaces(req, res, accountsCtx); return; }
      if (req.method === 'POST' && url.pathname === '/api/workspaces/accept-invite') { await handlePostAcceptInvite(req, res, accountsCtx); return; }

      const wsMatch = url.pathname.match(/^\/api\/workspaces\/([^/]+)$/);
      if (wsMatch) {
        const workspaceId = decodeURIComponent(wsMatch[1]);
        if (req.method === 'PATCH') { await handlePatchWorkspace(req, res, accountsCtx, workspaceId); return; }
        if (req.method === 'DELETE') { handleDeleteWorkspace(req, res, accountsCtx, workspaceId); return; }
      }

      const membersMatch = url.pathname.match(/^\/api\/workspaces\/([^/]+)\/members$/);
      if (membersMatch && req.method === 'GET') { handleGetMembers(req, res, accountsCtx, decodeURIComponent(membersMatch[1])); return; }

      const memberMatch = url.pathname.match(/^\/api\/workspaces\/([^/]+)\/members\/([^/]+)$/);
      if (memberMatch) {
        const [, wsId, userId] = memberMatch;
        if (req.method === 'DELETE') { await handleDeleteMember(req, res, accountsCtx, decodeURIComponent(wsId), decodeURIComponent(userId)); return; }
        if (req.method === 'PATCH') { await handlePatchMemberRole(req, res, accountsCtx, decodeURIComponent(wsId), decodeURIComponent(userId)); return; }
      }

      const inviteMatch = url.pathname.match(/^\/api\/workspaces\/([^/]+)\/invites$/);
      if (inviteMatch && req.method === 'POST') { await handlePostInvite(req, res, accountsCtx, decodeURIComponent(inviteMatch[1])); return; }

      const apiKeysMatch = url.pathname.match(/^\/api\/workspaces\/([^/]+)\/api-keys$/);
      if (apiKeysMatch) {
        const workspaceId = decodeURIComponent(apiKeysMatch[1]);
        if (req.method === 'POST') { await handlePostApiKey(req, res, accountsCtx, workspaceId); return; }
        if (req.method === 'GET') { handleGetApiKeys(req, res, accountsCtx, workspaceId); return; }
      }
      const apiKeyMatch = url.pathname.match(/^\/api\/workspaces\/([^/]+)\/api-keys\/([^/]+)$/);
      if (apiKeyMatch && req.method === 'DELETE') {
        handleDeleteApiKey(req, res, accountsCtx, decodeURIComponent(apiKeyMatch[1]), decodeURIComponent(apiKeyMatch[2]));
        return;
      }

      const auditMatch = url.pathname.match(/^\/api\/workspaces\/([^/]+)\/audit-log$/);
      if (auditMatch && req.method === 'GET') { handleGetAuditLog(req, res, accountsCtx, decodeURIComponent(auditMatch[1])); return; }

      if (req.method === 'GET' && url.pathname === '/api/billing/config') { handleGetBillingConfig(res, env); return; }
      if (req.method === 'POST' && url.pathname === '/api/billing/webhook') { await handlePostBillingWebhook(req, res, env, accountsStore, log); return; }
      const billingStatusMatch = url.pathname.match(/^\/api\/billing\/status\/([^/]+)$/);
      if (billingStatusMatch && req.method === 'GET') { handleGetBillingStatus(req, res, accountsStore, decodeURIComponent(billingStatusMatch[1])); return; }

      sendError(res, 404, 'Not found', 'not_found');
    } catch (e: any) {
      log.error('unhandled request error', { error: String(e?.message ?? e), stack: e?.stack });
      if (!res.headersSent) sendError(res, 500, 'Internal server error', 'internal_error');
      else res.end();
    }
  };
}
