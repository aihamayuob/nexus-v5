/**
 * Fail-fast environment loading. Deliberately hand-rolled (no zod/joi)
 * so this file has zero external dependencies and can be imported by
 * anything, including test scripts, without an npm install.
 *
 * Nothing in this file ever logs a secret value — only which keys are
 * *present*, via redact(). Startup fails loudly if the auth secret is
 * missing, since running the gateway without it would silently expose
 * every configured provider key to anyone who can reach the port.
 */

export interface Env {
  PORT: number;
  HOST: string;
  GATEWAY_API_KEY: string; // clients must send this to use /api/*
  PUBLIC_APP_URL?: string;
  ALLOWED_ORIGINS: string[];

  ANTHROPIC_API_KEY?: string;
  OPENAI_API_KEY?: string;
  DEEPSEEK_API_KEY?: string;
  OPENROUTER_API_KEY?: string;
  MISTRAL_API_KEY?: string;
  GEMINI_API_KEY?: string;
  OLLAMA_BASE_URL?: string;
  LMSTUDIO_BASE_URL?: string;

  RATE_LIMIT_MAX_REQUESTS: number;
  RATE_LIMIT_WINDOW_MS: number;
  STREAM_BUFFER_TTL_MS: number;
  LOG_LEVEL: 'debug' | 'info' | 'warn' | 'error';
  SYNC_DB_PATH: string;

  // Phase 7 — all optional: the accounts/RBAC/billing layer is additive.
  // If GOOGLE_CLIENT_ID is unset, /api/auth/* and /api/workspaces/* simply
  // aren't registered — every earlier phase keeps working unchanged.
  ACCOUNTS_DB_PATH: string;
  GOOGLE_CLIENT_ID?: string;
  GOOGLE_CLIENT_SECRET?: string;
  GOOGLE_REDIRECT_URI?: string;
  GOOGLE_MOBILE_REDIRECT_URI?: string;
  MOBILE_APP_REDIRECT_URI?: string;
  PUBLIC_APP_URL_FOR_REDIRECT?: string; // where to send the browser after login completes
  SESSION_TTL_MS: number;
  PADDLE_API_KEY?: string;
  PADDLE_WEBHOOK_SECRET?: string;
  PADDLE_CLIENT_TOKEN?: string; // public, safe to expose to the frontend for Paddle.js
  PADDLE_PRICE_ID_PRO?: string;
}

class EnvValidationError extends Error {}

function required(name: string, source: NodeJS.ProcessEnv): string {
  const v = source[name];
  if (!v || v.trim() === '') {
    throw new EnvValidationError(`Missing required environment variable: ${name}`);
  }
  return v;
}

function optionalInt(name: string, fallback: number, source: NodeJS.ProcessEnv): number {
  const v = source[name];
  if (!v) return fallback;
  const n = Number.parseInt(v, 10);
  if (Number.isNaN(n)) throw new EnvValidationError(`${name} must be an integer, got "${v}"`);
  return n;
}

export function loadEnv(source: NodeJS.ProcessEnv = process.env): Env {
  const atLeastOneProvider = [
    'ANTHROPIC_API_KEY',
    'OPENAI_API_KEY',
    'DEEPSEEK_API_KEY',
    'OPENROUTER_API_KEY',
    'MISTRAL_API_KEY',
    'GEMINI_API_KEY',
    'OLLAMA_BASE_URL',
    'LMSTUDIO_BASE_URL',
  ].some((k) => !!source[k]);

  if (!atLeastOneProvider) {
    throw new EnvValidationError(
      'No provider is configured — set at least one of ANTHROPIC_API_KEY, OPENAI_API_KEY, ' +
        'DEEPSEEK_API_KEY, OPENROUTER_API_KEY, MISTRAL_API_KEY, GEMINI_API_KEY, OLLAMA_BASE_URL, LMSTUDIO_BASE_URL.'
    );
  }

  const gatewayKey = required('GATEWAY_API_KEY', source);
  if (gatewayKey.length < 24) {
    throw new EnvValidationError(
      'GATEWAY_API_KEY is too short (< 24 chars) — generate one with: openssl rand -hex 32'
    );
  }

  return {
    PORT: optionalInt('PORT', 8787, source),
    HOST: source.HOST || '0.0.0.0',
    GATEWAY_API_KEY: gatewayKey,
    PUBLIC_APP_URL: source.PUBLIC_APP_URL,
    ALLOWED_ORIGINS: (source.ALLOWED_ORIGINS || '').split(',').map((s: string) => s.trim()).filter(Boolean),

    ANTHROPIC_API_KEY: source.ANTHROPIC_API_KEY,
    OPENAI_API_KEY: source.OPENAI_API_KEY,
    DEEPSEEK_API_KEY: source.DEEPSEEK_API_KEY,
    OPENROUTER_API_KEY: source.OPENROUTER_API_KEY,
    MISTRAL_API_KEY: source.MISTRAL_API_KEY,
    GEMINI_API_KEY: source.GEMINI_API_KEY,
    OLLAMA_BASE_URL: source.OLLAMA_BASE_URL,
    LMSTUDIO_BASE_URL: source.LMSTUDIO_BASE_URL,

    RATE_LIMIT_MAX_REQUESTS: optionalInt('RATE_LIMIT_MAX_REQUESTS', 30, source),
    RATE_LIMIT_WINDOW_MS: optionalInt('RATE_LIMIT_WINDOW_MS', 60_000, source),
    STREAM_BUFFER_TTL_MS: optionalInt('STREAM_BUFFER_TTL_MS', 120_000, source),
    LOG_LEVEL: (source.LOG_LEVEL as Env['LOG_LEVEL']) || 'info',
    SYNC_DB_PATH: source.SYNC_DB_PATH || './data/sync.sqlite',

    ACCOUNTS_DB_PATH: source.ACCOUNTS_DB_PATH || './data/accounts.sqlite',
    GOOGLE_CLIENT_ID: source.GOOGLE_CLIENT_ID,
    GOOGLE_CLIENT_SECRET: source.GOOGLE_CLIENT_SECRET,
    GOOGLE_REDIRECT_URI: source.GOOGLE_REDIRECT_URI,
    GOOGLE_MOBILE_REDIRECT_URI: source.GOOGLE_MOBILE_REDIRECT_URI,
    MOBILE_APP_REDIRECT_URI: source.MOBILE_APP_REDIRECT_URI,
    PUBLIC_APP_URL_FOR_REDIRECT: source.PUBLIC_APP_URL_FOR_REDIRECT,
    SESSION_TTL_MS: optionalInt('SESSION_TTL_MS', 30 * 24 * 60 * 60 * 1000, source), // 30 days
    PADDLE_API_KEY: source.PADDLE_API_KEY,
    PADDLE_WEBHOOK_SECRET: source.PADDLE_WEBHOOK_SECRET,
    PADDLE_CLIENT_TOKEN: source.PADDLE_CLIENT_TOKEN,
    PADDLE_PRICE_ID_PRO: source.PADDLE_PRICE_ID_PRO,
  };
}

/** Safe-to-log summary — presence only, never values. */
export function redactedSummary(env: Env): Record<string, unknown> {
  const keys = [
    'ANTHROPIC_API_KEY', 'OPENAI_API_KEY', 'DEEPSEEK_API_KEY', 'OPENROUTER_API_KEY',
    'MISTRAL_API_KEY', 'GEMINI_API_KEY',
  ] as const;
  const summary: Record<string, unknown> = {
    port: env.PORT,
    host: env.HOST,
    allowedOrigins: env.ALLOWED_ORIGINS,
    ollama: !!env.OLLAMA_BASE_URL,
    lmstudio: !!env.LMSTUDIO_BASE_URL,
  };
  for (const k of keys) summary[k] = env[k] ? 'configured' : 'not configured';
  return summary;
}
