import { isIP } from 'node:net';

export interface FetchDeps {
  lookup: (hostname: string) => Promise<{ address: string; family: number }>;
  fetchImpl: typeof fetch;
}

export interface SafeFetchOptions {
  timeoutMs: number;
  maxBytes: number;
  maxRedirects: number;
}

export class SSRFBlockedError extends Error {}
export class FetchToolError extends Error {}

/**
 * Blocks the well-known private/reserved ranges, including the two an
 * attacker actually cares about for SSRF against a server that can make
 * outbound requests: loopback (reaching the backend's own local
 * services) and link-local 169.254.0.0/16 (which is where every major
 * cloud provider's instance-metadata endpoint lives — 169.254.169.254 —
 * a classic SSRF-to-credential-theft path).
 */
export function isPrivateOrReservedIP(ip: string): boolean {
  const version = isIP(ip);
  if (version === 4) {
    const parts = ip.split('.').map(Number);
    const [a, b] = parts;
    if (parts.length !== 4 || parts.some((p) => Number.isNaN(p) || p < 0 || p > 255)) return true; // malformed — fail closed
    if (a === 10) return true; // 10.0.0.0/8
    if (a === 172 && b >= 16 && b <= 31) return true; // 172.16.0.0/12
    if (a === 192 && b === 168) return true; // 192.168.0.0/16
    if (a === 127) return true; // 127.0.0.0/8 loopback
    if (a === 169 && b === 254) return true; // 169.254.0.0/16 link-local incl. cloud metadata
    if (a === 0) return true; // 0.0.0.0/8
    if (a === 100 && b >= 64 && b <= 127) return true; // 100.64.0.0/10 carrier-grade NAT
    if (a >= 224) return true; // multicast (224+) and reserved (240+)
    return false;
  }
  if (version === 6) {
    const lower = ip.toLowerCase();
    if (lower === '::1' || lower === '::') return true;
    if (lower.startsWith('fc') || lower.startsWith('fd')) return true; // fc00::/7 unique local
    if (lower.startsWith('fe80')) return true; // fe80::/10 link-local
    if (lower.startsWith('::ffff:')) {
      // IPv4-mapped IPv6 — unwrap and check the embedded IPv4 address too,
      // since this is a well-known way to smuggle a private IPv4 target
      // past a check that only looks at IPv6 syntax.
      return isPrivateOrReservedIP(lower.slice(7));
    }
    return false;
  }
  return true; // not a valid IP at all — fail closed rather than guess
}

/**
 * Fetches `url` as plain text, re-validating the resolved IP (not just
 * the hostname) before every single request — including after each
 * redirect, since `http://evil.com` redirecting to `http://169.254.169.254/`
 * is exactly the attack this exists to stop, and checking only the
 * original URL would miss it entirely.
 */
export async function safeFetchText(
  url: string,
  opts: SafeFetchOptions,
  deps: FetchDeps
): Promise<{ text: string; finalUrl: string; contentType: string; truncated: boolean }> {
  let currentUrl = url;

  for (let hop = 0; hop <= opts.maxRedirects; hop++) {
    let parsed: URL;
    try {
      parsed = new URL(currentUrl);
    } catch {
      throw new FetchToolError(`Invalid URL: "${currentUrl}"`);
    }
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
      throw new SSRFBlockedError(`Blocked protocol "${parsed.protocol}" — only http/https are allowed.`);
    }

    let resolved: { address: string };
    try {
      resolved = await deps.lookup(parsed.hostname);
    } catch (e: any) {
      throw new FetchToolError(`DNS resolution failed for "${parsed.hostname}": ${e.message}`);
    }
    if (isPrivateOrReservedIP(resolved.address)) {
      throw new SSRFBlockedError(
        `Blocked: "${parsed.hostname}" resolves to ${resolved.address}, a private/reserved address. Refusing to fetch internal network targets.`
      );
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), opts.timeoutMs);
    let res: Response;
    try {
      res = await deps.fetchImpl(currentUrl, { signal: controller.signal, redirect: 'manual' });
    } catch (e: any) {
      if (e.name === 'AbortError') throw new FetchToolError(`Request timed out after ${opts.timeoutMs}ms.`);
      throw new FetchToolError(`Fetch failed: ${e.message}`);
    } finally {
      clearTimeout(timeout);
    }

    if ([301, 302, 303, 307, 308].includes(res.status)) {
      const location = res.headers.get('location');
      if (!location) throw new FetchToolError(`Redirect (${res.status}) with no Location header.`);
      currentUrl = new URL(location, currentUrl).toString();
      continue; // next loop iteration re-resolves + re-validates the NEW host
    }

    if (!res.ok) {
      throw new FetchToolError(`HTTP ${res.status} fetching "${currentUrl}".`);
    }

    const contentType = res.headers.get('content-type') || '';
    if (!res.body) return { text: '', finalUrl: currentUrl, contentType, truncated: false };

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let text = '';
    let bytes = 0;
    let truncated = false;
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      bytes += value.length;
      if (bytes > opts.maxBytes) {
        truncated = true;
        await reader.cancel();
        break;
      }
      text += decoder.decode(value, { stream: true });
    }
    return { text, finalUrl: currentUrl, contentType, truncated };
  }

  throw new FetchToolError(`Too many redirects (limit: ${opts.maxRedirects}).`);
}

/** Reasonable-effort HTML-to-text — not a full parser, just enough to
 *  turn a fetched page into something worth spending LLM context on. */
export function stripHtmlToText(html: string): string {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, '')
    .replace(/<style[\s\S]*?<\/style>/gi, '')
    .replace(/<!--[\s\S]*?-->/g, '')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/[ \t]+/g, ' ')
    .replace(/\n\s*\n+/g, '\n\n')
    .trim();
}
