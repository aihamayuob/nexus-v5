import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';

/**
 * This backend is single-tenant by design (one GATEWAY_API_KEY = one
 * person's deployment — see nexus-backend/README.md's "Auth model,
 * honestly" section). Cloud sync follows the same model: there is
 * exactly ONE sync document ('main'), shared across every device that
 * has the gateway key + the sync passphrase. Multi-account sync would
 * need real user accounts, which is Phase 7 (Enterprise) territory, not
 * bolted on here.
 *
 * The server NEVER sees plaintext. `ciphertextB64` and `ivB64` are
 * opaque to it — only `saltB64` (not secret, by design: PBKDF2 salts
 * exist to be public) and bookkeeping (version, device id, timestamp)
 * are readable here. This is what makes it genuinely end-to-end
 * encrypted rather than "encrypted in transit only."
 */

export interface SyncRecord {
  version: number;
  deviceId: string;
  updatedAt: string;
  saltB64: string;
  ivB64: string;
  ciphertextB64: string;
}

export class SyncStore {
  private db: DatabaseSync;

  constructor(dbPath: string) {
    if (dbPath !== ':memory:') {
      try { mkdirSync(dirname(dbPath), { recursive: true }); } catch { /* already exists */ }
    }
    this.db = new DatabaseSync(dbPath);
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS sync_blob (
        id TEXT PRIMARY KEY,
        version INTEGER NOT NULL,
        device_id TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        salt_b64 TEXT NOT NULL,
        iv_b64 TEXT NOT NULL,
        ciphertext_b64 TEXT NOT NULL
      )
    `);
  }

  get(scope = 'main'): SyncRecord | null {
    const row = this.db.prepare('SELECT * FROM sync_blob WHERE id = ?').get(scope) as any;
    if (!row) return null;
    return {
      version: row.version,
      deviceId: row.device_id,
      updatedAt: row.updated_at,
      saltB64: row.salt_b64,
      ivB64: row.iv_b64,
      ciphertextB64: row.ciphertext_b64,
    };
  }

  /**
   * Optimistic-concurrency write: succeeds only if `expectedBaseVersion`
   * matches the version currently stored (or the store is empty and
   * `expectedBaseVersion` is 0). This is the actual conflict-detection
   * mechanism — two devices racing to write both read version N, but
   * only the first PUT actually lands at N+1; the second is rejected
   * with the current record so the client can resolve it explicitly
   * instead of one device's changes silently vanishing.
   */
  putIfVersionMatches(
    expectedBaseVersion: number,
    deviceId: string,
    saltB64: string,
    ivB64: string,
    ciphertextB64: string,
    scope = 'main'
  ): { ok: true; record: SyncRecord } | { ok: false; current: SyncRecord | null } {
    const current = this.get(scope);
    const currentVersion = current?.version ?? 0;
    if (currentVersion !== expectedBaseVersion) {
      return { ok: false, current };
    }

    const record: SyncRecord = {
      version: currentVersion + 1,
      deviceId,
      updatedAt: new Date().toISOString(),
      saltB64,
      ivB64,
      ciphertextB64,
    };

    this.db.prepare(`
      INSERT INTO sync_blob (id, version, device_id, updated_at, salt_b64, iv_b64, ciphertext_b64)
      VALUES (?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET
        version = excluded.version, device_id = excluded.device_id, updated_at = excluded.updated_at,
        salt_b64 = excluded.salt_b64, iv_b64 = excluded.iv_b64, ciphertext_b64 = excluded.ciphertext_b64
    `).run(scope, record.version, record.deviceId, record.updatedAt, record.saltB64, record.ivB64, record.ciphertextB64);

    return { ok: true, record };
  }

  delete(scope = 'main'): void {
    this.db.prepare('DELETE FROM sync_blob WHERE id = ?').run(scope);
  }

  close(): void {
    this.db.close();
  }
}
