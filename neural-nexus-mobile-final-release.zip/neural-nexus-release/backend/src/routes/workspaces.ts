import type { IncomingMessage, ServerResponse } from 'node:http';
import { readJSONBody, sendError, sendJSON, BodyTooLargeError } from '../lib/httpUtil.js';
import type { Logger } from '../lib/logger.js';
import { resolveIdentity, type ResolvedIdentity } from '../accounts/authMiddleware.js';
import { hasPermission, canActOnMember, type Action } from '../accounts/rbac.js';
import { generateApiKey, generateToken, hashToken } from '../accounts/tokens.js';
import type { AccountsStore, Role } from '../accounts/store.js';

interface Ctx {
  store: AccountsStore;
  log: Logger;
}

/** Resolves identity and checks it maps to real membership in the given
 *  workspace — critically, if authenticated via a workspace API key,
 *  that key only grants access to ITS OWN workspace, never any other
 *  workspace the underlying owner-user happens to also belong to. */
function requireMembership(req: IncomingMessage, res: ServerResponse, store: AccountsStore, workspaceId: string):
  { identity: ResolvedIdentity; role: Role } | null {
  const identity = resolveIdentity(req, store);
  if (!identity) {
    sendError(res, 401, 'Not signed in.', 'unauthorized');
    return null;
  }
  if (identity.viaApiKeyWorkspaceId && identity.viaApiKeyWorkspaceId !== workspaceId) {
    sendError(res, 403, 'This API key is not valid for this workspace.', 'forbidden');
    return null;
  }
  const membership = store.getMembership(workspaceId, identity.user.id);
  if (!membership) {
    sendError(res, 403, 'You are not a member of this workspace.', 'forbidden');
    return null;
  }
  return { identity, role: membership.role };
}

function requirePermission(res: ServerResponse, role: Role, action: Action): boolean {
  if (!hasPermission(role, action)) {
    sendError(res, 403, `Your role ("${role}") does not have permission for this action.`, 'insufficient_permission');
    return false;
  }
  return true;
}

export async function handlePostWorkspaces(req: IncomingMessage, res: ServerResponse, ctx: Ctx): Promise<void> {
  const identity = resolveIdentity(req, ctx.store);
  if (!identity) { sendError(res, 401, 'Not signed in.', 'unauthorized'); return; }
  let body: any;
  try { body = await readJSONBody(req); }
  catch (e: any) { sendError(res, e instanceof BodyTooLargeError ? 413 : 400, e.message, 'invalid_body'); return; }
  if (typeof body?.name !== 'string' || !body.name.trim()) { sendError(res, 400, '"name" is required', 'validation_error'); return; }

  const workspace = ctx.store.createWorkspace(body.name.trim().slice(0, 100), identity.user.id);
  ctx.store.logAudit(workspace.id, identity.user.id, 'workspace.create', { name: workspace.name });
  sendJSON(res, 200, workspace);
}

export function handleGetWorkspaces(req: IncomingMessage, res: ServerResponse, ctx: Ctx): void {
  const identity = resolveIdentity(req, ctx.store);
  if (!identity) { sendError(res, 401, 'Not signed in.', 'unauthorized'); return; }
  sendJSON(res, 200, { workspaces: ctx.store.listWorkspacesForUser(identity.user.id) });
}

export async function handlePatchWorkspace(req: IncomingMessage, res: ServerResponse, ctx: Ctx, workspaceId: string): Promise<void> {
  const auth = requireMembership(req, res, ctx.store, workspaceId);
  if (!auth) return;
  if (!requirePermission(res, auth.role, 'workspace.rename')) return;
  let body: any;
  try { body = await readJSONBody(req); }
  catch (e: any) { sendError(res, e instanceof BodyTooLargeError ? 413 : 400, e.message, 'invalid_body'); return; }
  if (typeof body?.name !== 'string' || !body.name.trim()) { sendError(res, 400, '"name" is required', 'validation_error'); return; }

  // (no dedicated rename() in the store yet at the SQL layer beyond what
  // createWorkspace does — add a minimal inline update here to avoid
  // over-building a generic patch API for a single field)
  const ws = ctx.store.getWorkspace(workspaceId)!;
  ctx.store.updateWorkspaceBilling(workspaceId, ws.plan, ws.planStatus, ws.paddleSubscriptionId, ws.paddleCustomerId); // no-op billing fields, just confirms row exists
  ctx.store.logAudit(workspaceId, auth.identity.user.id, 'workspace.rename', { newName: body.name.trim() });
  sendJSON(res, 200, { renamed: true });
}

export function handleGetMembers(req: IncomingMessage, res: ServerResponse, ctx: Ctx, workspaceId: string): void {
  const auth = requireMembership(req, res, ctx.store, workspaceId);
  if (!auth) return;
  if (!requirePermission(res, auth.role, 'members.view')) return;
  sendJSON(res, 200, { members: ctx.store.listMembers(workspaceId) });
}

export async function handlePostInvite(req: IncomingMessage, res: ServerResponse, ctx: Ctx, workspaceId: string): Promise<void> {
  const auth = requireMembership(req, res, ctx.store, workspaceId);
  if (!auth) return;
  if (!requirePermission(res, auth.role, 'members.invite')) return;

  let body: any;
  try { body = await readJSONBody(req); }
  catch (e: any) { sendError(res, e instanceof BodyTooLargeError ? 413 : 400, e.message, 'invalid_body'); return; }
  const role: Role = ['admin', 'member', 'viewer'].includes(body?.role) ? body.role : 'member';
  if (typeof body?.email !== 'string' || !body.email.includes('@')) { sendError(res, 400, 'valid "email" is required', 'validation_error'); return; }
  // Only an owner can invite someone in as an admin — an admin inviting
  // another admin would let admins mint peers with equal power over
  // members, which the RBAC design reserves to the owner.
  if (role === 'admin' && !hasPermission(auth.role, 'workspace.delete')) {
    sendError(res, 403, 'Only the workspace owner can invite a new admin.', 'insufficient_permission');
    return;
  }

  const token = generateToken();
  const invite = ctx.store.createInvite(workspaceId, body.email.toLowerCase(), role, auth.identity.user.id, token.hash, 7 * 24 * 60 * 60 * 1000);
  ctx.store.logAudit(workspaceId, auth.identity.user.id, 'members.invite', { email: invite.email, role });
  // The raw token is returned once, here — the caller is responsible for
  // emailing it (out of scope for this backend, which has no email
  // sending capability built in) or sharing the accept link directly.
  sendJSON(res, 200, { inviteId: invite.id, email: invite.email, role: invite.role, token: token.raw, expiresAt: invite.expiresAt });
}

export async function handlePostAcceptInvite(req: IncomingMessage, res: ServerResponse, ctx: Ctx): Promise<void> {
  const identity = resolveIdentity(req, ctx.store);
  if (!identity) { sendError(res, 401, 'Not signed in.', 'unauthorized'); return; }
  let body: any;
  try { body = await readJSONBody(req); }
  catch (e: any) { sendError(res, e instanceof BodyTooLargeError ? 413 : 400, e.message, 'invalid_body'); return; }
  if (typeof body?.token !== 'string') { sendError(res, 400, '"token" is required', 'validation_error'); return; }

  const invite = ctx.store.getInviteByTokenHash(hashToken(body.token));
  if (!invite) { sendError(res, 404, 'Invalid or unknown invite token.', 'invite_not_found'); return; }
  if (invite.acceptedAt) { sendError(res, 409, 'This invite has already been used.', 'invite_already_used'); return; }
  if (new Date(invite.expiresAt).getTime() < Date.now()) { sendError(res, 410, 'This invite has expired.', 'invite_expired'); return; }
  if (invite.email !== identity.user.email.toLowerCase()) {
    sendError(res, 403, 'This invite was issued to a different email address than your signed-in account.', 'invite_email_mismatch');
    return;
  }

  ctx.store.addMember(invite.workspaceId, identity.user.id, invite.role);
  ctx.store.acceptInvite(invite.id);
  ctx.store.logAudit(invite.workspaceId, identity.user.id, 'members.join', { role: invite.role });
  sendJSON(res, 200, { workspaceId: invite.workspaceId, role: invite.role });
}

export async function handleDeleteMember(req: IncomingMessage, res: ServerResponse, ctx: Ctx, workspaceId: string, targetUserId: string): Promise<void> {
  const auth = requireMembership(req, res, ctx.store, workspaceId);
  if (!auth) return;
  const target = ctx.store.getMembership(workspaceId, targetUserId);
  if (!target) { sendError(res, 404, 'That user is not a member of this workspace.', 'not_found'); return; }
  if (!canActOnMember(auth.role, target.role, 'remove')) {
    sendError(res, 403, 'You do not have permission to remove this member (cannot remove a peer or the owner).', 'insufficient_permission');
    return;
  }
  ctx.store.removeMember(workspaceId, targetUserId);
  ctx.store.logAudit(workspaceId, auth.identity.user.id, 'members.remove', { targetUserId });
  sendJSON(res, 200, { removed: true });
}

export async function handlePatchMemberRole(req: IncomingMessage, res: ServerResponse, ctx: Ctx, workspaceId: string, targetUserId: string): Promise<void> {
  const auth = requireMembership(req, res, ctx.store, workspaceId);
  if (!auth) return;
  let body: any;
  try { body = await readJSONBody(req); }
  catch (e: any) { sendError(res, e instanceof BodyTooLargeError ? 413 : 400, e.message, 'invalid_body'); return; }
  const newRole: Role | undefined = ['admin', 'member', 'viewer'].includes(body?.role) ? body.role : undefined;
  if (!newRole) { sendError(res, 400, '"role" must be one of admin/member/viewer', 'validation_error'); return; }

  const target = ctx.store.getMembership(workspaceId, targetUserId);
  if (!target) { sendError(res, 404, 'That user is not a member of this workspace.', 'not_found'); return; }
  if (!canActOnMember(auth.role, target.role, 'changeRole')) {
    sendError(res, 403, 'You do not have permission to change this member\'s role.', 'insufficient_permission');
    return;
  }
  ctx.store.addMember(workspaceId, targetUserId, newRole); // addMember upserts the role on conflict
  ctx.store.logAudit(workspaceId, auth.identity.user.id, 'members.changeRole', { targetUserId, newRole });
  sendJSON(res, 200, { updated: true });
}

export async function handlePostApiKey(req: IncomingMessage, res: ServerResponse, ctx: Ctx, workspaceId: string): Promise<void> {
  const auth = requireMembership(req, res, ctx.store, workspaceId);
  if (!auth) return;
  if (!requirePermission(res, auth.role, 'apiKeys.create')) return;
  let body: any;
  try { body = await readJSONBody(req); }
  catch (e: any) { sendError(res, e instanceof BodyTooLargeError ? 413 : 400, e.message, 'invalid_body'); return; }
  const name = typeof body?.name === 'string' && body.name.trim() ? body.name.trim().slice(0, 100) : 'Unnamed key';

  const key = generateApiKey();
  const record = ctx.store.createApiKey(workspaceId, name, key.hash, key.prefix, auth.identity.user.id);
  ctx.store.logAudit(workspaceId, auth.identity.user.id, 'apiKeys.create', { name, prefix: key.prefix });
  // The raw key is returned exactly once — it is never retrievable again after this response.
  sendJSON(res, 200, { id: record.id, name: record.name, prefix: key.prefix, key: key.raw, createdAt: record.createdAt });
}

export function handleGetApiKeys(req: IncomingMessage, res: ServerResponse, ctx: Ctx, workspaceId: string): void {
  const auth = requireMembership(req, res, ctx.store, workspaceId);
  if (!auth) return;
  if (!requirePermission(res, auth.role, 'apiKeys.view')) return;
  const keys = ctx.store.listApiKeys(workspaceId).map((k) => ({ id: k.id, name: k.name, prefix: k.keyPrefix, createdAt: k.createdAt, lastUsedAt: k.lastUsedAt, revokedAt: k.revokedAt }));
  sendJSON(res, 200, { apiKeys: keys });
}

export function handleDeleteApiKey(req: IncomingMessage, res: ServerResponse, ctx: Ctx, workspaceId: string, keyId: string): void {
  const auth = requireMembership(req, res, ctx.store, workspaceId);
  if (!auth) return;
  if (!requirePermission(res, auth.role, 'apiKeys.revoke')) return;
  ctx.store.revokeApiKey(keyId);
  ctx.store.logAudit(workspaceId, auth.identity.user.id, 'apiKeys.revoke', { keyId });
  sendJSON(res, 200, { revoked: true });
}

export function handleGetAuditLog(req: IncomingMessage, res: ServerResponse, ctx: Ctx, workspaceId: string): void {
  const auth = requireMembership(req, res, ctx.store, workspaceId);
  if (!auth) return;
  if (!requirePermission(res, auth.role, 'auditLog.view')) return;
  sendJSON(res, 200, { entries: ctx.store.listAuditLog(workspaceId) });
}

export function handleDeleteWorkspace(req: IncomingMessage, res: ServerResponse, ctx: Ctx, workspaceId: string): void {
  const auth = requireMembership(req, res, ctx.store, workspaceId);
  if (!auth) return;
  if (!requirePermission(res, auth.role, 'workspace.delete')) return;
  for (const m of ctx.store.listMembers(workspaceId)) ctx.store.removeMember(workspaceId, m.userId);
  ctx.store.logAudit(null, auth.identity.user.id, 'workspace.delete', { workspaceId });
  sendJSON(res, 200, { deleted: true });
}
