import { randomUUID } from 'node:crypto';
import type { IncomingMessage, ServerResponse } from 'node:http';
import type { Env } from '../config/env.js';
import { BodyTooLargeError, readJSONBody, sendError, sendJSON, startSSE, writeSSEFrame } from '../lib/httpUtil.js';
import type { Logger } from '../lib/logger.js';
import type { StreamBuffer } from '../lib/streamBuffer.js';
import type { ChatRequest, ProviderAdapter, StreamEvent } from '../providers/types.js';
import { UpstreamProviderError } from '../providers/types.js';

interface ChatRequestBody extends ChatRequest {
  stream?: boolean;
}

function validateBody(body: unknown): { ok: true; value: ChatRequestBody } | { ok: false; error: string } {
  if (typeof body !== 'object' || body === null) return { ok: false, error: 'Body must be a JSON object' };
  const b = body as Record<string, unknown>;
  if (typeof b.provider !== 'string' || !b.provider) return { ok: false, error: '"provider" is required' };
  if (typeof b.model !== 'string' || !b.model) return { ok: false, error: '"model" is required' };
  if (!Array.isArray(b.messages)) return { ok: false, error: '"messages" must be an array' };
  return { ok: true, value: b as unknown as ChatRequestBody };
}

/** Serializes one normalized StreamEvent to the (event, data) pair
 *  written on the wire — kept separate from StreamEvent's TS shape so
 *  the wire format can evolve independently of internal typing. */
function toWireFrame(ev: StreamEvent): { event: string; data: string } {
  switch (ev.type) {
    case 'start': return { event: 'start', data: JSON.stringify({ requestId: ev.requestId }) };
    case 'token': return { event: 'token', data: JSON.stringify({ text: ev.text }) };
    case 'tool_use_start': return { event: 'tool_use_start', data: JSON.stringify({ id: ev.id, name: ev.name }) };
    case 'tool_use_delta': return { event: 'tool_use_delta', data: JSON.stringify({ id: ev.id, partialJson: ev.partialJson }) };
    case 'usage': return { event: 'usage', data: JSON.stringify({ inputTokens: ev.inputTokens, outputTokens: ev.outputTokens }) };
    case 'error': return { event: 'error', data: JSON.stringify({ message: ev.message, retryable: ev.retryable, code: ev.code ?? null }) };
    case 'done': return { event: 'done', data: JSON.stringify({ stopReason: ev.stopReason }) };
  }
}

export async function handlePostChat(
  req: IncomingMessage,
  res: ServerResponse,
  ctx: { providers: Map<string, ProviderAdapter>; buffer: StreamBuffer; env: Env; log: Logger }
): Promise<void> {
  let body: unknown;
  try {
    body = await readJSONBody(req);
  } catch (e: any) {
    const status = e instanceof BodyTooLargeError ? 413 : 400;
    sendError(res, status, e.message, e instanceof BodyTooLargeError ? 'payload_too_large' : 'invalid_body');
    return;
  }

  const validated = validateBody(body);
  if (!validated.ok) {
    sendError(res, 400, validated.error, 'validation_error');
    return;
  }
  const chatReq = validated.value;

  const adapter = ctx.providers.get(chatReq.provider);
  if (!adapter) {
    sendError(
      res,
      400,
      `Unknown or unconfigured provider "${chatReq.provider}". Configured: ${[...ctx.providers.keys()].join(', ') || '(none)'}`,
      'unknown_provider'
    );
    return;
  }

  if (!chatReq.stream) {
    // Non-streaming path — response shape is byte-for-byte what the
    // existing frontend's `requestOnce()` already parses, so it keeps
    // working with zero frontend changes.
    const controller = new AbortController();
    res.on('close', () => controller.abort());
    try {
      const result = await adapter.chat(chatReq, controller.signal);
      sendJSON(res, 200, result);
    } catch (e: any) {
      handleAdapterError(res, e, ctx.log);
    }
    return;
  }

  // Streaming path.
  const requestId = randomUUID();
  const controller = new AbortController();
  ctx.buffer.create(requestId, controller);
  res.on('close', () => controller.abort());

  startSSE(res);
  const startFrame = toWireFrame({ type: 'start', requestId });
  const startEntry = ctx.buffer.append(requestId, startFrame.event, startFrame.data)!;
  writeSSEFrame(res, startEntry.id, startEntry.event, startEntry.data);

  try {
    for await (const ev of adapter.streamChat(chatReq, controller.signal)) {
      const frame = toWireFrame(ev);
      const entry = ctx.buffer.append(requestId, frame.event, frame.data);
      if (entry) writeSSEFrame(res, entry.id, entry.event, entry.data);
    }
  } catch (e: any) {
    if (e?.name === 'AbortError') {
      ctx.log.info('stream aborted by client', { requestId });
    } else {
      const message = e instanceof UpstreamProviderError ? e.message : 'Internal streaming error';
      const retryable = e instanceof UpstreamProviderError ? e.retryable : true;
      ctx.log.error('stream failed', { requestId, error: String(e?.message ?? e) });
      const frame = toWireFrame({ type: 'error', message, retryable });
      const entry = ctx.buffer.append(requestId, frame.event, frame.data);
      if (entry) writeSSEFrame(res, entry.id, entry.event, entry.data);
    }
  } finally {
    ctx.buffer.markFinished(requestId);
    res.end();
  }
}

export async function handleResumeChat(
  req: IncomingMessage,
  res: ServerResponse,
  requestId: string,
  afterId: number,
  ctx: { buffer: StreamBuffer; log: Logger }
): Promise<void> {
  if (!ctx.buffer.exists(requestId)) {
    sendError(res, 404, `Unknown or expired requestId "${requestId}" — start a new request instead.`, 'unknown_request');
    return;
  }

  startSSE(res);

  const backlog = ctx.buffer.eventsAfter(requestId, afterId) ?? [];
  for (const entry of backlog) writeSSEFrame(res, entry.id, entry.event, entry.data);

  if (ctx.buffer.isFinished(requestId)) {
    res.end();
    return;
  }

  const unsubscribe = ctx.buffer.subscribe(
    requestId,
    (entry) => writeSSEFrame(res, entry.id, entry.event, entry.data),
    () => res.end()
  );
  res.on('close', unsubscribe);
}

export async function handleCancelChat(
  res: ServerResponse,
  requestId: string,
  ctx: { buffer: StreamBuffer }
): Promise<void> {
  const found = ctx.buffer.abort(requestId);
  sendJSON(res, found ? 200 : 404, { cancelled: found });
}

function handleAdapterError(res: ServerResponse, e: unknown, log: Logger): void {
  if (e instanceof UpstreamProviderError) {
    log.warn('upstream provider error', { status: e.statusCode, retryable: e.retryable });
    sendError(res, e.statusCode >= 400 && e.statusCode < 600 ? e.statusCode : 502, e.message, 'upstream_error');
    return;
  }
  log.error('unexpected chat handler error', { error: String((e as Error)?.message ?? e) });
  sendError(res, 500, 'Internal server error', 'internal_error');
}
