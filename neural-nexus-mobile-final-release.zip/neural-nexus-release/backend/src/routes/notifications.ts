import type { IncomingMessage, ServerResponse } from 'node:http';
import { BodyTooLargeError, readJSONBody, sendError, sendJSON } from '../lib/httpUtil.js';
import { resolveMobileIdentity } from '../accounts/authMiddleware.js';
import type { AccountsStore, PushTokenRecord } from '../accounts/store.js';

const EXPO_TOKEN_RE = /^(ExponentPushToken|ExpoPushToken)\[[^\]\s]{10,256}\]$/;

export async function handlePostNotificationToken(req: IncomingMessage, res: ServerResponse, store: AccountsStore): Promise<void> {
  const identity = resolveMobileIdentity(req, store);
  if (!identity) { sendError(res, 401, 'A mobile session is required.', 'unauthorized'); return; }
  let body: any;
  try { body = await readJSONBody(req); }
  catch (e: any) { sendError(res, e instanceof BodyTooLargeError ? 413 : 400, e.message, 'invalid_body'); return; }
  const token = typeof body?.token === 'string' ? body.token.trim() : '';
  const platform: PushTokenRecord['platform'] = ['android', 'ios'].includes(body?.platform) ? body.platform : 'unknown';
  if (!EXPO_TOKEN_RE.test(token)) { sendError(res, 400, 'A valid Expo push token is required.', 'validation_error'); return; }
  const record = store.upsertPushToken(identity.user.id, token, platform);
  store.logAudit(null, identity.user.id, 'notifications.register', { platform });
  sendJSON(res, 200, { registered: true, id: record.id, platform: record.platform });
}

export async function handleDeleteNotificationToken(req: IncomingMessage, res: ServerResponse, store: AccountsStore): Promise<void> {
  const identity = resolveMobileIdentity(req, store);
  if (!identity) { sendError(res, 401, 'A mobile session is required.', 'unauthorized'); return; }
  let body: any;
  try { body = await readJSONBody(req); }
  catch (e: any) { sendError(res, e instanceof BodyTooLargeError ? 413 : 400, e.message, 'invalid_body'); return; }
  const token = typeof body?.token === 'string' ? body.token.trim() : '';
  if (!EXPO_TOKEN_RE.test(token)) { sendError(res, 400, 'A valid Expo push token is required.', 'validation_error'); return; }
  store.deletePushToken(identity.user.id, token);
  sendJSON(res, 200, { deleted: true });
}
