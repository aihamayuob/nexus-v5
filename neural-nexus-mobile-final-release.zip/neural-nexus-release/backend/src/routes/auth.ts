import { randomBytes } from 'node:crypto';
import type { IncomingMessage, ServerResponse } from 'node:http';
import { sendError, sendJSON } from '../lib/httpUtil.js';
import type { Logger } from '../lib/logger.js';
import type { Env } from '../config/env.js';
import { buildGoogleAuthUrl, decodeIdToken, exchangeCodeForTokens, GoogleOAuthError } from '../accounts/googleOAuth.js';
import { generatePrefixedToken, generateToken, hashToken } from '../accounts/tokens.js';
import { serializeCookie, serializeExpiredCookie } from '../accounts/cookies.js';
import { SESSION_COOKIE_NAME, resolveIdentity } from '../accounts/authMiddleware.js';
import { parseCookies } from '../accounts/cookies.js';
import type { AccountsStore } from '../accounts/store.js';

// Short-lived CSRF state for the OAuth round trip — a few minutes is
// plenty; this never needs to survive a restart, so in-memory is fine
// (same reasoning as the existing StreamBuffer's TTL'd in-memory design).
const OAUTH_STATE_TTL_MS = 5 * 60 * 1000;
const MOBILE_AUTH_CODE_TTL_MS = 60 * 1000;
const pendingStates = new Map<string, { createdAt: number; mobile: boolean }>();
function sweepStates() {
  const cutoff = Date.now() - OAUTH_STATE_TTL_MS;
  for (const [state, value] of pendingStates) if (value.createdAt < cutoff) pendingStates.delete(state);
}

export function handleGetAuthGoogleStart(res: ServerResponse, env: Env): void {
  if (!env.GOOGLE_CLIENT_ID || !env.GOOGLE_REDIRECT_URI) {
    sendError(res, 501, 'Google OAuth is not configured on this backend (GOOGLE_CLIENT_ID/GOOGLE_REDIRECT_URI unset).', 'oauth_not_configured');
    return;
  }
  sweepStates();
  const state = randomBytes(24).toString('base64url');
  pendingStates.set(state, { createdAt: Date.now(), mobile: false });
  const url = buildGoogleAuthUrl(env.GOOGLE_CLIENT_ID, env.GOOGLE_REDIRECT_URI, state);
  res.writeHead(302, { location: url });
  res.end();
}

export function handleGetAuthMobileGoogleStart(res: ServerResponse, env: Env): void {
  if (!env.GOOGLE_CLIENT_ID || !env.GOOGLE_CLIENT_SECRET || !env.GOOGLE_MOBILE_REDIRECT_URI || !env.MOBILE_APP_REDIRECT_URI) {
    sendError(res, 501, 'Mobile Google OAuth is not configured (GOOGLE_CLIENT_ID/GOOGLE_CLIENT_SECRET/GOOGLE_MOBILE_REDIRECT_URI/MOBILE_APP_REDIRECT_URI).', 'mobile_oauth_not_configured');
    return;
  }
  sweepStates();
  const state = randomBytes(24).toString('base64url');
  pendingStates.set(state, { createdAt: Date.now(), mobile: true });
  const googleUrl = buildGoogleAuthUrl(env.GOOGLE_CLIENT_ID, env.GOOGLE_MOBILE_REDIRECT_URI, state);
  res.writeHead(302, { location: googleUrl });
  res.end();
}

export async function handleGetAuthGoogleCallback(
  req: IncomingMessage,
  res: ServerResponse,
  url: URL,
  env: Env,
  store: AccountsStore,
  log: Logger
): Promise<void> {
  const code = url.searchParams.get('code');
  const state = url.searchParams.get('state');
  const errorParam = url.searchParams.get('error');

  const pending = state ? pendingStates.get(state) : undefined;
  const isMobileFlow = !!pending?.mobile;
  const redirectBase = isMobileFlow ? (env.MOBILE_APP_REDIRECT_URI || '/') : (env.PUBLIC_APP_URL_FOR_REDIRECT || '/');

  if (errorParam) {
    res.writeHead(302, { location: `${redirectBase}?auth_error=${encodeURIComponent(errorParam)}` });
    res.end();
    return;
  }
  if (!code || !state || !pending) {
    res.writeHead(302, { location: `${redirectBase}?auth_error=invalid_state` });
    res.end();
    return;
  }
  pendingStates.delete(state); // one-time use

  if (!env.GOOGLE_CLIENT_ID || !env.GOOGLE_CLIENT_SECRET || !env.GOOGLE_REDIRECT_URI) {
    sendError(res, 501, 'Google OAuth is not configured on this backend.', 'oauth_not_configured');
    return;
  }

  try {
    const tokens = await exchangeCodeForTokens(code, env.GOOGLE_CLIENT_ID, env.GOOGLE_CLIENT_SECRET, env.GOOGLE_REDIRECT_URI, fetch);
    const claims = decodeIdToken(tokens.idToken, env.GOOGLE_CLIENT_ID);
    if (!claims.emailVerified) {
      res.writeHead(302, { location: `${redirectBase}?auth_error=email_not_verified` });
      res.end();
      return;
    }

    const user = store.findOrCreateUserByGoogle(claims.sub, claims.email, claims.name, claims.picture);

    if (isMobileFlow) {
      store.purgeExpiredMobileAuthCodes();
      const mobileCode = generatePrefixedToken('nxc_', 24);
      store.createMobileAuthCode(user.id, mobileCode.hash, MOBILE_AUTH_CODE_TTL_MS);
      store.logAudit(null, user.id, 'auth.mobile_login_code_issued', { method: 'google' });
      const target = `${redirectBase}${redirectBase.includes('?') ? '&' : '?'}code=${encodeURIComponent(mobileCode.raw)}`;
      res.writeHead(302, { location: target });
      res.end();
      return;
    }

    const session = generateToken();
    store.createSession(user.id, session.hash, env.SESSION_TTL_MS);
    store.logAudit(null, user.id, 'auth.login', { method: 'google' });

    const isHttps = (env.PUBLIC_APP_URL_FOR_REDIRECT ?? '').startsWith('https://');
    res.writeHead(302, {
      location: redirectBase,
      'set-cookie': serializeCookie(SESSION_COOKIE_NAME, session.raw, {
        maxAgeSeconds: Math.floor(env.SESSION_TTL_MS / 1000),
        secure: isHttps,
      }),
    });
    res.end();
  } catch (e: any) {
    log.warn('Google OAuth callback failed', { error: String(e?.message ?? e) });
    const code = e instanceof GoogleOAuthError ? 'oauth_failed' : 'internal_error';
    res.writeHead(302, { location: `${redirectBase}?auth_error=${code}` });
    res.end();
  }
}

export function handlePostAuthMobileExchange(req: IncomingMessage, res: ServerResponse, store: AccountsStore, env: Env): void {
  let body: any = {};
  const chunks: Buffer[] = [];
  let size = 0;
  req.on('data', (chunk: Buffer) => {
    size += chunk.length;
    if (size <= 16 * 1024) chunks.push(chunk);
  });
  req.on('end', () => {
    try {
      body = JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}');
    } catch {
      sendError(res, 400, 'Request body is not valid JSON.', 'invalid_body');
      return;
    }
    if (typeof body?.code !== 'string' || !/^nxc_[A-Za-z0-9_-]+$/.test(body.code)) {
      sendError(res, 400, 'A valid one-time mobile authorization code is required.', 'validation_error');
      return;
    }
    const user = store.consumeMobileAuthCode(hashToken(body.code));
    if (!user) {
      sendError(res, 401, 'The mobile authorization code is invalid, expired, or already used.', 'invalid_mobile_code');
      return;
    }
    const session = generatePrefixedToken('nxm_live_');
    store.createSession(user.id, session.hash, env.SESSION_TTL_MS);
    store.logAudit(null, user.id, 'auth.mobile_login', { method: 'google' });
    sendJSON(res, 200, {
      accessToken: session.raw,
      expiresIn: Math.floor(env.SESSION_TTL_MS / 1000),
      user: { id: user.id, email: user.email, name: user.name, avatarUrl: user.avatarUrl },
    });
  });
}

export function handlePostAuthLogout(req: IncomingMessage, res: ServerResponse, store: AccountsStore, env: Env): void {
  const authHeader = req.headers['authorization'];
  if (typeof authHeader === 'string') {
    const mobileMatch = authHeader.match(/^Bearer (nxm_live_\S+)$/);
    if (mobileMatch) {
      store.deleteSession(hashToken(mobileMatch[1]!));
      sendJSON(res, 200, { loggedOut: true });
      return;
    }
  }

  const cookies = parseCookies(req.headers['cookie'] as string | undefined);
  const rawSession = cookies[SESSION_COOKIE_NAME];
  if (rawSession) store.deleteSession(hashToken(rawSession));

  const isHttps = (env.PUBLIC_APP_URL_FOR_REDIRECT ?? '').startsWith('https://');
  res.setHeader('set-cookie', serializeExpiredCookie(SESSION_COOKIE_NAME, '/', isHttps));
  sendJSON(res, 200, { loggedOut: true });
}

export function handleGetAuthMe(req: IncomingMessage, res: ServerResponse, store: AccountsStore): void {
  const identity = resolveIdentity(req, store);
  if (!identity) {
    sendError(res, 401, 'Not signed in.', 'unauthorized');
    return;
  }
  sendJSON(res, 200, {
    id: identity.user.id,
    email: identity.user.email,
    name: identity.user.name,
    avatarUrl: identity.user.avatarUrl,
  });
}
