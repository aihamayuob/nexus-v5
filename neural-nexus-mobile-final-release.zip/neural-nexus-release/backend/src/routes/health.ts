import type { ServerResponse } from 'node:http';
import type { Env } from '../config/env.js';
import { redactedSummary } from '../config/env.js';
import { sendJSON } from '../lib/httpUtil.js';
import type { ProviderAdapter } from '../providers/types.js';

const startedAt = Date.now();

export function handleHealth(
  res: ServerResponse,
  env: Env,
  providers: Map<string, ProviderAdapter>
): void {
  sendJSON(res, 200, {
    status: 'ok',
    uptimeSeconds: Math.round((Date.now() - startedAt) / 1000),
    providersConfigured: [...providers.keys()],
    config: redactedSummary(env),
    memory: process.memoryUsage.rss ? { rssMB: Math.round(process.memoryUsage().rss / 1024 / 1024) } : undefined,
  });
}
