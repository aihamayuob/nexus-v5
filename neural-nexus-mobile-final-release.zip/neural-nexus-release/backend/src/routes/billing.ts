import type { IncomingMessage, ServerResponse } from 'node:http';
import { readRawBody, sendError, sendJSON } from '../lib/httpUtil.js';
import type { Logger } from '../lib/logger.js';
import type { Env } from '../config/env.js';
import { resolveIdentity } from '../accounts/authMiddleware.js';
import { hasPermission } from '../accounts/rbac.js';
import { mapPaddleStatus, parsePaddleSubscriptionEvent, verifyPaddleWebhookSignature, PaddleSignatureError } from '../accounts/paddleWebhook.js';
import type { AccountsStore } from '../accounts/store.js';

export function handleGetBillingConfig(res: ServerResponse, env: Env): void {
  if (!env.PADDLE_CLIENT_TOKEN) {
    sendError(res, 501, 'Billing is not configured on this backend.', 'billing_not_configured');
    return;
  }
  // All of these are meant to be public — a Paddle client-side token and
  // price IDs are not secrets (same category as a Stripe publishable key).
  sendJSON(res, 200, { clientToken: env.PADDLE_CLIENT_TOKEN, priceIds: { pro: env.PADDLE_PRICE_ID_PRO ?? null } });
}

export function handleGetBillingStatus(req: IncomingMessage, res: ServerResponse, store: AccountsStore, workspaceId: string): void {
  const identity = resolveIdentity(req, store);
  if (!identity) { sendError(res, 401, 'Not signed in.', 'unauthorized'); return; }
  const membership = store.getMembership(workspaceId, identity.user.id);
  if (!membership) { sendError(res, 403, 'You are not a member of this workspace.', 'forbidden'); return; }
  if (!hasPermission(membership.role, 'workspace.billing.view')) {
    sendError(res, 403, 'Your role does not have permission to view billing.', 'insufficient_permission');
    return;
  }
  const ws = store.getWorkspace(workspaceId);
  if (!ws) { sendError(res, 404, 'Workspace not found.', 'not_found'); return; }
  sendJSON(res, 200, { plan: ws.plan, planStatus: ws.planStatus });
}

export async function handlePostBillingWebhook(req: IncomingMessage, res: ServerResponse, env: Env, store: AccountsStore, log: Logger): Promise<void> {
  if (!env.PADDLE_WEBHOOK_SECRET) {
    sendError(res, 501, 'Billing webhooks are not configured on this backend.', 'billing_not_configured');
    return;
  }

  const rawBody = await readRawBody(req);
  try {
    verifyPaddleWebhookSignature(rawBody, req.headers['paddle-signature'] as string | undefined, env.PADDLE_WEBHOOK_SECRET);
  } catch (e: any) {
    log.warn('Rejected webhook with invalid Paddle signature', { error: e.message });
    sendError(res, 400, e instanceof PaddleSignatureError ? e.message : 'Signature verification failed.', 'invalid_signature');
    return;
  }

  let payload: unknown;
  try {
    payload = JSON.parse(rawBody);
  } catch {
    sendError(res, 400, 'Body is not valid JSON.', 'invalid_body');
    return;
  }

  const event = parsePaddleSubscriptionEvent(payload);
  if (!event) {
    // Not a subscription.* event (or missing fields) — acknowledge with
    // 200 anyway. Paddle retries on non-2xx, and there's nothing wrong
    // with an event type we simply don't act on; retrying it forever
    // would be a bug, not a safeguard.
    sendJSON(res, 200, { acknowledged: true, handled: false });
    return;
  }

  const workspaceId = event.customData?.workspaceId as string | undefined;
  if (!workspaceId) {
    log.warn('Paddle subscription event had no workspaceId in custom_data — cannot apply it', { subscriptionId: event.subscriptionId });
    sendJSON(res, 200, { acknowledged: true, handled: false });
    return;
  }
  const ws = store.getWorkspace(workspaceId);
  if (!ws) {
    log.warn('Paddle event referenced an unknown workspace', { workspaceId });
    sendJSON(res, 200, { acknowledged: true, handled: false });
    return;
  }

  const status = mapPaddleStatus(event.status);
  const plan = status === 'canceled' ? 'free' : 'pro';
  store.updateWorkspaceBilling(workspaceId, plan, status, event.subscriptionId, event.customerId);
  store.logAudit(workspaceId, null, 'billing.webhook', { eventType: event.eventType, status });
  log.info('Applied Paddle subscription event', { workspaceId, eventType: event.eventType, status });
  sendJSON(res, 200, { acknowledged: true, handled: true });
}
