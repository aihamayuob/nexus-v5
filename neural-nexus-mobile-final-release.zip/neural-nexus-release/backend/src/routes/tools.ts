import { lookup } from 'node:dns/promises';
import type { IncomingMessage, ServerResponse } from 'node:http';
import { readJSONBody, sendError, sendJSON, BodyTooLargeError } from '../lib/httpUtil.js';
import type { Logger } from '../lib/logger.js';
import { safeFetchText, stripHtmlToText, SSRFBlockedError, FetchToolError } from '../tools/webFetch.js';

const FETCH_OPTIONS = { timeoutMs: 10_000, maxBytes: 2_000_000, maxRedirects: 5 };
const MAX_TEXT_CHARS_RETURNED = 8000; // this feeds directly into LLM context — keep it bounded regardless of page size

export async function handlePostToolsFetch(req: IncomingMessage, res: ServerResponse, log: Logger): Promise<void> {
  let body: any;
  try {
    body = await readJSONBody(req);
  } catch (e: any) {
    const status = e instanceof BodyTooLargeError ? 413 : 400;
    sendError(res, status, e.message, e instanceof BodyTooLargeError ? 'payload_too_large' : 'invalid_body');
    return;
  }

  if (typeof body?.url !== 'string' || !body.url.trim()) {
    sendError(res, 400, '"url" is required', 'validation_error');
    return;
  }

  try {
    const result = await safeFetchText(body.url, FETCH_OPTIONS, { lookup, fetchImpl: fetch });
    const isHtml = result.contentType.includes('html');
    const text = isHtml ? stripHtmlToText(result.text) : result.text;
    const truncatedForContext = text.length > MAX_TEXT_CHARS_RETURNED;
    sendJSON(res, 200, {
      finalUrl: result.finalUrl,
      contentType: result.contentType,
      text: text.slice(0, MAX_TEXT_CHARS_RETURNED),
      truncated: result.truncated || truncatedForContext,
    });
  } catch (e: any) {
    if (e instanceof SSRFBlockedError) {
      log.warn('web_fetch tool blocked a request', { message: e.message });
      sendError(res, 400, e.message, 'blocked_target');
      return;
    }
    if (e instanceof FetchToolError) {
      sendError(res, 502, e.message, 'fetch_failed');
      return;
    }
    log.error('web_fetch tool unexpected error', { error: String(e?.message ?? e) });
    sendError(res, 500, 'Internal error', 'internal_error');
  }
}
