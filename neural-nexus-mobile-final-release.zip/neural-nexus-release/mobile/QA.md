# Neural Nexus Mobile — Final QA Gate

## Implemented
- React Native / Expo / TypeScript / Expo Router.
- Google mobile OAuth with one-time code callback and SecureStore session.
- Backend bearer token `nxm_live_*`.
- Chat SSE using the backend normalized `token` event.
- Dynamic provider discovery from `/api/status`.
- Single, Collective, Situation Room, Mirror, Cross-Examination, Deep Analysis, Multi-Model and Bias Watcher modes.
- Agent registry preserved in `src/data/agents.ts`.
- Knowledge base with sensitive local entries in SecureStore.
- Push token registration through `/api/notifications/token`.
- Camera/image/file/location packages configured for native expansion.
- E2E mobile-to-mobile cloud sync using the Web platform's PBKDF2-SHA256 150,000 iterations + AES-256-GCM format (`saltB64`, `ivB64`, `ciphertextB64`).
- Sync conflict remains HTTP 409 and is never silently overwritten.

## Verified from source
- Backend has `/api/auth/mobile/google/start`, `/api/auth/mobile/google/callback`, `/api/auth/mobile/exchange`.
- Backend accepts `Authorization: Bearer nxm_live_*`.
- Backend `/api/chat` emits `event: token` with `{text}`.
- Backend `/api/runtime/plan` and `/api/runtime/run` exist.
- Backend `/api/sync` is versioned and returns 409 on conflicts.
- Backend `/api/notifications/token` exists.
- Backend `/api/status` returns `providersConfigured`.

## Environment limitation
The supplied execution environment does not provide the project's npm registry dependencies (`@types/node` and the Expo dependency graph are not installable from the internal registry). Therefore a native Android/iOS build and full TypeScript project typecheck cannot truthfully be marked as executed here.

## Required release verification on the developer machine
1. `npm install`
2. `npm run typecheck`
3. `npx expo-doctor`
4. Configure `.env` with `EXPO_PUBLIC_API_BASE_URL`.
5. Configure Google OAuth redirect URI to `/api/auth/mobile/google/callback`.
6. `npx expo start` for UI/chat smoke test.
7. Development builds for Android and iOS for OAuth, notifications and native modules.
8. Test Google login -> callback -> SecureStore -> `/api/auth/me`.
9. Test each advanced mode with at least one configured provider.
10. Test sync on two authenticated devices with the same passphrase and a deliberate 409 conflict.
