# Feature Matrix — Mobile

| Feature | Mobile | Backend dependency | Status |
|---|---|---|---|
| Single Chat | Yes | `/api/chat` | Ready for integration test |
| SSE | Yes | `/api/chat` stream | Ready |
| Agent list | Yes | None | Implemented |
| Domain Groups | Data layer | None | Implemented |
| Collective | Yes | `/api/chat` | Implemented client orchestration |
| Situation Room | Yes | `/api/chat` | Implemented client orchestration |
| Mirror Mode | Yes | `/api/chat` | Implemented client orchestration |
| Cross Examination | Yes | `/api/chat` | Implemented client orchestration |
| Deep Analysis | Yes | `/api/chat` | Implemented multi-stage orchestration |
| Multi-model | Yes | `/api/chat` | Requires provider keys server-side |
| Bias Watcher | Yes | `/api/chat` | Implemented |
| Agent Runtime | Adapter | `/api/runtime/*` | Requires real Backend contract test |
| Workspaces | Adapter | `/api/workspaces` | Requires real Backend contract test |
| Knowledge | Yes | None for local | Implemented |
| Sensitive local KB | Yes | SecureStore | Implemented local-only |
| Cloud E2E Sync | Adapter only | `/api/sync` | BLOCKED until Web/Backend crypto parity verified |
| Camera/Gallery | Yes | Optional upload contract | Implemented native picker |
| Files | Yes | Optional ingestion | Implemented picker; parsing/upload contract remains backend-specific |
| Location | Yes | None | Permission + one-shot location |
| Push Notifications | Adapter | `/api/notifications/token` | Requires development/release build + backend endpoint |
| Deep Links | Yes | OAuth callback | Requires production/development build |
| OAuth | Flow adapter | `/api/auth/*` | Requires exact Backend mobile exchange endpoint |
| Secure Session | Yes | Mobile token endpoint | Implemented client-side |
