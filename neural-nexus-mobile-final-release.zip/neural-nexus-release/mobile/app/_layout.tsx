import{Stack,Redirect,useSegments}from'expo-router';import React,{useEffect,useState}from'react';import{getToken}from'../src/lib/secure';
function Guard(){const[ready,setReady]=useState(false);const[auth,setAuth]=useState(false);const seg=useSegments();useEffect(()=>{getToken().then(v=>{setAuth(!!v);setReady(true)})},[seg.join('/')]);if(!ready)return null;const inAuth=seg[0]==='auth';if(!auth&&!inAuth)return <Redirect href="/auth/sign-in"/>;return null}
export default function Layout(){return <><Guard/><Stack screenOptions={{headerShown:false,contentStyle:{backgroundColor:'#05070d'}}}/></>}
