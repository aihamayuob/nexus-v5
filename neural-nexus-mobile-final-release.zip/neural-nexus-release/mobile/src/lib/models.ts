import type {Provider} from '../api/types';
export const DEFAULT_MODELS:Record<Provider,string>={anthropic:'claude-sonnet-4-6',openai:'gpt-5.5',deepseek:'deepseek-chat',gemini:'gemini-2.5-flash',openrouter:'openai/gpt-5.5',mistral:'mistral-large-latest',ollama:'llama3.2',lmstudio:'local-model'};
export function modelFor(provider:Provider){return DEFAULT_MODELS[provider];}
