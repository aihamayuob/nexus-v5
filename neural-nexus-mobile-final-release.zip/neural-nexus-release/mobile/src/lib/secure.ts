import * as SecureStore from 'expo-secure-store';
const TOKEN='nexus.mobile.access_token';
const DEVICE='nexus.mobile.device_id';
export async function saveToken(v:string){await SecureStore.setItemAsync(TOKEN,v,{keychainAccessible:SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY});}
export async function getToken(){return SecureStore.getItemAsync(TOKEN);}
export async function clearToken(){await SecureStore.deleteItemAsync(TOKEN);}
export async function getDeviceId(){let v=await SecureStore.getItemAsync(DEVICE);if(!v){v=`mob_${Date.now()}_${Math.random().toString(36).slice(2)}`;await SecureStore.setItemAsync(DEVICE,v,{keychainAccessible:SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY});}return v;}
