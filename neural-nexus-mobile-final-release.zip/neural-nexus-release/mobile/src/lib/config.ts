export function requireApiBase(){const value=process.env.EXPO_PUBLIC_API_BASE_URL;if(typeof value!=='string'||!value.trim())throw new Error('رابط Backend غير مضبوط. ضع EXPO_PUBLIC_API_BASE_URL في .env.');return value.replace(/\/$/,'');}
export const APP_SCHEME=String(process.env.EXPO_PUBLIC_APP_SCHEME||'neuralnexus');
