import AsyncStorage from '@react-native-async-storage/async-storage';
// Optional dependency is intentionally isolated. If not installed, replace this adapter with your chosen local store.
export async function loadJSON<T>(key:string, fallback:T):Promise<T>{try{const raw=await AsyncStorage.getItem(key);return raw?JSON.parse(raw):fallback}catch{return fallback}}
export async function saveJSON<T>(key:string,value:T){await AsyncStorage.setItem(key,JSON.stringify(value));}
