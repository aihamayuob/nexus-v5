import {loadJSON,saveJSON} from './local';
export type LocalState={messages:{role:'user'|'assistant';content:string;agentId?:string;agentName?:string;type?:string}[];selectedAgentIds:string[];settings:{provider:'anthropic'|'openai'|'deepseek'|'gemini'|'openrouter'|'mistral'|'ollama'|'lmstudio';mode:string;bias:boolean;cloudSync:boolean;language:'ar'|'en'|'fr'};knowledge:{id:string;title:string;content:string;sensitive:boolean}[]};
const KEY='neural-nexus.mobile.state.v1';
export const defaultState:LocalState={messages:[],selectedAgentIds:['general'],settings:{provider:'anthropic',mode:'single',bias:false,cloudSync:false,language:'ar'},knowledge:[]};
export async function loadState(){return loadJSON(KEY,defaultState)}
export async function saveState(s:LocalState){return saveJSON(KEY,s)}
