import {requireApiBase} from '../lib/config';
import {getToken} from '../lib/secure';
export class ApiError extends Error{constructor(public status:number,public body:unknown){super(`HTTP ${status}`);this.name='ApiError';}}
export async function api<T>(path:string,init:RequestInit={}):Promise<T>{
 const token=await getToken(); const headers=new Headers(init.headers); headers.set('Accept','application/json');
 if(init.body&&!headers.has('Content-Type')) headers.set('Content-Type','application/json');
 if(token) headers.set('Authorization',`Bearer ${token}`);
 const r=await fetch(requireApiBase()+path,{...init,headers});
 const ct=r.headers.get('content-type')||''; const body=ct.includes('json')?await r.json().catch(()=>null):await r.text().catch(()=> '');
 if(!r.ok) throw new ApiError(r.status,body); return body as T;
}
