export type Provider = 'anthropic'|'openai'|'deepseek'|'gemini'|'openrouter'|'mistral'|'ollama'|'lmstudio';
export type ChatMessage = { role:'user'|'assistant'; content: unknown };
export type ChatRequest = { provider:Provider; model:string; system?:string; messages:ChatMessage[]; maxTokens?:number; temperature?:number };
export type SSEFrame = { event:string; data:string; id?:string|null };
