import {api} from './client';
import type {Provider} from './types';
export const auth={me:()=>api<any>('/api/auth/me'),logout:()=>api<any>('/api/auth/logout',{method:'POST'}),exchange:(code:string)=>api<any>('/api/auth/mobile/exchange',{method:'POST',body:JSON.stringify({code})}),googleStart:()=>requireBackendUrl('/api/auth/mobile/google/start')};
function requireBackendUrl(path:string){return `${requireApiBase()}${path}`;}
import {requireApiBase} from '../lib/config';
export const status={get:()=>api<{status:string;providersConfigured:Provider[]}>('/api/status')};
export const runtime={plan:(goal:string,provider?:Provider,model?:string)=>api<any>('/api/runtime/plan',{method:'POST',body:JSON.stringify({goal,provider,model})}),run:(plan:any,config?:any)=>api<any>('/api/runtime/run',{method:'POST',body:JSON.stringify({plan,config})})};
export const sync={get:()=>api<any>('/api/sync'),put:(body:any)=>api<any>('/api/sync',{method:'PUT',body:JSON.stringify(body)}),remove:()=>api<any>('/api/sync',{method:'DELETE'})};
export const workspaces={list:()=>api<any[]>('/api/workspaces')};
export const notifications={register:(token:string,platform:'android'|'ios'|'unknown')=>api<any>('/api/notifications/token',{method:'POST',body:JSON.stringify({token,platform})}),remove:(token:string)=>api<any>('/api/notifications/token',{method:'DELETE',body:JSON.stringify({token})})};
