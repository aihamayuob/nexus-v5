import {fetch as expoFetch} from 'expo/fetch';
import {requireApiBase} from '../lib/config';
import {getToken} from '../lib/secure';
import type {ChatRequest,SSEFrame} from './types';
function parseFrame(raw:string):SSEFrame|null{let event:string|undefined;let id:string|undefined;const data:string[]=[];for(const line of raw.split('\n')){if(!line||line.startsWith(':'))continue;const i=line.indexOf(':');const k=i<0?line:line.slice(0,i);let v=i<0?'':line.slice(i+1);if(v.startsWith(' '))v=v.slice(1);if(k==='event')event=v;else if(k==='id')id=v;else if(k==='data')data.push(v);}if(!event&&data.length===0)return null;return{event:event||'message',data:data.join('\n'),id};}
export async function streamChat(req:ChatRequest,onFrame:(f:SSEFrame)=>void,signal?:AbortSignal){
 const token=await getToken(); const headers=new Headers({'Content-Type':'application/json','Accept':'text/event-stream','Cache-Control':'no-cache'}); if(token)headers.set('Authorization',`Bearer ${token}`);
 const r=await expoFetch(requireApiBase()+'/api/chat',{method:'POST',headers,body:JSON.stringify({...req,stream:true}),signal});
 if(!r.ok)throw new Error(`فشل الاتصال: HTTP ${r.status}`); if(!r.body)throw new Error('Backend لم يُرجع stream.');
 const reader=r.body.getReader(); const decoder=new TextDecoder(); let buf='';
 try{while(true){const {done,value}=await reader.read();if(done)break;buf+=decoder.decode(value,{stream:true}).replace(/\r\n/g,'\n').replace(/\r/g,'\n');let i:number;while((i=buf.indexOf('\n\n'))>=0){const raw=buf.slice(0,i);buf=buf.slice(i+2);const f=parseFrame(raw);if(f)onFrame(f);}}buf+=decoder.decode();if(buf.trim()){const f=parseFrame(buf);if(f)onFrame(f);}}finally{reader.releaseLock();}
}
