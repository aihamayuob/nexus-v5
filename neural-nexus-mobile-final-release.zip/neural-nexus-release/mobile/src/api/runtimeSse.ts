import {fetch as expoFetch} from 'expo/fetch';
import {requireApiBase} from '../lib/config';
import {getToken} from '../lib/secure';
function parse(raw:string){let event='message';const data:string[]=[];for(const line of raw.split('\n')){if(line.startsWith('event:'))event=line.slice(6).trim();else if(line.startsWith('data:'))data.push(line.slice(5).trimStart())}return{event,data:data.join('\n')}}
export async function runRuntime(plan:any,onEvent:(event:string,data:any)=>void){
 const token=await getToken();const headers=new Headers({'content-type':'application/json','accept':'text/event-stream'});if(token)headers.set('Authorization',`Bearer ${token}`);
 const r=await expoFetch(requireApiBase()+'/api/runtime/run',{method:'POST',headers,body:JSON.stringify({plan})});
 if(!r.ok)throw new Error(`HTTP ${r.status}`);if(!r.body)throw new Error('Backend لم يُرجع stream.');
 const reader=r.body.getReader();const decoder=new TextDecoder();let buf='';
 try{
  while(true){const {done,value}=await reader.read();if(done)break;buf+=decoder.decode(value,{stream:true}).replace(/\r\n/g,'\n').replace(/\r/g,'\n');let i;while((i=buf.indexOf('\n\n'))>=0){const f=parse(buf.slice(0,i));buf=buf.slice(i+2);let data:any;try{data=JSON.parse(f.data)}catch{data=f.data}onEvent(f.event,data)}}
  buf+=decoder.decode();if(buf.trim()){const f=parse(buf);let data:any;try{data=JSON.parse(f.data)}catch{data=f.data}onEvent(f.event,data)}
 }finally{reader.releaseLock()}
}
