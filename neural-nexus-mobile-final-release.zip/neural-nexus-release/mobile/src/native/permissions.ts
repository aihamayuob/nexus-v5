import * as Camera from 'expo-camera';import * as ImagePicker from 'expo-image-picker';import * as Location from 'expo-location';import * as Notifications from 'expo-notifications';
export async function requestCamera(){return (await Camera.requestCameraPermissionsAsync()).status==='granted'}
export async function requestPhotos(){return (await ImagePicker.requestMediaLibraryPermissionsAsync()).status==='granted'}
export async function requestLocation(){return (await Location.requestForegroundPermissionsAsync()).status==='granted'}
export async function requestNotifications(){return (await Notifications.requestPermissionsAsync()).status==='granted'}
