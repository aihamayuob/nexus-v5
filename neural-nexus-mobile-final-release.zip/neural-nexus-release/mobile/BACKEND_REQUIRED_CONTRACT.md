# Backend Contract — Verified Against Supplied `nexus-backend`

The mobile client is designed against the supplied backend source. These are not invented endpoints.

| Endpoint | Auth | Mobile use |
|---|---|---|
| `GET /api/status` | mobile bearer or gateway | discover configured providers |
| `GET /api/auth/mobile/google/start` | public accounts route | start Google OAuth |
| `GET /api/auth/mobile/google/callback` | public accounts route | OAuth callback; redirects to app scheme |
| `POST /api/auth/mobile/exchange` | public accounts route | one-time code -> mobile session |
| `GET /api/auth/me` | mobile bearer | validate session |
| `POST /api/auth/logout` | mobile bearer | revoke session |
| `POST /api/chat` | mobile bearer | streaming chat |
| `POST /api/runtime/plan` | mobile bearer | create DAG plan |
| `POST /api/runtime/run` | mobile bearer | execute DAG + SSE |
| `GET/PUT/DELETE /api/sync` | mobile bearer | encrypted versioned sync |
| `GET /api/workspaces` | mobile bearer | workspace discovery |
| `POST/DELETE /api/notifications/token` | mobile bearer | push token lifecycle |

## Critical wire detail

The backend normalizes chat streaming to:

- `event: start` -> `{ requestId }`
- `event: token` -> `{ text }`
- `event: usage`
- `event: done`
- `event: error`

The mobile SSE client consumes `token`, not `delta`.

## OAuth

Backend environment must contain:

```env
GOOGLE_CLIENT_ID=...
GOOGLE_CLIENT_SECRET=...
GOOGLE_MOBILE_REDIRECT_URI=https://YOUR-DOMAIN/api/auth/mobile/google/callback
MOBILE_APP_REDIRECT_URI=neuralnexus://auth/callback
SESSION_TTL_MS=2592000000
```

Google Cloud must register the exact HTTPS mobile callback URI.

## Providers

The backend `/api/status` response is authoritative. The mobile client does not assume that every provider is configured.

Provider credentials remain backend-only.
