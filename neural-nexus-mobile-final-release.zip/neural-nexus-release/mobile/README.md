# Neural Nexus AI Agents — Mobile

Cross-platform mobile client for the existing Neural Nexus backend.

## Stack
- Expo SDK 57
- React Native 0.86
- TypeScript
- Expo Router
- SecureStore
- Expo Notifications / Camera / Image Picker / Document Picker / Location

## Configuration
Create `.env`:

```env
EXPO_PUBLIC_API_BASE_URL=https://YOUR-BACKEND-DOMAIN
EXPO_PUBLIC_APP_SCHEME=neuralnexus
```

Never put provider API keys or the backend gateway key in this file or in the mobile bundle.

## Run

```bash
npm install
npm run typecheck
npx expo start
```

Use a Development Build for Google OAuth deep linking and remote push notifications.

## Authentication

The app opens:

`/api/auth/mobile/google/start`

The backend redirects to:

`neuralnexus://auth/callback?code=...`

The callback exchanges the one-time code at:

`/api/auth/mobile/exchange`

The resulting `nxm_live_*` token is stored in SecureStore.

## Backend contract
See `BACKEND_REQUIRED_CONTRACT.md`.

## QA
See `QA.md`.
