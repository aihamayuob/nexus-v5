# CODE-CAPABILITY-MATRIX — تدقيق القدرات (قراءة ساكنة فقط)

الأساس: شجرة OD-C13 المُعاد بناؤها (HEAD `cbdc898…` + 6 رقع، 877 ملفًا). المسارات نسبية لـ `src-baseline/nexus-backend/src/` ما لم يُذكر غير ذلك (الواجهة: `frontend/`).
**قراءة الأعمدة** (فصل إلزامي حسب تعليمات المشروع):
- **الشيفرة**: هل الشيفرة موجودة؟ (قراءة ساكنة).
- **اختبار**: هل يوجد ملف اختبار يخصها؟ (وجود الملف فقط — لم يُشغَّل شيء).
- **مسار متكامل**: هل نجح مسار متكامل؟ = **UNVERIFIED لكل الصفوف** (لا تشغيل بأمر التفويض).
- **متاح للمستخدم**: هل يصل إليه المستخدم فعلًا دون إعداد إضافي؟ (استنتاج من الشيفرة/الإعداد الافتراضي).
الحالة = كلمات رسمية؛ تعني: "ما أثبتته القراءة الساكنة". الاختبار الموجود: 63 ملف `*.test.ts` + 13 ملف مساعد/آخر في `test/` (76 ملفًا) — ولم يُشغَّل أيٌّ منها.

---
## A. المزوّدون وتوجيه النماذج
| القدرة | الشيفرة | اختبار | متاح للمستخدم | الحالة | الدليل (ملف:سطر) |
|---|---|---|---|---|---|
| ستة مزوّدين مسجَّلين: anthropic, openai, deepseek, gemini, ollama, lmstudio | موجودة | موجود (`adaptiveModelRouter`, `googleGrounding`, … ) | نعم عند ضبط المفتاح/المضيف | VERIFIED (وجودًا) | `config/providerRegistry.ts:21` |
| سجل المزوّدين مصدر الحقيقة الوحيد؛ مفاتيح من متغيرات بيئة `NEXUS_*_API_KEY` | موجودة | — | نعم | VERIFIED | `config/providerRegistry.ts:52,77,89,103` |
| محوّل OpenAI-compatible مُعاد استخدامه (openai/deepseek/lmstudio) | موجودة | — | نعم | VERIFIED | `providers/openaiCompatible.ts`, `providers/lmstudioAdapter.ts:8` |
| قدرات لكل مزوّد: streaming/tools/images/embeddings/isLocal/webSearch | موجودة | — | — | VERIFIED | `config/providerRegistry.ts:33,82,96` |
| ستة أوضاع توجيه: BEST/CHEAPEST/FASTEST/LOCAL_ONLY/PRIVATE/USER_SELECTED | موجودة | موجود | نعم | VERIFIED | `providers/routingModes.ts:18` |
| PRIVATE مطابق لـ LOCAL_ONLY (ليس مستوى مستقلًا) | موجودة (موثَّقة) | — | — | PARTIAL | `providers/routingModes.ts:62-67` |
| GAP-1: المزوّد المحلي الأساسي لا يتراجع إلى سحابي | موجودة | موجود (`cloudEgressMission`…) | نعم | VERIFIED (وجودًا)؛ المسار الفعلي UNVERIFIED | `providers/modelRouter.ts:76` |
| موجّه تكيّفي (حد أدنى 8 عينات) | موجودة | موجود (`adaptiveModelRouter.test.ts`) | نعم | PARTIAL (لم يُفحص منطق الإحصاء تشغيلًا) | `providers/adaptiveModelRouter.ts:38` |
| مرونة: resilientCall + سجل صحة + فحص صحة | موجودة | — | نعم | PARTIAL | `providers/resilientCall.ts`, `healthRegistry.ts`, `healthCheck.ts` |
| بحث ويب مدمج | **Gemini grounding فقط** (علم `webSearch`)؛ مزوّد بحث مستقل غير موجود | موجود (`googleGrounding.test.ts`) | عبر Gemini فقط | PARTIAL | `config/providerRegistry.ts` (علم webSearch) |
| Mistral / Cohere / vLLM / مزوّدون آخرون | غير موجودة (بحث نصي) | — | لا | UNVERIFIED كغياب مطلق؛ لا أثر لها في `ProviderId` | `config/providerRegistry.ts:21` |

## B. الأسرار وتدفق الاعتماد
| القدرة | الشيفرة | اختبار | متاح | الحالة | الدليل |
|---|---|---|---|---|---|
| مفاتيح المزوّدين تُقرأ من البيئة فقط وتُحلّ في `.apiKey`؛ `publicMetadata` لا يكشفها | موجودة | `gatewayKeyLeak.test.ts` | نعم | VERIFIED (وجودًا) | `config/providerRegistry.ts:181` |
| مصادقة البوابة بمفتاح مشترك؛ مقارنة ثابتة الزمن | موجودة | `authGateway.test.ts` | نعم | VERIFIED (وجودًا) | `gateway/middleware/auth.ts:2,12` |
| وضع Trusted/no-auth عند عدم ضبط مفاتيح | موجودة | `deploymentGuard.test.ts` | نعم | VERIFIED | `gateway/middleware/auth.ts` (التعليق ~36-40) |
| حارس نشر: يرفض الربط على الشبكة بلا مفاتيح (≥16 حرفًا)؛ بلا TLS | موجودة | موجود | نعم | VERIFIED؛ الحدود موثَّقة | `config/deploymentGuard.ts:21,36-72` ، الحدود `:13-17` |
| مفتاح البوابة في الواجهة في الذاكرة فقط + تنظيف المفتاح القديم المخزَّن | موجودة | `frontend/modules/gatewayKey.test.mjs` | نعم | VERIFIED (وجودًا) | `frontend/modules/settings.mjs:51-61` |
| ادعاء "رسائل خطأ عامة" بدل نص المزوّد | **الشيفرة لا تطابق الادعاء** | — | — | PARTIAL (انظر F-03) | `security/secrets.ts:10-12` مقابل `providers/anthropicAdapter.ts:136-147` |
| مفاتيح أجهزة IoT: مخزَّنة نصًا صريحًا؛ مقارنة `!==` | موجودة (موثَّقة) | — | عند تفعيل IoT | PARTIAL | `routes/v2/iot.ts:29-30,38` |
| OAuth / OIDC / SSO / تعدد مستأجرين | غير موجودة | — | لا | UNVERIFIED كغياب مطلق؛ قرار المالك: نظام أحادي المستأجر | `capability/permissionModel.ts` (تعليق القرار) |

## C. حدود السحابة (Egress) والخصوصية
| القدرة | الشيفرة | اختبار | متاح | الحالة | الدليل |
|---|---|---|---|---|---|
| نقطة اختناق واحدة للنداءات الداخلية (Verifier/Evaluation/Genome/Freshness) | موجودة | `cloudEgressGuard.test.ts` | نعم | VERIFIED (وجودًا) | `security/cloudEgressGuard.ts:71-101` |
| قرار التقييد: privacyMode أو agentMode أو علامة المهمة | موجودة | موجود | نعم | VERIFIED | `cloudEgressGuard.ts:42-45,71-78` |
| تدقيق الرفض بلا محتوى (purpose/provider/reason/taskId فقط) | موجودة | — | نعم | VERIFIED | `cloudEgressGuard.ts:23,84-90` |
| وسم المهمة المقيَّدة من `chatService` | موجودة | `cloudEgressMission.test.ts` | نعم | VERIFIED | `orchestrator/chatService.ts:76,82` |
| وسوم المهام في الذاكرة فقط؛ سقف 10,000 مع إخراج الأقدم | موجودة (موثَّقة جزئيًا) | — | — | PARTIAL (انظر F-06) | `cloudEgressGuard.ts:20-21,47-48,55-58` |
| سياج حقن الأوامر (`fence`) للنص الخارجي | موجودة، **مستخدمة في 3 مواضع فقط** | — | جزئيًا | PARTIAL (انظر F-04) | `security/promptInjectionGuard.ts:53`؛ الاستخدام: `evaluation/evaluationEngine.ts:5`, `knowledge/freshnessEngine.ts:6`, `memory/contextFabric.ts:7` |
| حارس SSRF مع تحليل DNS وتثبيت العنوان | موجودة | موجود | نعم | VERIFIED (وجودًا) | `security/ssrfGuard.ts:1,65-67`؛ `tools/builtin/webFetchTool.ts:1` |
| تغطية الحارس لكل مسارات الإرسال السحابي | **غير مكتملة** | — | — | PARTIAL (F-01, F-02, F-05) | `routes/legacy/embed.ts:19-31`, `finetuning/fineTuning.ts:161-195`, `orchestrator/planner.ts:66`, `evaluation/benchmarkTasks.ts:97`, `memory/embeddingsService.ts:56` |

## D. الموصّلات والتنفيذ المُدار (VEL)
| القدرة | الشيفرة | اختبار | متاح | الحالة | الدليل |
|---|---|---|---|---|---|
| تصنيف أثر إلزامي لكل أداة تحتفظ بـ `execute()`: pure / read_only / legacy_exempt | موجودة | موجود | — | VERIFIED (وجودًا)؛ "إقرار قابل للمراجعة وليس برهانًا" | `tools/registry.ts:14-25`, `tools/effectTypes.ts:86-100` |
| أدوات ذات أثر خارجي: لا `execute()` وتمر فقط عبر بوابة VEL | موجودة (بنية) | `executionPolicy.test.ts` وغيره | **لا موصّل إنتاجي** | PARTIAL | `tools/pipeline.ts:56-58`, `tools/effectTypes.ts:1-15` |
| سياسة default-deny: قاعدة صريحة (أداة+مورد+فاعل) + شروط المهمة، تُقيَّم عند كل محاولة | موجودة | موجود | عند ضبط `NEXUS_VEL_POLICY_JSON` | VERIFIED (وجودًا) | `tools/effectPolicy.ts:10,106-127` |
| رفض السياق العام `public:` وغير المصادَق | موجودة | — | نعم | VERIFIED | `tools/effectPolicy.ts:112-114` |
| إيصال write-ahead + قراءة مستقلة `observe()` + تصنيف الفشل الغامض | موجودة | موجود | — | VERIFIED (وجودًا) | `tools/effectTypes.ts:11-15,40-58`, `tools/verifiedExecution.ts` |
| أدوات مسجَّلة افتراضيًا: web_fetch (read_only) و calculate (pure) فقط | موجودة | موجود | نعم | VERIFIED | `tools/bootstrap.ts:11-12` |
| code_execution غير مسجَّلة (قرار OPTION C) | موجودة وغير مفعّلة | `codeExecutionNotRegistered.test.ts` | لا | VERIFIED | `tools/bootstrap.ts:13-18` |
| موصّلات فعلية ذات أثر (فواتير/دفتر/بريد/…) | **لا يوجد إنتاجي**؛ موصّل اختبار `fakeLedgerConnector` فقط | اختبارات | لا | PENDING | `test/helpers/fakeLedgerConnector.ts` |
| موافقة بشرية مرتبطة بفعل محدد | غير موجودة (موافقة على مستوى المهمة فقط) | — | — | PENDING | `tools/effectPolicy.ts:17-18`, `orchestrator/approvalGate.ts` |
| MCP / A2A / OpenAPI-import | غير موجودة | — | لا | UNVERIFIED كغياب مطلق | بحث نصي في `src/` |
| وسيط MQTT مدمج (اختياري، معطَّل افتراضيًا، توثيق لكل جهاز) | موجودة | — | عند `NEXUS_MQTT_PORT` | PARTIAL | `iot/mqttBroker.ts`; الحدود `config/deploymentGuard.ts:13-17` |
| مهلة الأداة تُجهض الانتظار لا النداء الفعلي | موجودة | — | — | PARTIAL (F-10) | `tools/pipeline.ts:38-45,73` |

## E. التدويل وتغطية اللغات
| القدرة | الشيفرة | اختبار | متاح | الحالة | الدليل |
|---|---|---|---|---|---|
| واجهة افتراضية عربية RTL (`lang="ar" dir="rtl"`) | موجودة | e2e موجود (لم يُشغَّل) | نعم | VERIFIED | `frontend/neural_nexus_ai_agents-4-3-5-3.html:2` |
| ثلاث لغات في الواجهة: ar / en / fr | موجودة | — | نعم | VERIFIED | `…html:1957-1959`, `TRANSLATIONS` `:5378-5475` |
| اتجاه الصفحة: RTL فقط إن كانت اللغة `ar` | موجودة | — | — | PARTIAL: لا دعم لأي لغة RTL غير العربية | `…html:5482` |
| تنسيق الأرقام/التواريخ بـ `ar` ثابتة في 14 موضعًا (لا تتبع لغة الواجهة) | موجودة | — | — | PARTIAL | `…html` (14 مطابقة لـ `toLocale…('ar…')`) |
| اللغة المخزَّنة `nexus_ui_lang` الافتراضية `ar` | موجودة | — | نعم | VERIFIED | `frontend/modules/settings.mjs:82-85` |
| محرك النية الخلفي: كلمات مفتاحية عربية/إنجليزية فقط (لا فرنسية) | موجودة | — | — | PARTIAL | `intent/intentEngine.ts:3-6` |
| أنماط كشف الحقن: عربي/إنجليزي؛ نص التحذير عربي فقط | موجودة | — | — | PARTIAL | `security/promptInjectionGuard.ts:24-33,56-57` |
| رسائل أخطاء الخادم والمحتوى المولَّد: عربية في الغالب (لا ترجمة) | موجودة | — | — | PARTIAL | `core/errors.ts`, `tools/pipeline.ts:39` ، `security/cloudEgressGuard.ts:98` |
| لغات RTL أخرى (فارسي/أردو/عبرية) أو لغات آسيوية | غير موجودة | — | لا | UNVERIFIED كغياب مطلق | `…html:1957-1959` |
| تحقق WCAG/قارئات الشاشة/خطوط | **لم يُفحص** (يحتاج تشغيل) | — | — | UNVERIFIED | — |

---
## تصحيحات لتقريري السابق المبني على الوثائق (الآن مثبتة من الشيفرة)
- محوّلات deepseek وopenai وlmstudio **موجودة فعلًا** (ستة مزوّدين).
- لا Mistral ولا Cohere ولا vLLM، ولا OAuth/OIDC، ولا MCP/A2A/OpenAPI، ولا محرك بحث غير Gemini grounding.
- لا موصّل إنتاجي ذو أثر خارجي؛ VEL بنية جاهزة بلا موصّل.
- الواجهة 3 لغات (ar/en/fr) لا أكثر.

## حدود هذه المصفوفة
قراءة ساكنة فقط. كل "VERIFIED" هنا يعني وجود الشيفرة/النص كما هو مكتوب في الشجرة المعاد بناؤها؛ لا يعني أن السلوك يعمل أو أن الاختبارات تنجح. أعمدة "مسار متكامل" كلها UNVERIFIED.
