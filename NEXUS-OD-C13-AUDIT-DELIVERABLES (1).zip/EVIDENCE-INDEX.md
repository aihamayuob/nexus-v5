# EVIDENCE-INDEX — فهرس الأدلة

كل المسارات: ملفات التسليم في `out/`؛ ملفات الشجرة نسبية لـ `baseline/tree/src-baseline/nexus-backend/src/` (الواجهة: `baseline/tree/frontend/`). لا شيء من هذه الملفات داخل شجرة المصدر.

## 1. سجلات خام (RAW-LOGS/)
| الملف | يثبت |
|---|---|
| 00-expected-input-hashes-from-G1.txt / 00-actual-input-hashes-extracted.txt | قائمة الـ hashes المتوقعة (G1) مقابل المستخرجة: 7/7 |
| 00-zip-hashes-before.txt / 10-zip-hashes-after.txt | هاش أرشيفات الـ zip السبعة قبل/بعد: متطابقة |
| 01-input-hashes-at-use.txt | تحقق 7/7 لحظة الاستخدام |
| 02-git-version.txt | إصدار Git المستخدم |
| 03-bundle-verify.txt | الـ bundle صالح، تاريخ كامل، HEAD `cbdc898…` |
| 04-clone-and-remote.txt | clone من bundle محلي ثم حذف `origin`؛ لا remotes |
| 05-patch-apply.log | نتيجة check/apply لكل رقعة بالترتيب + الحالة النهائية |
| 06-git-status-full.txt / 06-git-status-porcelain.txt | حالة Git بعد الرقع: 27 معدَّل + 23 غير متتبَّع |
| 07-tree-vs-snapshot-and-genomegate.txt | مقارنة الشجرة بلقطة CLOSURE (ملفان وثائقيان) + فحص غياب GENOME-GATE |
| 08-fingerprint-reproduction.txt | إعادة إنتاج بصمات G1 (V1) والتاريخية (V2) |
| 09-git-status-after.txt | حالة Git بعد التدقيق: مطابقة |
| 11-BASELINE-IDENTITY.txt | سجل هوية خط الأساس المستقل |
| manifests/ BEFORE/AFTER-worktree.tsv, BEFORE/AFTER-dotgit.tsv | sha256+حجم+مسار لكل ملف (877 + 26) قبل/بعد |
| ../SHA256-BEFORE-AFTER-COMPARISON.txt | الخلاصة: لا تغيير/إضافة/حذف |

## 2. أدلة الشيفرة (مفهرسة حسب النتيجة)
| المعرّف | الدليل الأساسي |
|---|---|
| A: مزوّدون/توجيه | `config/providerRegistry.ts:21,33,52,77,82,89,96,103,181`; `providers/routingModes.ts:18,62-67`; `providers/modelRouter.ts:76`; `providers/adaptiveModelRouter.ts:38`; `providers/lmstudioAdapter.ts:8` |
| B: أسرار | `gateway/middleware/auth.ts:2,12,30-34,54`; `config/deploymentGuard.ts:13-17,21,36-72`; `frontend/modules/settings.mjs:51-61,82-85`; `routes/v2/iot.ts:29-30,38`; `security/secrets.ts:10-12` |
| C: egress | `security/cloudEgressGuard.ts:6-8,20-23,42-48,55-58,71-101`; `orchestrator/chatService.ts:76,82,134,175`; `security/promptInjectionGuard.ts:2-22,24-33,53-57`; `security/ssrfGuard.ts:1,65-67` |
| D: موصّلات/VEL | `tools/effectPolicy.ts:10,14,17-18,66-81,101-127`; `tools/effectTypes.ts:1-15,30,40-58,86-100`; `tools/registry.ts:14-25`; `tools/pipeline.ts:38-45,56-58,73`; `tools/bootstrap.ts:11-18`; `test/helpers/fakeLedgerConnector.ts` |
| E: تدويل | `frontend/neural_nexus_ai_agents-4-3-5-3.html:2,1957-1959,5378-5475,5478-5500 (dir عند 5482)`; `intent/intentEngine.ts:3-6` |
| F-01 | `routes/legacy/embed.ts:19-20,24,28-32`; `gateway/router.ts:99` (سياق `public:<ip>`) |
| F-02 | `finetuning/fineTuning.ts:132-140,161-174` |
| F-03 | `providers/anthropicAdapter.ts:41,61,136-147`; `orchestrator/chatService.ts:134` |
| F-04 | `tools/builtin/webFetchTool.ts:69,73`; `orchestrator/chatService.ts:175`; استيراد `fence`: `evaluation/evaluationEngine.ts:5`, `knowledge/freshnessEngine.ts:6`, `memory/contextFabric.ts:7` |
| F-05 | `orchestrator/planner.ts:50-51,66`; `evaluation/benchmarkTasks.ts:97`; `memory/embeddingsService.ts:56` |
| F-06 | `security/cloudEgressGuard.ts:20-21,47-48,55-58` |
| F-08/9/10 | `gateway/middleware/auth.ts:30-34`; `routes/v2/iot.ts:38`; `tools/pipeline.ts:38-45,73` |

## 3. وثائق G1/المشروع المقارَن بها (قراءة فقط)
`continuity/g1/g1-input-hashes.txt`, `continuity/G1-ISOLATED-MEASUREMENT-2026-11-03.md`, `continuity/BASELINE-GOVERNANCE-2026-10-30.md`, `continuity/G1-LOCKFILE-RERUN-2026-11-04.md`, `continuity/g1/patch-apply.log`, `continuity/g1/tree-vs-closure-snapshot.diff`.

## 4. حدود الأدلة
قراءة ساكنة فقط؛ لا تشغيل؛ أرقام الأسطر لشجرة OD-C13 المُعاد بناؤها وليست للمستودع الحي. بعض مراسي الأسطر (adaptiveModelRouter:38, lmstudioAdapter:8, router:99) أُعيد التحقق منها في هذه الجولة؛ الباقي مأخوذ من قراءات جولة التدقيق نفسها.
