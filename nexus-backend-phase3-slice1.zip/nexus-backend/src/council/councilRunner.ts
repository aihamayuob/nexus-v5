import { randomUUID } from 'node:crypto';
import { runAgentTask } from '../agents/agentRunner.js';
import { AgentRegistry } from '../agents/agentRegistry.js';
import { Verifier } from '../orchestrator/verifier.js';
import { getRepos } from '../persistence/repos.js';
import type { GatewayContext } from '../capability/permissionModel.js';
import type { CreateCouncilSessionInput, CouncilSession } from './councilTypes.js';
import { logger } from '../core/logger.js';

/** In-memory cancellation registry, scoped to this process — same "fire, then let the caller cancel by id" shape as taskManager.ts's abort-signal map, kept local here because a council session is not a DAG-tracked task. */
const abortControllers = new Map<string, AbortController>();

export function cancelCouncilSession(sessionId: string): boolean {
  const ctrl = abortControllers.get(sessionId);
  if (!ctrl) return false;
  ctrl.abort();
  return true;
}

/**
 * Runs one bounded cross-examination round: Proposal -> Critique -> Rebuttal
 * -> independent Verification -> Supervisor Synthesis. Every text-producing
 * step goes through runAgentTask() (Slice 2) — this file adds ZERO new
 * provider-calling code; it only sequences existing, tested calls and
 * persists the transcript. Mirrors the frontend's runCrossExamination()
 * round-by-round (see councilTypes.ts's file doc comment).
 */
export async function runCouncilSession(input: CreateCouncilSessionInput, gwCtx: GatewayContext): Promise<{ sessionId: string }> {
  if (!AgentRegistry.has(input.proposerAgentId)) throw new Error(`وكيل الاقتراح غير معروف: ${input.proposerAgentId}`);
  if (!AgentRegistry.has(input.criticAgentId)) throw new Error(`وكيل النقد غير معروف: ${input.criticAgentId}`);
  if (input.proposerAgentId === input.criticAgentId) throw new Error('يجب أن يكون وكيل الاقتراح ووكيل النقد مختلفين.');
  const supervisorAgentId = input.supervisorAgentId ?? 'supervisor';
  if (!AgentRegistry.has(supervisorAgentId)) throw new Error(`وكيل الإشراف غير معروف: ${supervisorAgentId}`);

  const id = `council_${Date.now()}_${randomUUID().slice(0, 8)}`;
  const repos = getRepos();
  repos.council.create({
    id,
    mode: 'cross_exam',
    topic: input.topic,
    proposerAgentId: input.proposerAgentId,
    criticAgentId: input.criticAgentId,
    supervisorAgentId,
  });

  const controller = new AbortController();
  abortControllers.set(id, controller);

  // Fire-and-poll — same contract as missionRunner.runMission()'s dispatch
  // from routes/v2/missions.ts: the HTTP layer never blocks on this.
  void executeCouncilSession(id, input, supervisorAgentId, gwCtx, controller.signal).finally(() => abortControllers.delete(id));

  return { sessionId: id };
}

async function executeCouncilSession(
  sessionId: string,
  input: CreateCouncilSessionInput,
  supervisorAgentId: string,
  gwCtx: GatewayContext,
  signal: AbortSignal
): Promise<void> {
  const repos = getRepos();
  const ctxBase = { missionId: sessionId, gwCtx, signal };

  try {
    // Round 1 — Proposal
    const proposal = await runAgentTask(input.proposerAgentId, {
      ...ctxBase,
      agentId: input.proposerAgentId,
      taskNodeId: 'proposal',
      taskDescription: input.topic,
      upstreamOutputs: {},
    });
    repos.council.appendRound(sessionId, 'proposal', input.proposerAgentId, proposal.output, proposal.providerUsed, proposal.modelUsed);

    // Round 2 — Critique (attacks the actual proposal, not an independent view)
    const critique = await runAgentTask(input.criticAgentId, {
      ...ctxBase,
      agentId: input.criticAgentId,
      taskNodeId: 'critique',
      taskDescription:
        `السؤال الأصلي: ${input.topic}\n\n` +
        'مهمتك تحديداً الآن: هاجم الاقتراح التالي بصرامة وموضوعية من زاوية تخصصك، واكشف كل ثغرة أو خطر أو نقطة ضعف فيه. لا تطرح حلاً بديلاً كاملاً، ركّز فقط على النقد المحدد.',
      upstreamOutputs: { proposal: proposal.output },
    });
    repos.council.appendRound(sessionId, 'critique', input.criticAgentId, critique.output, critique.providerUsed, critique.modelUsed);

    // Round 3 — Rebuttal
    const rebuttal = await runAgentTask(input.proposerAgentId, {
      ...ctxBase,
      agentId: input.proposerAgentId,
      taskNodeId: 'rebuttal',
      taskDescription: 'مهمتك تحديداً الآن: رد على نقد زميلك لاقتراحك — دافع عن النقاط الصحيحة، وعدّل اقتراحك بما يعالج أي ثغرة حقيقية أثارها.',
      upstreamOutputs: { proposal: proposal.output, critique: critique.output },
    });
    repos.council.appendRound(sessionId, 'rebuttal', input.proposerAgentId, rebuttal.output, rebuttal.providerUsed, rebuttal.modelUsed);

    // Round 4 — independent Verification (existing Verifier module, hardcoded to anthropic — pre-existing, documented limitation, not addressed by this slice)
    const verdict = await Verifier.verify(input.topic, rebuttal.output);
    repos.council.appendRound(
      sessionId,
      'verification',
      null,
      verdict.ran ? `verdict=${verdict.verdict}; issues=${JSON.stringify(verdict.issues)}` : 'verification did not run (judge provider not configured)',
      'anthropic',
      null
    );

    // Round 5 — Supervisor Synthesis
    const verifierNote = verdict.ran && verdict.issues.length ? `\n\nملاحظات مراجع مستقل (${verdict.verdict}): ${verdict.issues.join('؛ ')}` : '';
    const synthesis = await runAgentTask(supervisorAgentId, {
      ...ctxBase,
      agentId: supervisorAgentId,
      taskNodeId: 'synthesis',
      taskDescription:
        'بناءً على المناظرة الكاملة (اقتراح ← نقد ← رد)، اصغ الحل النهائي الأمتن: ادمج أفضل ما في الاقتراح الأصلي مع معالجة كل ثغرة حقيقية كشفها النقد. كن حاسماً وعملياً، ونظّم ردّك بعناوين واضحة.' +
        verifierNote,
      upstreamOutputs: { proposal: proposal.output, critique: critique.output, rebuttal: rebuttal.output },
    });
    repos.council.appendRound(sessionId, 'synthesis', supervisorAgentId, synthesis.output, synthesis.providerUsed, synthesis.modelUsed);

    repos.council.complete(sessionId, synthesis.output, verdict.ran ? verdict.verdict : 'unavailable', verdict.ran ? verdict.issues.length : null);
  } catch (e) {
    const err = e as Error;
    if (signal.aborted) {
      repos.council.fail(sessionId, 'تم إلغاء الجلسة يدويًا.');
      logger.info('Council session cancelled', { sessionId });
      return;
    }
    repos.council.fail(sessionId, err.message);
    logger.warn('Council session failed', { sessionId, message: err.message });
  }
}

export function getCouncilSession(id: string): CouncilSession | null {
  return getRepos().council.get(id);
}
