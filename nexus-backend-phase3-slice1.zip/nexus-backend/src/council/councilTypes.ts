/**
 * Council/Debate domain (Phase 3 §Council). This is a deliberate SERVER-SIDE
 * port of the frontend's existing, field-tested "Cross-Examination Mode"
 * (see neural_nexus_ai_agents-*.html's runCrossExamination()) — same round
 * structure, same synthesis contract — NOT a new debate design invented
 * from scratch. The frontend's client-side implementation is untouched
 * (additive-only); this gives the backend an equivalent, durable,
 * resumable, HTTP-reachable version built on the Slice 2 Agent Runtime.
 *
 * Scope of THIS slice: 'cross_exam' mode only (one proposer, one critic,
 * one rebuttal, one supervisor synthesis — bounded, single round). The
 * frontend's 'situation_room' mode (N parallel specialists + follow-up
 * round + merge) and full N-agent Dynamic Swarm are explicitly deferred to
 * a later slice — see PHASE3_SLICE1_REPORT.md's "Recommended Next Slice".
 */

export type CouncilMode = 'cross_exam';

export type CouncilState = 'RUNNING' | 'COMPLETED' | 'FAILED' | 'CANCELLED';

export type CouncilRoundKind = 'proposal' | 'critique' | 'rebuttal' | 'verification' | 'synthesis';

export interface CouncilRound {
  sessionId: string;
  seq: number;
  kind: CouncilRoundKind;
  agentId: string | null; // null for the 'verification' round, which runs Verifier.verify() rather than an Agent
  content: string;
  providerUsed: string | null;
  modelUsed: string | null;
  createdAt: number;
}

export interface CouncilSession {
  id: string;
  mode: CouncilMode;
  topic: string;
  proposerAgentId: string;
  criticAgentId: string;
  supervisorAgentId: string;
  state: CouncilState;
  finalOutput: string | null;
  verificationVerdict: 'ok' | 'issues_found' | 'unavailable' | null;
  verificationIssueCount: number | null;
  errorMessage: string | null;
  createdAt: number;
  updatedAt: number;
  completedAt: number | null;
}

export interface CreateCouncilSessionInput {
  topic: string;
  proposerAgentId: string;
  criticAgentId: string;
  supervisorAgentId?: string; // defaults to 'supervisor' (existing agent registry role — see agentRegistry.ts)
}
