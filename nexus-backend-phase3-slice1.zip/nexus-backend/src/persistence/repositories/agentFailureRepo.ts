import type { DatabaseSync } from 'node:sqlite';
import { randomUUID } from 'node:crypto';

export interface AgentFailureRecord {
  id: string;
  agentId: string;
  missionId: string | null;
  taskNodeId: string | null;
  provider: string | null;
  errorMessage: string;
  createdAt: number;
}

function rowToRecord(row: Record<string, unknown>): AgentFailureRecord {
  return {
    id: row.id as string,
    agentId: row.agent_id as string,
    missionId: (row.mission_id as string) ?? null,
    taskNodeId: (row.task_node_id as string) ?? null,
    provider: (row.provider as string) ?? null,
    errorMessage: row.error_message as string,
    createdAt: row.created_at as number,
  };
}

export class AgentFailureRepo {
  constructor(private db: DatabaseSync) {}

  record(f: { agentId: string; missionId?: string | null; taskNodeId?: string | null; provider?: string | null; errorMessage: string }): void {
    this.db
      .prepare(
        'INSERT INTO agent_failures (id, agent_id, mission_id, task_node_id, provider, error_message, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
      )
      .run(randomUUID(), f.agentId, f.missionId ?? null, f.taskNodeId ?? null, f.provider ?? null, f.errorMessage, Date.now());
  }

  /** Most recent failures for one agent — this IS AgentDefinition.failureHistory's dynamic backing store (see agentRegistry.ts's doc comment on why the static definition doesn't carry this itself). */
  recentForAgent(agentId: string, limit = 20): AgentFailureRecord[] {
    const rows = this.db
      .prepare('SELECT * FROM agent_failures WHERE agent_id = ? ORDER BY created_at DESC LIMIT ?')
      .all(agentId, limit) as Record<string, unknown>[];
    return rows.map(rowToRecord);
  }

  countForAgent(agentId: string, sinceMs?: number): number {
    const row = sinceMs
      ? (this.db.prepare('SELECT COUNT(*) AS c FROM agent_failures WHERE agent_id = ? AND created_at >= ?').get(agentId, sinceMs) as {
          c: number;
        })
      : (this.db.prepare('SELECT COUNT(*) AS c FROM agent_failures WHERE agent_id = ?').get(agentId) as { c: number });
    return row.c;
  }
}
