import type { DatabaseSync } from 'node:sqlite';
import type { CouncilSession, CouncilState, CouncilRound, CouncilRoundKind, CouncilMode } from '../../council/councilTypes.js';

function rowToSession(row: Record<string, unknown>): CouncilSession {
  return {
    id: row.id as string,
    mode: row.mode as CouncilMode,
    topic: row.topic as string,
    proposerAgentId: row.proposer_agent_id as string,
    criticAgentId: row.critic_agent_id as string,
    supervisorAgentId: row.supervisor_agent_id as string,
    state: row.state as CouncilState,
    finalOutput: (row.final_output as string) ?? null,
    verificationVerdict: (row.verification_verdict as CouncilSession['verificationVerdict']) ?? null,
    verificationIssueCount: (row.verification_issue_count as number) ?? null,
    errorMessage: (row.error_message as string) ?? null,
    createdAt: row.created_at as number,
    updatedAt: row.updated_at as number,
    completedAt: (row.completed_at as number) ?? null,
  };
}

export class CouncilRepo {
  constructor(private db: DatabaseSync) {}

  create(s: { id: string; mode: CouncilMode; topic: string; proposerAgentId: string; criticAgentId: string; supervisorAgentId: string }): CouncilSession {
    const now = Date.now();
    this.db
      .prepare(
        `INSERT INTO council_sessions (id, mode, topic, proposer_agent_id, critic_agent_id, supervisor_agent_id, state, final_output, verification_verdict, verification_issue_count, error_message, created_at, updated_at, completed_at)
         VALUES (?, ?, ?, ?, ?, ?, 'RUNNING', NULL, NULL, NULL, NULL, ?, ?, NULL)`
      )
      .run(s.id, s.mode, s.topic, s.proposerAgentId, s.criticAgentId, s.supervisorAgentId, now, now);
    return this.get(s.id)!;
  }

  get(id: string): CouncilSession | null {
    const row = this.db.prepare('SELECT * FROM council_sessions WHERE id = ?').get(id) as Record<string, unknown> | undefined;
    return row ? rowToSession(row) : null;
  }

  appendRound(sessionId: string, kind: CouncilRoundKind, agentId: string | null, content: string, providerUsed: string | null, modelUsed: string | null): void {
    const seqRow = this.db.prepare('SELECT COALESCE(MAX(seq), 0) + 1 AS next FROM council_rounds WHERE session_id = ?').get(sessionId) as { next: number };
    this.db
      .prepare('INSERT INTO council_rounds (session_id, seq, kind, agent_id, content, provider_used, model_used, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
      .run(sessionId, seqRow.next, kind, agentId, content, providerUsed, modelUsed, Date.now());
  }

  rounds(sessionId: string): CouncilRound[] {
    const rows = this.db.prepare('SELECT * FROM council_rounds WHERE session_id = ? ORDER BY seq ASC').all(sessionId) as Record<string, unknown>[];
    return rows.map((r) => ({
      sessionId: r.session_id as string,
      seq: r.seq as number,
      kind: r.kind as CouncilRoundKind,
      agentId: (r.agent_id as string) ?? null,
      content: r.content as string,
      providerUsed: (r.provider_used as string) ?? null,
      modelUsed: (r.model_used as string) ?? null,
      createdAt: r.created_at as number,
    }));
  }

  complete(id: string, finalOutput: string, verdict: CouncilSession['verificationVerdict'], issueCount: number | null): void {
    const now = Date.now();
    this.db
      .prepare("UPDATE council_sessions SET state = 'COMPLETED', final_output = ?, verification_verdict = ?, verification_issue_count = ?, updated_at = ?, completed_at = ? WHERE id = ?")
      .run(finalOutput, verdict, issueCount, now, now, id);
  }

  fail(id: string, errorMessage: string): void {
    const now = Date.now();
    this.db.prepare("UPDATE council_sessions SET state = 'FAILED', error_message = ?, updated_at = ?, completed_at = ? WHERE id = ?").run(errorMessage, now, now, id);
  }
}
