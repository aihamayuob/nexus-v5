import { AgentRegistry } from './agentRegistry.js';
import type { AgentExecutionContext, AgentResult, AgentRuntimeState } from './agentTypes.js';
import { selectProviderForMode } from '../providers/routingModes.js';
import { runChatCompletion } from '../orchestrator/chatService.js';
import { TaskObservability } from '../observability/recorder.js';
import { getRepos } from '../persistence/repos.js';
import { normalizeError } from '../core/errors.js';

/**
 * Runs one agent turn: resolve the agent's static definition -> select a
 * provider/model via its declared RoutingMode (NEVER a hardcoded provider
 * — Phase 2 §D) -> call the SAME runChatCompletion() every other path in
 * this codebase uses -> record failure history on error. This is the
 * "Agent Selection + Model Selection + Execution" slice of the
 * Autonomous Core pipeline (autonomousCore.ts), factored out so it's
 * reusable as a DAG node's runNode() AND independently testable.
 */
export async function runAgentTask(agentId: string, ctx: AgentExecutionContext): Promise<AgentResult> {
  const def = AgentRegistry.get(agentId); // throws a clear error for an unknown agent id — never silently falls back
  const state: AgentRuntimeState = { status: 'selecting_model', attempt: 1 };

  const upstreamEntries = Object.entries(ctx.upstreamOutputs);
  let userMessage = ctx.taskDescription;
  if (upstreamEntries.length) {
    userMessage += '\n\nنتائج مهام سابقة ذات صلة:\n' + upstreamEntries.map(([id, out]) => `[${id}]: ${out}`).join('\n\n');
  }

  try {
    const routed = await selectProviderForMode({ mode: def.models });
    state.status = 'running';
    state.providerUsed = routed.provider;
    state.modelUsed = routed.model;

    const obs = new TaskObservability(ctx.missionId ?? `agent_${agentId}`, 'runtime_plan');
    const result = await runChatCompletion(
      {
        mode: def.models,
        system: def.systemPrompt,
        messages: [{ role: 'user', content: userMessage }],
        // Agent policy caps the request — never lets an agent's declared
        // maxTokens be silently exceeded by whatever the caller passes.
        maxTokens: def.policies.maxTokens,
        signal: ctx.signal,
        route: 'runtime_plan',
        taskId: ctx.missionId ?? `agent_${agentId}`,
      },
      ctx.gwCtx,
      obs
    );

    const textBlock = result.content.find((b) => b.type === 'text');
    state.status = 'done';
    return {
      output: textBlock && textBlock.type === 'text' ? textBlock.text : '',
      providerUsed: routed.provider,
      modelUsed: result.content.length ? routed.model : routed.model,
      toolsUsed: [], // this slice doesn't yet give agents their own tool loop — see agentTypes.ts AgentDefinition.tools doc comment
      usage: result.usage,
    };
  } catch (e) {
    state.status = 'failed';
    const err = normalizeError(e);
    getRepos().agentFailures.record({
      agentId,
      missionId: ctx.missionId,
      taskNodeId: ctx.taskNodeId,
      provider: state.providerUsed ?? null,
      errorMessage: err.message,
    });
    throw e;
  }
}
