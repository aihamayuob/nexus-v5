import type { Router, RouteContext } from '../../gateway/router.js';
import { readJsonBody } from '../../gateway/middleware/bodyLimit.js';
import { runCouncilSession, getCouncilSession, cancelCouncilSession } from '../../council/councilRunner.js';
import { getRepos } from '../../persistence/repos.js';
import { Errors } from '../../core/errors.js';

interface CreateCouncilRequestBody {
  topic?: string;
  proposerAgentId?: string;
  criticAgentId?: string;
  supervisorAgentId?: string;
}

export function registerCouncilRoutes(router: Router) {
  /** Fire-and-poll, same contract as POST /v2/missions. */
  router.post('/v2/council', async (ctx: RouteContext) => {
    const body = await readJsonBody<CreateCouncilRequestBody>(ctx.req);
    if (!body.topic || !body.topic.trim()) throw Errors.validation('الحقل "topic" مطلوب.');
    if (!body.proposerAgentId) throw Errors.validation('الحقل "proposerAgentId" مطلوب.');
    if (!body.criticAgentId) throw Errors.validation('الحقل "criticAgentId" مطلوب.');

    let sessionId: string;
    try {
      const result = await runCouncilSession(
        { topic: body.topic, proposerAgentId: body.proposerAgentId, criticAgentId: body.criticAgentId, supervisorAgentId: body.supervisorAgentId },
        ctx.gw
      );
      sessionId = result.sessionId;
    } catch (e) {
      throw Errors.validation((e as Error).message);
    }
    ctx.res.writeHead(202, { 'Content-Type': 'application/json' });
    ctx.res.end(JSON.stringify({ sessionId }));
  });

  router.get('/v2/council/:id', async (ctx: RouteContext) => {
    const session = getCouncilSession(ctx.params.id!);
    if (!session) throw Errors.notFound('جلسة المجلس غير موجودة.');
    ctx.res.writeHead(200, { 'Content-Type': 'application/json' });
    ctx.res.end(JSON.stringify(session));
  });

  router.get('/v2/council/:id/rounds', async (ctx: RouteContext) => {
    const session = getCouncilSession(ctx.params.id!);
    if (!session) throw Errors.notFound('جلسة المجلس غير موجودة.');
    ctx.res.writeHead(200, { 'Content-Type': 'application/json' });
    ctx.res.end(JSON.stringify({ rounds: getRepos().council.rounds(session.id) }));
  });

  router.post('/v2/council/:id/cancel', async (ctx: RouteContext) => {
    const session = getCouncilSession(ctx.params.id!);
    if (!session) throw Errors.notFound('جلسة المجلس غير موجودة.');
    const cancelling = cancelCouncilSession(session.id);
    ctx.res.writeHead(202, { 'Content-Type': 'application/json' });
    ctx.res.end(JSON.stringify({ cancelling }));
  });
}
