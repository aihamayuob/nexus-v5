async function askClaude(message, agent = 'general_manager') {
  return `[${agent}] تم استلام الرسالة: ${message}`;
}

module.exports = { askClaude };
