const express = require('express');
const router = express.Router();
const { askClaude } = require('../services/anthropic');

router.post('/', async (req, res) => {
  try {
    const { message, agent } = req.body;

    const reply = await askClaude(message, agent);

    res.json({ success: true, reply });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

module.exports = router;
