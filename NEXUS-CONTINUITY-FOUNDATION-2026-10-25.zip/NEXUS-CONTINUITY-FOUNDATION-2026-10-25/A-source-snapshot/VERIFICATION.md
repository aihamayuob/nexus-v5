# VERIFICATION.md — سجل أدلة البناء والاختبار والتحقق

> **الدور:** يربط كل نتيجة اختبار/بناء بـ(النطاق، الأمر أو ملف الدليل، النتيجة الفعلية، معرّف النسخة المختبرة، التاريخ، الحدود، الحالة). أُنشئ 2026-10-25 (OD-C2).
> **قاعدة قراءته:** كل رقم هنا **مرتبط بنسخة وتاريخ محددين**؛ لا يُقرأ أي عدد اختبارات كأنه نتيجة تُنجح الآن. **في مهمة تأسيس الاستمرارية (2026-10-25) لم يُشغَّل أي كود أو اختبار** (OD-C9/C10)؛ لذا كل ما في §A–§C **تاريخي** (مصدره تقرير/سجل ذُكر)، ويصير «حاليًا» فقط بإعادة التشغيل على النسخة المحددة. §D فقط تحقق وثائقي أُجري في هذه المهمة.
> **الحالة** تستخدم المفردات الست فقط، وتصف ما قاله المصدر ضمن حدوده (لا رفعًا من عندي). **تعذّر الإثبات** = BLOCKED/UNVERIFIED كما هو مبيَّن.
> **النسخة:** لا `.git` ⇒ معرّف النسخة هو اسم الحزمة + SHA-256 (حيث توفر) و/أو hash commit **المذكور في وثيقة** (لم يُتحقق منه بـgit، CF-06).

## A) مسار الواجهة/Core — Phase 2 (تاريخي؛ المصدر: `NEXUS-CURRENT-STATE.md`، `docs/checkpoints/CP-*.md`، `baseline/evidence/`)
| ID | النطاق / النسخة | الأمر أو الدليل | النتيجة المسجَّلة | التاريخ | الحالة | حدود |
|---|---|---|---|---|---|---|
| V-A01 | Phase 0 baseline، خلفية | سجلات `baseline/evidence` (`PH-A00`) | `npm test` 406/406، tsc وbuild نظيفان، 0 ثغرات | 2026-09-16 | VERIFIED (تاريخي) | ذاكرة + BASELINE.md؛ لم يُعَد تشغيله هنا |
| V-A02 | Vitest للواجهة (حدود 1–4 ثم core) | `cd frontend && npx vitest run` | 116 (بعد الحد 4) → 168 (قبل slice 10) → 178 (بعد slice 10، 6 ملفات) → 186 (بعد B4، 7 ملفات) | 2026-10…16 | VERIFIED (تاريخي) | jsdom؛ التغطية 70%+ للوحدات المنقولة وفق التقارير |
| V-A03 | E2E Chromium 141 headless + خلفية وهمية | `e2e/*.mjs` | baseline 12/12؛ phase1-security 16/16؛ phase2-core-seed 16/16 (E-1 وميض معروف)؛ slice4 21/21؛ slice5 27 `SURVIVES`؛ slice6 35 `ACCEPTED`؛ slice7 40 `NOT-STUCK`؛ slice8 79 `ACCEPTED`؛ slice10 28/28 `ACCEPTED`؛ EI-UI 26/26؛ CP-19: VALID 19/19، PRES 42/42 | 2026-10-10…15 | VERIFIED ضمن الحدود | Chromium 141 فقط؛ لا Firefox/Safari/أجهزة |
| V-A04 | Evidence Integrity (خلفية) | `npm test` في `src-baseline/nexus-backend` | 472/472 (406 + 66 جديدة، 27 منها `[SEC]`)، tsc 0، هجرة 016 | 2026-10-11 | VERIFIED ضمن حدود CP-16 | النوع «declared» لا يُتحقق منه؛ قاضٍ وهمي |
| V-A05 | طفرات/استقلال | سكربتات `baseline/evidence/phase2-*mutation*` | slice4 16/16 قُتلت؛ slice8 7/7 (K5/K6 INVALID موثَّقان)؛ slice10 8 طفرات (M4 تُقتل بالفحص الساكن فقط)؛ CP-19: 24 REJECTED، MU23 ناجية متوقعة، **MU05 INVALID (قرار مالك)**؛ استقلال CP-19 عن slice 10 على clone `bc05f58` | 2026-10-10…15 | PARTIAL (طفرات CP-19) / VERIFIED (استقلال) | |
| V-A06 | ADR-003 مراجعة | CP-17 §4 | Erratum مُلحَق؛ الادعاء #6 خاطئ؛ Decision لم يُمَس | 2026-10-12/13 | VERIFIED (توثيق فقط) | |
| V-A07 | اختبارات لم تُشغَّل | — | backend وسكربتات الطفرات القديمة لم تُشغَّل في CP-19؛ ثم 472/472 في جلسة release-hardening | 2026-10-15/16 | NOT RUN → أُعيد لاحقًا | `CP-19.md` §3–4 |

## B) مسار Release V1 (محلي/LAN) — B1 وB4 فقط؛ B2/B3 بلا أثر (CF-10، PD-14)
| ID | النطاق / النسخة | الدليل | النتيجة المسجَّلة | التاريخ | الحالة | حدود |
|---|---|---|---|---|---|---|
| V-B01 | B1 `frontend/sw.js` (مُؤلَّف حديثًا، ليس الأصل) | `e2e/release-v1-b1-offline-sw-flows.mjs` → `baseline/evidence/release-v1-b1-POST.log`/`-results.json`؛ PRE `release-v1-b1-PRE.log` | **PRE: B1-VERDICT = REJECTED** (SW غير موجود)؛ **POST: ACCEPTED** — VALID 6/6، PRES 1/1، PS 11/11، Chromium 141.0.7390.37؛ شاهد (control) بلا `state.mjs` يكسر الإقلاع دون اتصال؛ إعادة تشغيل بعد B4: ACCEPTED (`release-v1-b1-after-b4.log`) | 2026-10-16 | VERIFIED ضمن حدود B1 | SW حقيقي + خادم محلي مغلق للمحاكاة؛ cdnjs (QR/PDF.js) غير متاحة دون اتصال؛ لا Firefox/Safari/أجهزة؛ الأصل المفقود وسلوكه غير مُستنسخ (push/background sync) |
| V-B02 | B4 خلفية | `test/deploymentGuard.test.ts`, `securityHeaders.test.ts`, `gatewayKeyLeak.test.ts`، `authGateway` (إضافة فقط) → `release-v1-b4-be-POST-new.log`، `-POST-full.log`، `-PRE.log`، `-be-build.log` | الجديدة 36/36؛ **الكاملة 502/502**؛ PRE: 9 اختبارات 6 نجحت و3 فشلت | 2026-10-16 | VERIFIED ضمن حدود B4 | الحارس يمنع إقلاع عملية حقيقية على عنوان غير loopback بلا مفاتيح ≥16 حرفًا؛ `X-Forwarded-For` مُصدَّق (خارج النطاق) |
| V-B03 | B4 واجهة: مفتاح في الذاكرة + CSP | `e2e/release-v1-b4-key-and-csp-flows.mjs` → `release-v1-b4fe-POST.log` | VALID 9/9، PS 20/20 ⇒ `B4FE-VERDICT = ACCEPTED`؛ PRE يفشل | 2026-10-16 | VERIFIED (Chromium 141) | CSP عبر `<meta>` مع `'unsafe-inline'` فلا تمنع XSS المضمّن؛ `frame-ancestors`/HSTS لا تُضبط من `<meta>` |
| V-B04 | مسار المصادقة بخلفية حقيقية عبر CORS | `e2e/release-v1-b4-real-backend-auth-flow.mjs` → `release-v1-b4rb-POST.log` | VALID 2/2، PS 7/7 ⇒ ACCEPTED (200 للصحيح، 401 للخاطئ وبعد إعادة التحميل) | 2026-10-16 | VERIFIED (مسار المصادقة فقط) | المحادثة/البث/الإلغاء/fallback/الميزانية: **PENDING — DATA NOT EXECUTED** (لا مفتاح مزوّد) |
| V-B05 | Vitest بعد B4 | `release-v1-b4-fe-vitest-POST.log` | 7 ملفات، 186/186؛ اختبار واحد استُبدل علنًا (`release-v1-b4-superseded-tests.md`) | 2026-10-16 | VERIFIED | تغيير عقد مقصود: المفتاح يُعاد إدخاله بعد كل إعادة تحميل |
| V-B06 | الجهاز الآخر على LAN عبر HTTP عادي | `release-v1-lan-secure-context-probe-*.log` | `127.0.0.1`: `isSecureContext`/`subtle`/`sw`/إقلاع = true؛ `192.0.2.2`: false/false/false/لم يكتمل | 2026-10-16 | **BLOCKED** (قيد متصفح سابق للإصدار) | وكيل HTTPS غير مُختبَر (UNVERIFIED) |

## C) مسار الخلفية الأمني — GAP-1…GENOME-GATE (نسخ معزولة؛ لا `.git`؛ لم تُطبَّق على الحي)
| ID | النطاق / النسخة | الدليل | النتيجة المسجَّلة | التاريخ | الحالة | حدود |
|---|---|---|---|---|---|---|
| V-C01 | GAP-1 وGAP-1B | لا تقرير ولا رقعة في المصادر المتاحة؛ الكود يحمل أثرهما (`modelRouter.ts`، `chatService.ts`، `verifier.ts`، `evaluationEngine.ts`، `agentGenome.ts`، `freshnessEngine.ts`)؛ تقرير VEL يسجّل خط الأساس: حزمة `NEXUS-GAP1B-HANDOFF-2026-10-20.zip`، 901 ملفًا مطابقة، `tsc` 0، **546/546** | 2026-10-20 | **UNVERIFIED** (للشريحتين نفسيهما؛ الأساس مذكور فقط) | قرارات النطاق في DECISIONS OD-G1…G3؛ HEAD الأساس `cbdc898…` من وثيقة لم يُتحقق منه |
| V-C02 | VEL vertical slice | `NEXUS-VEL-VERTICAL-SLICE-REPORT.md`؛ `B-evidence/VEL/` | 44 اختبارًا جديدًا؛ **590/590**؛ 12 طفرة اكتُشفت؛ tsc/build 0؛ تشغيل `dist` | 2026-10-20/21 | **PARTIAL** | موصل اختبار معزول فقط؛ ADR = PROPOSED؛ لا موصل إنتاجي |
| V-C03 | G8 تصنيف الأثر | `NEXUS-G8-REPORT.md`؛ `B-evidence/G8/` | 10/10؛ **600/600**؛ 12/12 طفرة؛ tsc/build 0 | 2026-10-21 | **PARTIAL** | إقرار لا إثبات؛ `code_execution` `legacy_exempt` |
| V-C04 | G8.1 | `NEXUS-G8.1-REPORT.md`؛ `B-evidence/G8.1/` | **610/610**؛ طفرات 7/7 | 2026-10-21 | VERIFIED ضمن الحدود (+PARTIAL/BLOCKED لما تبقّى) | لا عزل أُضيف؛ حارس `src/` فحص نصي |
| V-C05 | G8.2 | `NEXUS-G8.2-REPORT.md`؛ `B-evidence/G8.2/` | 4 اختبارات؛ **614/614**؛ طفرات 6/6؛ عُدِّل اختباران قائمان (مُفصَح عنه) | 2026-10-22 | VERIFIED ضمن حدود بيئة الاختبار؛ BLOCKED لإثبات git | |
| V-C06 | G8.2-CLOSURE | `NEXUS-G8.2-CLOSURE-REPORT.md`؛ `B-evidence/G8.2-CLOSURE/` | 6 اختبارات؛ **620/620**؛ طفرات 12/12؛ `dist-check-g82c.mjs` PASS | 2026-10-24 | **PARTIAL** | التزام النموذج بالسياسة UNVERIFIED |
| V-C07 | **G8.2-GENOME-GATE** | `NEXUS-G8.2-GENOME-GATE-REPORT.md`؛ `B-evidence/G8.2-GENOME-GATE/evidence/*`؛ سجلا الأرشيف `07-post-zip-verification.log`/`08-rerun-from-archive.log` | خط الأساس 620/620؛ RED 55 اختبارًا فشل 30 (كلها `ERR_ASSERTION`)؛ الجديدة 61/61 ×3؛ **الكاملة 681/681**؛ tsc 0؛ build 0؛ `dist-check-gate.mjs` PASS؛ طفرات 18/18 (14 مطلوبة + 4)؛ الرقعة تُطبَّق وتُعكَس بايتًا ببايت؛ **إعادة التشغيل من الأرشيف المفكوك: 61/61 و681/681 وtsc وbuild وdist-check PASS** | 2026-10-24/25 | **PARTIAL** (قرار OD-C4) | عيّنة التخصيص in-sample؛ 6 اختبارات أُضيفت بعد التنفيذ بلا RED؛ L1–L3 غير مكتشفة؛ **تدقيق القاعدة الحية BLOCKED**؛ **التزام نموذج حقيقي UNVERIFIED**؛ الطفرات لم تُعَد من الأرشيف؛ لا يتغير التقييم إلا بدليل جديد |

## P) سلامة الحزم والأصول
| ID | العنصر | البصمة (SHA-256) | الحالة |
|---|---|---|---|
| V-P01 | `NEXUS-G8.2-CLOSURE-HANDOFF-2026-10-24.zip` (مرفق المالك) | `7dfa84927602ea0f556efe8bbe80030445787b00e1d7cd466332a759f7ce67f0` | VERIFIED (مطابقة ملف `.sha256` المرفق، وSHA256SUMS الداخلية: OK) |
| V-P02 | `NEXUS-G8.2-GENOME-GATE-HANDOFF-2026-10-24.zip` | `24a04441930251bfd08ffc8563d8fc9b2b6abe3440211190a297119c02d5be25` | VERIFIED (`.sha256` + 1027 ملفًا داخليًا OK، 2026-10-25) |
| V-P03 | أصول ملفات هذه المهمة قبل التعديل | `C-originals/ORIGINALS-SHA256.txt` (`CHANGELOG`, `NEXUS-CONTINUATION`, `NEXUS-CURRENT-STATE`, `PLAN`, `ROADMAP`, `NEXT-SESSION-START-HERE`) | VERIFIED (مسجَّلة قبل أي تعديل) |
| V-P04 | حزم VEL وG8 وG8.1 وG8.2 وGAP-1B المنفردة | غير متاحة (فقط ما تضمّنته الحزم التراكمية) | UNVERIFIED |

## D) تحقق وثائقي أُجري في مهمة التأسيس (2026-10-25) — لا كود ولا اختبارات
> نتائج فعلية فقط. لا كود ولا اختبارات شُغّلت في هذه المهمة (فحوص نصية على الوثائق). انظر `PROJECT_HISTORY.md` ← PH-CONT وتقرير المهمة.

| ID | الفحص | النتيجة |
|---|---|---|
| V-D01 | وجود الملفات | الأربعة الجديدة (`CLAUDE.md`, `DECISIONS.md`, `VERIFICATION.md`, `PROJECT_HISTORY.md`) + الملفات القائمة المعدَّلة الستة + ملحق v2 موجودة: **VERIFIED** |
| V-D02 | بصمات الأصول | `sha256sum -c` على 6 أصول في `C-originals/`: **6/6 OK** (بعد إزالة سطر ذاتي قديم من `ORIGINALS-SHA256.txt`) |
| V-D03 | قبل/بعد (diff أصل↔حالي) | CHANGELOG +13 سطرًا، NEXUS-CONTINUATION +7، NEXUS-CURRENT-STATE +55 (قبل هذا السجل)، NEXT-SESSION-START-HERE +15؛ **0 أسطر محذوفة** فيها. ROADMAP وPLAN: **سطر واحد معدَّل في كل منهما** (حالة DONE النشطة → «VERIFIED (historical; originally written DONE)»)، والباقي إضافات. لا حذف تاريخي: **VERIFIED** |
| V-D04 | المعرّفات المتقاطعة | 130 معرّفًا مُشارًا إليه / 125 معرّفًا معرَّفًا؛ وُجد مرجعان معلّقان (`PH-BASE`، `PH-GENOME-GATE`) **وأُصلحا** (→ `PH-A00`، `PH-PKG-GG`)؛ المتبقي `OD-P*`، `PH-B*`، `PH-C*` رموز مجموعات (wildcards) مقصودة لا معرّفات مفردة |
| V-D05 | مراجعة DONE | كل ورود «DONE» فُحص؛ حالتان نشطتان فقط عُدِّلتا (ROADMAP، PLAN)؛ الباقي تاريخي/نص قاعدة وبقي كما هو (انظر «DONE audit» في `NEXUS-CURRENT-STATE.md`) |
| V-D06 | حفظ Project وقراءة مرتجعة | انظر «سجل حفظ الحزمة والذاكرة» في `NEXUS-CURRENT-STATE.md`؛ الأرشيف رُفض (NUL) |
| V-D07 | اختبار القراءة المستقل (وكيل فرعي بسياق جديد، أداة قراءة فقط، أُعطي المسارات فقط ولا ملخصًا، 2026-10-25) | **PARTIAL→أُصلحت الملاحظات.** أجاب الوكيل بصحة على الأسئلة 1–7 و9 (ترتيب البدء، BLOCKED للمستودع الحي، حالة GENOME-GATE وما لم يُحسم، المفردات الست وDONE التاريخي، الترتيبان، نقطة الاستئناف والمحظورات، PD-01…16، عدم ادعاء التحميل التلقائي) وحكم أنه يستطيع الاستئناف من الوثائق وحدها. الملاحظات التي كشفها وما فُعل: (1) V-D07 فارغ — سُجّل الآن؛ (2) OD-C8 يقول «سبعة» وCF حتى 12 — وُضّح؛ (3) وصف `C-originals/` في NEXT مضلِّل — صُحّح؛ (4) قائمتا قرارات/تعليمات في NEXT — أُضيفت جملة «أي القائمتين تحكم» (PD-* هي السارية)؛ (5) Node 22.22 مقابل 22.23.4 — وُضّح أنه وصف بيئي؛ (6) نص «sw.js غير متوفر/الشريحة 10» الأعلى من التصحيح — أُضيف تنبيه في STATE وNEXUS-CONTINUATION. **لا يزال قائمًا (حدود، لم تُعالَج):** مراجع إلى ملفات خارج الحزمة (وثيقة 15-أكتوبر المرجعية، ملحق v1، ADR-006 المفقود، تقرير المهمة النهائي)؛ مسار «جذر آخر حزمة تسليم» ليس مسارًا ثابتًا لمستودع حي؛ أرقام 130/125 في V-D04 لم يتحقق منها الوكيل. **هذا الاختبار لا يثبت التحميل التلقائي لـ`CLAUDE.md` في Claude Code (UNVERIFIED)** ولا يثبت أن جلسة حقيقية ستسلك المسار نفسه. أُجري على النسخة قبل الإصلاحات أعلاه؛ **لم يُعَد بعدها** |
