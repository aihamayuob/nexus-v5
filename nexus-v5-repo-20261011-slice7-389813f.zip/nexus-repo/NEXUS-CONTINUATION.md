# NEXUS-CONTINUATION

How to resume. Repository state beats this file and beats chat memory.

## 1. Reconstruct first (do not skip)
1. Unpack the latest ZIP; `git branch --show-current` (expect `v5.0-polish`),
   `git status --short`, `git log --oneline | head`.
2. Read `NEXUS-CURRENT-STATE.md`, then `docs/checkpoints/CP-14.md` (latest; core slice 7 — evidence-only: `isSendingMessage` stuck flag CONFIRMED at runtime, NOT fixed; plus the intermittent seed-flows check E-1),
   then `docs/checkpoints/CP-13.md` (core slice 6 — I-1 handled via O2, `main.js` startup tail only; its §8 static finding is what slice 7 confirmed),
   then `docs/checkpoints/CP-12.md` (core slice 5 — runtime test of I-1, evidence-only, I-1 CONFIRMED = LOST; its §6 wording about the send button is corrected in CP-13 §1),
   then `docs/checkpoints/CP-11.md` (core slice 4 / C1 — registry-parameter
   snapshot/restore/reset, VERIFIED), then `docs/checkpoints/CP-10.md` (core slice 3 — read-only
   state map, facts vs inferences, candidate seams), then `docs/checkpoints/CP-9.md` (Evidence
   Integrity inspection — guard BLOCKED on owner decisions, no production change), then
   `docs/checkpoints/CP-8.md` (slice 2, evidence-only), then `docs/checkpoints/CP-7.md` (slice 1), then
   `PHASE2-MODULARIZE.md` (section "Boundary 5 — core, slice 1"; its "DONE" wording for
   boundaries 1–4 is historical — see the Terminology note in CURRENT-STATE).
3. Read ADR-002 (bridge pattern) and ADR-003 (storage boundary; see the
   documentation finding in CURRENT-STATE / CP-8 before relying on its wording).
   Verify the chain: `git rev-parse HEAD~1` should be `5770104` (slice 6), `HEAD~2` = `fbd7236` (slice 5), `HEAD~3` = `669386b`, `HEAD~4` = `9c95fbd`, `HEAD~5` = `b9d4808`, `HEAD~6` = `0520af7`, `HEAD~7` = `4c3e169`.

## 2. Environment (this repo's tests need it)
- `cd frontend && npm ci && npx vitest run --coverage`
- Backend: `cd src-baseline/nexus-backend && npm ci && npm run build && npm test`
- E2E: scripts hard-code `/home/claude/nexus-v5/`, so create a symlink to the
  unpacked repo there (outside the repo). Chromium is provided by
  `PLAYWRIGHT_BROWSERS_PATH=/opt/pw-browsers`; verify with a real
  `chromium.launch()`, do not infer availability from `~/.cache`.
- E2E setup (learned in slice 3): `e2e/` has no lockfile, so `npm ci` fails — use
  `PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1 npm install --no-package-lock --no-save playwright@1.56.1`
  (the unpinned latest playwright does not match the browsers in `/opt/pw-browsers`), and build the backend first
  (`cd src-baseline/nexus-backend && npm run build`) or `backend-boot` fails. Do not commit `node_modules`/lockfiles.
- `cd e2e && node baseline-flows.mjs && node phase1-security-flows.mjs && node phase2-core-seed-flows.mjs`
- Slice 3 analyzer (read-only, self-locating; acorn is not a repo dependency — `npm i acorn@8.19.0` in a scratch
  dir and point `ACORN_DIR` at its `node_modules` parent): `ACORN_DIR=<dir> node baseline/evidence/phase2-core-slice3-state-map.mjs`
  (expects 22/22; rewrites `…-state-map-results.json`, which must stay byte-identical on an unchanged tree).
- Slice 2 probe (self-locating, no hard-coded path):
  `PLAYWRIGHT_BROWSERS_PATH=/opt/pw-browsers node baseline/evidence/phase2-core-slice2-adr003-probe.mjs`
  (expects 19/19; it rewrites `…-probe-results.json` and the generated module — if you
  re-run it, `git diff` shows only timestamps/scratch path changes in the JSON).
- Slice 4 scripts (repo root; all self-locating): `node baseline/evidence/phase2-core-slice4-extract-script.mjs verify 9c95fbd` (17/17, read-only,
  rewrites the deterministic `…-extract-results.json`); `ACORN_DIR=<dir> node baseline/evidence/phase2-core-slice4-exec-order-check.mjs` (9/9);
  `node baseline/evidence/phase2-core-slice4-unit-vs-original.mjs` (36/36); `PROOF_BASE_REF=9c95fbd node baseline/evidence/phase2-core-slice4-mutation-script.mjs`
  (needs the E2E setup above; ~7 min; modifies then restores 3 production files — never run it concurrently with anything else); `node e2e/phase2-core-slice4-flows.mjs` (21/21).
- Slice 5 (needs the E2E setup above): `cd e2e && node phase2-core-slice5-flows.mjs` (expects 27/27 validity and `I1-VERDICT = LOST`; rewrites
  `baseline/evidence/phase2-core-slice5-i1-results.json`, which contains no timestamps but does contain run-unique marker strings — expect a diff in those only);
  `node baseline/evidence/phase2-core-slice5-mutation-script.mjs` (3/3 mutants, ~2 min, works on tmp copies; also rewrites `…-mutation-results.json`).
  `NEXUS_FRONTEND_DIR` points the script at another frontend dir; `NEXUS_S5_RESULTS` redirects the results JSON.
- Slice 6 (needs the E2E setup above): `cd e2e && node phase2-core-slice6-flows.mjs` (expects 35/35 → `S6-VERDICT = ACCEPTED`: VALID 12, PRES 12, PS 11; it rewrites
  `baseline/evidence/phase2-core-slice6-results.json` unless `NEXUS_S6_RESULTS` points elsewhere); `node baseline/evidence/phase2-core-slice6-mutation-script.mjs`
  (6 scratch mutants K1–K6 on tmp copies, ~5 min, works only on the PATCHED tree; run it alone). On an UNPATCHED tree the acceptance script is REJECTED with only PS checks failing — by design.
- Slice 7 (needs the E2E setup above): `cd e2e && node phase2-core-slice7-flows.mjs` (expects 47/47 → `S7-VERDICT = STUCK` on the current tree; rewrites `baseline/evidence/phase2-core-slice7-results.json` unless `NEXUS_S7_RESULTS` points elsewhere; deterministic);
  `NEXUS_S7_TMP=<scratch> node baseline/evidence/phase2-core-slice7-mutation-script.mjs` (5 scenarios on tmp copies, ~5 min: CTRL=STUCK, M1/M4 candidate fixes=NOT-STUCK, M2/M3=INCONCLUSIVE; run it alone). If a future slice FIXES the defect, the slice 7 script's STUCK-specific checks (AC-4/AC-5/AC-7 and the classification) must be adapted deliberately — it will then report NOT-STUCK.
  `NEXUS_S7_MUT_RESULTS` redirects the mutation results JSON. Slice 4 mutation script (~7 min) re-ran 16/16, 0 survivors in slice 7; it rewrites a committed results JSON — `git checkout` it afterwards.
- Slice 2 probe and slice 3 analyzer assert a clean production-path `git status` (`frontend src-baseline e2e ADR` — so an UNCOMMITTED new file under `e2e/` also trips them, 18/19 and 21/22): run them on a COMMITTED tree (on a dirty tree they report 18/19 and 20/22 for that reason only).
  Slice 3's committed results JSON is a historical artifact of `b9d4808` (line numbers moved since); do not commit a regenerated one without a reason.
- Slice 4 `extract-script.mjs verify 9c95fbd` reports 16/17 now (P7 "nothing else touched" is time-bound: it was 17/17 only at the slice 4 commit; verified identical on a clean `fbd7236`). Its P5 and the exec-order check A7 were adapted for the slice 6 startup block.
- `e2e/phase2-core-seed-flows.mjs` check `ciphertext-hides-plaintext` is INTERMITTENT (~3.5% false failure: substring "42" in random base64; CP-14 §E-1). A lone 15/16 → re-run before concluding anything.
- Expected on this commit: Vitest 168, E2E 12 / 16 / 16 + slice 4 21, slice 5 27 (now `SURVIVES`), slice 6 35, slice 7 47 (`STUCK`), slice 5 mutation 3/3 (M1 now = revert → LOST), slice 7 mutation 5/5, slice 4 mutation 16/16 (0 survivors), exec-order 9/9, slice 3 analyzer 22/22 (clean tree), backend 406 (+ `tsc --noEmit` exit 0), slice 2 probe 19 —
  as numbers to RE-MEASURE, not to trust.

## 3. Rules that bit us this session
- Slice 7 lessons: a first-run failure in an old evidence script is not automatically a regression nor automatically noise — read the check, quantify (here 20000 real `encryptState` calls), re-run N times, and write both outcomes down. A new uncommitted file under `e2e/` makes slice 2/3 cleanliness checks fail: commit-or-move it before running them.
  For stateful-flag bugs use controls (normal cycle; the precondition without the trigger), wait out toasts so new ones are attributable, and add a CAUSAL intervention (reset only the suspected variable) before calling the cause. Prove discrimination with scratch mutants incl. the candidate fix.
  The E2E online send needs no mock: with every non-origin request aborted, `callClaude` fails ("Failed to fetch") and the real `finally` runs (~2 s).
- A classic-script `let`/`const` is not a `window` property; bridge pattern =
  `main.js` import + `window.x = x`, assigned BEFORE the startup calls.
- Extraction scripts must abort if the monolith differs from HEAD or the target
  block is not found exactly once.
- Prove tests can fail (mutation) and restore byte-identical (sha256).
- E2E scripts must report failures, not crash: a crash is detection but not evidence.
- `autoInitApp` swallows decrypt errors: assert restored DATA, not absence of errors.
- Slice 2 finding (Chromium 141): module code can read/write classic top-level `let`/`var`
  by bare name (const: read OK, write TypeError; let/const not on `window`). This is a
  FINDING, not a design authorization: ADR-003 and the bridge pattern are unchanged until
  a separate explicit decision. Evidence-probe helpers must use collision-proof names
  (a helper called `R` or `p` could shadow a monolith global and corrupt a read).
- Slice 5 lessons: Playwright `context.setOffline(true)` makes a page reload fail (`ERR_INTERNET_DISCONNECTED`) unless the document is served by `context.route`; serve from an
  `https://` fake origin (secure context ⇒ `crypto.subtle`; plain `http://nexus.test` has none ⇒ `encryptionKey` never set) and register the route when the context is created. Always PROVE offline per boot
  (`navigator.onLine` captured at document start + the app's banner), and keep a positive control (offline, no blob) so an absent entry can't be a measurement artifact (mutant M3).
  Report the outcome with `[OBSERVED]` instead of asserting the hypothesis, so the script can't be "passing" merely because it agrees with the inference.
- Slice 6 lessons: evidence scripts that match `main.js` by exact text or only scan top-level `ExpressionStatement`s break silently when the startup block changes — grep the scripts for the text you edit and
  MEASURE each one on the clean previous commit (clone) before blaming the patch. A VALID check must be able to fail (it caught a test bug: reading `hasBlob` after `persistState()` writes one). Never `await` a startup promise at module top level when the
  following calls must survive its rejection: use `.finally`. Hold init open with a test-side gate on the first `localStore.get`, not with sleeps.
- Slice 4 lessons: a classic function declaration owns its `window` name, so module functions cannot be bridged under the same name when the classic
  callers keep the old signature — bridge as a namespace (`window.PersistableStateCore`) and keep one-line classic wrappers. A behavior check in an E2E must
  not depend on a patch-specific block (it fails pre-patch for the wrong reason). Mutation anchors must be unique (a comment can duplicate code text).

## 4. Next slice
**Core slices 4 (CP-11), 5 (CP-12), 6 (CP-13) and 7 (CP-14): VERIFIED — do not redo.** Slice 6: I-1 handled via O2. Slice 7 (evidence-only): the `isSendingMessage` finding of CP-13 §8 is CONFIRMED at runtime (`S7-VERDICT = STUCK`, Chromium 141 headless + emulated offline only) and is NOT fixed.
**No next slice is auto-approved. Phase 2 is NOT complete (PARTIAL); boundary 5 core is PARTIAL.** Owner decisions pending: (b) ownership mechanism for C2/C3 + a separate ADR-003 revision;
(c) Evidence Integrity decisions (CP-9 §4); (d) whether to apply a fix for the CONFIRMED `isSendingMessage` defect as its own small slice (CP-14 §6: candidate A = set the flag after the offline check, or B = reset it in the offline branch; both validated only on scratch mutants; acceptance criteria first; PRE = slice 7 STUCK, POST = NOT-STUCK) and whether to fix the intermittent seed-flows check (CP-14 §E-1) in a separate tools slice.
Moving variable ownership (C2/C3) stays blocked on (b).

Separate and owner-gated (do NOT mix with core): the Evidence Integrity guard is
BLOCKED until the decisions in `docs/checkpoints/CP-9.md` §4 are made (fail-closed policy for
`EvidenceItem` without a declared kind; kind for Ops Center manual evidence rows; reason
persistence; ADR-004). The recommended minimal seam is in CP-9 §5.

## 5. Exact Arabic command for the next conversation
(قرار المالك مطلوب قبل أي شريحة كود — اختر/عدّل البنود بين الأقواس قبل الإرسال.)
```
NEXUS v5.0 — Continue من الحالة الموثقة الحالية في المستودع (NEXUS-CURRENT-STATE.md و CP-14)، ولا تعِد ما تم ولا تعيد التخطيط.
أولاً: أعد بناء الحالة من المستودع (Git، الشجرة، الـ HEAD، السلسلة HEAD~1=5770104) وأعد قياس الاختبارات ولا تثق بالأرقام المكتوبة (انتبه: seed-flows فحص ciphertext-hides-plaintext متقلّب ≈3.5% — CP-14 §E-1).
I-1 مُعالَجة في slice 6 (CP-13) وملاحظة isSendingMessage مؤكَّدة بالتشغيل في slice 7 (CP-14: STUCK) — لا تُعاد. اختر الهدف التالي بقرار مالك صريح: [إصلاح isSendingMessage (المرشّح A أو B من CP-14 §6) | آلية ملكية C2/C3 + مراجعة ADR-003 | قرارات Evidence Integrity (CP-9 §4) | إصلاح الفحص المتقلّب في seed-flows | غير ذلك: ...].
ثم نفّذ فقط الشريحة التي تنتج عن هذا القرار، بمعايير قبول مكتوبة قبل الرقعة وPRE/POST وmutation، ثم CP-14 + تحديث CURRENT-STATE/CONTINUATION/CHANGELOG.
Evidence Integrity يبقى BLOCKED ولا يُخلط. لا تبدأ نقل ملكية أي متغير (C2/C3) ولا تعدّل PERSISTABLE_STATE أو ADR-003 دون قرار مالك صريح.
ثم commit وأنشئ ZIP بعد الـ commit، وتحقق أن الشجرة نظيفة والـ HEAD المُوثَّق يطابق الـ commit، واكتب الخلاصة بالعربية (STATUS / COMMIT / TESTS / E2E / CHECKPOINT / ما بقي / الشريحة التالية)، ثم STOP.
```
