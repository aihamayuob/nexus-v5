@echo off
REM One-command run (Windows). Requires Node >= 22.5.
cd /d "%~dp0source"
if not exist src-baseline\nexus-backend\node_modules call npm --prefix src-baseline/nexus-backend ci --no-audit --no-fund
if not exist src-baseline\nexus-backend\dist\index.js call npm --prefix src-baseline/nexus-backend run build
node scripts\nexus-run.mjs
