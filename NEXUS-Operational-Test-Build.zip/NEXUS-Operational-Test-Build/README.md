# NEXUS-Operational-Test-Build

Source commit: `fba63d5b522d33827dae3a311af1132d0ee0a5b8` (branch `integrate/fui1-fui2` of the working repo). Verification logs were produced at commit `a98f34b`; commits after it changed documentation and `.env.example` only.

**Run**: `./run.sh` (or `run.cmd` on Windows) → open the printed URL (also `/NEXUS.html`). Paste the printed gateway key into Settings. Node >= 22.5. Without provider keys/local model runtime the UI works but model calls return an honest "no provider" error; see `source/src-baseline/nexus-backend/.env.example`.
Note: the HTML needs HTTP (ES modules) — opening the file directly from disk is not supported; the launcher serves it.

| Folder/file | Content |
|---|---|
| `source/` | full tree (git archive; no node_modules, no DB, no secrets) incl. tests, e2e, ADRs, migrations, lockfiles, `.env.example` |
| `prebuilt/backend-dist.tar.gz` | the built backend (`dist/`) at the verified build; `run.sh` rebuilds from source if absent |
| `verification/` | raw logs of the clean full verification (npm ci, typecheck, build, 638 backend tests, 186 Vitest, 17 E2E, 38 scenarios, UI demo) + scenario JSON |
| `screenshots/` | launcher UI demo screenshots (desktop 1280, phone 390; ar/RTL) |
| `OPERATIONAL-BUILD.md` | identity, run guide, REAL vs SIMULATED, capability matrix, open findings |
| `IP-LICENSE-SECURITY-DELTA-2026-11-14.md` | dependency/license/IP/security register delta |

All model providers in the verification were **simulated**. Nothing here was deployed or published.
