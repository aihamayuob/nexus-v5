#!/usr/bin/env bash
# One-command run (Linux/macOS). Requires Node >= 22.5.
set -e; cd "$(dirname "$0")/source"
[ -d src-baseline/nexus-backend/node_modules ] || npm --prefix src-baseline/nexus-backend ci --no-audit --no-fund
[ -f src-baseline/nexus-backend/dist/index.js ] || npm --prefix src-baseline/nexus-backend run build
exec node scripts/nexus-run.mjs
