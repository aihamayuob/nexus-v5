// SCRATCH reviewer test (not in package): F-06 demonstration — X-Forwarded-For makes the rate-limit identity attacker-controlled in keyless mode.
import './helpers/zzXffEnv.js';
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createNexusServer } from '../src/gateway/server.js';
test('F-06 demo: rotating X-Forwarded-For bypasses the per-client rate limit (keyless mode)', async () => {
  const s = createNexusServer();
  const url: string = await new Promise((r) => s.listen(0, '127.0.0.1', () => r(`http://127.0.0.1:${(s.address() as any).port}`)));
  const codes = async (hdr: (i: number) => Record<string,string>) => { const o: number[] = []; for (let i = 0; i < 12; i++) o.push((await fetch(`${url}/v2/models`, { headers: hdr(i) })).status); return o; };
  const same = await codes(() => ({}));
  const rotating = await codes((i) => ({ 'X-Forwarded-For': `10.9.8.${i}` }));
  console.log('SAME_CLIENT   ', same.join(','));
  console.log('ROTATING_XFF  ', rotating.join(','));
  await new Promise((r) => s.close(r));
  assert.ok(same.includes(429)); assert.ok(!rotating.includes(429));
});
