// Reviewer-authored, standalone. Re-implements encryptState exactly as frontend/modules/security.mjs and compares OLD vs NEW 'plainHidden'.
import { webcrypto as crypto } from 'node:crypto';
const bufToB64 = (b) => Buffer.from(new Uint8Array(b)).toString('base64');
const obj = { اسم: 'نكسس', n: 42, nested: { a: [1, 2, { b: null }], t: true }, emoji: '🔒', s: "q'\"<>&" };
const pt = new TextEncoder().encode(JSON.stringify(obj));
const OLD = (p) => !atob(p.data).includes('نكسس') && !p.data.includes('42');
const has = (ct, needle) => { const n = new TextEncoder().encode(needle); outer: for (let i = 0; i + n.length <= ct.length; i++) { for (let j = 0; j < n.length; j++) if (ct[i + j] !== n[j]) continue outer; return true; } return false; };
const NEW = (p) => { const ct = Uint8Array.from(atob(p.data), (c) => c.charCodeAt(0)); return !has(ct,'نكسس') && !has(ct,'nested') && !has(ct,'emoji'); };
const real = async (key) => { const iv = crypto.getRandomValues(new Uint8Array(12)); const c = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, pt); return { iv: bufToB64(iv), data: bufToB64(c) }; };
const mutants = {
  'M1 identity (base64 of plaintext JSON, no encryption)': async () => ({ iv: 'AAAA', data: bufToB64(pt) }),
  'M2 plaintext + fake tag (identity prefix)':             async () => ({ iv: 'AAAA', data: bufToB64(new Uint8Array([...pt, ...new Uint8Array(16)])) }),
  'M3 reversed plaintext (obfuscation)':                    async () => ({ iv: 'AAAA', data: bufToB64(new Uint8Array([...pt].reverse())) }),
  'M4 XOR 0x5A single byte (weak obfuscation)':            async () => ({ iv: 'AAAA', data: bufToB64(pt.map((b) => b ^ 0x5a)) }),
};
const N = 20000;
const key = await crypto.subtle.generateKey({ name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
let oldFail = 0, newFail = 0, len = 0;
for (let i = 0; i < N; i++) { const p = await real(key); len = atob(p.data).length; if (!OLD(p)) oldFail++; if (!NEW(p)) newFail++; }
console.log(`REAL AES-GCM x${N} (ciphertext+tag = ${len} bytes, data b64 len ${bufToB64(new Uint8Array(len)).length}): false-failures OLD=${oldFail} (${(100*oldFail/N).toFixed(2)}%)  NEW=${newFail}`);
console.log('Analytic NEW false-failure bound per run ≈ positions*(2^-8n): ' + [['نكسس',new TextEncoder().encode('نكسس').length],['nested',6],['emoji',5]].map(([n,l])=>`${n}(${l}B): ${((len-l+1)/2**(8*l)).toExponential(2)}`).join(', '));
console.log('\nMUTANTS (insecure "encryption"): predicate must be FALSE (= detect) :');
for (const [name, f] of Object.entries(mutants)) { const p = await f(); console.log(`  ${name}: OLD detects=${!OLD(p)}  NEW detects=${!NEW(p)}`); }
// Repeat M1 many times for old's detection rate (base64 of identical plaintext is deterministic => old result is constant)
