# استعادة النسخة المستعادة (restored copy) من هذه الحزمة

النسخة المستعادة **ليست** المستودع الحي: هي clone من الـbundle مع لقطة شجرة العمل فوقه. الخطوات (مأخوذة من `02-original-handoff-unpacked/MANIFEST.md` §4، وأعيد اختبارها في فحص ما قبل الضغط — انظر `INTEGRITY-CHECK-REPORT.md`):

```
# من جذر الحزمة، في مجلد عمل معزول وفارغ:
mkdir -p /path/to/work && cd /path/to/work
cp -a <HANDOFF-ROOT>/02-original-handoff-unpacked ./h
cd h && sha256sum -c SHA256SUMS.txt                       # 944 ملفًا: OK
git bundle verify git/nexus-v5-v5.0-polish.bundle
git clone git/nexus-v5-v5.0-polish.bundle nexus-v5        # HEAD cbdc898a3ba605211d9791979a6415f314ba1c8f
cp -a repo-snapshot/nexus-v5/. nexus-v5/
cd nexus-v5 && git status --porcelain=v1 -uall            # المتوقع: 7 أسطر ?? eval/arabic-v1/* فقط
```

ملفات مرجعية في هذا المجلد (لقطات أُخذت قبل أي عمل CP-20 على النسخة المستعادة):
- `restored-worktree-baseline.sha256` — بصمة كل ملف (861 ملفًا خارج `.git`) في النسخة المستعادة. للمقارنة بعد الاستعادة: `cd nexus-v5 && find . -path ./.git -prune -o -type f -print0 | sort -z | xargs -0 sha256sum | cmp - /path/to/restored-worktree-baseline.sha256`
- `restored-git-state-baseline.txt` — الفرع/HEAD/المراجع/حالة `git status` وقت اللقطة.

ما **لا** تفعله هنا: لا `npm ci`/بناء/تشغيل اختبارات ضمن هذه الحزمة دون قرار صريح (يغيّر الشجرة ويولّد `node_modules`/`dist`). إن شغّلتها فسجّلها كسجلات جديدة منفصلة عن السجلات التاريخية.

الاعتماديات لإعادة التشغيل (لم تُشغَّل في هذه الجلسات): frontend `npm ci`؛ backend `npm ci && npm run build` (`npm test` يستعمل `tsx` غير المُعلن)؛ e2e `npm install --no-package-lock --no-save playwright@1.56.1`؛ Chromium 141 (بيئة التسجيل).
