# HANDOFF-TO-NEXT-CHAT — NEXUS v5 — 2026-10-18

> اقرأ هذا الملف أولًا، ثم `HANDOFF-MANIFEST.md`. مسارات الملفات نسبية إلى جذر هذه الحزمة `NEXUS-COMPLETE-HANDOFF-2026-10-18/`.
> لا أسرار في هذه الحزمة ولا ينبغي إضافتها. كل رقم اختبار فيها **سجل تاريخي** إلا ما وُصف صراحةً بأنه «فحص فعلي في هذه الجلسة».

**وسوم الأدلة المستعملة أدناه:** `[فحص فعلي]` نتيجة فحص نُفّذ في جلسة 2026-10-17/18 على النسخة المستعادة أو الحزمة · `[تاريخي]` رقم/حالة مقروءة من سجل محفوظ لم يُعَد تشغيله · `[استنتاج]` · `[غير مثبت]`.
**الحالات المسموحة للمشروع:** VERIFIED / PARTIAL / PENDING / BLOCKED / FAILED / UNVERIFIED فقط (لا تُستعمل كلمة الإنجاز كحالة).

---

## 1) ما هو NEXUS والهدف
NEXUS v5 («Neural Nexus AI Agents») منصة وكلاء ذكاء اصطناعي عربية يبنيها أيهم وحده: واجهة HTML أحادية كبيرة (~945 KB، 11,764 سطرًا) + `main.js` + 5 وحدات ES (`security`, `storage`, `utilities`, `settings`, `state`) + `sw.js`، وخلفية `nexus-backend` 2.0.0 (Node ≥ 22.5، TypeScript، SQLite، بلا اعتماديات تشغيل). الهدف: منصة «تجارية ومستوى بحث» موثوقة ومعيارية ومستقلة عن مزوّد النموذج، تُثبِت قيمتها بأدلة قابلة للتكرار قبل أي ادعاء تجاري. المسار: Phase 2 Modularization ← Reliability/Production Hardening ← Commercial Readiness ← Research/Advanced ← Real-world Validation. المرجع الحاكم: المستودع والأدلة القابلة لإعادة الإنتاج، لا ذاكرة المحادثات. التعليمات الدائمة: `05-project-reference/PROJECT-INSTRUCTIONS-PERMANENT.md`.

## 2) آخر HEAD معروف (للنسخة المستعادة، لا بالضرورة للمستودع الحي)
- الفرع `v5.0-polish`، HEAD `cbdc898a3ba605211d9791979a6415f314ba1c8f` («Release V1 B4: local-release security…»)، 23 commit، 854 ملفًا متتبعًا. `[فحص فعلي]` على النسخة المستعادة؛ `[تاريخي]` بالنسبة إلى الحي (سُجّل في `02-original-handoff-unpacked/GIT-STATE.txt` بتاريخ 2026-10-17 14:53 +03:00).
- 7 ملفات غير متتبعة = حزمة B6 (`eval/arabic-v1/*`) **غير ملتزمة بـcommit**.
- مرجع مشروع Claude القديم يقول HEAD `80c558a`: **قديم** (انظر `05-project-reference/PROVENANCE-NOTE.md`).

## 3) النسخة المستعادة مقابل المستودع الحي وحدود الوصول
- **النسخة المستعادة** = `git clone` لـ`02-original-handoff-unpacked/git/nexus-v5-v5.0-polish.bundle` + نسخ `repo-snapshot/nexus-v5/` فوقها (خطوات في `06-restoration/RESTORE-STEPS.md`). فيها `origin` يشير إلى ملف الـbundle.
- **المستودع الحي** (في بيئة أخرى، بلا remote) **لم يُفتح قط** في أي من الجلستين. لا تدّعِ مطابقته للنسخة المستعادة ولا انطباق الرقع عليه؛ يلزم `git status` / `git rev-parse HEAD` / `git apply --check` هناك أولًا.
- هذه المحادثة (وأي محادثة لاحقة بلا وصول) تعمل على نسخة مستعادة فقط. كل «فحص فعلي» أدناه عليها.
- وجود الحزمة في محادثة جديدة لا يمنح وصولًا للحي؛ إن لزم، اطلب من المالك مخرجات `git status` الحية أو ملفات محددة.

## 4) المُتحقَّق منه فعليًا / تاريخي فقط / غير مُختبَر
**[فحص فعلي] في الجلستين (فحوص الحزمة والنسخة المستعادة؛ ليست دليل صحة هندسية):**
- بصمة الـZIP المرجعي `c7f40b58…8cbf` والتقرير `be555608…8fbb0`؛ `SHA256SUMS.txt` الأصلي يتحقق (944 ملفًا).
- النسخة المستعادة: HEAD `cbdc898…`، 854 متتبعًا، 7 غير متتبعة، 0 معدّل؛ ملفات B6 تتحقق بـ`sha256sum -c`.
- حزمة CP-20: v1 (35/35) وv2 (68/68، ثم 68/68 بعد الضغط) — **تصف فحوص الحزمة التحضيرية ونطاقها فقط**.
- فحص أسرار: لا أنماط مفاتيح حقيقية في شجرة الحزمة ولا في تاريخ git للنسخة المستعادة؛ فقط قيم اختبار واضحة (`fake-key`, `LAN-test-key-…`). التفاصيل في `INTEGRITY-CHECK-REPORT.md`.

**[تاريخي] لم يُعَد تشغيله (لا تقدّمه كنتيجة جديدة):** backend 502/502؛ Vitest 186/186 (بعد صف واحد استُبدل علنًا)؛ 14 سكربت E2E على clone نظيف لـ`cbdc898` كلها exit=0 (2026-10-17 04:56–05:00)؛ `b1` ‏PRE 2/11 ← POST 11/11؛ `b4fe` ‏5/20 ← 20/20؛ `b4rb` 7/7؛ slice-2 19/19، slice-3 23/23، exec-order 9/9، unit-vs-original 36/36؛ CP-19 characterization؛ مُقيِّم B6 37/37 على استجابات **اصطناعية**. الفهرس: `02-original-handoff-unpacked/TEST-EVIDENCE-INDEX.md` (+ ملحق H1–H14 المقترح في CP-20).

**[غير مُختبَر / UNVERIFIED]:** المستودع الحي؛ HTTPS؛ Firefox/Safari/أجهزة حقيقية؛ B3 وB5 وB6 الحقيقي؛ `npm ci && npm test` على جهاز بلا `tsx` عام؛ التراخيص والملكية الفكرية؛ تقييم أي نموذج فعلي.
**لا تستعمل 37/37 دليلًا على جودة أي نموذج.**

## 5) حالة الشرائح وADRs
| البند | الحالة | ملاحظة موجزة |
|---|---|---|
| Phase 0 / Phase 1 | VERIFIED `[تاريخي]` | CP-1, CP-2 |
| Phase 2 | **PARTIAL** | حدود 1–4 VERIFIED (security, storage, utilities, settings: CP-3…CP-6)؛ حد 5 core PARTIAL؛ 6–9 PENDING |
| Core slice 1 (CP-7) encryptState/decryptState → security.mjs | VERIFIED | |
| Slice 2 (CP-8) probe وصول الوحدات للروابط الكلاسيكية | VERIFIED (دليل فقط) | |
| Evidence Integrity (CP-9 → CP-16, ADR-004) | CP-9 كان BLOCKED ثم عولج في CP-16: VERIFIED ضمن الحدود (قاضٍ وهمي، Chromium 141) | منفصل عن Core |
| Slice 3 (CP-10) خريطة `PERSISTABLE_STATE` والمتغيرات الـ16 | VERIFIED كخريطة | |
| Slice 4 (CP-11) snapshot/restore/reset (C1) | VERIFIED ضمن الحدود؛ أداة `extract-verify` عند `cbdc898` = 11/17 → **PENDING (تحديث دليل)** | سبب الإخفاقات غير مشخَّص لكل فحص `[استنتاج]` أن B4 غيّر الملفات |
| Slices 5–6 (CP-12/13) I-1 (activityLog أثناء إقلاع offline) → معالجة O2 | VERIFIED ضمن الحدود | |
| Slices 7–8 (CP-14/15) قفل `isSendingMessage` العالق → إصلاحه | VERIFIED ضمن الحدود | E-1 أدناه |
| Slice 9 (CP-17) ملكية C2/C3 بالقياس + مراجعة ADR-003 | VERIFIED كشريحة دليل | |
| Slice 10 (CP-18, ADR-005) تجربة `agentOrder` بالـglobal accessor | VERIFIED محليًا ضمن الحدود (متغير واحد) | **R1 في ADR-005 (`sw.js` BLOCKED) قديم**: `sw.js` موجود منذ `711f353` |
| Slice 11 (CP-19) اختبار توصيفي لـ`fullAgentPrompt` | VERIFIED ضمن الحدود (Chromium 141، خلفية وهمية)؛ طفرات PARTIAL؛ MU05 INVALID | |
| Core المتبقي | PENDING | `PERSISTABLE_STATE` و15 من 16 متغيرًا (قرارات المالك D1–D4، ADR-005 R5)؛ `NexusContext`/`ContextFabric` (D5) |
| Release V1 / B1 (Service Worker) | VERIFIED ضمن الحدود | Chromium 141 headless + loopback؛ `sw.js` مُؤلَّف لا مُستعاد؛ SHELL = 6 ملفات JS؛ لا يثبت LAN/HTTPS |
| B2 | **UNDEFINED IN AVAILABLE EVIDENCE** | لا تعريف ولا مصدر؛ لا تصنّفه |
| B3 (مزوّد حي) | PENDING — DATA NOT EXECUTED | لا مفتاح مزوّد؛ لا أثر في الملفات المفحوصة |
| B4 (أمن الإصدار المحلي) | VERIFIED ضمن الحدود | 502/186 سُجّلا على شجرة العمل قبل الالتزام ولم يُعادا على clone نظيف؛ CSP فيه `'unsafe-inline'`؛ بلا TLS؛ غير صالح للإنترنت العام |
| B5 (أداء) | PENDING (لم يبدأ) | |
| B6 (حزمة تقييم عربي) | PARTIAL | الحزمة غير ملتزمة؛ التقييم الحقيقي PENDING — DATA NOT EXECUTED؛ عيبان توثيقيان (E1, E2) |
| LAN عبر HTTP | BLOCKED | `isSecureContext=false` خارج loopback؛ HTTPS UNVERIFIED |
| ADRs 000–005 | موجودة؛ **ADR-006 مقترح فقط** (PROPOSED) | ADR-003: 4 عناصر storage؛ ADR-004: Evidence Integrity؛ ADR-005: ملكية global accessor لـ`agentOrder` فقط، R5 لا تعميم |

## 6) حالة CP-20 وD5 وADR-006 وB2
- CP-20 **PROPOSED** (توثيق فقط): `04-cp20-prep-v2/NEXUS-CP20-PREP-2026-10-18/` (والـZIP بجانبه + `.sha256`). لم يُطبَّق على الحي، ولا commit. النسخة v1 كما سُلّمت في `03-cp20-prep-v1-as-delivered/` (محفوظة تاريخًا؛ لا تعتمدها بدل v2).
- محتوى v2: `proposed/docs/checkpoints/CP-20.md`؛ ثلاث رقع إلحاق/إدراج فقط (`NEXUS-CURRENT-STATE.md` +59، `ADR/005` +10، `CP-18.md` +10، 0 محذوف)؛ `proposed/ADR/006-…PROPOSED.md`؛ errata لـB6؛ ملحق `TEST-EVIDENCE-INDEX`؛ وتقارير (`CP20-CHANGE-TRACE`, `UNPROVEN-CLAIMS`, `LIVE-REPO-UPDATE-LIST`, `SCOPE-VERIFICATION-REPORT`, `FINAL-REPORT`).
- **D5** (قرار المالك 2026-10-14): معالجته **إعادة بناء توثيقية لجوهر القرار، لا استرجاعًا للنص التاريخي**. النص الحرفي للخيارات غير متاح في الأدلة المفحوصة؛ لا تُختلق صياغة ولا خيارات إضافية. الجوهر: ContextFabric يبقى كلاسيكيًا؛ NexusContext لا يُنقل في المرحلة الحالية؛ أي نقل لاحق بحقن اعتماديات صريح؛ الوصول بالاسم المجرد مرفوض؛ الخيار (أ) المفضّل بحسب السجلات المتاحة (صياغته الحرفية غير مثبتة). المؤكَّد في وثائق المستودع: الأول والثاني ومتطلب اختبار التوصيف (CP-19) والحقن الصريح؛ المسجَّل في ملاحظة المالك/المراجعة فقط: رفض الاسم المجرد وتفضيل (أ).
- **ADR-006**: `PROPOSED`، «Approval: NOT GIVEN»، مرتبط بـ`CP-20.md` §5. لا يصير قرارًا إلا بموافقة المالك الصريحة.
- **B2**: سُحب تصنيفه من الحالة المعتمدة؛ في `UNPROVEN-CLAIMS.md` بالنص: «B2 — UNDEFINED IN AVAILABLE EVIDENCE; definition and source required.» لا تخترع تعريفًا. إن ظهر دليل أصلي موثوق، سجّل مصدره ومرجعه قبل أي تحديث.

## 7) المخاطر والعيوب والادعاءات غير المثبتة والمؤجَّل
- **مخاطر/عيوب (تاريخي):** E-1 اختبار `ciphertext-hides-plaintext` المتقطع في `e2e/phase2-core-seed-flows.mjs` (~3.5% بالصدفة؛ عيب أداة دليل موثَّق في CP-14 §E-1؛ لم يُصلَح؛ تقرير التسليم يقول «غير مشخَّص» وهذا متجاوَز بـCP-14)؛ `extract-verify` 11/17؛ `tsx` غير مُعلن؛ `typescript:"*"`؛ لا lockfile للـe2e؛ لا LICENSE؛ ملفات B6 غير ملتزمة؛ `X-Forwarded-For` قابل للتزوير؛ MQTT غير مُحصَّن؛ مجموعة B6 كتبها ذكاء اصطناعي ولم يراجعها عربي بشري؛ العتبات مقترحة غير مقيسة.
- **أخطاء توثيقية في B6** (errata مقترح، دون لمس الملفات المجمّدة): README يشير إلى `release-v1-b6-*.log` و«5 mutants» غير موجودين؛ `criteria.frozen.md` يقول «8 categories» والبيانات 7.
- **ادعاءات غير مثبتة:** 17 بندًا في `04-…/reports/UNPROVEN-CLAIMS.md`.
- **مؤجَّل:** B3 ← B6 الحقيقي (يحتاج مفتاح مزوّد)؛ B5؛ إصلاحات قابلية الإعادة؛ تحديث `extract-verify`؛ قرار LAN/HTTPS؛ مستند التراخيص/IP؛ أي نقل لـContextFabric/NexusContext؛ باقي حدود Phase 2 (6–9)؛ تحديث مرجع المشروع.

## 8) ماذا تقرأ أولًا (بهذا الترتيب)
1. هذا الملف ثم `HANDOFF-MANIFEST.md` و`INTEGRITY-CHECK-REPORT.md` و`PROVENANCE-REPORT.md`.
2. `05-project-reference/PROJECT-INSTRUCTIONS-PERMANENT.md` ثم `…REFERENCE-2026-10-15.md` (مع `PROVENANCE-NOTE.md`: قديم في نقطتين).
3. `02-original-handoff-unpacked/GIT-STATE.txt`، `TEST-EVIDENCE-INDEX.md`، وقسم «NEXT SESSION — START HERE» في `NEXUS-HANDOFF-REPORT-2026-10-17.md`.
4. `02-original-handoff-unpacked/repo-snapshot/nexus-v5/`: `NEXUS-CURRENT-STATE.md`، `docs/checkpoints/CP-19.md` (والأحدث)، `ADR/003–005`، `PHASE2-MODULARIZE.md`، `PLAN.md`، `ROADMAP.md`، `docs/DEPLOYMENT-LAN.md`.
5. `04-cp20-prep-v2/NEXUS-CP20-PREP-2026-10-18/README-FIRST.md` ثم `proposed/docs/checkpoints/CP-20.md` و`reports/UNPROVEN-CLAIMS.md`.
6. لفهم B1/B4: `baseline/evidence/release-v1-b1-*` و`release-v1-b4-*`؛ لـB6: `eval/arabic-v1/README.md` + `criteria.frozen.md` + `04-…/proposed/docs/errata/`؛ لـPhase 2: CP-3…CP-19 + `evidence-external/`.

## 9) الخطوة التالية المسموحة تمامًا وما يحتاج موافقة صريحة
**المسموح دون موافقة جديدة (قراءة/تحقق فقط):** قراءة الحزمة، تشغيل `sha256sum -c`، استعادة نسخة في مجلد معزول وفحصها بأوامر قراءة فقط، الإجابة على الأسئلة، وإعداد مسودات في مجلد عمل منفصل **دون** نقلها إلى أي مستودع.
**الخطوة التالية الوحيدة:** انتظار قرار المالك المستقل على حزمة CP-20 v2 (الاعتماد/التعديل/الرفض) وعلى ADR-006.
**يحتاج موافقة المالك الصريحة قبل أي تنفيذ:** (أ) تطبيق CP-20 على المستودع الحي (`reports/LIVE-REPO-UPDATE-LIST.md`: شروط مسبقة ثم ترتيب 1→6 ثم commit وثائق فقط)؛ (ب) أي commit أو push؛ (ج) حماية حزمة B6 بـcommit؛ (د) اعتماد ADR-006 أو تعريف B2؛ (هـ) تحديث مرجع مشروع Claude؛ (و) أي شريحة تنفيذية جديدة أو لمس إنتاج/اختبارات/حزم/ملفات مجمّدة؛ (ز) إعادة تشغيل اختبارات على المستودع الحي أو توفير مفاتيح مزوّد.

## 10) تعليمات صريحة
- **لا تبدأ من الصفر** ولا تعِد تحليل المشروع كاملًا: ابدأ من هذه الحزمة وتحقّق من الحالة الحالية بما يكفي لتفادي الافتراضات القديمة.
- **لا تُعِد عملًا مكتملًا** (CP-20 التحضيري، فحوص الأسرار، بناء الحزم) دون سبب فني موثّق؛ ولا تعِد اختبارًا تاريخيًا لمجرد التأكد.
- **لا تخلط الأدلة التاريخية بنتائج فحوص جديدة**: أي رقم لم يُشغَّل الآن يُسمّى «سجل تاريخي». أي اختبار تشغّله لاحقًا يُسجَّل بأمره ونتيجته وبيئته كسجل جديد بجانب القديم.
- لا تضعف اختبارًا أو معيارًا مجمّدًا، ولا تحذف سجل فشل، ولا ترفع حالة دون دليل، ولا تدّعِ وصولًا للمستودع الحي، ولا تعتمد «35/35» أو «68/68» أو «37/37» دليلًا على الصحة الهندسية أو جودة نموذج.
- بعد أي شريحة: INSPECT → MAP → DIAGNOSE → PATCH → TEST → VERIFY → DOCUMENT → **STOP**.
