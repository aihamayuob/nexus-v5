# PROVENANCE-REPORT — أصلي / جديد / مقترح معدِّل

## 1) التصنيف
| الفئة | المسار | الدليل على وضعها |
|---|---|---|
| **أصلي (من المالك، دون تعديل)** | `01-original-handoff-2026-10-17/NEXUS-HANDOFF-2026-10-17.zip`، `…/NEXUS-HANDOFF-REPORT-2026-10-17.md`، `00-owner-requests/*` | بصمتان مُطابَقتان لما رُفع: ZIP `c7f40b58…8cbf`، التقرير `be555608…8fbb0` (P1 في سجل الفحص) |
| **أصلي مفكوك** | `02-original-handoff-unpacked/` | `diff -r` مع فك جديد للـZIP: لا فرق؛ `SHA256SUMS.txt` الأصلي يتحقق |
| **جديد (أُنتج في جلستي 2026-10-17/18، توثيق فقط)** | `03-cp20-prep-v1-as-delivered/*`، `04-cp20-prep-v2/*`، `06-restoration/*`، `HANDOFF-*.md`، `EXCLUSIONS.md`، `PROVENANCE-REPORT.md`، `INTEGRITY-CHECK-REPORT.md`، `integrity/*` | هذا التقرير وسجلات الفحص |
| **نسخ من مشروع Claude** | `05-project-reference/*` | ملاحظة المصدر؛ غير ممهورة ببصمة أصلية |
| **مقترح معدِّل (PROPOSED؛ يعدّل ملفات المشروع لو طُبّق، ولم يُطبَّق)** | داخل `04-…/NEXUS-CP20-PREP-2026-10-18/proposed/`: ثلاث رقع (`NEXUS-CURRENT-STATE.md` +59، `ADR/005-…` +10، `docs/checkpoints/CP-18.md` +10، 0 محذوف) ونسخها الكاملة `*.proposed`؛ وملفات جديدة مقترحة: `docs/checkpoints/CP-20.md`، `docs/errata/B6-…ERRATA…md`، `ADR/006-…PROPOSED.md`، `TEST-EVIDENCE-INDEX.addendum.md` | الأصول الثلاثة في `02-…/repo-snapshot/nexus-v5/` **لم تتغير** (بصماتها = الأساس) |
| **نسخة تاريخية مُتجاوَزة** | `03-…` (v1) | v2 تحلّ محلها؛ v1 محفوظة كما سُلّمت (يتضمن مسودة ADR-006 بالاسم `.DRAFT.md`) |

لا ملف إنتاج أو اختبار أو حزمة أو مجمّد تغيّر: `02-…/repo-snapshot/nexus-v5/**` مطابق للأصل بايتًا (P1، P2).

## 2) فروق v1 → v2 (من `diff -rq` على الحزمتين)
| الملف | التغيير |
|---|---|
| `proposed/ADR/006-…DRAFT.md` (v1) → `006-…PROPOSED.md` (v2) | حالة PROPOSED صريحة، «Approval: NOT GIVEN»، ربط بـCP-20، إعادة بناء توثيقية، جدول مصادر، جدول اتساق مع ADR-003/004/005 |
| `proposed/docs/checkpoints/CP-20.md` | §0 قرارات المراجعة؛ سحب صف B2؛ §5 D5 معاد كتابته؛ إشارة ADR-006 |
| `proposed/patches/NEXUS-CURRENT-STATE.md.patch` و`files-full/…proposed` | إزالة صف B2 من جدول الحالة؛ قسم D5 معاد صياغته؛ إشارة ADR-006 (PROPOSED)؛ 59 سطرًا مضافًا |
| `proposed/TEST-EVIDENCE-INDEX.addendum.md` | H13 بصياغة «غياب أي أثر لـB3/B5 في الملفات المفحوصة»؛ B2 غير مصنَّف |
| `reports/UNPROVEN-CLAIMS.md` | قسم B2 بالسطر الحرفي المطلوب؛ تعديل البنود 6 و8 و9 |
| `reports/CP20-CHANGE-TRACE.md`، `LIVE-REPO-UPDATE-LIST.md` | مواءمة (ADR-006 PROPOSED، +59، قرارات المراجعة) |
| `reports/SCOPE-VERIFICATION-REPORT.md` | أُعيدت كتابته؛ قسم «ما الذي يصفه عدد الفحوص» |
| `reports/FINAL-REPORT.md` | جديد |
| `README-FIRST.md`، `SHA256SUMS.txt` | محدَّثان |
| `evidence/` | **إضافة فقط**: سكربت v2 وسجلاته (بما فيها التشغيل الفاشل 66/68)، لقطات بداية v2، نسخ سجلات v1 النهائية؛ لا حذف ولا استبدال لسجل v1 |
| غير متغيّر | رقعتا `ADR_005…` و`docs_checkpoints_CP-18…` ونسخهما الكاملة؛ errata B6 |

## 3) سجل الإخفاقات (تاريخي؛ محفوظ)
- v1: فحص 34/35 (سلسلة بحث حساسة للحالة)؛ ثم 34/35 بعد الضغط (ذكر الوسم المحظور في نص تقرير)؛ ثم 35/35.
- v2: التشغيل الأول 66 ناجحًا / 2 فاشلان (سلسلتا بحث متشددتان في السكربت)؛ ثم 68/68؛ ثم 68/68 بعد إضافة FINAL-REPORT؛ ثم 68/68 على النسخة المفكوكة من الـZIP.
- كل إخفاق أصلحه تعديل **نص الفحص** لا المحتوى، والسجلان القديم والجديد محفوظان.
