#!/usr/bin/env bash
# Pre-zip integrity checks of the complete handoff BUILD TREE. Read-only on the tree; scratch in $T.
# Usage: verify-handoff-prezip.sh <BUILD_ROOT> <SCRATCH_DIR>
B=${1:?}; T=${2:?}; S=/tmp/claude-0/-home-claude/bfd15cfd-5e21-5f58-adc1-6afcec4bbcd8/scratchpad
pass=0; fail=0
ok(){ if [ "$1" = 0 ]; then echo "[PASS] $2"; pass=$((pass+1)); else echo "[FAIL] $2"; fail=$((fail+1)); fi; }
sec(){ printf '\n##### %s\n' "$1"; }
rm -rf "$T"; mkdir -p "$T"

sec "P1 original handoff ZIP and report"
Z=$B/01-original-handoff-2026-10-17/NEXUS-HANDOFF-2026-10-17.zip
[ "$(sha256sum $Z | awk '{print $1}')" = c7f40b58750249f21623d62b813a3b036507881a4e24345480d5c99fe7148cbf ]; ok $? "01 ZIP sha256 == c7f40b58…8cbf (the user's upload)"
[ "$(sha256sum $B/01-original-handoff-2026-10-17/NEXUS-HANDOFF-REPORT-2026-10-17.md | awk '{print $1}')" = be55560828f58db179af2f27b582bc12ec93a9e9899e2b7f0a06a10f0c58fbb0 ]; ok $? "01 report sha256 == be555608…8fbb0"
cmp -s $B/01-original-handoff-2026-10-17/NEXUS-HANDOFF-REPORT-2026-10-17.md $B/02-original-handoff-unpacked/NEXUS-HANDOFF-REPORT-2026-10-17.md; ok $? "01 standalone report is byte-identical to the report inside the ZIP"
mkdir $T/z && unzip -q $Z -d $T/z && diff -r $T/z/NEXUS-HANDOFF-2026-10-17 $B/02-original-handoff-unpacked >/dev/null; ok $? "02 unpacked copy == fresh extraction of the 01 ZIP (diff -r: no difference)"
( cd $B/02-original-handoff-unpacked && sha256sum -c SHA256SUMS.txt >/dev/null 2>&1 ); ok $? "02 original SHA256SUMS.txt verifies"
[ "$(cd $B/02-original-handoff-unpacked && find . -type f | wc -l)" = 945 ]; ok $? "02 contains 945 files"

sec "P2 git bundle and reproducibility of the restored copy"
git clone -q $B/02-original-handoff-unpacked/git/nexus-v5-v5.0-polish.bundle $T/nexus-v5 2>/dev/null; ok $? "git clone from the bundle (RESTORE-STEPS step)"
git -C $T/nexus-v5 bundle verify $B/02-original-handoff-unpacked/git/nexus-v5-v5.0-polish.bundle >/dev/null 2>&1; ok $? "git bundle verify (run inside a repository: the command requires one)"
cp -a $B/02-original-handoff-unpacked/repo-snapshot/nexus-v5/. $T/nexus-v5/; ok $? "snapshot overlay copied"
cd $T/nexus-v5
[ "$(git rev-parse HEAD)" = cbdc898a3ba605211d9791979a6415f314ba1c8f ] && [ "$(git rev-list --count HEAD)" = 23 ] && [ "$(git ls-files | wc -l)" = 854 ]; ok $? "reproduced copy: HEAD cbdc898…, 23 commits, 854 tracked"
[ "$(git status --porcelain=v1 -uall | wc -l)" = 7 ] && [ "$(git status --porcelain=v1 -uall | grep -c '^?? eval/arabic-v1/')" = 7 ]; ok $? "reproduced copy: status == the 7 untracked eval/arabic-v1/* files only"
find . -path ./.git -prune -o -type f -print0 | sort -z | xargs -0 sha256sum > $T/repro.sha256
cmp -s $T/repro.sha256 $B/06-restoration/restored-worktree-baseline.sha256; ok $? "reproduced worktree digest == restored-worktree-baseline.sha256 ($(wc -l < $T/repro.sha256) files)"
( cd eval/arabic-v1 && sha256sum -c SHA256SUMS.txt >/dev/null 2>&1 ); ok $? "reproduced copy: B6 sha256sum -c"
cd $B

sec "P3 CP-20 packages"
( cd $B/03-cp20-prep-v1-as-delivered && sha256sum -c NEXUS-CP20-PREP-2026-10-17.zip.sha256 >/dev/null 2>&1 ); ok $? "v1 ZIP matches its .sha256"
mkdir $T/v1 && unzip -q $B/03-cp20-prep-v1-as-delivered/NEXUS-CP20-PREP-2026-10-17.zip -d $T/v1 && ( cd $T/v1/NEXUS-CP20-PREP-2026-10-17 && sha256sum -c SHA256SUMS.txt >/dev/null 2>&1 ); ok $? "v1 ZIP content verifies against its own SHA256SUMS.txt"
( cd $B/04-cp20-prep-v2 && sha256sum -c NEXUS-CP20-PREP-2026-10-18.zip.sha256 >/dev/null 2>&1 ); ok $? "v2 ZIP matches its .sha256"
mkdir $T/v2 && unzip -q $B/04-cp20-prep-v2/NEXUS-CP20-PREP-2026-10-18.zip -d $T/v2 && diff -r $T/v2/NEXUS-CP20-PREP-2026-10-18 $B/04-cp20-prep-v2/NEXUS-CP20-PREP-2026-10-18 >/dev/null; ok $? "v2 unpacked copy == fresh extraction of the v2 ZIP"
( cd $B/04-cp20-prep-v2/NEXUS-CP20-PREP-2026-10-18 && sha256sum -c SHA256SUMS.txt >/dev/null 2>&1 ); ok $? "v2 content verifies against its own SHA256SUMS.txt"
grep -c . $B/04-cp20-prep-v2/v2-post-zip-scope-check.log >/dev/null; grep -q 'SUMMARY pass=68 fail=0' $B/04-cp20-prep-v2/v2-post-zip-scope-check.log; ok $? "recorded v2 post-zip scope check log says pass=68 fail=0 (a copy of an earlier run; not re-executed here)"

sec "P4 required files present"
for f in HANDOFF-TO-NEXT-CHAT.md HANDOFF-MANIFEST.md EXCLUSIONS.md PROVENANCE-REPORT.md 05-project-reference/PROJECT-INSTRUCTIONS-PERMANENT.md 05-project-reference/NEXUS-CLAUDE-PROJECT-INSTRUCTIONS-REFERENCE-2026-10-15.md 05-project-reference/PROVENANCE-NOTE.md 06-restoration/RESTORE-STEPS.md 02-original-handoff-unpacked/TEST-EVIDENCE-INDEX.md 02-original-handoff-unpacked/GIT-STATE.txt 02-original-handoff-unpacked/repo-snapshot/nexus-v5/NEXUS-CURRENT-STATE.md 02-original-handoff-unpacked/repo-snapshot/nexus-v5/docs/checkpoints/CP-19.md 02-original-handoff-unpacked/repo-snapshot/nexus-v5/eval/arabic-v1/dataset.jsonl 04-cp20-prep-v2/NEXUS-CP20-PREP-2026-10-18/proposed/docs/checkpoints/CP-20.md 04-cp20-prep-v2/NEXUS-CP20-PREP-2026-10-18/proposed/ADR/006-D5-contextfabric-nexuscontext-boundary.PROPOSED.md 04-cp20-prep-v2/NEXUS-CP20-PREP-2026-10-18/reports/UNPROVEN-CLAIMS.md 04-cp20-prep-v2/NEXUS-CP20-PREP-2026-10-18/reports/FINAL-REPORT.md; do [ -s "$B/$f" ]; ok $? "present and non-empty: $f"; done
for n in 003-phase2-storage-boundary 004-evidence-integrity 005-global-accessor-state-ownership; do [ -s $B/02-original-handoff-unpacked/repo-snapshot/nexus-v5/ADR/$n.md ]; ok $? "ADR present: $n"; done
for d in release-v1-b1-acceptance-criteria.md release-v1-b4-acceptance-criteria.md; do [ -s $B/02-original-handoff-unpacked/repo-snapshot/nexus-v5/baseline/evidence/$d ]; ok $? "evidence present: $d"; done

sec "P5 exclusions: no secret-bearing / oversized build artefacts"
[ "$(find $B -name node_modules -o -name dist -o -name .git -o -name '.env' | wc -l)" = 0 ]; ok $? "no node_modules / dist / .git / .env in the tree"
[ "$(find $B -type f \( -name '*.pem' -o -name '*.key' -o -name 'id_rsa*' -o -name '*.sqlite*' -o -name '*.db' \) | wc -l)" = 0 ]; ok $? "no key / certificate / database file"
find $B -iname '.env*' | sed "s#$B/#  found: #"
[ "$(find $B -iname '.env*' ! -name '.env.example' | wc -l)" = 0 ]; ok $? "the only .env-named file is .env.example"
[ "$(du -sk $B | awk '{print $1}')" -lt 200000 ]; ok $? "tree under 200 MB ($(du -sh $B | awk '{print $1}'))"

sec "P6 secret-pattern scan of the whole tree (text files)"
PAT='\bsk-[A-Za-z0-9_-]{20,}|\bsk-ant-[A-Za-z0-9_-]{10,}|AKIA[0-9A-Z]{16}|BEGIN [A-Z ]*PRIVATE KEY|ghp_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}|xox[baprs]-[A-Za-z0-9-]{10,}|AIza[0-9A-Za-z_-]{35}|Bearer [A-Za-z0-9._-]{20,}'
n=$(grep -rIEc "$PAT" $B | awk -F: '{s+=$2} END{print s+0}'); [ "$n" = 0 ]; ok $? "strict token patterns in tree: $n matches"
echo "distinct non-empty key-like assignments (inspect: should all be obvious test fixtures):"
grep -rIEoh '(API_KEY|SECRET|TOKEN|PASSWORD|GATEWAY_KEYS)[A-Z_]*\s*=\s*[^#[:space:]]{6,}' $B | sed 's/^[^=]*=//' | sort -u | sed 's/^/    /' | head -40
bad=$(grep -rIEoh '(API_KEY|SECRET|TOKEN|PASSWORD|GATEWAY_KEYS)[A-Z_]*\s*=\s*[^#[:space:]]{6,}' $B | sed 's/^[^=]*=//' | sort -u | grep -viE "fake|test|LEGACY-persisted|secret-key-abc|super-secret-value-should-never-leak|saved|\\$\\(|مفتاح|False|\\\\s|^$" | wc -l); [ "$bad" = 0 ]; ok $? "every distinct assignment value is a recognizable fixture/placeholder (non-matching values: $bad)"
echo; echo "SUMMARY pass=$pass fail=$fail"
echo "SCOPE: checks of the HANDOFF PACKAGE contents and reproducibility of the restored copy. Not evidence of engineering correctness; the live repository was not accessed; no project test was run."
[ $fail = 0 ]
