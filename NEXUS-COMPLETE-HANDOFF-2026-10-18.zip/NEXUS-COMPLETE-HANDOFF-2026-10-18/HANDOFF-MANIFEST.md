# HANDOFF-MANIFEST — NEXUS-COMPLETE-HANDOFF-2026-10-18

أُعدّت في 2026-10-18 (Asia/Damascus). **توثيق وتجميع فقط**: لا تعديل على أي ملف إنتاج/اختبار/حزمة/مجمّد، لا commit، ولا وصول إلى المستودع الحي.

> **عن الاسم «COMPLETE»:** الاسم بحسب طلبك. الحزمة كاملة بالنسبة إلى **ما كان متاحًا** (حزمة التسليم 2026-10-17 + عمل CP-20 + مرجع المشروع). ليست سجلًّا كاملًا للمشروع؛ ما ينقصها مذكور في `EXCLUSIONS.md` §ب («مفقود أو غير متاح»): المستودع الحي، تعريف B2، النص الحرفي لخيارات D5، أي أثر لـB3/B5، وثيقة `NEXUS-PROJECT-MASTER-CONTEXT-2.md` (في المشروع لا هنا)، سجلات `release-v1-b6-*.log` المشار إليها في README الخاص بـB6.

## 1) المحتويات
| المسار | ما هو | النوع (انظر `PROVENANCE-REPORT.md`) |
|---|---|---|
| `HANDOFF-TO-NEXT-CHAT.md` | ملف البدء للمحادثة الجديدة (10 نقاط) | جديد |
| `HANDOFF-MANIFEST.md` | هذا الفهرس | جديد |
| `EXCLUSIONS.md` | ما استُبعد/ما هو مفقود، السبب، الأثر، البديل | جديد |
| `PROVENANCE-REPORT.md` | أصلي / جديد / مقترح معدِّل؛ فروق v1→v2 | جديد |
| `INTEGRITY-CHECK-REPORT.md` + `integrity/` | فحوص ما قبل الضغط، سكربتها وسجلها | جديد |
| `SHA256SUMS.txt` | بصمة كل ملف في الحزمة عدا نفسه | مُولَّد |
| `00-owner-requests/` | نصا الطلبين (CP-20 التحضيري؛ قرارات المراجعة وحزمة التسليم) كما وردا | أصلي من المالك |
| `01-original-handoff-2026-10-17/` | ZIP التسليم الأصلي (sha256 `c7f40b58750249f21623d62b813a3b036507881a4e24345480d5c99fe7148cbf`) + تقرير التسليم (`be55560828f58db179af2f27b582bc12ec93a9e9899e2b7f0a06a10f0c58fbb0`) | أصلي، دون تعديل |
| `02-original-handoff-unpacked/` | نسخة مفكوكة من ZIP التسليم (945 ملفًا) للقراءة المباشرة — فيها `GIT-STATE.txt`، `TEST-EVIDENCE-INDEX.md`، `MANIFEST.md`، `git/*.bundle`، `repo-snapshot/nexus-v5/` (861 ملفًا)، `evidence-external/` (76 ملفًا) | أصلي مفكوك، مطابق بايتًا للـZIP |
| `03-cp20-prep-v1-as-delivered/` | CP-20 التحضيري v1 كما سُلّم (ZIP + sha256 + سجلا الفحص النهائيان، أحدهما فاشل 34/35 محفوظ) | جديد (جلسة 2026-10-17)، تاريخي |
| `04-cp20-prep-v2/` | CP-20 v2 بعد قرارات المراجعة: ZIP + `.sha256` + نسخة مفكوكة + سجل الفحص بعد الضغط | جديد/مقترح (PROPOSED) |
| `05-project-reference/` | مرجع الاستئناف 2026-10-15 + تعليمات المشروع الدائمة + ملاحظة مصدر | نسخ من مشروع Claude (غير ممهورة ببصمة أصلية) |
| `06-restoration/` | خطوات استعادة النسخة المستعادة + بصمات الأساس | جديد/مأخوذ من أساس قبل العمل |

## 2) أين يوجد الدليل لكل بند (داخل `02-original-handoff-unpacked/` ما لم يُذكر)
| البند | الملفات الأساسية |
|---|---|
| فهم الحالة الكلية | `NEXUS-HANDOFF-REPORT-2026-10-17.md` (01 أو 02)، `GIT-STATE.txt`، `TEST-EVIDENCE-INDEX.md`، `repo-snapshot/nexus-v5/NEXUS-CURRENT-STATE.md`، `NEXUS-CONTINUATION.md`، `PLAN.md`، `ROADMAP.md` |
| Phase 2 / Core | `repo-snapshot/nexus-v5/PHASE2-MODULARIZE.md`، `docs/checkpoints/CP-3…CP-19.md`، `ADR/002…005`، `baseline/evidence/phase2-*`، `e2e/phase2-*.mjs`، `frontend/modules/*.mjs` |
| B1 (Service Worker) | `frontend/sw.js`، `e2e/release-v1-b1-offline-sw-flows.mjs`، `baseline/evidence/release-v1-b1-*` (PRE/POST/after-b4)، commit `711f353` |
| B2 | **لا شيء**: غير معرَّف في الأدلة المتاحة |
| B3 | **لا أثر**: PENDING — DATA NOT EXECUTED (لا مفتاح مزوّد) |
| B4 | `src-baseline/nexus-backend/src/config/deploymentGuard.ts` والاختبارات، `frontend/modules/{settings.mjs,gatewayKey.test.mjs}`، `frontend/main.js`، `e2e/release-v1-b4-*.mjs`، `baseline/evidence/release-v1-b4-*` و`release-v1-lan-secure-context-probe-*`، `docs/DEPLOYMENT-LAN.md` |
| B5 | **لا أثر**: PENDING (لم يبدأ) |
| B6 | `repo-snapshot/nexus-v5/eval/arabic-v1/` (7 ملفات غير ملتزمة)، `evidence-external/b6-self-test-rerun-at-packaging.log`، أخطاء توثيقية في `04-…/proposed/docs/errata/` |
| الانحدار (14 سكربت) | `evidence-external/logs/regress/` (`_summary.txt`) |
| الصدق والجلسات | `evidence-external/session-honesty-notes.md`، `evidence-external/recovery/` |
| CP-20 | `04-cp20-prep-v2/NEXUS-CP20-PREP-2026-10-18/` (ابدأ بـ`README-FIRST.md`) |
| D5 / ADR-006 | `…/proposed/ADR/006-…PROPOSED.md`، `…/proposed/docs/checkpoints/CP-20.md` §5 |

## 3) كيف تتحقق
```
sha256sum -c SHA256SUMS.txt                 # من جذر الحزمة المفكوكة؛ يغطي كل الملفات عدا نفسه
sha256sum -c ../NEXUS-COMPLETE-HANDOFF-2026-10-18.zip.sha256   # بصمة الـZIP نفسها (ملف منفصل بجانب الـZIP)
```
بصمة الـZIP لا يمكن أن تكون داخله؛ وهي مسلَّمة في ملف `NEXUS-COMPLETE-HANDOFF-2026-10-18.zip.sha256` المنفصل. فحوص ما بعد الضغط (فك الأرشيف، المطابقة، المقارنة بشجرة البناء، فحص الأسرار) مسجَّلة في تقرير خارجي مُسلَّم مع الـZIP لأن الملف لا يضم سجل بنائه.

## 4) أرقام
عدد الملفات وحجمها: انظر `SHA256SUMS.txt` (سطر لكل ملف) و`INTEGRITY-CHECK-REPORT.md`.
