# ADR 006 — Owner decision D5: `ContextFabric` / `NexusContext` boundary

**Status: PROPOSED.** Not an approved architecture decision. It becomes one only after the owner reviews it and approves it explicitly. Approval: **NOT GIVEN**.
**Nature of this document:** a **documentary reconstruction of the engineering substance** of owner decision D5 (2026-10-14). It is **not** a verbatim recovery of the original decision, and its wording must not be quoted as the owner's historical words.
**Linked to:** `docs/checkpoints/CP-20.md` §5 (CP-20 carries the summary and the review history; this file carries the detail).
**Date of this version:** 2026-10-18 (revision after the owner's review of the CP-20 preparation package). Prepared from the restored handoff package only; the live repository was not consulted.
**Scope:** documentation only. No production, test or frozen-criteria file is touched.

## 0) What is and is not established (read first)

- The **literal text of the original D5 options is not available** in the evidence examined: the restored repository, the project documents attached to the Claude project, and the handoff package.
- This document **does not invent** literal option text, **does not add** options beyond those named below, and **does not claim** to restore the original.
- The option letters (ج / أ / ب) are known only through the records listed in §1. What each letter stands for is taken from those records; the original wording behind each letter is **unproven**.
- Whether the original option list contained other options is **unknown**.

## 1) Sources and what each one establishes

| # | Substance | Where it is recorded | Kind of evidence |
|---|---|---|---|
| 1 | `ContextFabric` stays in its classic form (classic script) | `NEXUS-CURRENT-STATE.md` (core slice 11 entry); `docs/checkpoints/CP-19.md` header; owner's request of 2026-10-17 | repository documents + owner statement |
| 2 | `NexusContext` is **not moved in the current phase** | same | same |
| 3 | A characterization test of context composition through `fullAgentPrompt` is a prerequisite for any later move; it was written and verified within its limits (CP-19, commit `80c558a`; mutation testing PARTIAL; MU05 INVALID by owner decision) | `CP-19.md` §1, §3 | repository documents |
| 4 | Any later move requires **explicit dependency injection** | `NEXUS-CURRENT-STATE.md` (core slice 11 entry: "any later move only by explicit injection"); owner's review decision 2026-10-18 | repository document + owner statement |
| 5 | **Access by bare name is rejected** | owner's recorded decision note (2026-10-14, a summary, not a verbatim message); owner's review decision 2026-10-18 | owner statements only; **not written in any repository document** |
| 6 | Option **(أ)** — explicit dependency injection — is the preferred path according to the available records | owner's recorded decision note (summary); owner's review decision 2026-10-18 | owner statements only; the original literal wording of (أ), (ب), (ج) is **unproven** |
| 7 | Execution beyond the characterization test needs a later explicit approval; earlier items reserved for owner decisions (ADR-005 R5, `PERSISTABLE_STATE` and the 16 variables) are not skipped | owner's recorded decision note (summary) | owner statement only |

Letter mapping as used in the available records (not as original text): ج = `ContextFabric` stays classic; أ = explicit dependency injection (preferred path for any later move); ب = access by bare name (rejected).

## 2) Operational restatement (PROPOSED wording — not historical text)

1. `ContextFabric` remains a classic-script object until its dependencies are settled within the proper architectural boundaries.
2. `NexusContext` is not moved in the current phase.
3. Any future move of either object must pass its dependencies in explicitly (dependency injection). Reaching them from a module by bare global name is rejected.
4. Such a move needs a separate explicit approval, acceptance criteria frozen before any production edit, PRE/POST evidence and a full regression run. It must not bypass the open owner decisions on `PERSISTABLE_STATE` and the 16 variables (D1–D4, ADR-005 R5).
5. The CP-19 characterization test is the behavioural baseline for such a move. It describes behaviour; it does not judge it correct (CP-19 §5).

## 3) Consistency with earlier decisions and with the actual project state

Checked by reading the restored package (not the live repository):

| Reference | Finding |
|---|---|
| ADR-003 (Decision: extract four storage items; `PERSISTABLE_STATE` and its 16 variables stay in the monolith) | No conflict. ADR-003 does not mention `NexusContext` or `ContextFabric`; this ADR neither moves nor re-opens `PERSISTABLE_STATE` |
| ADR-005 (global-accessor ownership for `agentOrder` only; R5: no generalization) | No conflict. This ADR authorizes no variable migration and no accessor mechanism |
| ADR-004 (Evidence Integrity) | Unrelated; not touched |
| `PHASE2-MODULARIZE.md` | Lists both objects as untouched and PENDING (lines 382, 412, 474) — consistent with "not moved" |
| `docs/checkpoints/CP-19.md` | States "move of `NexusContext`/`ContextFabric`: not started (decision D5)" — consistent |
| Actual project state | Neither object is moved; no production file changed by this ADR |

Method and limit: a text search of `ADR/*.md` for the two names returned no matches; the other references were read. No conflict was found **within those documents**. The live repository and any document outside the restored package were not examined.

## 4) Consequences

- No code, ADR-003 Decision, ADR-005 Decision, test or evidence changes follow from this document.
- The CP-19 baseline is VERIFIED only within its limits: Chromium 141 headless, a fake backend with two endpoints, no live LLM, no real fetch.
- If the owner rejects or corrects §2, this file is revised or withdrawn; no other document depends on it except the pointers in CP-20 §5 and in the proposed `NEXUS-CURRENT-STATE.md` block.

## 5) Owner actions requested

- Review §1 and §2: confirm, correct or reject.
- Supply the original D5 text if it exists outside the material reviewed (it would then be recorded with its source before any further update).
- Approve or withdraw ADR-006. Until then it stays PROPOSED.
