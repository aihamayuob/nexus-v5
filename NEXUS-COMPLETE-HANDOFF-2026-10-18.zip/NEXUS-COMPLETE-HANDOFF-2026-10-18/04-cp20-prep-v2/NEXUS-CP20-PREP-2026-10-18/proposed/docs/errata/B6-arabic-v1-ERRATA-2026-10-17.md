# Errata — B6 Arabic evaluation pack (`eval/arabic-v1/`) — 2026-10-17 (PROPOSED)

**Nature**: documentation errata kept OUTSIDE the pack so that the seven pack files and their `SHA256SUMS.txt` stay byte-identical. This file corrects nothing in place; it records two documentation defects found by cross-checking the pack against the restored repository (commit `cbdc898`).
**Pack status (unchanged by this file)**: PARTIAL — uncommitted at handoff; real evaluation **PENDING — DATA NOT EXECUTED**. The scorer self-test 37/37 runs on SYNTHETIC responses and validates the scorer's logic only, not any model.

## E1 — referenced logs `release-v1-b6-*.log` do not exist; the "5 scorer mutants" claim has no saved record

- Claim (`eval/arabic-v1/README.md`, "Status" paragraph): the scorer's self-test passes 37/37 "plus 5 scorer mutants that the self-test kills; see baseline/evidence/release-v1-b6-*.log".
- Check performed (restored repository, `baseline/evidence/`): no file matching `release-v1-b6*` exists; none exists in the handoff package's `evidence-external/logs/` either. The handoff report §5 states the mutation record is absent from the package.
- What IS recorded: the packaging-time rerun of `node score.mjs --self-test` (37/37, `evidence-external/b6-self-test-rerun-at-packaging.log`).
- Status of the mutant claim: **UNVERIFIED**. Do not cite it as evidence. It can be closed only by locating the original logs, or by a new, separately approved mutation run whose logs are saved (that would be new evidence, not a correction).

## E2 — "8 categories" versus 7 categories

- Claim (`criteria.frozen.md` §1): "38 prompts in 8 categories", followed by a list of seven categories whose counts sum to 38: knowledge 8, math 6, instruction following 6, summarization 4, dialect/register 4, safety 6, RAG faithfulness 4 (8+6+6+4+4+6+4 = 38).
- Check performed: `dataset.jsonl` has 38 items and exactly 7 distinct `category` values with those counts (knowledge 8, instruction_following 6, math 6, safety 6, dialect 4, rag_faithfulness 4, summarization 4).
- Conclusion: the numeral "8" is a miscount in the prose; the item counts and the data agree with seven categories. No threshold in §4 depends on the category count, so no reported number changes. (That no other section depends on it was checked only by reading §1–§5.)

## Handling rules

- Do not edit the frozen files to fix E1/E2. The README states that a change to the criteria after the first real run creates v2; no real run has happened yet, so whether to correct in place before the first run is an owner decision. Until the owner decides, this errata file is the record.
- Do not re-hash or edit `eval/arabic-v1/SHA256SUMS.txt`; this file lives in `docs/errata/` and is not part of that manifest.
- Related counters that are NOT defects: dataset items (38) and self-test cases (37) are different counters.
