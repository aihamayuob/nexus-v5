#!/usr/bin/env bash
# CP-20 preparation v2 — SCOPE VERIFICATION of the PREPARATION PACKAGE (not of the project's engineering correctness).
# Read-only except stdout and a scratch dir. Targets: restored COPY (never the live repo), extracted handoff package, this package.
S=/tmp/claude-0/-home-claude/bfd15cfd-5e21-5f58-adc1-6afcec4bbcd8/scratchpad
C=$S/cp20; V2=$C/NEXUS-CP20-PREP-2026-10-18; V1=$C/NEXUS-CP20-PREP-2026-10-17
H=$S/handoff/NEXUS-HANDOFF-2026-10-17; R=$S/handoff/restored; E=$V2/evidence; T=$C/tmpwork2
U=/root/.claude/uploads/bfd15cfd-5e21-5f58-adc1-6afcec4bbcd8
mkdir -p $T; pass=0; fail=0
ok(){ if [ "$1" = 0 ]; then echo "[PASS] $2"; pass=$((pass+1)); else echo "[FAIL] $2"; fail=$((fail+1)); fi; }
sec(){ printf '\n##### %s\n' "$1"; }
no(){ grep -q "$@"; [ $? = 1 ]; }   # "pattern must be absent"

sec "V1 input provenance and environment separation"
[ "$(sha256sum $U/9deae3e4-NEXUS-HANDOFF-2026-10-17.zip | awk '{print $1}')" = c7f40b58750249f21623d62b813a3b036507881a4e24345480d5c99fe7148cbf ]; ok $? "uploaded handoff ZIP sha256 == c7f40b58…8cbf"
[ ! -e /tmp/claude-0/-home-claude/32993d6c-3079-5c91-b5d3-407731a6cd59/scratchpad/release/nexus-v5 ]; ok $? "the live-repository path named in GIT-STATE.txt does not exist in this environment (no live access; all checks ran on the restored COPY)"

sec "V2 restored worktree vs BOTH baselines (pre-work baseline from v1, and v2-start)"
( cd $R && find . -path ./.git -prune -o -type f -print0 | sort -z | xargs -0 sha256sum ) > $T/restored-now.sha256
cmp -s $T/restored-now.sha256 $V1/evidence/baseline-restored-worktree.sha256; ok $? "restored worktree == pre-work baseline ($(wc -l < $T/restored-now.sha256) files, incl. production, tests, packages, 7 B6 files)"
cmp -s $T/restored-now.sha256 $E/v2-start-restored-worktree.sha256; ok $? "restored worktree == v2-start snapshot"
( cd $H && find . -type f -print0 | sort -z | xargs -0 sha256sum ) > $T/handoff-now.sha256
cmp -s $T/handoff-now.sha256 $V1/evidence/baseline-handoff-extract.sha256; ok $? "extracted handoff package == pre-work baseline ($(wc -l < $T/handoff-now.sha256) files)"
( cd $H && sha256sum -c SHA256SUMS.txt >/dev/null 2>&1 ); ok $? "original SHA256SUMS.txt of the handoff package still verifies"

sec "V3 git state of the restored copy (no new commit; HEAD unchanged — verifiable only inside this environment)"
cd $R
[ "$(git rev-parse HEAD)" = cbdc898a3ba605211d9791979a6415f314ba1c8f ]; ok $? "HEAD == cbdc898a3ba605211d9791979a6415f314ba1c8f"
[ "$(git rev-list --count HEAD)" = 23 ] && [ "$(git ls-files | wc -l)" = 854 ]; ok $? "23 commits, 854 tracked files"
git for-each-ref --format='%(objectname) %(refname)' > $T/refs-now.txt
diff -q <(sed -n '/^all refs:/,/^--- git status/p' $V1/evidence/baseline-git-state.txt | grep -E '^[0-9a-f]{40} ') $T/refs-now.txt >/dev/null; ok $? "refs identical to baseline"
[ "$(git ls-files -s | sha256sum | awk '{print $1}')" = "$(grep tracked-index-digest $V1/evidence/baseline-git-state.txt | awk '{print $2}')" ]; ok $? "tracked index digest identical to baseline"
[ "$(git status --porcelain=v1 -uall | wc -l)" = 7 ] && [ "$(git status --porcelain=v1 -uall | grep -c '^?? eval/arabic-v1/')" = 7 ]; ok $? "status == exactly the 7 untracked eval/arabic-v1/* files"
[ "$(git diff --name-only | wc -l)" = 0 ] && [ "$(git stash list | wc -l)" = 0 ]; ok $? "no modified tracked file, no stash"

sec "V4 frozen B6 pack"
( cd eval/arabic-v1 && sha256sum -c SHA256SUMS.txt >/dev/null 2>&1 ); ok $? "eval/arabic-v1: sha256sum -c"
for f in README.md SHA256SUMS.txt build_dataset.py criteria.frozen.md dataset.jsonl judge-prompt.md score.mjs; do
  cmp -s <(grep " ./eval/arabic-v1/$f\$" $T/restored-now.sha256) <(grep " ./eval/arabic-v1/$f\$" $V1/evidence/baseline-restored-worktree.sha256); ok $? "B6 file == baseline: $f"; done

sec "V5 history is preserved (nothing from v1 deleted, rewritten or replaced)"
rm -rf $T/v1-zip && mkdir -p $T/v1-zip && unzip -q $C/out/NEXUS-CP20-PREP-2026-10-17.zip -d $T/v1-zip
( cd $T/v1-zip/NEXUS-CP20-PREP-2026-10-17 && sha256sum -c SHA256SUMS.txt >/dev/null 2>&1 ); ok $? "v1 as-delivered ZIP still verifies against its own manifest"
[ "$(sha256sum $C/out/NEXUS-CP20-PREP-2026-10-17.zip | awk '{print $1}')" = "$(awk '{print $1}' $C/out/NEXUS-CP20-PREP-2026-10-17.zip.sha256)" ]; ok $? "v1 ZIP sha256 equals its .sha256 file"
for f in $(cd $T/v1-zip/NEXUS-CP20-PREP-2026-10-17/evidence && ls); do
  cmp -s $T/v1-zip/NEXUS-CP20-PREP-2026-10-17/evidence/$f $E/$f; ok $? "v1 evidence file carried unchanged into v2: $f"; done
cmp -s $T/v1-zip/NEXUS-CP20-PREP-2026-10-17/evidence/verify-scope.sh $E/verify-scope.v1.sh; ok $? "v1 scope script preserved as verify-scope.v1.sh"
for f in v1-final-scope-check-RUN-A-1FAIL-forbidden-label-in-scope-report.log v1-final-scope-check-after-zip-35of35.log; do [ -s $E/$f ]; ok $? "v1 failure/repair history present: $f"; done

sec "V6 what the proposal consists of — documentation only"
cd $V2; find proposed reports -type f | sort | sed 's#^#  #'
[ "$(find proposed reports -type f ! \( -name '*.md' -o -name '*.patch' -o -name '*.proposed' \) | wc -l)" = 0 ]; ok $? "proposed/ and reports/ contain only .md / .patch / .proposed"
[ "$(find proposed -type f \( -name '*.mjs' -o -name '*.js' -o -name '*.ts' -o -name '*.json' -o -name '*.html' -o -name '*.sh' -o -name '*.py' \) | wc -l)" = 0 ]; ok $? "no code/config/test file in proposed/"

sec "V7 patches: 3 existing docs only, additions only, apply cleanly, equal the full proposed copies"
touched=$(grep -h '^+++ ' proposed/patches/*.patch | sed 's#^+++ b/##' | sort | tr '\n' ' ')
[ "$touched" = "ADR/005-global-accessor-state-ownership.md NEXUS-CURRENT-STATE.md docs/checkpoints/CP-18.md " ]; ok $? "patched paths == {NEXUS-CURRENT-STATE.md, ADR/005-…md, docs/checkpoints/CP-18.md}"
rm -rf $T/apply && mkdir -p $T/apply/ADR $T/apply/docs/checkpoints
for f in NEXUS-CURRENT-STATE.md ADR/005-global-accessor-state-ownership.md docs/checkpoints/CP-18.md; do git -C $R show HEAD:$f > $T/apply/$f; done
for p in proposed/patches/*.patch; do
  rem=$(grep -c '^-[^-]' $p); add=$(grep -c '^+[^+]' $p); [ "$rem" = 0 ]; ok $? "$(basename $p): removed lines=$rem (non-blank added lines=$add)"
  git -C $R apply --check $V2/$p >/dev/null 2>&1; ok $? "$(basename $p): git apply --check on the restored repo (writes nothing)"
  ( cd $T/apply && patch -p1 -s < $V2/$p ); ok $? "$(basename $p): applied to a throw-away copy of HEAD content"
done
for f in NEXUS-CURRENT-STATE.md ADR/005-global-accessor-state-ownership.md docs/checkpoints/CP-18.md; do cmp -s $T/apply/$f proposed/files-full/$f.proposed; ok $? "patched copy == full proposed file: $f"; done
cmp -s <(git -C $R show HEAD:NEXUS-CURRENT-STATE.md) $R/NEXUS-CURRENT-STATE.md; ok $? "restored NEXUS-CURRENT-STATE.md still equals HEAD (patches were not applied to the restored copy)"

sec "V8 review decisions are reflected (D5 / ADR-006 / B2)"
A=proposed/ADR/006-D5-contextfabric-nexuscontext-boundary.PROPOSED.md
[ -f $A ] && [ ! -e proposed/ADR/006-D5-contextfabric-nexuscontext-boundary.DRAFT.md ]; ok $? "ADR-006 is a standalone .PROPOSED.md file (v1 .DRAFT.md is not carried into v2)"
grep -q '^\*\*Status: PROPOSED\.\*\*' $A; ok $? "ADR-006 Status line is PROPOSED"
no -qiE 'Status:\s*\**\s*Accepted' $A; ok $? "ADR-006 does not declare itself Accepted"
grep -q 'Approval: \*\*NOT GIVEN\*\*' $A; ok $? "ADR-006 records approval as NOT GIVEN"
grep -qi 'documentary reconstruction' $A && grep -qi 'verbatim recovery' $A; ok $? "ADR-006 states it is a documentary reconstruction, not a verbatim recovery"
grep -qi 'literal text of the original D5 options is not available' $A && grep -qi 'does not invent' $A; ok $? "ADR-006 states the literal option text is unavailable and nothing is invented"
grep -q 'ContextFabric' $A && grep -qi 'bare name is rejected' $A && grep -qi 'explicit dependency injection' $A && grep -q 'NexusContext. is not moved' $A; ok $? "ADR-006 carries the five required substance points (classic / not moved / DI / bare name rejected / (أ) preferred)"
grep -q '(أ)' $A; ok $? "ADR-006 names option (أ) as preferred per available records"
grep -q 'CP-20.md' $A && grep -q '006-D5-contextfabric-nexuscontext-boundary.PROPOSED.md' proposed/docs/checkpoints/CP-20.md; ok $? "ADR-006 <-> CP-20 are cross-linked"
no -q '^| B2 |' proposed/docs/checkpoints/CP-20.md; ok $? "CP-20 status table has no B2 row"
no -qw 'B2' <(grep -h '^+[^+]' proposed/patches/*.patch); ok $? "no B2 classification in any added line of the patches (CURRENT-STATE block etc.)"
grep -qx 'B2 — UNDEFINED IN AVAILABLE EVIDENCE; definition and source required.' reports/UNPROVEN-CLAIMS.md; ok $? "UNPROVEN-CLAIMS.md holds the exact B2 line"
grep -q 'فحوص الحزمة التحضيرية ونطاقها المحدد فقط' reports/SCOPE-VERIFICATION-REPORT.md; ok $? "scope report limits the meaning of the pass count to the preparation package"

sec "V9 forbidden content and honesty markers in ADDED text"
cat <(grep -h '^+[^+]' proposed/patches/*.patch) proposed/docs/checkpoints/CP-20.md proposed/ADR/*.md proposed/docs/errata/*.md proposed/TEST-EVIDENCE-INDEX.addendum.md reports/*.md README-FIRST.md > $T/added-text.txt
no -nw 'DONE' $T/added-text.txt; ok $? "the project-forbidden status label does not occur in any added text"
no -nE 'sk-[A-Za-z0-9]{10,}|AKIA[0-9A-Z]{12,}|BEGIN [A-Z ]*PRIVATE KEY|Bearer [A-Za-z0-9._-]{12,}|ghp_[A-Za-z0-9]{20,}' $T/added-text.txt; ok $? "no credential-like token in added text"
grep -q 'PROPOSED TEXT — not applied' proposed/files-full/NEXUS-CURRENT-STATE.md.proposed; ok $? "CURRENT-STATE block carries the 'PROPOSED TEXT — not applied' banner"
grep -q 'لم يُعَد تشغيل أي اختبار' proposed/docs/checkpoints/CP-20.md; ok $? "CP-20 states no test was re-run"
grep -q 'DATA NOT EXECUTED' proposed/files-full/NEXUS-CURRENT-STATE.md.proposed; ok $? "B3/B6 'PENDING — DATA NOT EXECUTED' present"
grep -qi 'synthetic' proposed/files-full/NEXUS-CURRENT-STATE.md.proposed && grep -q 'says nothing about any model' proposed/files-full/NEXUS-CURRENT-STATE.md.proposed; ok $? "synthetic scorer 37/37 is not presented as model quality"
echo; echo "SUMMARY pass=$pass fail=$fail"
echo "SCOPE OF THIS RESULT: describes the checks of the PREPARATION PACKAGE and the restored copy listed above. It is not evidence of the project's engineering correctness and not evidence that anything succeeded on the live repository (which was not accessed)."
[ $fail = 0 ]
