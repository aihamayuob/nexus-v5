#!/usr/bin/env bash
# CP-20 preparation — READ-ONLY checks. Writes nothing except stdout (captured to readonly-checks.log by the caller).
# Targets: (H) the extracted handoff package, (R) the restored repository copy. Neither is modified.
# Nothing here re-runs an NEXUS test suite; it re-reads saved files and counts.
S=/tmp/claude-0/-home-claude/bfd15cfd-5e21-5f58-adc1-6afcec4bbcd8/scratchpad
H=$S/handoff/NEXUS-HANDOFF-2026-10-17
R=$S/handoff/restored
U=/root/.claude/uploads/bfd15cfd-5e21-5f58-adc1-6afcec4bbcd8
L=$H/evidence-external/logs/regress
sec(){ printf '\n##### %s\n' "$1"; }

sec "C01 inputs: sha256 of the uploaded ZIP and report"
sha256sum $U/9deae3e4-NEXUS-HANDOFF-2026-10-17.zip $U/3c5b490a-NEXUS-HANDOFF-REPORT-2026-10-17.md
sec "C02 package integrity: sha256sum -c SHA256SUMS.txt (summary) and report byte-identity"
( cd $H && sha256sum -c SHA256SUMS.txt 2>&1 | awk '{print $NF}' | sort | uniq -c; sha256sum -c SHA256SUMS.txt 2>&1 | grep -vc ': OK' )
cmp $H/NEXUS-HANDOFF-REPORT-2026-10-17.md $U/3c5b490a-NEXUS-HANDOFF-REPORT-2026-10-17.md && echo "report inside ZIP == uploaded report"
sec "C03 restored repository identity (restored COPY, not the live repo)"
cd $R || exit 1
git bundle verify $H/git/nexus-v5-v5.0-polish.bundle 2>&1 | tail -2
echo "branch=$(git branch --show-current) HEAD=$(git rev-parse HEAD) commits=$(git rev-list --count HEAD) tracked=$(git ls-files | wc -l)"
git status --porcelain=v1 -uall
echo "tracked files differing from HEAD: $(git diff --name-only | wc -l)"
sec "C04 B6 pack integrity + dataset categories"
( cd eval/arabic-v1 && sha256sum -c SHA256SUMS.txt 2>&1 )
python3 -I - <<'EOF'
import json,collections
rows=[json.loads(l) for l in open('eval/arabic-v1/dataset.jsonl',encoding='utf-8')]
print('items',len(rows),'categories',len(set(r['category'] for r in rows)),dict(collections.Counter(r['category'] for r in rows)))
EOF
grep -n 'categories\|mutants' eval/arabic-v1/criteria.frozen.md eval/arabic-v1/README.md | cut -c1-230
sec "C05 B6 mutant logs referenced by README: existence"
ls baseline/evidence | grep -i 'release-v1-b6' || echo "no release-v1-b6* in repository baseline/evidence"
ls $H/evidence-external/logs | grep -i 'b6' || echo "no b6 log in handoff evidence-external/logs"
find $H -iname '*b6*' | sed "s#$H/##"
sec "C06 dependency declarations (static)"
grep -n '"tsx"\|"typescript"\|"test"\|"dev"' src-baseline/nexus-backend/package.json
echo "tsx entries in backend package-lock.json: $(grep -c 'node_modules/tsx' src-baseline/nexus-backend/package-lock.json)"
echo "e2e lockfile present?"; ls e2e/package-lock.json 2>&1 | head -1
grep -n 'playwright\|license' e2e/package.json
echo "LICENSE file at repo root?"; ls LICENSE* 2>&1 | head -1
grep -n 'license\|private' frontend/package.json src-baseline/nexus-backend/package.json || true
sec "C07 lockfile-declared licenses (package metadata, NOT a legal review)"
python3 -I - <<'EOF'
import json,collections
for p in ['frontend/package-lock.json','src-baseline/nexus-backend/package-lock.json']:
    d=json.load(open(p))['packages']
    ent={k:v for k,v in d.items() if k}
    c=collections.Counter(str(v.get('license')) for v in ent.values())
    print(p,'entries',len(ent),'all-dev',all(v.get('dev') for v in ent.values()),dict(c))
    print('  MPL-2.0:',sorted(k.split('node_modules/')[-1] for k,v in ent.items() if v.get('license')=='MPL-2.0'))
EOF
sec "C08 regression records (14 scripts) — result lines read from saved logs, NOT re-run"
cat $L/_summary.txt | grep -c '^exit=0'; grep -h 'ALL-DONE' $L/_summary.txt
for f in baseline-flows phase1-security-flows seed-flows slice4-flows slice5-flows slice6-flows slice7-flows slice8-flows slice10-flows ei-ui-flows slice11-flows b1-flows b4fe-flows b4rb-flows; do
  printf '%-22s ' $f; grep -E 'checks passed|VALID [0-9]+/[0-9]+|SUMMARY VALID|VERDICT' $L/$f.log | tail -2 | tr '\n' '|' | cut -c1-200; echo; done
sec "C09 slice 2/3/4 evidence tools — result lines from saved logs"
for f in tool-slice2-probe tool-slice3-analyzer tool-slice4-exec-order tool-slice4-unit-vs-original; do printf '%-34s ' $f; tail -3 $L/$f.log | tr '\n' '|' | cut -c1-200; echo; done
for f in tool-slice4-extract-verify tool-slice4-extract-verify-PRE-B4-711f353; do echo "== $f"; grep -o '^\[FAIL\] P[0-9a-z]*' $L/$f.log | tr '\n' ' '; echo; grep 'EXTRACTION PROOF' $L/$f.log; done
sec "C10 which frontend paths each commit changed"
echo "-- 711f353 (frontend/ and src-baseline/ only)"; git show --stat --format= 711f353 | grep -E 'frontend|src-baseline' | cut -c1-110
echo "-- cbdc898 (frontend/ only)"; git show --stat --format= cbdc898 | grep -E 'frontend/' | cut -c1-110
sec "C11 sw.js SHELL list and B1 evidence lines"
sed -n 26,34p frontend/sw.js
grep -h 'B1-VERDICT\|^VALID' baseline/evidence/release-v1-b1-PRE.log baseline/evidence/release-v1-b1-POST.log baseline/evidence/release-v1-b1-after-b4.log
grep -h 'V4a' baseline/evidence/release-v1-b1-POST.log | cut -c1-170
sec "C12 line numbers cited in the CURRENT-STATE block (original file)"
grep -n 'sw\.js' NEXUS-CURRENT-STATE.md | cut -c1-70 | grep -E '^(32|38|41|49|295|297|333):'
grep -n 'UNCOMMITTED' NEXUS-CURRENT-STATE.md | cut -c1-60
grep -n '^## Latest Verified Commit\|^## Working Tree State\|^## Verified Work (slice 2\|^## Next Safe Slice\|^## Remaining Scope' NEXUS-CURRENT-STATE.md
wc -l NEXUS-CURRENT-STATE.md
sec "C13 absence of B2/B3/B5 artifacts in the repository"
grep -rIl -E 'release-v1-b[235]' baseline docs e2e 2>/dev/null | head -3; ls baseline/evidence | grep -E 'release-v1-b[235]' || echo "no release-v1-b2/b3/b5 file in baseline/evidence"
git log --format='%h %s' | grep -iE 'B[235]\b' || echo "no commit subject mentions B2/B3/B5"
sec "C14 E-1 documentation (CP-14 §E-1) and probe files"
sed -n 60,66p docs/checkpoints/CP-14.md | cut -c1-260
ls baseline/evidence | grep seedflow
sec "C15 D5 mentions in repository documents"
grep -rn 'D5' --include=*.md . | grep -v node_modules | cut -c1-140 | grep -v 'ADR/000'
sec "C16 B4 limits cited: superseded-test record"
cat baseline/evidence/release-v1-b4-superseded-tests.md | cut -c1-240
echo; echo "END readonly-checks"
