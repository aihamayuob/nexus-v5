#!/usr/bin/env bash
# CP-20 preparation — SCOPE VERIFICATION (documentation-only proof). Read-only except stdout.
# Compares the restored repo copy and the extracted handoff package against the baseline fingerprints taken BEFORE any work.
S=/tmp/claude-0/-home-claude/bfd15cfd-5e21-5f58-adc1-6afcec4bbcd8/scratchpad
P=$S/cp20/NEXUS-CP20-PREP-2026-10-17
H=$S/handoff/NEXUS-HANDOFF-2026-10-17; R=$S/handoff/restored; E=$P/evidence
mkdir -p $S/cp20/tmpwork; pass=0; fail=0
ok(){ if [ "$1" = 0 ]; then echo "[PASS] $2"; pass=$((pass+1)); else echo "[FAIL] $2"; fail=$((fail+1)); fi; }
sec(){ printf '\n##### %s\n' "$1"; }

sec "S1 restored worktree: every file byte-identical to the pre-work baseline (861 files incl. the 7 B6 files)"
( cd $R && find . -path ./.git -prune -o -type f -print0 | sort -z | xargs -0 sha256sum ) > $S/cp20/tmpwork/after-restored.sha256 2>/dev/null || true
cmp -s $S/cp20/tmpwork/after-restored.sha256 $E/baseline-restored-worktree.sha256; ok $? "restored worktree digest == baseline ($(wc -l < $E/baseline-restored-worktree.sha256) files)"
sec "S2 extracted handoff package unchanged"
( cd $H && find . -type f -print0 | sort -z | xargs -0 sha256sum ) > $S/cp20/tmpwork/after-handoff.sha256
cmp -s $S/cp20/tmpwork/after-handoff.sha256 $E/baseline-handoff-extract.sha256; ok $? "handoff extract digest == baseline ($(wc -l < $E/baseline-handoff-extract.sha256) files)"
( cd $H && sha256sum -c SHA256SUMS.txt >/dev/null 2>&1 ); ok $? "handoff SHA256SUMS.txt still verifies (944 files)"
sec "S3 git state of the restored copy unchanged: no new commit, no ref moved, index untouched"
cd $R
[ "$(git rev-parse HEAD)" = cbdc898a3ba605211d9791979a6415f314ba1c8f ]; ok $? "HEAD == cbdc898a3ba605211d9791979a6415f314ba1c8f"
[ "$(git rev-list --count HEAD)" = 23 ]; ok $? "commit count == 23"
git for-each-ref --format='%(objectname) %(refname)' > $S/cp20/tmpwork/after-refs.txt
diff -q <(sed -n '/^all refs:/,/^--- git status/p' $E/baseline-git-state.txt | grep -E '^[0-9a-f]{40} ') $S/cp20/tmpwork/after-refs.txt >/dev/null; ok $? "refs identical to baseline"
[ "$(git ls-files -s | sha256sum | awk '{print $1}')" = "$(grep tracked-index-digest $E/baseline-git-state.txt | awk '{print $2}')" ]; ok $? "tracked index digest identical"
[ "$(git status --porcelain=v1 -uall | grep -vc '^?? eval/arabic-v1/')" = 0 ] && [ "$(git status --porcelain=v1 -uall | wc -l)" = 7 ]; ok $? "status: exactly the 7 untracked eval/arabic-v1/* files, nothing else"
[ "$(git stash list | wc -l)" = 0 ]; ok $? "no stash"
sec "S4 B6 frozen pack untouched"
( cd eval/arabic-v1 && sha256sum -c SHA256SUMS.txt >/dev/null 2>&1 ); ok $? "eval/arabic-v1 sha256sum -c"
for f in README.md SHA256SUMS.txt build_dataset.py criteria.frozen.md dataset.jsonl judge-prompt.md score.mjs; do
  grep -q " ./eval/arabic-v1/$f\$" $E/baseline-restored-worktree.sha256 && grep " ./eval/arabic-v1/$f\$" $S/cp20/tmpwork/after-restored.sha256 | cmp -s - <(grep " ./eval/arabic-v1/$f\$" $E/baseline-restored-worktree.sha256); ok $? "B6 file unchanged: $f"; done
sec "S5 what the proposal consists of (file types) — documentation only"
cd $P
find proposed reports -type f | sort | sed "s#^#  #"
bad=$(find proposed reports -type f ! \( -name '*.md' -o -name '*.patch' -o -name '*.proposed' \) | wc -l); [ "$bad" = 0 ]; ok $? "proposed/ and reports/ contain only .md / .patch / .proposed files"
bad=$(find proposed -type f \( -name '*.mjs' -o -name '*.js' -o -name '*.ts' -o -name '*.json' -o -name '*.html' -o -name '*.sh' -o -name '*.py' \) | wc -l); [ "$bad" = 0 ]; ok $? "no code/config/test file in proposed/"
sec "S6 patches: touch exactly 3 existing docs, add lines only, apply cleanly (git apply --check, writes nothing)"
touched=$(grep -h '^+++ ' proposed/patches/*.patch | sed 's#^+++ b/##' | sort | tr '\n' ' ')
[ "$touched" = "ADR/005-global-accessor-state-ownership.md NEXUS-CURRENT-STATE.md docs/checkpoints/CP-18.md " ]; ok $? "patched paths == {NEXUS-CURRENT-STATE.md, ADR/005-…md, docs/checkpoints/CP-18.md}"
for p in proposed/patches/*.patch; do
  rem=$(grep -c '^-[^-]' $p); add=$(grep -c '^+[^+]' $p); [ "$rem" = 0 ]; ok $? "$(basename $p): removed lines=$rem added lines=$add"
  git -C $R apply --check $P/$p >/dev/null 2>&1; ok $? "$(basename $p): git apply --check on the restored repo"
done
sec "S7 forbidden content in ADDED text"
cat <(grep -h '^+[^+]' proposed/patches/*.patch) proposed/docs/checkpoints/CP-20.md proposed/ADR/*.md proposed/docs/errata/*.md proposed/TEST-EVIDENCE-INDEX.addendum.md reports/*.md > $S/cp20/tmpwork/added-text.txt
grep -nw 'DONE' $S/cp20/tmpwork/added-text.txt >/dev/null; [ $? = 1 ]; ok $? "the word DONE does not occur in any added text"
grep -nE 'sk-[A-Za-z0-9]{10,}|AKIA[0-9A-Z]{12,}|BEGIN [A-Z ]*PRIVATE KEY|Bearer [A-Za-z0-9._-]{12,}' $S/cp20/tmpwork/added-text.txt >/dev/null; [ $? = 1 ]; ok $? "no credential-like token in added text"
for f in proposed/docs/checkpoints/CP-20.md proposed/ADR/006-D5-contextfabric-nexuscontext-boundary.DRAFT.md proposed/docs/errata/B6-arabic-v1-ERRATA-2026-10-17.md; do grep -qE 'PROPOSED|DRAFT' $f; ok $? "marked PROPOSED/DRAFT: $f"; done
grep -c 'PROPOSED TEXT — not applied' proposed/files-full/NEXUS-CURRENT-STATE.md.proposed | grep -q '^1$'; ok $? "CURRENT-STATE block carries the 'PROPOSED TEXT — not applied' banner"
sec "S8 honesty markers"
grep -q 'لم يُعَد تشغيل أي اختبار' proposed/docs/checkpoints/CP-20.md; ok $? "CP-20 states no test was re-run"
grep -qi 'not available' proposed/ADR/006-D5-contextfabric-nexuscontext-boundary.DRAFT.md; ok $? "ADR-006 draft states the literal D5 text is NOT available"
grep -q 'DATA NOT EXECUTED' proposed/files-full/NEXUS-CURRENT-STATE.md.proposed; ok $? "B6/B3 'PENDING — DATA NOT EXECUTED' present in the proposed state"
echo; echo "SUMMARY pass=$pass fail=$fail"
[ $fail = 0 ]
