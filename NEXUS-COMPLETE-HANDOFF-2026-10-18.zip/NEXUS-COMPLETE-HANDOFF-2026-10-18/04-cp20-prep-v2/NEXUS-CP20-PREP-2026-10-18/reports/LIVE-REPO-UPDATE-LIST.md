# قائمة الملفات التي ينبغي تحديثها لاحقًا على المستودع الحي (النسخة 2، 2026-10-18)

**لا شيء من هذا طُبّق.** كل بند يحتاج موافقتك الصريحة. التطبيق يتم على المستودع الحي وبواسطتك أو بتعليمات منك، لا على النسخة المستعادة. مسارات الحزمة نسبية إلى جذر هذه الحزمة؛ مسارات الوجهة نسبية إلى جذر المستودع.

## شروط مسبقة (تُفحَص على المستودع الحي قبل أي تطبيق)
1. `git branch --show-current` = `v5.0-polish`؛ `git rev-parse HEAD` = `cbdc898a3ba605211d9791979a6415f314ba1c8f` (وإن اختلف: أوقف وأعِد توليد الرقع).
2. `git status --porcelain=v1 -uall` لا يُظهر غير ملفات `eval/arabic-v1/*` السبعة (أو يكون فارغًا إن حُميت بـcommit سابق).
3. تطابق أصول الرقع مع الملفات الحية: `sha256sum NEXUS-CURRENT-STATE.md ADR/005-global-accessor-state-ownership.md docs/checkpoints/CP-18.md` يطابق بصمات `evidence/baseline-restored-worktree.sha256` لهذه الملفات الثلاثة.
4. `git apply --check` ناجح لكل رقعة (لا يكتب شيئًا).

## الملفات
| # | الوجهة في المستودع | الإجراء | مصدر في هذه الحزمة | ملاحظات |
|---|---|---|---|---|
| 1 | `NEXUS-CURRENT-STATE.md` | إدراج كتلة (+59 سطرًا شاملة الفارغ، 0 محذوف) | `proposed/patches/NEXUS-CURRENT-STATE.md.patch` (أو الملف الكامل `proposed/files-full/NEXUS-CURRENT-STATE.md.proposed`) | يغيّر ترقيم الأسطر؛ قائمة «Superseded» تشير إلى أرقام الملف قبل الإدراج |
| 2 | `ADR/005-global-accessor-state-ownership.md` | إلحاق erratum (+10) | `proposed/patches/ADR_005-global-accessor-state-ownership.md.patch` | لا تغيير في Status/Decision/R1–R5 |
| 3 | `docs/checkpoints/CP-18.md` | إلحاق §9 (+10) | `proposed/patches/docs_checkpoints_CP-18.md.patch` | السطر 4 وR1 في §6 يبقيان كما كُتبا |
| 4 | `docs/checkpoints/CP-20.md` | ملف جديد | `proposed/docs/checkpoints/CP-20.md` | يحتاج مراجعتك قبل النسخ |
| 5 | `docs/errata/B6-arabic-v1-ERRATA-2026-10-17.md` | ملف جديد (المجلد `docs/errata/` غير موجود حاليًا) | `proposed/docs/errata/B6-arabic-v1-ERRATA-2026-10-17.md` | خارج `eval/arabic-v1/` عمدًا كي يبقى `SHA256SUMS.txt` سليمًا |
| 6 | `ADR/006-D5-contextfabric-nexuscontext-boundary.md` | ملف جديد بحالة **PROPOSED** (يُنسخ من `…PROPOSED.md`)؛ لا يُعدّ قرارًا معتمدًا قبل موافقتك الصريحة | `proposed/ADR/006-D5-contextfabric-nexuscontext-boundary.PROPOSED.md` | إعادة بناء توثيقية لا نص تاريخي؛ الرقم 006 مقترح |
| 7 | `TEST-EVIDENCE-INDEX.md` (داخل حزمة التسليم القادمة، لا المستودع) | إلحاق القسم H | `proposed/TEST-EVIDENCE-INDEX.addendum.md` | كل صف مسند إلى قسم في `evidence/readonly-checks.log` |
| 8 | مرجع مشروع Claude (`NEXUS-CLAUDE-PROJECT-INSTRUCTIONS-REFERENCE-2026-10-15.md`) | تحديث HEAD (`80c558a` ← الحالي) وحالة `sw.js` | — (لا مسودة في هذه الحزمة) | **خارج المستودع**، بموافقتك فقط، بعد تطبيق 1–6؛ طلبتَ ألا أحدّثه الآن |

## ترتيب مقترح عند التطبيق
(شريحة منفصلة، بعد حماية حزمة B6 بـcommit إن وافقتَ) 1 → 2 → 3 → 4 → 5 → 6 ثم commit واحد للوثائق فقط، ثم تحقق: `git diff --stat HEAD~1` يضم `*.md` فقط، و`git status` نظيف، و`sha256sum -c eval/arabic-v1/SHA256SUMS.txt` سليم. أمر الـcommit ورسالته وملحقاته يقرّرها المالك؛ لم أُنشئ أي commit.

## ما لا يجوز لمسه في هذا التطبيق
ملفات الإنتاج والاختبارات و`package*.json` و`eval/arabic-v1/*` و`baseline/evidence/*` وأي ملف مجمّد وأي ADR/CP قائم عدا الإلحاقين الموصوفين.
