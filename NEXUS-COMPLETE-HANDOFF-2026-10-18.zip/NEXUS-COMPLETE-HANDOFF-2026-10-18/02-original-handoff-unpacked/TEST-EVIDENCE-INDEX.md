# TEST-EVIDENCE-INDEX — NEXUS v5 handoff 2026-10-17

Every number below was read from a log file that is inside this ZIP (path given). Nothing here was re-run for the handoff, except where stated ("re-run at packaging"). A passing test proves only what it exercises; it does not prove the project is bug-free.

Path prefixes: `REPO` = `repo-snapshot/nexus-v5/`, `EXT` = `evidence-external/` (evidence that lived outside the repository in the working session).
Environment of all runs: Node v22.22.0, npm 10.9.4, Chromium 141.0.7390.37 headless (Playwright 1.56.1), Linux container. Chromium only — Firefox/Safari/real devices were never tested.

## A. Regression of 14 E2E scripts on a CLEAN clone of B4 commit `cbdc898`
Run window 2026-10-17 04:56:55 → 05:00:06 (+03:00). Runner summary: `EXT/logs/regress/_summary.txt` — all 14 scripts `exit=0`, then `ALL-DONE`.

| # | Script (log in `EXT/logs/regress/`) | Result line read from the log | Status |
|---|---|---|---|
| 1 | baseline-flows | 12/12 checks passed | VERIFIED (this clone, Chromium 141) |
| 2 | phase1-security-flows | 16/16 checks passed | VERIFIED |
| 3 | seed-flows | 16/16 checks passed | VERIFIED |
| 4 | slice4-flows | 21/21 checks passed | VERIFIED |
| 5 | slice5-flows | 27/27 validity checks passed; `I1-VERDICT = SURVIVES` (the offline-boot activityLog entry now survives; this script was the evidence test for the historical loss, re-run on the fixed tree) | VERIFIED |
| 6 | slice6-flows | VALID 12/12, PRES 12/12, PS 11/11; `S6-VERDICT = ACCEPTED` | VERIFIED |
| 7 | slice7-flows | 40/40 validity checks passed; `S7-VERDICT = NOT-STUCK` (the `isSendingMessage` defect confirmed in slice 7 is fixed by slice 8) | VERIFIED |
| 8 | slice8-flows | 79/79 (VALID 44/44, PRES 12/12, PS 23/23); `S8-VERDICT = ACCEPTED` | VERIFIED |
| 9 | slice10-flows | 28/28 (VALID 9/9, PRES 12/12, PS 7/7); `S10-VERDICT = ACCEPTED` | VERIFIED |
| 10 | ei-ui-flows | 26/26 (VALID 4/4, PRES 6/6, PS 16/16); `EI-UI-VERDICT = ACCEPTED` | VERIFIED |
| 11 | slice11-flows | VALID 19/19, PRES 42/42 (=61/61), pageErrors=0; `S11-VERDICT = ACCEPTED` | VERIFIED |
| 12 | b1-flows | VALID 6/6, PRES 1/1, PS 11/11; `B1-VERDICT = ACCEPTED` | VERIFIED (Chromium headless only) |
| 13 | b4fe-flows | VALID 9/9, PS 20/20; `B4FE-VERDICT = ACCEPTED` | VERIFIED (Chromium headless only) |
| 14 | b4rb-flows | VALID 2/2, PS 7/7; `B4RB-VERDICT = ACCEPTED` | VERIFIED (auth path only) |

Reading: no regression was detected by these 14 scripts on that clone. The user-supplied figures (Baseline 12/12, Security 16/16, Slice 8 79/79, Slice 11 61/61) match the logs exactly. Result JSONs: `EXT/logs/regress/{b1,b4fe,b4rb,ei,s5,s6,s7,s8,s10,s11}.json`.

## B. Unit / backend suites (run on the working tree during B4, before commit `cbdc898`; `src` unchanged afterwards)
| Suite | Result | Evidence |
|---|---|---|
| Backend `node --test` (tsx) | **502/502 pass, 0 fail** | `REPO/baseline/evidence/release-v1-b4-be-POST-full.log` |
| Backend PRE-B4 (new guard test with the guard NOT wired) | 6/9 pass, 3 fail — expected REJECTED | `…release-v1-b4-be-PRE.log` |
| Backend PRE-B4 (guard module present, not wired) | 16/21 pass, 5 fail — expected REJECTED | `…release-v1-b4-be-PRE-guard-module-only-unwired.log` |
| Backend new tests only (POST) | 36/36 pass, 0 fail | `…release-v1-b4-be-POST-new.log` |
| Backend `tsc` build | exit 0 (4-line log) | `…release-v1-b4-be-build.log` |
| Frontend Vitest (POST, after openly superseding one row) | **186/186 pass, 7 files** | `…release-v1-b4-fe-vitest-POST.log` |
| Frontend Vitest (before the superseded row was updated) | 1 failed / 186 passed (187) — recorded, not hidden | `…release-v1-b4-fe-vitest-POST-before-supersede.log` |
| Superseded test, with justification | 1 table row | `…release-v1-b4-superseded-tests.md` |

Limit: these two suites were NOT re-run on the clean clone for the handoff (the task forbade re-running the full suite). They were run on the working tree whose `src` equals the committed `cbdc898` `src`; "unchanged after the run" is stated from the session record, not re-proven byte-for-byte here (PENDING VERIFICATION).

## C. Release V1 acceptance evidence (PRE must fail, POST must pass)
| Item | PRE | POST | Evidence (under `REPO/baseline/evidence/`) |
|---|---|---|---|
| B1 offline Service Worker | VALID 6/6, PRES 1/1, PS 2/11 → `B1-VERDICT = REJECTED` | PS 11/11 → `ACCEPTED` | `release-v1-b1-PRE.log`, `…b1-POST.log`, `…b1-acceptance-criteria.md`; first PRE run kept as `…PRE-first-run-INVALID-test-defect.log`; re-check after B4: `…b1-after-b4.log` |
| B4 frontend (key memory-only, CSP) | VALID 9/9, PS 5/20 → `REJECTED` | PS 20/20 → `ACCEPTED` (two POST runs: `…POST.log`, `…POST-run2.log`) | `release-v1-b4fe-*.log/json`, `…b4-acceptance-criteria.md` |
| B4 real-backend auth flow | — | VALID 2/2, PS 7/7 → `ACCEPTED` | `release-v1-b4rb-POST*.{log,json}` |
| LAN secure-context probe | non-loopback address: `isSecureContext=false`, no WebCrypto, no SW, boot incomplete | loopback: all true, boot OK | `release-v1-lan-secure-context-probe-{PRE,POST}.log` + `.mjs` (BLOCKED finding, see report §3/§8) |

## D. Evidence tools bound to the monolith bytes (slices 2/3/4) — re-run on the clean B4 clone
| Tool log (`EXT/logs/regress/`) | Result | Status |
|---|---|---|
| tool-slice2-probe | 19/19 | VERIFIED |
| tool-slice3-analyzer | 23/23 | VERIFIED |
| tool-slice4-exec-order | 9/9 | VERIFIED |
| tool-slice4-unit-vs-original | vitest 36 passed (36), exit 0 | VERIFIED |
| tool-slice4-extract-verify (B4 tree) | **11/17** — FAILED: P2b, P5, P6c, P7, P7b, P7c | **PENDING — evidence refresh required** |
| tool-slice4-extract-verify-PRE-B4-711f353 | 14/17 — FAILED: P6c, P7, P7b | pre-existing, time-bound failures |

Interpretation (inference, labelled as such): P2b/P5/P7c pass at `711f353` and fail on the B4 tree, so they are B4-attributable (they compare files byte-for-byte to the slice-4 base and B4 legitimately changed the monolith/`main.js`/settings). P6c/P7/P7b already fail at `711f353` (scope-of-diff checks that cannot hold after later commits). The tool refresh is recorded as pending and was NOT executed in this task.

## E. B6 Arabic evaluation pack (UNCOMMITTED, untracked)
| Check | Result | Evidence |
|---|---|---|
| Scorer self-test on SYNTHETIC responses | **37/37** (re-run at packaging, read-only) | `EXT/b6-self-test-rerun-at-packaging.log` |
| Integrity of the 7 files | `sha256sum -c SHA256SUMS.txt` all OK | `REPO/eval/arabic-v1/SHA256SUMS.txt` |
| Real-model evaluation | **PENDING — DATA NOT EXECUTED** (no provider key, no `responses.jsonl`) | `REPO/eval/arabic-v1/README.md` |

## F. Not run / not available
Live provider chat/stream/cancel/fallback/budget (B3): NOT RUN, no key. Performance baseline (B5): NOT STARTED. Firefox/Safari/real devices: NOT RUN. HTTPS/reverse proxy: NOT RUN. Frontend `vitest --coverage`: NOT RUN. Backend mutation scripts of earlier slices: NOT RUN in this task.

## G. Evidence/log inventory
- Release V1 repo evidence: `REPO/baseline/evidence/release-v1-*` (27 files).
- Working-session logs: `EXT/logs/*` (npm ci, tsc, test, vitest, B1/B4 PRE/POST, LAN probe, regress/).
- Recovery set (how the 6-slice uncommitted work was protected before commit `e17c76d`): `EXT/recovery/` (patch sha256 `a8a53472…6d6a`, untracked lists, `classification.tsv`).
- Honesty log of the session: `EXT/session-honesty-notes.md`.
- Slice evidence of earlier phases: `REPO/baseline/` (563 files under `baseline/`, `evidence/` and the CP-1 … CP-19 evidence copies included).
