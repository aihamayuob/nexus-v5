# running notes (honesty log) — release V1
B1: PRE first run INVALID = test defect (V5 determinism failed + P2b counted my own V3 probe's failed request; random probe path). Fixed before any patch; first-run log kept.
B1: D scenario had an unbounded `serviceWorker.ready` wait (hang on PRE) — bounded; first PRE attempt killed by timeout (no verdict).
B1: PRE (no sw.js) REJECTED: VALID 6/6, PRES 1/1, PS 2/11 (P4/P5 pass vacuously without SW). POST ACCEPTED first run: VALID 6/6, PRES 1/1, PS 11/11. Control (sw.js without state.mjs) fails offline exactly at /modules/state.mjs.
sw.js = AUTHORED from evidence, not the original. cdnjs libs (qrcode, jsQR, pdf.js) not available offline.
