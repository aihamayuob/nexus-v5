# MANIFEST — NEXUS-HANDOFF-2026-10-17.zip

Purpose: everything needed to resume NEXUS v5 in a new session without relying on conversation memory. Documentation/packaging only: no production file, test, evidence tool or build setting was modified; no commit; no push.
Created: 2026-10-17 (Asia/Damascus, +03:00). Integrity: `SHA256SUMS.txt` lists every file in this ZIP except itself; the ZIP's own hash is not (and cannot be) inside it — it is given in the delivery message and in `NEXUS-HANDOFF-ZIP.sha256` next to the ZIP.

## 1. Contents
| Path in ZIP | What it is | Source (all read-only copies) | Files |
|---|---|---|---|
| `NEXUS-HANDOFF-REPORT-2026-10-17.md` | The 10-section engineering handoff report (byte-identical to the standalone copy delivered next to the ZIP) | written for this handoff | 1 |
| `MANIFEST.md` | this file | written for this handoff | 1 |
| `GIT-STATE.txt` | Git state captured with read-only commands: branch, HEAD, log, status incl. untracked, worktrees, stash, remotes | `git` on the working copy | 1 |
| `TEST-EVIDENCE-INDEX.md` | Tests, results, evidence paths (numbers read from the logs below) | written from the logs in this ZIP | 1 |
| `SHA256SUMS.txt` | sha256 of every other file in the ZIP | `sha256sum` | 1 |
| `repo-snapshot/nexus-v5/` | **Working-tree snapshot** of the repository: `git ls-files -c -o --exclude-standard` = 854 tracked + 7 untracked files. NOT `git archive HEAD` (that would drop the 7 untracked B6 files) | `/tmp/claude-0/-home-claude/32993d6c-3079-5c91-b5d3-407731a6cd59/scratchpad/release/nexus-v5` | 861 |
| `git/nexus-v5-v5.0-polish.bundle` | Full git history of branch `v5.0-polish` (23 commits, HEAD `cbdc898`). `git bundle verify` OK; a clone yields HEAD `cbdc898a3ba605211d9791979a6415f314ba1c8f` and 854 tracked files. It also carries a ref `worktrees/b4-pre/HEAD` (`711f353`) — a side-effect ref of the B4 PRE measurement | `git bundle create` (read-only) | 1 |
| `git/git-log-full.txt`, `git/git-state-before-packaging.txt` | Plain-text log and the state captured before packaging began | `git` | 2 |
| `evidence-external/` | Evidence that lived OUTSIDE the repository during the session: PRE/POST logs of B1/B4, build/test logs, the 14-script regression run (`logs/regress/`), the recovery set made before commit `e17c76d` (`recovery/`), the packaging-time B6 self-test re-run, and the session honesty notes | session scratch directories (copied) | 76 |

Inside `repo-snapshot/nexus-v5/` (counts of files): `ADR/` 6 · `docs/` 20 (`DEPLOYMENT-LAN.md` + checkpoints CP-1…CP-19) · `baseline/` 563 (`baseline/evidence/` incl. 27 `release-v1-*` files and per-slice evidence) · `e2e/` 15 · `eval/arabic-v1/` 7 (B6, **untracked**) · `frontend/` 18 · `src-baseline/` 222 (backend source, tests, migrations) · 9 root `*.md` (`NEXUS-CURRENT-STATE.md`, `NEXUS-CONTINUATION.md`, `PLAN.md`, `ROADMAP.md`, `CHANGELOG.md`, `BASELINE.md`, `PHASE1-SECURITY.md`, `PHASE2-MODULARIZE.md`, `FINAL-HTML-INTEGRATION-REPORT.md`).

Key B4/B6 files: B4 backend `src-baseline/nexus-backend/src/config/deploymentGuard.ts`, `…/test/{deploymentGuard,securityHeaders,gatewayKeyLeak}.test.ts`; B4 frontend `frontend/modules/{settings.mjs,gatewayKey.test.mjs}`, `frontend/main.js`, the HTML (CSP meta); B1 `frontend/sw.js`; E2E `e2e/release-v1-*.mjs`; docs `docs/DEPLOYMENT-LAN.md`; evidence `baseline/evidence/release-v1-*`; B6 `eval/arabic-v1/*`.

## 2. Exclusions (and their effect)
| Excluded | Why | Effect on re-running / understanding | How to restore |
|---|---|---|---|
| `.git/` directory | requested; and it holds a registered extra worktree pointing at a scratch path | history would be lost | replaced by `git/nexus-v5-v5.0-polish.bundle` (**disclosed deviation**: there is no remote, so excluding history entirely would have made it unrecoverable) |
| `frontend/node_modules`, `e2e/node_modules`, `src-baseline/nexus-backend/node_modules` | build artifacts | tests cannot run until installed | frontend: `npm ci`; backend: `npm ci && npm run build`; e2e (no lockfile): `npm install --no-package-lock --no-save playwright@1.56.1`. Note: backend `npm test` uses `tsx`, which is NOT declared in the backend `package.json`/lockfile (see report §7) |
| `src-baseline/nexus-backend/dist/` | build artifact | the backend must be built before E2E that start it | `npm run build` |
| `src-baseline/nexus-backend/data/` (ignored test SQLite DB, ~389 KB) | runtime data, git-ignored | none; recreated at start | — |
| Chromium / Playwright browsers | environment-provided (`/opt/pw-browsers`) | E2E needs Chromium 141 (or accept different results) | provided by environment or install separately |
| `.env` files / secrets | requirement | none; only `.env.example` (empty `NEXUS_GATEWAY_KEYS=`) is included | create locally; never commit |
| Previous handoff packages (e.g. `NEXUS-CP19-HANDOFF-2026-10-15.zip`) | not part of this task; preserved untouched where they are | none | still available from the earlier delivery |
| Regress clones / scratch worktrees (`scratchpad/work/*`, `scratchpad/pkg/*`) | duplicates of repository content | none | reproducible from the bundle |

## 3. Secret scan (staged files, before zipping)
No `.env` file; no token patterns; `NEXUS_*KEY` matches are empty assignments or the known FAKE constants used in tests and their logs. A second scan on the unzipped result is reported in the delivery message.

## 4. Restore procedure (tested in an isolated folder at packaging: HEAD `cbdc898…`, 0 modified, 7 untracked)
```
unzip NEXUS-HANDOFF-2026-10-17.zip && cd NEXUS-HANDOFF-2026-10-17
sha256sum -c SHA256SUMS.txt
git clone git/nexus-v5-v5.0-polish.bundle nexus-v5
cp -a repo-snapshot/nexus-v5/. nexus-v5/
cd nexus-v5 && git status --porcelain=v1 -uall    # expect exactly the 7 ?? eval/arabic-v1/* lines
```
