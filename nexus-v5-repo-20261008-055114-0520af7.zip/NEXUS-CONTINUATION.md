# NEXUS-CONTINUATION

How to resume. Repository state beats this file and beats chat memory.

## 1. Reconstruct first (do not skip)
1. Unpack the latest ZIP; `git branch --show-current` (expect `v5.0-polish`),
   `git status --short`, `git log --oneline | head`.
2. Read `NEXUS-CURRENT-STATE.md`, then `docs/checkpoints/CP-8.md` (latest; slice 2,
   evidence-only), then `docs/checkpoints/CP-7.md` (slice 1), then
   `PHASE2-MODULARIZE.md` (section "Boundary 5 — core, slice 1"; its "DONE" wording for
   boundaries 1–4 is historical — see the Terminology note in CURRENT-STATE).
3. Read ADR-002 (bridge pattern) and ADR-003 (storage boundary; see the
   documentation finding in CURRENT-STATE / CP-8 before relying on its wording).
   Verify the chain: `git rev-parse HEAD~1` should be `4c3e169`.

## 2. Environment (this repo's tests need it)
- `cd frontend && npm ci && npx vitest run --coverage`
- Backend: `cd src-baseline/nexus-backend && npm ci && npm run build && npm test`
- E2E: scripts hard-code `/home/claude/nexus-v5/`, so create a symlink to the
  unpacked repo there (outside the repo). Chromium is provided by
  `PLAYWRIGHT_BROWSERS_PATH=/opt/pw-browsers`; verify with a real
  `chromium.launch()`, do not infer availability from `~/.cache`.
- `cd e2e && npm ci && node baseline-flows.mjs && node phase1-security-flows.mjs && node phase2-core-seed-flows.mjs`
- Slice 2 probe (self-locating, no hard-coded path):
  `PLAYWRIGHT_BROWSERS_PATH=/opt/pw-browsers node baseline/evidence/phase2-core-slice2-adr003-probe.mjs`
  (expects 19/19; it rewrites `…-probe-results.json` and the generated module — if you
  re-run it, `git diff` shows only timestamps/scratch path changes in the JSON).
- Expected on this commit: Vitest 132, E2E 12 / 16 / 16, backend 406, slice 2 probe 19 —
  as numbers to RE-MEASURE, not to trust.

## 3. Rules that bit us this session
- A classic-script `let`/`const` is not a `window` property; bridge pattern =
  `main.js` import + `window.x = x`, assigned BEFORE the startup calls.
- Extraction scripts must abort if the monolith differs from HEAD or the target
  block is not found exactly once.
- Prove tests can fail (mutation) and restore byte-identical (sha256).
- E2E scripts must report failures, not crash: a crash is detection but not evidence.
- `autoInitApp` swallows decrypt errors: assert restored DATA, not absence of errors.
- Slice 2 finding (Chromium 141): module code can read/write classic top-level `let`/`var`
  by bare name (const: read OK, write TypeError; let/const not on `window`). This is a
  FINDING, not a design authorization: ADR-003 and the bridge pattern are unchanged until
  a separate explicit decision. Evidence-probe helpers must use collision-proof names
  (a helper called `R` or `p` could shadow a monolith global and corrupt a read).

## 4. Next slice
Core slice 3 (read-only): §22 ownership / initialization / mutation map of
`PERSISTABLE_STATE` and the 16 state variables, ending in a shortlist of the smallest
candidate seam(s). No code change, no extraction, no ADR-003 edit. Stop after documenting.

## 5. Exact Arabic command for the next conversation
```
NEXUS v5.0 — Continue من الحالة الموثقة الحالية في المستودع (NEXUS-CURRENT-STATE.md و CP-8)، ولا تعِد ما تم ولا تعيد التخطيط.
أولاً: أعد بناء الحالة من المستودع (Git، الشجرة، الـ HEAD، الوثائق) وأعد قياس الاختبارات ولا تثق بالأرقام المكتوبة.
ثم نفّذ فقط: Boundary 5 — Core — Slice 3: خريطة قراءة فقط (§22) لملكية الحالة وترتيب التهيئة والكتابة لـ PERSISTABLE_STATE والمتغيرات الـ16 (المالك، المُهيِّئ، الكاتبون، persistState، autoInitApp، المعتمدون، inline handlers، الحاجة لـ window bridge)، وتنتهي بقائمة مرشّحة لأصغر seam آمن.
دليل/توثيق فقط: بدون أي تعديل على كود الإنتاج، وبدون استخراج، وبدون تعديل ADR-003، وبدون تغيير نمط الـ bridge.
سجّل النتيجة (CP-9 + تحديث CURRENT-STATE/CONTINUATION/CHANGELOG)، ثم commit وأنشئ ZIP بعد الـ commit، وتحقق أن الشجرة نظيفة والـ HEAD المُوثَّق يطابق الـ commit، واكتب الخلاصة بالعربية (STATUS / COMMIT / TESTS / E2E / CHECKPOINT / ما بقي / الشريحة التالية)، ثم STOP.
```
