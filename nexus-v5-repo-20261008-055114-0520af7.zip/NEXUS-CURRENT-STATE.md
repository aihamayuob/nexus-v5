# NEXUS-CURRENT-STATE

> Dynamic state document. Written ONLY from evidence gathered in the session
> that produced it (2026-10-07). Not a plan. If the repository disagrees with
> this file, the repository wins. Created in the core slice 1 commit (`4c3e169`);
> updated by the core slice 2 commit.

## Current Phase
Phase 2 — Modularization (`/nexus-modularize`): **PARTIAL**
(branch `v5.0-polish`).

## Current Boundary
Boundary 5/9 "core": **PARTIAL** (slice 1 VERIFIED; slice 2 VERIFIED as an evidence-only
slice; everything else in core PENDING).
Boundaries 1–4 (security, storage, utilities, settings): VERIFIED (earlier work,
historical evidence; re-confirmed only indirectly by this session's regression runs).
Boundaries 6–9 (agents, modes, ops-center, workspace) and the UI-remainder: PENDING.

## Current TARGET SLICE
Core slice 2 — evidence-only browser-level (real Chromium) probe of module access to
classic-script top-level `let`/`const`/`var` by bare name, plus a strictly read-only
check against the real monolith: **VERIFIED**. No production code changed. Stopped at
its stop point.
Previous: Core slice 1 — move `encryptState` / `decryptState` into
`modules/security.mjs`, bridge on `window` in `main.js`: **VERIFIED** (commit `4c3e169`).

## Latest Verified Commit
Parent (base) of this slice: `4c3e169` (core slice 1, VERIFIED). The slice 2 commit is the
one that carries this version of this file (HEAD of `v5.0-polish` at ZIP time; a file
cannot contain its own hash — read it with `git log -1`; `git rev-parse HEAD~1` must be
`4c3e169`).

## Working Tree State
Clean immediately after the slice commit (verified with `git status --short`
after committing). Environment note: the E2E scripts hard-code
`/home/claude/nexus-v5/`; this session ran them from a COPY of the unpacked repo at
that path (outside the original extraction). The slice 2 runner resolves its paths
relative to its own location and needs no hard-coded path.

## Verified Work (slice 2 — this commit)
- Real Chromium **141.0.7390.37**. Synthetic classic+module page (layout mirrors the
  monolith), served from a scratch temp dir. Module code reads/writes by bare name:
  - **let**: read OK, write OK (seen by classic), NOT on `window`.
  - **var**: read OK, write OK (seen by classic and `window`), on `window`.
  - **const**: read OK, write throws **TypeError** (value unchanged), NOT on `window`.
  - Live binding both directions (classic write → module read). Module-declared
    `let`/`var` are invisible to the classic script (reverse isolation).
  - Negative controls: undeclared read and write → **ReferenceError**; `typeof` → `"undefined"`.
  - Modules-only control (module B reading module A's `let`/`const`/`var`) → ReferenceError
    ×3, showing the probe distinguishes shared-global from private scope.
- Read-only check on the REAL monolith (no assignments, no calls): 56/56 `let`,
  57/57 `const`, 370/370 functions readable by bare name from an injected module;
  0 mismatches vs. classic global scope; `let`/`const` on `window`: 0; functions: 370/370.
  Integrity: 13 frontend files SHA-256 identical before/after, `git status` on
  production paths empty, app-state fingerprint unchanged.
- Acceptance: **19/19** probe checks; two runs gave identical findings.
- Not exercised by design: writes on the real monolith; `var` on the real monolith
  (it has no column-0 top-level `var`).
- Interpretation and limits: `docs/checkpoints/CP-8.md`. The positive result does NOT
  authorize editing ADR-003, changing the bridge pattern, or changing production code.

## Verified Work (slice 1 — earlier commit `4c3e169`)
- Both functions moved byte-for-byte (only `export` added), proven by the
  extraction script (`byte-identical-after-export-strip: true`).
- Behavior equivalence with the ORIGINAL implementation: byte-identical
  envelopes for the same key+IV, cross-decrypt both directions, identical error
  classes, golden vector generated from the original code.
- Module/bridge integration in real Chromium, including the real
  persist → reload → restore pipeline through `autoInitApp`.
- Execution-order safety re-derived from the AST (no new ordering assumption).

## Current Test Evidence (all fresh, final tree)
- Slice 2 probe: `baseline/evidence/phase2-core-slice2-adr003-probe.mjs` → **19/19**
  (log: `…-probe.log`; raw JSON: `…-probe-results.json`).
- Slice 2 regression on the final tree (production paths show NO diff vs `4c3e169`, proven
  with `git diff --stat HEAD`): Vitest **132/132** (4 files; `security.mjs` 100% lines,
  100% funcs, 96.87% stmts, 85.71% branches); E2E `baseline-flows` **12/12**,
  `phase1-security-flows` **16/16**, `phase2-core-seed-flows` **16/16** — all re-run
  after the final documentation edits.
- Vitest: **132/132** (security.test.mjs: 35). security.mjs coverage: 100% lines/funcs.
- E2E `phase2-core-seed-flows.mjs`: **16/16** post; **15/16** pre-extraction
  (only the patch-specific `bridge-identity` fails, by design).
- E2E `baseline-flows.mjs`: **12/12**. E2E `phase1-security-flows.mjs`: **16/16**.
- Backend `npm test`: **406/406**; `tsc --noEmit`: no errors printed. Backend
  untouched (run only to confirm no collateral change).
- Fault injection: 5 function mutations (2–6 failing Vitest tests each) and 2
  bridge mutations (11/17 and 13/17 E2E checks failing); all files restored
  byte-identical by sha256 and re-passed.
- Logs: `baseline/evidence/phase2-core-slice1-*`. Details: `docs/checkpoints/CP-7.md`.
- Backend (re-measured earlier in the same slice 2 session, on the identical production
  tree; not re-run after the documentation-only edits, which cannot affect it):
  `tsc --noEmit` exit 0, `npm run build` exit 0, `npm test` **406/406**.

## Unverified Items
- Behavior in Firefox/Safari (Chromium only).
- ADR-003 still reads "cannot close over a `let` declared in a different script's scope".
  Browser-level evidence (slice 2, Chromium 141) does not support that wording for bare-name
  access from module code, but ADR-003 is UNEDITED and the decision to revise it is
  **PENDING** (separate decision). Not tested: moving `PERSISTABLE_STATE` itself, TDZ /
  initialization order in other layouts, closures stored and invoked later from classic,
  writes on the real monolith, Firefox/Safari.
- `NexusContext.buildAgentContext` live-caller status (static scan found no
  caller in the monolith; not investigated further, not reopened).

## Blocked Items
- `sw.js` is not among the provided artifacts: cumulative cache-manifest
  follow-up (5 files: `/main.js`, `/modules/security.mjs`, `/modules/storage.mjs`,
  `/modules/utilities.mjs`, `/modules/settings.mjs`) cannot be applied. This
  slice added no new file. Must be finalized before Phase 2's Exit Gate.

## Known Risks
- **Documentation finding (ADR-003), now with browser-level evidence:** real Chromium 141
  shows module code reading/writing classic top-level `let`/`var` (and reading `const`)
  by bare name, which conflicts with ADR-003's wording. ADR-003 NOT edited; bridge pattern
  NOT changed; nothing was built on the result. Any revision is a separate future decision.
  Chromium is available here (`PLAYWRIGHT_BROWSERS_PATH=/opt/pw-browsers`).
- `autoInitApp` swallows decrypt failures and "starts fresh"; any future change
  to the crypto seam can silently drop user data. The new E2E guards this.
- Remaining core is state-heavy (`PERSISTABLE_STATE`, 16 variables, `selectedAgentIds`
  has 15 write sites in 8 functions).

## Terminology note (historical "DONE")
`PHASE2-MODULARIZE.md` uses the word "DONE" for boundaries 1–4. That is **historical
wording from before the current six-state status vocabulary** and has intentionally NOT
been rewritten. The authoritative current status model is only:
`VERIFIED / PARTIAL / PENDING / BLOCKED / FAILED / UNVERIFIED`. Read the historical
"DONE" for boundaries 1–4 as the historical claim that they were VERIFIED at the time
(not freshly re-measured here, apart from indirect regression coverage).

## Remaining Scope
Core: `PERSISTABLE_STATE` + 16 state vars, `NexusContext`, `ContextFabric`.
Then agents, modes, ops-center, workspace, UI-remainder; `sw.js`; Phase 2 Exit Gate.

## Next Safe Slice
Core slice 3 — read-only, no production-code change: produce the §22 ownership /
initialization / mutation map for `PERSISTABLE_STATE` and the 16 state variables (owner,
initializer, availability time, writers, `persistState`, `autoInitApp` restore path,
dependents, inline-handler dependence, `window`-bridge need) and a shortlist of the
smallest candidate seam(s). No extraction in that slice. Revising ADR-003 is NOT part of
it; that remains a separate explicit decision.
