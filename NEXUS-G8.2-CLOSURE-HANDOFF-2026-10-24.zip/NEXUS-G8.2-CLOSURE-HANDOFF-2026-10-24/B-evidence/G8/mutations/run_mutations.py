import subprocess, hashlib, shutil, re, sys, os
R='src/tools/registry.ts'
def sh(p): return hashlib.sha256(open(p,'rb').read()).hexdigest()
muts=[
 ('M01 drop unclassified-execute check',R,"    if (tool.execute && !tool.effect) assertValidClassification(name, tool.effectClass);\n",""),
 ('M02 drop effect+execute check',R,"    if (tool.effect && tool.execute) throw","    if (false) throw"),
 ('M03 drop effect+effectClass check',R,"    if (tool.effect && tool.effectClass) throw","    if (false) throw"),
 ('M04 drop freeze of entry',R,"Object.freeze({ ...tool, effectClass:","({ ...tool, effectClass:"),
 ('M05 min length 10 -> 0',R,"MIN_ATTESTATION_CHARS = 10","MIN_ATTESTATION_CHARS = 0"),
 ('M06 drop legacy controls check',R,"if (o.kind === 'legacy_exempt' && text(o.compensatingControls)","if (false && text(o.compensatingControls)"),
 ('M07 code_execution attested read_only','src/tools/builtin/codeExecutionTool.ts',"kind: 'legacy_exempt',","kind: 'read_only',"),
 ('M08 calculate loses classification','src/tools/builtin/calculateTool.ts',"  effectClass: { kind: 'pure',","  _x: { kind: 'pure',"),
 ('M09 nested effectClass not frozen',R,"Object.freeze({ ...tool.effectClass })","({ ...tool.effectClass })"),
 ('M10 unknown kind accepted',R,"if (o.kind !== 'pure' && o.kind !== 'read_only' && o.kind !== 'legacy_exempt') return bad(","if (false) return bad("),
 ('M11 web_fetch attested legacy_exempt w/o pin change','src/tools/builtin/webFetchTool.ts',"kind: 'read_only',","kind: 'legacy_exempt', compensatingControls: 'ضوابط مفترضة للاختبار.',"),
]
res=[]
for name,f,old,new in muts:
    src=open(f,encoding='utf8').read()
    if old not in src: res.append((name,'NOT-APPLIED')); continue
    shutil.copy(f,'../mut/bak'); h=sh(f)
    open(f,'w',encoding='utf8').write(src.replace(old,new,1))
    p=subprocess.run(['npx','tsx','--test','test/toolEffectClassification.test.ts'],capture_output=True,text=True)
    out=p.stdout+p.stderr
    fails=re.findall(r'^not ok \d+ - (G8-\d+)',out,re.M)
    shutil.copy('../mut/bak',f)
    assert sh(f)==h
    res.append((name,'CAUGHT by '+','.join(fails) if fails else 'SURVIVED (exit %d)'%p.returncode))
# M12 rogue registration site
rf='src/rogueRegister.ts'
open(rf,'w').write("export function rogue(reg: { register(t: unknown): void }, t: unknown) { reg.register(t); }\n")
p=subprocess.run(['npx','tsx','--test','test/toolEffectClassification.test.ts'],capture_output=True,text=True)
fails=re.findall(r'^not ok \d+ - (G8-\d+)',p.stdout,re.M); os.remove(rf)
res.append(('M12 rogue .register( site in src/','CAUGHT by '+','.join(fails) if fails else 'SURVIVED'))
for r in res: print(*r,sep=' => ')
