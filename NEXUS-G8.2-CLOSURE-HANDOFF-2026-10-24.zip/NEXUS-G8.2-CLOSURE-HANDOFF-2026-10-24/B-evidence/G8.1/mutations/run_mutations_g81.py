import subprocess, hashlib, shutil, re, os
B='src/tools/bootstrap.ts'
def sh(p): return hashlib.sha256(open(p,'rb').read()).hexdigest()
TESTS=['test/codeExecutionNotRegistered.test.ts','test/toolEffectClassification.test.ts']
def run():
    p=subprocess.run(['npx','tsx','--test']+TESTS,capture_output=True,text=True)
    return re.findall(r'^not ok \d+ - ((?:G8|G81)-\d+)',p.stdout,re.M)
edits=[
 ('N01 bootstrap re-registers code_execution (import + register)',B,
   [("import { calculateTool } from './builtin/calculateTool.js';\n","import { calculateTool } from './builtin/calculateTool.js';\nimport { codeExecutionTool } from './builtin/codeExecutionTool.js';\n"),("  registry.register(calculateTool);\n","  registry.register(calculateTool);\n  registry.register(codeExecutionTool);\n")]),
 ('N02 bootstrap re-registers only when the env flag is on (normal re-enable path)',B,
   [("import { calculateTool } from './builtin/calculateTool.js';\n","import { calculateTool } from './builtin/calculateTool.js';\nimport { codeExecutionTool } from './builtin/codeExecutionTool.js';\nimport { ServerConfig } from '../config/env.js';\n"),("  registry.register(calculateTool);\n","  registry.register(calculateTool);\n  if (ServerConfig.codeExecutionEnabled) registry.register(codeExecutionTool);\n")]),
 ('N03 bootstrap registers an ALIAS copy named run_code',B,
   [("import { calculateTool } from './builtin/calculateTool.js';\n","import { calculateTool } from './builtin/calculateTool.js';\nimport { codeExecutionTool } from './builtin/codeExecutionTool.js';\n"),("  registry.register(calculateTool);\n","  registry.register(calculateTool);\n  registry.register({ ...codeExecutionTool, def: { ...codeExecutionTool.def, name: 'run_code' } });\n")]),
 ('N04 codeExecutionTool loses its effectClass (G8 gate)','src/tools/builtin/codeExecutionTool.ts',
   [("  effectClass: {\n    kind: 'legacy_exempt',","  _effectClass: {\n    kind: 'legacy_exempt',")]),
]
res=[]
for name,f,reps in edits:
    src=open(f,encoding='utf8').read(); ok=all(o in src for o,_ in reps)
    if not ok: res.append((name,'NOT-APPLIED')); continue
    shutil.copy(f,'../mut/bak2'); h=sh(f)
    for o,n in reps: src=src.replace(o,n,1)
    open(f,'w',encoding='utf8').write(src)
    fails=run(); shutil.copy('../mut/bak2',f); assert sh(f)==h
    res.append((name,'CAUGHT by '+','.join(fails) if fails else 'SURVIVED'))
rogues=[
 ('N05 rogue src file imports codeExecutionTool (alias module)','src/rogueAlias.ts',"import { codeExecutionTool } from './tools/builtin/codeExecutionTool.js';\nexport const x = codeExecutionTool;\n"),
 ('N06 rogue src file imports the Sandbox directly (new tool wrapper)','src/rogueSandbox.ts',"import { Sandbox } from './sandbox/sandbox.js';\nexport const y = Sandbox;\n"),
 ('N07 rogue src file calls registry.register','src/rogueRegister.ts',"export function z(reg: { register(t: unknown): void }, t: unknown) { reg.register(t); }\n"),
]
for name,f,body in rogues:
    open(f,'w').write(body); fails=run(); os.remove(f)
    res.append((name,'CAUGHT by '+','.join(fails) if fails else 'SURVIVED'))
for r in res: print(*r,sep=' => ')
