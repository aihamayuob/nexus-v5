import subprocess, hashlib, shutil, re
F='src/agents/agentRegistry.ts'
def sh(p): return hashlib.sha256(open(p,'rb').read()).hexdigest()
T=['test/agentDataNoCodeExecution.test.ts','test/codeExecutionNotRegistered.test.ts']
def run():
    p=subprocess.run(['npx','tsx','--test']+T,capture_output=True,text=True)
    return re.findall(r'^not ok \d+ - ((?:G8\d?|G82|G81)-\d+)',p.stdout,re.M)
SENT="واقتراح طرق عرض البيانات بشكل مفهوم وعملي.',\n    // G8.2"
muts=[
 ('A1 restore the tools declaration on data',"    ['بيانات', 'إحصاء', 'مؤشرات', 'data', 'analytics']\n  ),","    ['بيانات', 'إحصاء', 'مؤشرات', 'data', 'analytics'],\n    { tools: ['code_execution'] }\n  ),"),
 ('A2 restore the prompt promise',"واقتراح طرق عرض البيانات بشكل مفهوم وعملي.',\n    // G8.2","واقتراح طرق عرض البيانات بشكل مفهوم وعملي. عند الحاجة لحساب فعلي معقد يمكنك استخدام أداة code_execution.',\n    // G8.2"),
 ('A3 dangling declaration on another agent',"agent('general', 'المساعد العام', 'أنت مساعد عام ذكي وشامل، تجيب بوضوح ودقة وبأسلوب عملي مباشر، باللغة العربية ما لم يُطلب غير ذلك.', ['عام', 'general'])","agent('general', 'المساعد العام', 'أنت مساعد عام ذكي وشامل، تجيب بوضوح ودقة وبأسلوب عملي مباشر، باللغة العربية ما لم يُطلب غير ذلك.', ['عام', 'general'], { tools: ['nonexistent_tool'] })"),
 ('A4 another agent prompt promises code_execution',"أنت كاتب محتوى محترف","أنت كاتب محتوى محترف يستخدم code_execution"),
 ('A5 data skills changed (selection regression)',"['بيانات', 'إحصاء', 'مؤشرات', 'data', 'analytics']\n  ),","['بيانات']\n  ),"),
 ('A6 data persona prompt gutted',"أنت محلل بيانات خبير في الإحصاء، تفسير الأرقام، بناء المؤشرات (KPIs)، واقتراح طرق عرض البيانات بشكل مفهوم وعملي.'","أنت مساعد.'"),
]
res=[]
for n,o,w in muts:
    s=open(F,encoding='utf8').read()
    if o not in s: res.append((n,'NOT-APPLIED')); continue
    shutil.copy(F,'../mut/bak3'); h=sh(F)
    open(F,'w',encoding='utf8').write(s.replace(o,w,1))
    f=run(); shutil.copy('../mut/bak3',F); assert sh(F)==h
    res.append((n,'CAUGHT by '+','.join(f) if f else 'SURVIVED'))
for r in res: print(*r,sep=' => ')
