// G8.2-closure — checks the COMPILED dist (not the TS source). Usage (from src-baseline/nexus-backend, after `npm run build`):
//   node --experimental-sqlite ../../../B-evidence/G8.2-CLOSURE/evidence/dist-check-g82c.mjs "file://$PWD/dist"
// Fake local provider only (no network, no real provider, no live database): proves what the compiled code SENDS, nothing about a model's behaviour.
import { createServer } from 'node:http';

const base = process.argv[2];
process.env.NEXUS_DB_PATH = ':memory:';
process.env.NEXUS_GATEWAY_KEYS = '';
process.env.NEXUS_LOG_LEVEL = 'error';
process.env.NEXUS_ENABLE_CODE_EXECUTION_TOOL = 'true'; // worst case: operator flag ON

let lastBody = '';
const server = createServer(async (req, res) => {
  if (req.method === 'GET') { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end('{"data":[]}'); return; }
  const chunks = []; for await (const c of req) chunks.push(c);
  lastBody = Buffer.concat(chunks).toString('utf-8');
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ content: [{ type: 'text', text: 'تحليل نصي.' }], stop_reason: 'end_turn', usage: { input_tokens: 1, output_tokens: 1 } }));
});
await new Promise((r) => server.listen(0, '127.0.0.1', r));
process.env.NEXUS_ANTHROPIC_BASE_URL = `http://127.0.0.1:${server.address().port}`;
process.env.NEXUS_ANTHROPIC_API_KEY = 'fake-anthropic-key';

const { openTestDb } = await import(base + '/persistence/db.js');
const { buildRepos, resetReposSingletonForTests, getRepos } = await import(base + '/persistence/repos.js');
const { AgentRegistry } = await import(base + '/agents/agentRegistry.js');
const { runAgentTask } = await import(base + '/agents/agentRunner.js');
const { approveGenomeVersion } = await import(base + '/evolution/agentGenome.js');
const { bootstrapTools } = await import(base + '/tools/bootstrap.js');
const { getToolRegistry } = await import(base + '/tools/registry.js');

resetReposSingletonForTests(buildRepos(openTestDb()));
bootstrapTools();
const gw = { authenticated: true, clientKey: 'key:g82c-dist', projectId: null, userId: null };
const run = async (id) => { lastBody = ''; await runAgentTask(id, { agentId: id, missionId: null, taskNodeId: null, taskDescription: 'مهمة اختبار.', upstreamOutputs: {}, gwCtx: gw }); return JSON.parse(lastBody); };

const data = AgentRegistry.get('data');
const policy = data.fixedPolicy;
const count = (h, n) => h.split(n).length - 1;

const staticBody = await run('data');
const rec = getRepos().agentGenomes.create({ agentId: 'data', parentVersion: null, systemPrompt: 'أنت خبير تحليل إحصائي بديل ومعتمد من المالك، تشرح النتائج بإيجاز.', rationale: 'dist check', securityCheckPassed: true, securityCheckFindings: [], evaluationVerdict: null, evaluationRationale: null, status: 'proposed' });
approveGenomeVersion(rec.id, 'dist-check');
const genomeBody = await run('data');
const generalBody = await run('general');

const others = AgentRegistry.list().filter((a) => a.id !== 'data');
const out = {
  dataHasPolicy: typeof policy === 'string' && policy.length > 40,
  otherAgentsWithPolicy: others.filter((a) => a.fixedPolicy !== undefined).map((a) => a.id),
  staticSystemIsPersonaPlusPolicy: staticBody.system === `${data.systemPrompt}\n\n${policy}`,
  staticPolicyCount: count(staticBody.system, policy),
  genomeReplacedPersona: !genomeBody.system.includes(data.systemPrompt) && genomeBody.system.includes('أنت خبير تحليل إحصائي بديل'),
  genomePolicyCount: count(genomeBody.system, policy),
  genomePolicyIsLast: genomeBody.system.endsWith(policy),
  generalUnchanged: generalBody.system === AgentRegistry.get('general').systemPrompt,
  toolsFieldSent: ['tools' in staticBody, 'tools' in genomeBody],
  anyCodeExecutionInRequests: [lastBody, JSON.stringify(staticBody), JSON.stringify(genomeBody)].some((s) => s.includes('code_execution')),
  anyAgentDeclaresOrMentionsCodeExecution: AgentRegistry.list().some((a) => /code_execution/i.test(a.systemPrompt) || /code_execution/i.test(a.fixedPolicy ?? '') || a.tools.includes('code_execution')),
  dataTools: data.tools,
  registry: getToolRegistry().list().map((t) => t.name),
};
console.log(JSON.stringify(out, null, 1));
server.close();
const ok = out.dataHasPolicy && out.otherAgentsWithPolicy.length === 0 && out.staticSystemIsPersonaPlusPolicy && out.staticPolicyCount === 1 && out.genomeReplacedPersona && out.genomePolicyCount === 1 && out.genomePolicyIsLast && out.generalUnchanged && out.toolsFieldSent.every((x) => x === false) && !out.anyCodeExecutionInRequests && !out.anyAgentDeclaresOrMentionsCodeExecution && out.dataTools.length === 0 && out.registry.join() === 'web_fetch,calculate';
console.log(ok ? 'DIST-CHECK: PASS' : 'DIST-CHECK: FAIL');
process.exit(ok ? 0 : 1);
