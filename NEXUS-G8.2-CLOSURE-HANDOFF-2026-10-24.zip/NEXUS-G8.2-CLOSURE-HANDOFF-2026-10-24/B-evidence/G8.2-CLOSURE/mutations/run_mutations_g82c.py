"""G8.2-closure sabotage runs. Run from src-baseline/nexus-backend:  python3 ../../../B-evidence/G8.2-CLOSURE/mutations/run_mutations_g82c.py
Each mutation edits ONE source file, runs the 3 relevant test files, then restores the file and asserts it is byte-identical (sha256) to before.
A mutation is CAUGHT when the run exits non-zero (the failing test names are printed); NOT-APPLIED means the target text was not found (not counted)."""
import subprocess, hashlib, shutil, re, os, tempfile, sys

RUNNER = 'src/agents/agentRunner.ts'
REG = 'src/agents/agentRegistry.ts'
TESTS = ['test/agentDataFixedPolicy.test.ts', 'test/agentDataNoCodeExecution.test.ts', 'test/codeExecutionNotRegistered.test.ts']
BAK = tempfile.mkdtemp(prefix='g82c-mut-')


def sha(p):
    return hashlib.sha256(open(p, 'rb').read()).hexdigest()


def run():
    p = subprocess.run(['npx', 'tsx', '--test'] + TESTS, capture_output=True, text=True)
    failed = re.findall(r'^not ok \d+ - (.+)$', p.stdout, re.M)
    short = [re.match(r'((?:G8\d?C?|G82C|G82|G81)-\w+)', f).group(1) if re.match(r'((?:G8\d?C?|G82C|G82|G81)-\w+)', f) else f[:40] for f in failed]
    return p.returncode, short


COMPOSE = "const systemPrompt = def.fixedPolicy ? `${basePrompt}\\n\\n${def.fixedPolicy}` : basePrompt;"
POLICY_SENT2 = 'ولا تلمّح إلى أنك تملك أداة أو قدرة لا تُعرض عليك صراحةً في هذه المحادثة.'
SENT1 = 'ما لم يحدث التنفيذ فعلًا في هذه المحادثة وتصلك نتيجته منه.'
DATA_OPTS = "    ['بيانات', 'إحصاء', 'مؤشرات', 'data', 'analytics'],\n    { fixedPolicy: DATA_FIXED_POLICY }\n  ),"

muts = [
    ('M1 policy never composed into the request (system = base prompt only)', RUNNER, COMPOSE, 'const systemPrompt = basePrompt;'),
    ('M2 THE BYPASS: policy protects ONLY the no-genome path (an active genome replaces the whole prompt; no composition afterwards)', RUNNER,
     re.compile(r"const basePrompt = getActiveSystemPrompt\(agentId\) \?\? def\.systemPrompt;.*?const systemPrompt = [^\n]*\n", re.S),
     "const gen = getActiveSystemPrompt(agentId);\n  const systemPrompt = gen ?? (def.fixedPolicy ? `${def.systemPrompt}\\n\\n${def.fixedPolicy}` : def.systemPrompt);\n"),
    ('M3 data policy leaks to EVERY agent', RUNNER, COMPOSE, "const systemPrompt = `${basePrompt}\\n\\n${AgentRegistry.get('data').fixedPolicy}`;"),
    ('M4 policy PREPENDED instead of appended', RUNNER, COMPOSE, 'const systemPrompt = def.fixedPolicy ? `${def.fixedPolicy}\\n\\n${basePrompt}` : basePrompt;'),
    ('M5 policy appended twice', RUNNER, COMPOSE, 'const systemPrompt = def.fixedPolicy ? `${basePrompt}\\n\\n${def.fixedPolicy}\\n\\n${def.fixedPolicy}` : basePrompt;'),
    ('M6 policy text names code_execution (re-announcement)', REG, 'أو استعلامًا فعليًا بأي أداة،', 'أو استعلامًا فعليًا بأي أداة مثل code_execution،'),
    ('M7 data definition loses its fixedPolicy', REG, DATA_OPTS, "    ['بيانات', 'إحصاء', 'مؤشرات', 'data', 'analytics']\n  ),"),
    ('M8 policy weakened: rule about implied capabilities removed', REG, POLICY_SENT2, 'ولا تلمّح.'),
    ('M9 policy weakened: "only if execution really happened" condition removed', REG, SENT1, 'وتصلك نتيجته منه.'),
    ('M10 another agent (general) gets a fixedPolicy', REG, "['عام', 'general'])", "['عام', 'general'], { fixedPolicy: DATA_FIXED_POLICY })"),
    ('M11 data re-declares tools:[code_execution] next to the policy', REG, '{ fixedPolicy: DATA_FIXED_POLICY }', "{ fixedPolicy: DATA_FIXED_POLICY, tools: ['code_execution'] }"),
    ('M12 data skills changed (selection regression)', REG, "['بيانات', 'إحصاء', 'مؤشرات', 'data', 'analytics'],\n    { fixedPolicy", "['بيانات'],\n    { fixedPolicy"),
]

results = []
for name, f, old, new in muts:
    s = open(f, encoding='utf8').read()
    is_re = hasattr(old, 'search')
    if (not old.search(s)) if is_re else (old not in s):
        results.append((name, 'NOT-APPLIED'))
        continue
    bak = os.path.join(BAK, os.path.basename(f))
    shutil.copy(f, bak)
    h = sha(f)
    t = old.sub(lambda m: new, s, count=1) if is_re else s.replace(old, new, 1)
    open(f, 'w', encoding='utf8').write(t)
    try:
        code, failed = run()
    finally:
        shutil.copy(bak, f)
    assert sha(f) == h, 'file not restored byte-identically: ' + f
    results.append((name, ('CAUGHT by ' + ', '.join(failed)) if code != 0 else 'SURVIVED'))

for r in results:
    print(*r, sep=' => ')
caught = sum(1 for _, r in results if r.startswith('CAUGHT'))
applied = sum(1 for _, r in results if r.startswith('CAUGHT') or r == 'SURVIVED')
print(f'SUMMARY caught={caught} applied={applied} survived={applied - caught}')
sys.exit(0 if caught == applied else 1)
