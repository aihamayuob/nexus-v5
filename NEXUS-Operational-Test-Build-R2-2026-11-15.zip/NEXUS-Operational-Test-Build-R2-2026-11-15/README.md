# NEXUS — Operational Test Build R2 (2026-11-15)

Successor of `NEXUS-Operational-Test-Build` (source commit `fba63d5…`, verification logs at `a98f34b`). This is an **archive tree without `.git`**: nothing was committed, tagged, pushed, released or deployed; the live repository is not modified. Delta vs the previous package: provider-timeout fix D-PT-1 (`providers/timeoutFetch.ts`, wired in `providers/index.ts`), real-provider harness, MCP third-party interop script, ADR-007 (PROPOSED), docs/ROADMAP alignment, `verify-all.sh` update.

**Run**: `./run.sh` (or `run.cmd`) → open the printed URL (also `/NEXUS.html`); paste the printed gateway key in Settings. Node >= 22.5. Without provider keys the UI works and model calls return an honest "no provider" error. LAN/loopback HTTP only — not for the internet.

| File/folder | Content |
|---|---|
| `REAL-PROVIDER-VALIDATION-2026-11-15.md` | what was and was not proven against real providers; how to run it with your keys |
| `BUYER-EVIDENCE-AND-IP-FILE-2026-11-15.md` | tests, coverage, real-vs-simulated, capability matrix, IP/license register, limits |
| `OPERATIONAL-BUILD.md`, `IP-LICENSE-SECURITY-DELTA-2026-11-14.md` | run guide / capability matrix / security register (with dated 2026-11-15 additions) |
| `source/` | full tree (no node_modules/dist/DB/secrets): ADR (incl. 007), docs, `ROADMAP.md` (aligned), `NEXUS-CURRENT-STATE.md`, `NEXUS-CONTINUATION.md` (Addendum 21), `CHANGELOG.md`, e2e, scripts |
| `prebuilt/backend-dist.tar.gz` | backend `dist/` built from this source |
| `verification/verify-2026-11-15/` | raw logs of this round (backend 645/645, Vitest 186/186, 17 E2E, 38 scenarios, UI demo, coverage); `real-provider/`, `mcp-interop/` |
| `verification/verify-final2/` | previous round's logs (historical) |
| `screenshots/` | previous round's UI screenshots (UI unchanged in this round; not regenerated) |

All successful model completions in these runs were **simulated**. Real OpenAI/DeepSeek/Gemini/Ollama/LM Studio/Anthropic success paths: UNVERIFIED (BLOCKED here). MCP client, A2A, Universal Connector SDK: PENDING (criteria proposed, not implemented).
