#!/usr/bin/env python3
"""G8.2 Genome Security Gate — mutation runner. Applies ONE textual mutation at a time to the patched tree, runs the gate tests (+fineTuning for M13), records which
tests failed, restores the file and verifies its hash. A mutation is KILLED only if (a) it was actually applied exactly once, (b) the test file still loaded (full test
count), and (c) at least one test failed with ERR_ASSERTION. Anything else is INVALID (never counted as a kill)."""
import hashlib, re, subprocess, sys, json, os
ROOT = sys.argv[1]            # .../nexus-backend
EXPECTED_TESTS = int(sys.argv[2])
def sha(p): return hashlib.sha256(open(p,'rb').read()).hexdigest()
EV='src/evolution/genomeCapabilityCheck.ts'; AG='src/evolution/agentGenome.ts'; FT='src/finetuning/fineTuning.ts'
M = [
 ('M1', 'drop NFKC normalization', EV, ".normalize('NFKC')", ""),
 ('M2', 'drop zero-width stripping', EV, ".replace(/[\\u200b-\\u200f\\u202a-\\u202e\\u2060-\\u2064\\ufeff\\u00ad\\u180e]/g, '')", ""),
 ('M3', 'drop Arabic diacritics/tatweel stripping', EV, ".replace(/[\\u064b-\\u065f\\u0670\\u0640]/g, '')", ""),
 ('M4', 'drop the confusables fold', EV, "CONFUSABLES[ch] ?? ch", "ch"),
 ('M5', 'disable the negation/denial exemption', EV, "if (negated) continue;", "if (false as boolean) continue;"),
 ('M6', 'disable the user-actor / how-to exemption', EV, "!USER_CTX.test(clause) && !HOWTO.test(clause)", "true"),
 ('M7', 'ignore the offered-tools set', EV, "new Set(opts.offeredToolNames.map((n) => n.toLowerCase()))", "new Set<string>()"),
 ('M8', 'propose uses the legacy check only', AG, "const security = checkGenomePromptRisk(candidate, agentId);", "const security = checkGenomeSecurityRisk(candidate);"),
 ('M9', 'propose checks the baseline instead of the candidate', AG, "const security = checkGenomePromptRisk(candidate, agentId);", "const security = checkGenomePromptRisk(baseline, agentId);"),
 ('M10', 'approve skips the re-check', AG, "assertGenomePassesCurrentCheck(record, 'approval');", ""),
 ('M11', 'rollback skips the re-check', AG, "assertGenomePassesCurrentCheck(target, 'rollback');", ""),
 ('M12', 'passed is always true (findings still returned)', EV, "return { passed: list.length === 0, findings: list };", "return { passed: true, findings: list };"),
 ('M13', 'fineTuning switched to the new check (coupling)', FT, "checkGenomeSecurityRisk(examples[i]!.proposalContent)", "checkGenomePromptRisk(examples[i]!.proposalContent, agentId)"),
 ('M14', "drop 'web_fetch' from the static known-tool list", EV, "'web_search', 'web_fetch', ", "'web_search', "),
 ('X15', 'EXTRA: drop the how-to exemption only', EV, "!USER_CTX.test(clause) && !HOWTO.test(clause)", "!USER_CTX.test(clause)"),
 ('X16', "EXTRA: drop the don't-hesitate override", EV, "NEG.test(clause) && !HESITATE.test(clause)", "NEG.test(clause)"),
 ('X17', 'EXTRA: drop the imperative rule', EV, "const imperative = !!lead && objRe.test(lead[1] ?? '');", "const imperative = false;"),
 ('X18', 'EXTRA: disable the web-access layer', EV, "if (!webAllowed && WEB.test(clause) && CLAIM.test(clause))", "if (false as boolean)"),
]
results=[]
for mid, desc, rel, old, new in M:
    path=os.path.join(ROOT,rel); orig=open(path,encoding='utf-8').read(); h0=sha(path)
    n=orig.count(old)
    row={'id':mid,'desc':desc,'file':rel}
    if n!=1:
        row.update(status='INVALID',why=f'pattern found {n} times (need exactly 1)'); results.append(row); print(mid,row['status'],row['why']); continue
    if mid=='M13':  # needs the import swapped too
        mutated=orig.replace(old,new).replace("import { checkGenomeSecurityRisk } from '../evolution/agentGenome.js';","import { checkGenomePromptRisk } from '../evolution/agentGenome.js';")
    else: mutated=orig.replace(old,new)
    try:
        open(path,'w',encoding='utf-8').write(mutated)
        p=subprocess.run(['npx','tsx','--test','test/genomeCapabilityGate.test.ts'],cwd=ROOT,capture_output=True,text=True,timeout=300)
        out=p.stdout+p.stderr
    finally:
        open(path,'w',encoding='utf-8').write(orig)
    h1=sha(path)
    tests=int(re.search(r'^# tests (\d+)',out,re.M).group(1)) if re.search(r'^# tests (\d+)',out,re.M) else 0
    failed=re.findall(r'^not ok \d+ - (.+)$',out,re.M)
    assertion=len(re.findall(r"code: 'ERR_ASSERTION'",out))
    restored=(h0==h1)
    if not restored: status='INVALID'; why='file not restored byte-identically'
    elif tests!=EXPECTED_TESTS: status='INVALID'; why=f'test count {tests} != {EXPECTED_TESTS} (did not load cleanly)'
    elif not failed: status='SURVIVED'; why='no test failed'
    elif assertion==0: status='INVALID'; why='failures were not assertions'
    else: status='KILLED'; why=''
    row.update(status=status,why=why,failed=failed,restored=restored); results.append(row)
    print(mid,status,f'({len(failed)} failing)', '; '.join(f[:60] for f in failed[:4]))
json.dump(results,open(os.path.join(ROOT,'..','mutations-result.json'),'w'),ensure_ascii=False,indent=1)
bad=[r['id'] for r in results if r['status']!='KILLED']
print('SUMMARY: killed',sum(r['status']=='KILLED' for r in results),'of',len(results),'| not killed:',bad)
