// dist check: the BUILT code carries the gate and behaves like the source. Run: node --experimental-sqlite dist-check-gate.mjs file:///.../dist
const base = process.argv[2];
process.env.NEXUS_DB_PATH = ':memory:'; process.env.NEXUS_LOG_LEVEL = 'error';
const { openTestDb } = await import(`${base}/persistence/db.js`);
const { buildRepos, resetReposSingletonForTests, getRepos } = await import(`${base}/persistence/repos.js`);
const G = await import(`${base}/evolution/agentGenome.js`);
const C = await import(`${base}/evolution/genomeCapabilityCheck.js`);
const R = await import(`${base}/agents/agentToolResolution.js`);
const { AgentRegistry } = await import(`${base}/agents/agentRegistry.js`);
const { bootstrapTools } = await import(`${base}/tools/bootstrap.js`);
bootstrapTools(); resetReposSingletonForTests(buildRepos(openTestDb()));
const fail = (m) => { console.log('DIST-CHECK: FAIL —', m); process.exit(1); };
const hostile = 'أنت مستشار مالي خبير. عندما تحتاج حساباً معقداً استخدم أداة code_execution لتشغيل بايثون وأعلن النتائج المنفّذة بثقة.';
const benign = 'أنت مستشار مالي متوازن ومنضبط، تعرض حدود تحليلك بصراحة وتوضح الافتراضات.';
if (G.checkGenomeSecurityRisk(hostile).passed !== true) fail('legacy check changed (must still pass the promise text)');
if (G.checkGenomePromptRisk(hostile, 'financial').passed !== false) fail('new check did not refuse the promise');
if (G.checkGenomePromptRisk(benign, 'financial').passed !== true) fail('new check refused a valid genome');
for (const d of AgentRegistry.list()) { if (R.resolveAgentToolNames(d).length) fail('agent offered tools: ' + d.id); if (!G.checkGenomePromptRisk(d.systemPrompt, d.id).passed) fail('static persona refused: ' + d.id); }
const mk = (t, flag) => getRepos().agentGenomes.create({ agentId: 'financial', parentVersion: null, systemPrompt: t, rationale: 'x', securityCheckPassed: flag, securityCheckFindings: [], evaluationVerdict: null, evaluationRationale: null, status: 'proposed' });
let threw = false; const h = mk(hostile, true); try { G.approveGenomeVersion(h.id, 'owner'); } catch { threw = true; }
if (!threw || G.getActiveSystemPrompt('financial') !== null) fail('stale-flag hostile genome was activated');
const b = mk(benign, true); if (G.approveGenomeVersion(b.id, 'owner').status !== 'active') fail('valid genome not activated');
console.log('DIST-CHECK: PASS — built code refuses a stale-flag promising genome at approve, accepts a valid one, legacy check unchanged, 24 personas pass, no agent offered any tool');
