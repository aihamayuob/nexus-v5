// READ-ONLY audit of stored genomes against the CURRENT check. Usage:
//   node --experimental-sqlite audit-genomes-readonly.mjs file:///ABS/PATH/TO/dist /ABS/PATH/TO/nexus.db
// It opens the database with readOnly:true, never writes, never changes a genome's status. Output: one JSON object per genome + a summary line.
import { DatabaseSync } from 'node:sqlite';
const [base, dbPath] = process.argv.slice(2);
if (!base || !dbPath) { console.error('usage: audit-genomes-readonly.mjs <file:///.../dist> <db path>'); process.exit(2); }
process.env.NEXUS_DB_PATH = ':memory:'; process.env.NEXUS_LOG_LEVEL = 'error'; // importing the build must not touch any real database
const G = await import(`${base}/evolution/agentGenome.js`);
const { bootstrapTools } = await import(`${base}/tools/bootstrap.js`);
bootstrapTools();
const db = new DatabaseSync(dbPath, { readOnly: true });
const rows = db.prepare('SELECT id, agent_id, version, status, security_check_passed, system_prompt FROM agent_genomes ORDER BY agent_id, version').all();
const consequence = { active: 'ACTIVE & fails current check — stays active (D5: not auto-disabled); replace via a valid approval', superseded: 'rollback to this version is now REFUSED', proposed: 'approve is now REFUSED', rejected: 'already rejected — no action' };
let bad = 0;
for (const r of rows) {
  const res = G.checkGenomePromptRisk(r.system_prompt, r.agent_id);
  if (!res.passed) bad++;
  console.log(JSON.stringify({ genomeId: r.id, agentId: r.agent_id, version: r.version, status: r.status, storedPassedFlag: r.security_check_passed === 1, currentCheck: res.passed ? 'pass' : 'FAIL', findings: res.findings, consequence: res.passed ? null : (consequence[r.status] ?? 'unknown status') }));
}
console.log(JSON.stringify({ summary: { genomes: rows.length, failingCurrentCheck: bad, activeFailing: rows.filter((r) => r.status === 'active' && !G.checkGenomePromptRisk(r.system_prompt, r.agent_id).passed).length } }));
db.close();
