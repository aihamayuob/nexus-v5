import type { AgentDefinition } from './agentTypes.js';
import type { ToolDef } from '../providers/contract.js';
import { getToolRegistry } from '../tools/registry.js';

/**
 * Resolves an agent's declared tool NAMES (agentTypes.ts's
 * AgentDefinition.tools — a list of tools/registry.ts tool names, never
 * trusted blindly) into real ToolDef objects the provider adapter can
 * actually see, applying constraints.allowedToolsOverride (deny-by-default
 * allowlist, if set) and constraints.deniedTools on top. A name that
 * isn't in the tool registry (typo, or a tool removed after an agent was
 * defined) is silently dropped rather than thrown — an agent should
 * degrade to fewer tools, not fail entirely, for a config drift issue.
 * Returns undefined (not []) when the agent ends up with no tools, so
 * chatService.ts's `needsTools` check behaves exactly as it does for an
 * agent that never requested tools at all.
 *
 * G8.2 Genome Security Gate: moved VERBATIM from agentRunner.ts so that the runner and the genome capability check share ONE definition of
 * "what this agent is actually offered" (no duplicate source of truth). Behaviour is unchanged.
 */
export function resolveAgentTools(def: AgentDefinition): ToolDef[] | undefined {
  if (!def.tools.length) return undefined;
  const denied = new Set(def.constraints.deniedTools ?? []);
  const allowList = def.constraints.allowedToolsOverride;
  const candidateNames = allowList && allowList.length ? def.tools.filter((t) => allowList.includes(t)) : def.tools;
  const registry = getToolRegistry();
  const defs = candidateNames
    .filter((name) => !denied.has(name))
    .map((name) => registry.get(name)?.def)
    .filter((d): d is ToolDef => !!d);
  return defs.length ? defs : undefined;
}

/** Names of the tools the agent is actually offered (same resolution as the runner uses). Empty array — never undefined — for an agent with none. */
export function resolveAgentToolNames(def: AgentDefinition): string[] {
  return (resolveAgentTools(def) ?? []).map((t) => t.name);
}
