/**
 * Genome capability-claim check (G8.2 Genome Security Gate).
 *
 * WHAT IT IS: a deterministic, lexical scan of a candidate system prompt for POSITIVE claims or promises of a capability the agent is not actually offered:
 * (1) naming a tool the agent is not offered ("استخدم أداة code_execution"), (2) promising to run code/programs/queries, (3) promising live web access.
 * A text that DENIES or FORBIDS the capability ("لا تملك أداة …", "never claim you can run code") is not refused. Pure function: no database, no clock, no network.
 *
 * WHAT IT IS NOT: it does not understand meaning. It cannot see an implicit claim with no tool/verb vocabulary, a language other than Arabic/English, a claim split across
 * sentences or encoded, or a double negation ("لا تقل إنك لا تملك …"). test/genomeCapabilityGate.test.ts pins those limits (GC-9). It is a reviewer-assist gate that reduces
 * contradictory prompts; it is NOT technical enforcement — what an agent can really do is decided by which tools are offered (agents/agentToolResolution.ts) and registered
 * (tools/bootstrap.ts), and nothing here makes a model obey any text.
 */

export interface CapabilityCheckResult {
  passed: boolean;
  findings: string[];
}

export interface CapabilityCheckOptions {
  /** Tool names the agent is ACTUALLY offered (agents/agentToolResolution.ts → resolveAgentToolNames). Mentioning/claiming these is allowed. */
  offeredToolNames: readonly string[];
  /** Extra tool names to treat as known (e.g. everything currently registered). Merged with STATIC_KNOWN_TOOL_NAMES. */
  knownToolNames?: readonly string[];
}

/** Names the platform has ever defined or discussed as tools, whether or not registered today (code_execution/create_file/web_search are NOT registered by default). */
export const STATIC_KNOWN_TOOL_NAMES: readonly string[] = ['code_execution', 'web_search', 'web_fetch', 'create_file', 'calculate'];

/** Tools whose presence in the offered set makes execution claims truthful / web claims truthful. */
const EXECUTION_TOOLS = ['code_execution'];
const isWebTool = (n: string) => n.toLowerCase().startsWith('web_');

// ---------------------------------------------------------------- normalization
// Small, deliberate confusables table (Cyrillic/Greek look-alikes of Latin letters). Not Unicode TR39 — a pragmatic fold for tool identifiers.
const CONFUSABLES: Record<string, string> = {
  '\u043e': 'o', '\u0430': 'a', '\u0435': 'e', '\u0441': 'c', '\u0440': 'p', '\u0445': 'x', '\u0456': 'i', '\u0455': 's', '\u0458': 'j', '\u043d': 'h', '\u0442': 't', '\u043a': 'k', '\u043c': 'm',
  '\u03bf': 'o', '\u03b1': 'a', '\u03b5': 'e', '\u03c1': 'p', '\u03b9': 'i', '\u03ba': 'k', '\u03bd': 'v', '\u03c4': 't',
};

/** NFKC, drop zero-width/bidi/soft-hyphen, drop Arabic diacritics + tatweel, fold alef/ya variants, lowercase, fold confusables, unify apostrophes, collapse whitespace. */
export function normalizeForScan(text: string): string {
  let s = text
    .normalize('NFKC')
    .replace(/[\u200b-\u200f\u202a-\u202e\u2060-\u2064\ufeff\u00ad\u180e]/g, '')
    .replace(/[\u064b-\u065f\u0670\u0640]/g, '')
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/[\u2018\u2019\u00b4`]/g, "'")
    .toLowerCase();
  s = Array.from(s, (ch) => CONFUSABLES[ch] ?? ch).join('');
  return s.replace(/\s+/g, ' ').trim();
}

// ---------------------------------------------------------------- vocabulary (all patterns are written against NORMALIZED text)
const CLAUSE_SPLIT = /[.!?؟؛;:\n\r،,]+|\s(?:but|however|yet|although|though)\s|\s(?:لكن|ولكن|غير ان|الا ان)\s/;
const NEG = /\b(?:not|no|never|cannot|can't|cant|don't|dont|doesn't|doesnt|won't|wont|without|unable|unavailable|forbidden|prohibited|lack|lacks|lacking|disabled)\b|(?:^| )(?:و|ف)?(?:لا|لن|لم|ليس|ليست|ليسوا|غير|دون|بدون|ممنوع|محظور|يحظر|تحظر|عدم|يمنع|تمنع|عاجز|تعذر)(?: |$)/;
// "don't hesitate to use X" / "لا تتردد في استخدام X" contain a negation word but are PROMISES, not denials.
const HESITATE = /(?:do not|don't|dont|never)\s+(?:hesitate|be afraid|wait)|feel free|لا تتردد|لا تتاخر|لا تخف|لا تتوان|لا تتحرج/;
const USER_CTX = /\b(?:the user|users?|your user|client|customer)\b|المستخدم|المستخدمين|العميل|الزبون/;
const HOWTO = /\b(?:how to|explain|teach|tutorial|example|guide)\b|كيف|اشرح|علم|درس|مثال/;
const TOOL_CTX = /\b(?:tool|tools|function|capability|ability|plugin|feature|use|using|uses)\b|اداه|اداة|ادوات|دالة|ميزة|قدره|قدرة|استخدم|باستخدام/;
const SINGLE_WORD_TOOL_CTX_BEFORE = '(?:tool|function|اداه|اداة|ادوات|دالة)\\s*[:"\'`(«]?\\s*';
const SINGLE_WORD_TOOL_CTX_AFTER = '\\s*(?:tool|function|اداه|اداة)';

const EXECV = /\b(?:run|runs|running|ran|execute|executes|executing|executed|exec|compile|launch)\b|تنفيذ|تنفذ|ننفذ|نفذ|نفذت|اشغل|تشغيل|تشغل|شغل|شغلت|سنشغل|ساشغل|اجراء/;
const OBJ_BASE = '\\b(?:code|codes|script|scripts|python|javascript|sql|quer(?:y|ies)|program|programs|software|commands?|shell|terminal|notebooks?)\\b|الكود|كود|اكواد|الاكواد|سكربت|برنامج|برامج|بايثون|استعلام|استعلامات|الاوامر البرمجيه|الطرفيه';
const OBJ_CALC = '|\\b(?:calculations?|computations?)\\b|الحساب|الحسابات|العمليات الحسابيه';
const CLAIM = /\b(?:you can|you could|you may|you are able|you're able|you have|you will|you'll|i can|i will|i'll|i have|i ran|i executed|we can|ran|executed|has access|have access|access to)\b|يمكنك|تستطيع|بامكانك|لديك|تملك|عندك|ساقوم|ساشغل|ساجري|سانفذ|سنقوم|سنشغل|سننفذ|سوف|ستقوم|نفذت|شغلت|اجريت|وصول/;
const IMPERATIVE_LEAD = '^(?:(?:و|ف|ثم|then|and|also|please|always|دائما)\\s+)*(?:شغل|اشغل|نفذ|run|execute)\\s+(.{0,40})';
const WEB = /(?:browse|search|surf)\s+(?:the\s+)?(?:web|internet|net)\b|\bweb\s+search\b|\binternet\s+access\b|\baccess\s+to\s+the\s+(?:web|internet)\b|\breal[\s-]?time\s+(?:data|information|web|browsing|search)\b|\blive\s+(?:web|data|internet)\b|تصفح|البحث\s+في\s+(?:الانترنت|الويب|الشبكه|الشبكة)|الوصول\s+(?:الي|الى)\s+(?:الانترنت|الويب)|بحث\s+ويب|انترنت\s+مباشر/;

const snippet = (clause: string) => clause.trim().slice(0, 90);
const escapeRe = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

function nameRegexes(name: string): { strict?: RegExp; loose?: RegExp; single?: RegExp } {
  const tokens = name.toLowerCase().split(/[_\-\s]+/).filter(Boolean).map(escapeRe);
  if (tokens.length === 0) return {};
  if (tokens.length > 1) {
    return {
      strict: new RegExp(`(?<![a-z0-9])${tokens.join('[_\\-]')}(?![a-z0-9])`), // code_execution / code-execution: an identifier, always a tool claim
      loose: new RegExp(`(?<![a-z0-9])${tokens.join('\\s+')}(?![a-z0-9])`), // "code execution": a tool claim only with tool-ish context in the clause
    };
  }
  const n = tokens[0]!;
  return {
    // a one-word name ("calculate") is also an ordinary verb: only a tool claim when marked as a tool/function
    single: new RegExp(`(?:${SINGLE_WORD_TOOL_CTX_BEFORE}(?<![a-z0-9_])${n}(?![a-z0-9_]))|(?:(?<![a-z0-9_])${n}${SINGLE_WORD_TOOL_CTX_AFTER})|(?:(?<![a-z0-9_])${n}\\()`),
  };
}

/** Core scan. `text` is raw candidate prompt text; returns one finding per distinct claim (deduplicated). */
export function checkCapabilityClaims(text: string, opts: CapabilityCheckOptions): CapabilityCheckResult {
  const offered = new Set(opts.offeredToolNames.map((n) => n.toLowerCase()));
  const known = [...new Set([...STATIC_KNOWN_TOOL_NAMES, ...(opts.knownToolNames ?? [])].map((n) => n.toLowerCase()))];
  const unoffered = known.filter((n) => !offered.has(n));
  const nameRes = unoffered.map((n) => ({ n, ...nameRegexes(n) }));
  const execAllowed = EXECUTION_TOOLS.some((t) => offered.has(t));
  const webAllowed = [...offered].some(isWebTool);
  const objRe = new RegExp(OBJ_BASE + (offered.has('calculate') ? '' : OBJ_CALC));
  const imperativeRe = new RegExp(IMPERATIVE_LEAD);

  const findings = new Set<string>();
  for (const raw of normalizeForScan(text).split(CLAUSE_SPLIT)) {
    const clause = raw.trim();
    if (!clause) continue;
    const negated = NEG.test(clause) && !HESITATE.test(clause);
    if (negated) continue; // a denial/prohibition of the capability (or an unrelated negation) — never a positive claim

    for (const r of nameRes) {
      const hit = (r.strict && r.strict.test(clause)) || (r.loose && r.loose.test(clause) && TOOL_CTX.test(clause)) || (r.single && r.single.test(clause));
      if (hit) findings.add(`ادعاء/وعد بأداة غير معروضة لهذا الوكيل: "${r.n}" — «${snippet(clause)}»`);
    }

    if (!execAllowed && !USER_CTX.test(clause) && !HOWTO.test(clause)) {
      const claim = EXECV.test(clause) && objRe.test(clause) && CLAIM.test(clause);
      const lead = imperativeRe.exec(clause);
      const imperative = !!lead && objRe.test(lead[1] ?? '');
      if (claim || imperative) findings.add(`ادعاء/وعد بتنفيذ أكواد أو برامج أو استعلامات دون أن تُعرض على هذا الوكيل أداة تنفيذ — «${snippet(clause)}»`);
    }

    if (!webAllowed && WEB.test(clause) && CLAIM.test(clause)) {
      findings.add(`ادعاء/وعد بالوصول إلى الإنترنت أو البحث في الويب دون أداة ويب معروضة — «${snippet(clause)}»`);
    }
  }
  const list = [...findings];
  return { passed: list.length === 0, findings: list };
}
