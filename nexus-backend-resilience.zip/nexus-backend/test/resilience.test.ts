import './helpers/setResilienceTestEnv.js';
import { test, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { createServer, type Server } from 'node:http';
import { openTestDb } from '../src/persistence/db.js';
import { buildRepos, resetReposSingletonForTests, getRepos } from '../src/persistence/repos.js';
import { Verifier } from '../src/orchestrator/verifier.js';
import { EvaluationEngine } from '../src/evaluation/evaluationEngine.js';
import { proposeGenomeMutation, approveGenomeVersion } from '../src/evolution/agentGenome.js';
import { checkFreshness } from '../src/knowledge/freshnessEngine.js';
import { runWebResearch } from '../src/research/webResearch.js';
import { createNexusServer } from '../src/gateway/server.js';
import { resetRateLimitBucketsForTests } from '../src/gateway/middleware/rateLimit.js';
import { clearAdapterCacheForTests } from '../src/providers/index.js';
import type { GatewayContext } from '../src/capability/permissionModel.js';

const ctx: GatewayContext = { authenticated: true, clientKey: 'test', projectId: null, userId: null };

function freshDb() {
  resetReposSingletonForTests(buildRepos(openTestDb()));
}

let hangingAnthropic: Server;
let hangingGemini: Server;

before(async () => {
  // A server that accepts the TCP connection but NEVER responds and NEVER closes — the exact real-world failure mode (a stuck/overloaded provider) this whole test file exists to prove is now survivable.
  hangingAnthropic = createServer((req, res) => {
    if (req.method === 'GET') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ data: [] }));
      return;
    }
    // deliberately never respond to POST
  });
  await new Promise<void>((resolve) => hangingAnthropic.listen(0, '127.0.0.1', resolve));
  const addrA = hangingAnthropic.address();
  process.env.NEXUS_ANTHROPIC_BASE_URL = `http://127.0.0.1:${typeof addrA === 'object' && addrA ? addrA.port : 0}`;
  process.env.NEXUS_ANTHROPIC_API_KEY = 'fake-key';

  hangingGemini = createServer(() => {
    /* never respond */
  });
  await new Promise<void>((resolve) => hangingGemini.listen(0, '127.0.0.1', resolve));
  const addrG = hangingGemini.address();
  process.env.NEXUS_GEMINI_BASE_URL = `http://127.0.0.1:${typeof addrG === 'object' && addrG ? addrG.port : 0}`;
  process.env.NEXUS_GEMINI_API_KEY = 'fake-key';
});

after(async () => {
  // closeAllConnections() (not just close()) — a plain close() waits for
  // existing connections to end naturally, but these servers deliberately
  // never respond, so a client whose fetch() was aborted client-side can
  // leave the server-side socket in a state close() will wait on
  // indefinitely. Same fix already used elsewhere in this test suite for
  // the same reason.
  hangingAnthropic.closeAllConnections();
  await new Promise((r) => hangingAnthropic.close(r));
  hangingGemini.closeAllConnections();
  await new Promise((r) => hangingGemini.close(r));
});

beforeEach(() => {
  freshDb();
  resetRateLimitBucketsForTests();
});

// ---- Fix: judge-call / research-call timeout enforcement (previously unbounded — confirmed empirically to hang forever) ----

test('Verifier.verify() degrades to unavailable within the configured timeout against a hanging provider, instead of hanging forever', async () => {
  const start = Date.now();
  const result = await Verifier.verify('سؤال', 'إجابة مقترحة');
  const elapsed = Date.now() - start;
  assert.equal(result.ran, false);
  assert.equal(result.verdict, 'unavailable');
  assert.ok(elapsed < 5000, `expected a bounded wait, got ${elapsed}ms`);
});

test('EvaluationEngine.evaluate() degrades to unavailable within the configured timeout against a hanging provider', async () => {
  const start = Date.now();
  const result = await EvaluationEngine.evaluate('ادعاء', [{ source: 'x', content: 'دليل حقيقي بما يكفي للمرور عبر مسار الاستدعاء الفعلي.' }]);
  const elapsed = Date.now() - start;
  assert.equal(result.ran, false);
  assert.ok(elapsed < 5000, `expected a bounded wait, got ${elapsed}ms`);
});

test('Digital Genome proposeGenomeMutation() fails with a real, honest error within the configured timeout against a hanging provider', async () => {
  const start = Date.now();
  await assert.rejects(() => proposeGenomeMutation('financial'));
  const elapsed = Date.now() - start;
  assert.ok(elapsed < 5000, `expected a bounded wait, got ${elapsed}ms`);
});

test('Knowledge Freshness checkFreshness() degrades to a conservative default within the configured timeout against a hanging provider', async () => {
  const repos = getRepos();
  const item = repos.memory.add({ projectId: null, userId: null, kind: 'knowledge', title: 't', content: 'محتوى تجريبي', embedding: null });
  const start = Date.now();
  const result = await checkFreshness(item.id);
  const elapsed = Date.now() - start;
  assert.equal(result.volatility, 'medium');
  assert.ok(elapsed < 5000, `expected a bounded wait, got ${elapsed}ms`);
});

test('runWebResearch() does not hang forever against a hanging Gemini endpoint', async () => {
  // Unlike the four direct-adapter judge calls above, runWebResearch() goes
  // through chatService.ts's runChatCompletion() -> resilientCall(), which
  // treats a TimeoutError as a retryable condition by existing, deliberate
  // design (Errors.timeout() sets retryable:true) — so the real total wait
  // here is legitimately (attempts × judgeCallTimeoutMs) plus backoff, not
  // a single bare timeout. The fix's actual claim is "bounded, not
  // infinite" (confirmed directly against geminiAdapter.chat() alone: it
  // rejects in ~600ms every time) — this test's bound is set generously
  // above the real retried total, not tightened to a single attempt.
  const start = Date.now();
  await assert.rejects(() => runWebResearch('سؤال بحث', ctx, { persistToMemory: false, evaluate: false }));
  const elapsed = Date.now() - start;
  assert.ok(elapsed < 15000, `expected a bounded wait/failure even with retries, got ${elapsed}ms`);
});

// ---- Concurrent/racing mutations on the same resource ----

test('two concurrent approve() calls on the same Digital Genome proposal: exactly one succeeds, the other fails cleanly — no corrupted double-activation', async () => {
  // Use a fast, non-hanging fake so the proposal itself can actually be built for this test.
  const fastServer = createServer(async (req, res) => {
    if (req.method === 'GET') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ data: [] }));
      return;
    }
    for await (const c of req) {
      /* drain */
    }
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ content: [{ type: 'text', text: 'نص بديل آمن وواضح بما يكفي لتجاوز فحص الطول.' }], stop_reason: 'end_turn', usage: { input_tokens: 5, output_tokens: 5 } }));
  });
  await new Promise<void>((resolve) => fastServer.listen(0, '127.0.0.1', resolve));
  const addr = fastServer.address();
  const savedUrl = process.env.NEXUS_ANTHROPIC_BASE_URL;
  process.env.NEXUS_ANTHROPIC_BASE_URL = `http://127.0.0.1:${typeof addr === 'object' && addr ? addr.port : 0}`;
  clearAdapterCacheForTests(); // getProviderAdapter() caches per process lifetime (by design, for the normal case where env never changes mid-process) — a real fix this test itself needed once discovered, not a hypothetical
  try {
    const proposal = await proposeGenomeMutation('financial');
    // Wrapped in Promise.resolve().then(...) rather than calling the
    // synchronous approveGenomeVersion() directly inside the array literal:
    // a bare synchronous throw inside Promise.allSettled([...]) propagates
    // immediately out of the array construction itself, before
    // allSettled() is even invoked — this is exactly the real bug this
    // test itself had until caught here, not a hypothetical concern.
    const results = await Promise.allSettled([
      Promise.resolve().then(() => approveGenomeVersion(proposal.id, 'aiham')),
      Promise.resolve().then(() => approveGenomeVersion(proposal.id, 'someone-else')),
    ]);
    const fulfilled = results.filter((r) => r.status === 'fulfilled');
    const rejected = results.filter((r) => r.status === 'rejected');
    assert.equal(fulfilled.length, 1, 'exactly one concurrent approval must win');
    assert.equal(rejected.length, 1, 'the other must fail cleanly, not corrupt state');
    const genomes = getRepos().agentGenomes.list('financial');
    assert.equal(genomes.filter((g) => g.status === 'active').length, 1, 'never more than one active genome, even under a real race');
  } finally {
    process.env.NEXUS_ANTHROPIC_BASE_URL = savedUrl;
    clearAdapterCacheForTests(); // restore so any LATER test in this file gets an adapter bound to the hanging server again, matching what it expects
    await new Promise((r) => fastServer.close(r));
  }
});

// ---- Malformed / adversarial input resilience ----

test('malformed (non-JSON) request bodies are rejected with a clean 400, not a server crash or 500', async () => {
  const nexusServer = createNexusServer();
  await new Promise<void>((resolve) => nexusServer.listen(0, '127.0.0.1', () => resolve()));
  const addr = nexusServer.address();
  const nexusUrl = `http://127.0.0.1:${typeof addr === 'object' && addr ? addr.port : 0}`;
  try {
    const res = await fetch(`${nexusUrl}/v2/evaluation/claim`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{not valid json at all' });
    assert.equal(res.status, 400);
    // The server must still be alive and answering normally afterward.
    const healthRes = await fetch(`${nexusUrl}/v2/health`);
    assert.equal(healthRes.status, 200);
  } finally {
    await new Promise((r) => nexusServer.close(r));
  }
});

test('a request body with deeply nested JSON is accepted or cleanly rejected, never crashes the server', async () => {
  const nexusServer = createNexusServer();
  await new Promise<void>((resolve) => nexusServer.listen(0, '127.0.0.1', () => resolve()));
  const addr = nexusServer.address();
  const nexusUrl = `http://127.0.0.1:${typeof addr === 'object' && addr ? addr.port : 0}`;
  try {
    let deep: unknown = 'x';
    for (let i = 0; i < 500; i++) deep = { nested: deep };
    const res = await fetch(`${nexusUrl}/v2/evaluation/claim`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ claim: 'test', evidence: [], extra: deep }) });
    assert.ok(res.status === 200 || res.status === 400, `expected a clean response, got ${res.status}`);
    const healthRes = await fetch(`${nexusUrl}/v2/health`);
    assert.equal(healthRes.status, 200, 'server must still be alive afterward');
  } finally {
    await new Promise((r) => nexusServer.close(r));
  }
});

test('an oversized request body is rejected with 413, not accepted or crashed on', async () => {
  const nexusServer = createNexusServer();
  await new Promise<void>((resolve) => nexusServer.listen(0, '127.0.0.1', () => resolve()));
  const addr = nexusServer.address();
  const nexusUrl = `http://127.0.0.1:${typeof addr === 'object' && addr ? addr.port : 0}`;
  try {
    const oversized = 'x'.repeat(15 * 1024 * 1024); // 15MB — comfortably over any reasonable body limit
    const res = await fetch(`${nexusUrl}/v2/evaluation/claim`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ claim: oversized }) });
    assert.equal(res.status, 413);
    const healthRes = await fetch(`${nexusUrl}/v2/health`);
    assert.equal(healthRes.status, 200);
  } finally {
    await new Promise((r) => nexusServer.close(r));
  }
});

// ---- Real concurrent HTTP burst against the rate limiter ----

test('a genuine concurrent burst of requests (not sequential) is still counted and limited correctly', async () => {
  const nexusServer = createNexusServer();
  await new Promise<void>((resolve) => nexusServer.listen(0, '127.0.0.1', () => resolve()));
  const addr = nexusServer.address();
  const nexusUrl = `http://127.0.0.1:${typeof addr === 'object' && addr ? addr.port : 0}`;
  try {
    // Fire 40 requests genuinely in parallel (Promise.all, not a loop with awaits) from the same simulated caller.
    const requests = Array.from({ length: 40 }, () => fetch(`${nexusUrl}/v2/health`, { headers: { 'X-Forwarded-For': '203.0.113.77' } }));
    const responses = await Promise.all(requests);
    const statuses = responses.map((r) => r.status);
    const okCount = statuses.filter((s) => s === 200).length;
    const limitedCount = statuses.filter((s) => s === 429).length;
    assert.equal(okCount + limitedCount, 40, 'every request must get a real, clean response — none dropped or crashed');
    assert.ok(limitedCount > 0, 'a genuine burst of 40 concurrent requests must trip the rate limiter at some point (default burst is well under 40)');
  } finally {
    await new Promise((r) => nexusServer.close(r));
  }
});

// ---- DB resilience under genuine concurrent writers ----

test('many genuinely concurrent mission creations succeed without SQLITE_BUSY errors, thanks to busy_timeout', async () => {
  const nexusServer = createNexusServer();
  await new Promise<void>((resolve) => nexusServer.listen(0, '127.0.0.1', () => resolve()));
  const addr = nexusServer.address();
  const nexusUrl = `http://127.0.0.1:${typeof addr === 'object' && addr ? addr.port : 0}`;
  try {
    const requests = Array.from({ length: 15 }, (_, i) =>
      fetch(`${nexusUrl}/v2/missions`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ objective: `مهمة تزامن ${i}` }) })
    );
    const responses = await Promise.all(requests);
    for (const res of responses) assert.equal(res.status, 202, 'every concurrent mission-creation write must succeed cleanly');
  } finally {
    await new Promise((r) => nexusServer.close(r));
  }
});
