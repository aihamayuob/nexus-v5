// NEXUS / Neural Nexus AI Agents — Service Worker
// Purpose: (1) satisfy browser installability checks so "Add to Home Screen"
// actually appears, and (2) let the app shell load instantly / offline even
// on a flaky connection. It does NOT cache API responses — those must
// always be fresh/live.

const CACHE_NAME = 'neural-nexus-shell-v1';
const SHELL_FILES = [
  './',
  './index.html',
  './manifest.json',
  './icons/icon-192.png',
  './icons/icon-512.png',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(SHELL_FILES))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // Never cache API calls (Anthropic/OpenAI/DeepSeek/Gemini or our own
  // backend /api/*) — those must always hit the network live.
  if (url.pathname.startsWith('/api/') || url.hostname.includes('anthropic.com')
      || url.hostname.includes('openai.com') || url.hostname.includes('deepseek.com')
      || url.hostname.includes('googleapis.com')) {
    return; // let the browser handle it normally, no SW interception
  }

  // App shell files: cache-first, falling back to network.
  event.respondWith(
    caches.match(event.request).then((cached) => cached || fetch(event.request))
  );
});
