import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';

/** Raw tokens (session tokens, invite tokens, API keys) are shown to the
 *  client exactly once and never stored — only their SHA-256 hash lives
 *  in the database, so a database read alone can never yield a usable
 *  credential (same principle as never storing plaintext passwords). */
export function generateToken(byteLength = 32): { raw: string; hash: string } {
  const raw = randomBytes(byteLength).toString('base64url');
  return { raw, hash: hashToken(raw) };
}

export function hashToken(raw: string): string {
  return createHash('sha256').update(raw).digest('hex');
}

/** Workspace API keys use a recognizable, non-secret prefix (nxk_live_...)
 *  so they're identifiable in logs/UIs without ever needing to store or
 *  redisplay the actual secret after creation. */
export function generateApiKey(): { raw: string; hash: string; prefix: string } {
  const secret = randomBytes(24).toString('base64url');
  const raw = `nxk_live_${secret}`;
  return { raw, hash: hashToken(raw), prefix: raw.slice(0, 12) + '…' };
}

export function safeEqual(a: string, b: string): boolean {
  const bufA = Buffer.from(a);
  const bufB = Buffer.from(b);
  if (bufA.length !== bufB.length) return false;
  return timingSafeEqual(bufA, bufB);
}
