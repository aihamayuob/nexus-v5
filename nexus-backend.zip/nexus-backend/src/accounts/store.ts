import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
import { randomUUID } from 'node:crypto';

/**
 * This is a genuinely additive layer. Every route built in Phases 1-6
 * keeps working exactly as documented — a single GATEWAY_API_KEY, one
 * deployment, no accounts required. This schema exists for people who
 * want real multi-user workspaces on top of that: Google-authenticated
 * users, roles, invites, workspace-scoped API keys, and an audit trail.
 * Nothing here is required to run the rest of the backend.
 */

export type Role = 'owner' | 'admin' | 'member' | 'viewer';

export interface User {
  id: string;
  email: string;
  googleSub: string;
  name: string | null;
  avatarUrl: string | null;
  createdAt: string;
}

export interface Workspace {
  id: string;
  name: string;
  ownerUserId: string;
  plan: string;
  planStatus: 'active' | 'past_due' | 'canceled';
  paddleSubscriptionId: string | null;
  paddleCustomerId: string | null;
  createdAt: string;
}

export interface Membership {
  workspaceId: string;
  userId: string;
  role: Role;
  joinedAt: string;
}

export interface Invite {
  id: string;
  workspaceId: string;
  email: string;
  role: Role;
  invitedBy: string;
  tokenHash: string;
  createdAt: string;
  expiresAt: string;
  acceptedAt: string | null;
}

export interface ApiKeyRecord {
  id: string;
  workspaceId: string;
  name: string;
  keyHash: string;
  keyPrefix: string;
  createdBy: string;
  createdAt: string;
  lastUsedAt: string | null;
  revokedAt: string | null;
}

function nowIso(): string {
  return new Date().toISOString();
}

export class AccountsStore {
  private db: DatabaseSync;

  constructor(dbPath: string) {
    if (dbPath !== ':memory:') {
      try { mkdirSync(dirname(dbPath), { recursive: true }); } catch { /* already exists */ }
    }
    this.db = new DatabaseSync(dbPath);
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY, email TEXT UNIQUE NOT NULL, google_sub TEXT UNIQUE NOT NULL,
        name TEXT, avatar_url TEXT, created_at TEXT NOT NULL
      );
      CREATE TABLE IF NOT EXISTS sessions (
        token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL, created_at TEXT NOT NULL, expires_at TEXT NOT NULL
      );
      CREATE TABLE IF NOT EXISTS workspaces (
        id TEXT PRIMARY KEY, name TEXT NOT NULL, owner_user_id TEXT NOT NULL,
        plan TEXT NOT NULL DEFAULT 'free', plan_status TEXT NOT NULL DEFAULT 'active',
        paddle_subscription_id TEXT, paddle_customer_id TEXT, created_at TEXT NOT NULL
      );
      CREATE TABLE IF NOT EXISTS workspace_members (
        workspace_id TEXT NOT NULL, user_id TEXT NOT NULL, role TEXT NOT NULL, joined_at TEXT NOT NULL,
        PRIMARY KEY (workspace_id, user_id)
      );
      CREATE TABLE IF NOT EXISTS workspace_invites (
        id TEXT PRIMARY KEY, workspace_id TEXT NOT NULL, email TEXT NOT NULL, role TEXT NOT NULL,
        invited_by TEXT NOT NULL, token_hash TEXT UNIQUE NOT NULL, created_at TEXT NOT NULL,
        expires_at TEXT NOT NULL, accepted_at TEXT
      );
      CREATE TABLE IF NOT EXISTS api_keys (
        id TEXT PRIMARY KEY, workspace_id TEXT NOT NULL, name TEXT NOT NULL, key_hash TEXT UNIQUE NOT NULL,
        key_prefix TEXT NOT NULL, created_by TEXT NOT NULL, created_at TEXT NOT NULL,
        last_used_at TEXT, revoked_at TEXT
      );
      CREATE TABLE IF NOT EXISTS audit_log (
        id TEXT PRIMARY KEY, workspace_id TEXT, user_id TEXT, action TEXT NOT NULL,
        details TEXT, created_at TEXT NOT NULL
      );
    `);
  }

  // ---- users ----
  findOrCreateUserByGoogle(googleSub: string, email: string, name: string | null, avatarUrl: string | null): User {
    const existing = this.db.prepare('SELECT * FROM users WHERE google_sub = ?').get(googleSub) as any;
    if (existing) return this.rowToUser(existing);
    const id = randomUUID();
    const createdAt = nowIso();
    this.db.prepare('INSERT INTO users (id, email, google_sub, name, avatar_url, created_at) VALUES (?,?,?,?,?,?)')
      .run(id, email, googleSub, name, avatarUrl, createdAt);
    return { id, email, googleSub, name, avatarUrl, createdAt };
  }
  getUser(id: string): User | null {
    const row = this.db.prepare('SELECT * FROM users WHERE id = ?').get(id) as any;
    return row ? this.rowToUser(row) : null;
  }
  private rowToUser(row: any): User {
    return { id: row.id, email: row.email, googleSub: row.google_sub, name: row.name, avatarUrl: row.avatar_url, createdAt: row.created_at };
  }

  // ---- sessions ----
  createSession(userId: string, tokenHash: string, ttlMs: number): void {
    const now = Date.now();
    this.db.prepare('INSERT INTO sessions (token_hash, user_id, created_at, expires_at) VALUES (?,?,?,?)')
      .run(tokenHash, userId, new Date(now).toISOString(), new Date(now + ttlMs).toISOString());
  }
  getSessionUser(tokenHash: string): User | null {
    const row = this.db.prepare('SELECT * FROM sessions WHERE token_hash = ?').get(tokenHash) as any;
    if (!row) return null;
    if (new Date(row.expires_at).getTime() < Date.now()) {
      this.db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(tokenHash);
      return null;
    }
    return this.getUser(row.user_id);
  }
  deleteSession(tokenHash: string): void {
    this.db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(tokenHash);
  }

  // ---- workspaces & membership ----
  createWorkspace(name: string, ownerUserId: string): Workspace {
    const id = randomUUID();
    const createdAt = nowIso();
    this.db.prepare(`INSERT INTO workspaces (id, name, owner_user_id, plan, plan_status, created_at) VALUES (?,?,?, 'free','active', ?)`)
      .run(id, name, ownerUserId, createdAt);
    this.db.prepare('INSERT INTO workspace_members (workspace_id, user_id, role, joined_at) VALUES (?,?,?,?)')
      .run(id, ownerUserId, 'owner', createdAt);
    return { id, name, ownerUserId, plan: 'free', planStatus: 'active', paddleSubscriptionId: null, paddleCustomerId: null, createdAt };
  }
  getWorkspace(id: string): Workspace | null {
    const row = this.db.prepare('SELECT * FROM workspaces WHERE id = ?').get(id) as any;
    return row ? this.rowToWorkspace(row) : null;
  }
  private rowToWorkspace(row: any): Workspace {
    return {
      id: row.id, name: row.name, ownerUserId: row.owner_user_id, plan: row.plan, planStatus: row.plan_status,
      paddleSubscriptionId: row.paddle_subscription_id, paddleCustomerId: row.paddle_customer_id, createdAt: row.created_at,
    };
  }
  listWorkspacesForUser(userId: string): Workspace[] {
    const rows = this.db.prepare(
      `SELECT w.* FROM workspaces w JOIN workspace_members m ON m.workspace_id = w.id WHERE m.user_id = ? ORDER BY w.created_at ASC`
    ).all(userId) as any[];
    return rows.map((r) => this.rowToWorkspace(r));
  }
  getMembership(workspaceId: string, userId: string): Membership | null {
    const row = this.db.prepare('SELECT * FROM workspace_members WHERE workspace_id = ? AND user_id = ?').get(workspaceId, userId) as any;
    if (!row) return null;
    return { workspaceId: row.workspace_id, userId: row.user_id, role: row.role, joinedAt: row.joined_at };
  }
  listMembers(workspaceId: string): (Membership & { email: string; name: string | null })[] {
    const rows = this.db.prepare(
      `SELECT m.*, u.email, u.name FROM workspace_members m JOIN users u ON u.id = m.user_id WHERE m.workspace_id = ? ORDER BY m.joined_at ASC`
    ).all(workspaceId) as any[];
    return rows.map((r) => ({ workspaceId: r.workspace_id, userId: r.user_id, role: r.role, joinedAt: r.joined_at, email: r.email, name: r.name }));
  }
  addMember(workspaceId: string, userId: string, role: Role): void {
    this.db.prepare(
      `INSERT INTO workspace_members (workspace_id, user_id, role, joined_at) VALUES (?,?,?,?)
       ON CONFLICT(workspace_id, user_id) DO UPDATE SET role = excluded.role`
    ).run(workspaceId, userId, role, nowIso());
  }
  removeMember(workspaceId: string, userId: string): void {
    this.db.prepare('DELETE FROM workspace_members WHERE workspace_id = ? AND user_id = ?').run(workspaceId, userId);
  }
  updateWorkspaceBilling(workspaceId: string, plan: string, planStatus: Workspace['planStatus'], subscriptionId: string | null, customerId: string | null): void {
    this.db.prepare('UPDATE workspaces SET plan = ?, plan_status = ?, paddle_subscription_id = ?, paddle_customer_id = ? WHERE id = ?')
      .run(plan, planStatus, subscriptionId, customerId, workspaceId);
  }
  findWorkspaceByPaddleSubscription(subscriptionId: string): Workspace | null {
    const row = this.db.prepare('SELECT * FROM workspaces WHERE paddle_subscription_id = ?').get(subscriptionId) as any;
    return row ? this.rowToWorkspace(row) : null;
  }

  // ---- invites ----
  createInvite(workspaceId: string, email: string, role: Role, invitedBy: string, tokenHash: string, ttlMs: number): Invite {
    const id = randomUUID();
    const createdAt = nowIso();
    const expiresAt = new Date(Date.now() + ttlMs).toISOString();
    this.db.prepare(
      'INSERT INTO workspace_invites (id, workspace_id, email, role, invited_by, token_hash, created_at, expires_at, accepted_at) VALUES (?,?,?,?,?,?,?,?,NULL)'
    ).run(id, workspaceId, email, role, invitedBy, tokenHash, createdAt, expiresAt);
    return { id, workspaceId, email, role, invitedBy, tokenHash, createdAt, expiresAt, acceptedAt: null };
  }
  getInviteByTokenHash(tokenHash: string): Invite | null {
    const row = this.db.prepare('SELECT * FROM workspace_invites WHERE token_hash = ?').get(tokenHash) as any;
    if (!row) return null;
    return {
      id: row.id, workspaceId: row.workspace_id, email: row.email, role: row.role, invitedBy: row.invited_by,
      tokenHash: row.token_hash, createdAt: row.created_at, expiresAt: row.expires_at, acceptedAt: row.accepted_at,
    };
  }
  acceptInvite(id: string): void {
    this.db.prepare('UPDATE workspace_invites SET accepted_at = ? WHERE id = ?').run(nowIso(), id);
  }

  // ---- API keys ----
  createApiKey(workspaceId: string, name: string, keyHash: string, keyPrefix: string, createdBy: string): ApiKeyRecord {
    const id = randomUUID();
    const createdAt = nowIso();
    this.db.prepare(
      'INSERT INTO api_keys (id, workspace_id, name, key_hash, key_prefix, created_by, created_at, last_used_at, revoked_at) VALUES (?,?,?,?,?,?,?,NULL,NULL)'
    ).run(id, workspaceId, name, keyHash, keyPrefix, createdBy, createdAt);
    return { id, workspaceId, name, keyHash, keyPrefix, createdBy, createdAt, lastUsedAt: null, revokedAt: null };
  }
  getApiKeyByHash(keyHash: string): ApiKeyRecord | null {
    const row = this.db.prepare('SELECT * FROM api_keys WHERE key_hash = ?').get(keyHash) as any;
    if (!row || row.revoked_at) return null;
    return this.rowToApiKey(row);
  }
  listApiKeys(workspaceId: string): ApiKeyRecord[] {
    const rows = this.db.prepare('SELECT * FROM api_keys WHERE workspace_id = ? ORDER BY created_at DESC').all(workspaceId) as any[];
    return rows.map((r) => this.rowToApiKey(r));
  }
  revokeApiKey(id: string): void {
    this.db.prepare('UPDATE api_keys SET revoked_at = ? WHERE id = ?').run(nowIso(), id);
  }
  touchApiKey(id: string): void {
    this.db.prepare('UPDATE api_keys SET last_used_at = ? WHERE id = ?').run(nowIso(), id);
  }
  private rowToApiKey(row: any): ApiKeyRecord {
    return {
      id: row.id, workspaceId: row.workspace_id, name: row.name, keyHash: row.key_hash, keyPrefix: row.key_prefix,
      createdBy: row.created_by, createdAt: row.created_at, lastUsedAt: row.last_used_at, revokedAt: row.revoked_at,
    };
  }

  // ---- audit log ----
  logAudit(workspaceId: string | null, userId: string | null, action: string, details?: unknown): void {
    this.db.prepare('INSERT INTO audit_log (id, workspace_id, user_id, action, details, created_at) VALUES (?,?,?,?,?,?)')
      .run(randomUUID(), workspaceId, userId, action, details ? JSON.stringify(details) : null, nowIso());
  }
  listAuditLog(workspaceId: string, limit = 100): Array<{ id: string; userId: string | null; action: string; details: unknown; createdAt: string }> {
    // Ordered by rowid (SQLite's implicit, monotonically-increasing
    // insertion-order column), not created_at alone — two events logged
    // within the same millisecond (a real, common case: e.g. an
    // automated action that logs two related audit entries back to
    // back) would otherwise have identical timestamps and no
    // deterministic order.
    const rows = this.db.prepare('SELECT * FROM audit_log WHERE workspace_id = ? ORDER BY rowid DESC LIMIT ?').all(workspaceId, limit) as any[];
    return rows.map((r) => ({ id: r.id, userId: r.user_id, action: r.action, details: r.details ? JSON.parse(r.details) : null, createdAt: r.created_at }));
  }

  close(): void {
    this.db.close();
  }
}
