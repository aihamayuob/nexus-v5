import type { IncomingMessage, ServerResponse } from 'node:http';
import { readJSONBody, sendError, sendJSON, BodyTooLargeError } from '../lib/httpUtil.js';
import type { Logger } from '../lib/logger.js';
import type { SyncStore } from '../sync/store.js';

interface PushBody {
  baseVersion: number;
  deviceId: string;
  saltB64: string;
  ivB64: string;
  ciphertextB64: string;
}

function validatePushBody(body: unknown): { ok: true; value: PushBody } | { ok: false; error: string } {
  if (typeof body !== 'object' || body === null) return { ok: false, error: 'Body must be a JSON object' };
  const b = body as Record<string, unknown>;
  if (typeof b.baseVersion !== 'number' || b.baseVersion < 0) return { ok: false, error: '"baseVersion" must be a non-negative integer' };
  if (typeof b.deviceId !== 'string' || !b.deviceId) return { ok: false, error: '"deviceId" is required' };
  if (typeof b.saltB64 !== 'string' || !b.saltB64) return { ok: false, error: '"saltB64" is required' };
  if (typeof b.ivB64 !== 'string' || !b.ivB64) return { ok: false, error: '"ivB64" is required' };
  if (typeof b.ciphertextB64 !== 'string' || !b.ciphertextB64) return { ok: false, error: '"ciphertextB64" is required' };
  return { ok: true, value: b as unknown as PushBody };
}

export function handleGetSync(res: ServerResponse, store: SyncStore): void {
  const record = store.get();
  if (!record) {
    sendJSON(res, 404, { error: { message: 'No sync data yet — this device should push first.', code: 'no_sync_data' } });
    return;
  }
  sendJSON(res, 200, record);
}

export async function handlePutSync(
  req: IncomingMessage,
  res: ServerResponse,
  store: SyncStore,
  log: Logger
): Promise<void> {
  let body: unknown;
  try {
    body = await readJSONBody(req);
  } catch (e: any) {
    const status = e instanceof BodyTooLargeError ? 413 : 400;
    sendError(res, status, e.message, e instanceof BodyTooLargeError ? 'payload_too_large' : 'invalid_body');
    return;
  }

  const validated = validatePushBody(body);
  if (!validated.ok) {
    sendError(res, 400, validated.error, 'validation_error');
    return;
  }
  const { baseVersion, deviceId, saltB64, ivB64, ciphertextB64 } = validated.value;

  const result = store.putIfVersionMatches(baseVersion, deviceId, saltB64, ivB64, ciphertextB64);
  if (result.ok) {
    log.info('sync push accepted', { deviceId, newVersion: result.record.version });
    sendJSON(res, 200, result.record);
    return;
  }

  // Real, detected conflict: someone else's write landed between this
  // device's last pull and this push. Return 409 + the server's current
  // record so the client can show the user both versions and let them
  // choose — silently overwriting either side would be a real data-loss
  // bug, not a convenience.
  log.warn('sync push rejected: version conflict', { deviceId, expectedBaseVersion: baseVersion, actualVersion: result.current?.version ?? 0 });
  sendJSON(res, 409, {
    error: { message: 'Version conflict — another device pushed changes since your last sync.', code: 'sync_conflict' },
    current: result.current,
  });
}

export function handleDeleteSync(res: ServerResponse, store: SyncStore, log: Logger): void {
  store.delete();
  log.info('sync data deleted');
  sendJSON(res, 200, { deleted: true });
}
