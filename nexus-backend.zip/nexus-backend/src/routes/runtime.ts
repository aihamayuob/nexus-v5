import { randomUUID } from 'node:crypto';
import type { IncomingMessage, ServerResponse } from 'node:http';
import { readJSONBody, sendError, sendJSON, startSSE, writeSSEFrame, BodyTooLargeError } from '../lib/httpUtil.js';
import type { Logger } from '../lib/logger.js';
import type { StreamBuffer } from '../lib/streamBuffer.js';
import { createPlan } from '../runtime/planner.js';
import { runPlan } from '../runtime/executor.js';
import { DEFAULT_RUNTIME_CONFIG, PlanValidationError, validatePlan } from '../runtime/types.js';
import type { Plan, RuntimeConfig, RuntimeEvent } from '../runtime/types.js';
import type { ProviderAdapter } from '../providers/types.js';

interface RuntimeCtx {
  providers: Map<string, ProviderAdapter>;
  buffer: StreamBuffer;
  log: Logger;
}

function toWireFrame(ev: RuntimeEvent): { event: string; data: string } {
  return { event: ev.type, data: JSON.stringify(ev) };
}

export async function handlePostRuntimePlan(req: IncomingMessage, res: ServerResponse, ctx: RuntimeCtx): Promise<void> {
  let body: any;
  try {
    body = await readJSONBody(req);
  } catch (e: any) {
    const status = e instanceof BodyTooLargeError ? 413 : 400;
    sendError(res, status, e.message, e instanceof BodyTooLargeError ? 'payload_too_large' : 'invalid_body');
    return;
  }

  if (typeof body?.goal !== 'string' || !body.goal.trim()) {
    sendError(res, 400, '"goal" is required', 'validation_error');
    return;
  }
  const provider = typeof body.provider === 'string' ? body.provider : DEFAULT_RUNTIME_CONFIG.defaultProvider;
  const model = typeof body.model === 'string' ? body.model : DEFAULT_RUNTIME_CONFIG.defaultModel;
  const adapter = ctx.providers.get(provider);
  if (!adapter) {
    sendError(res, 400, `Unknown or unconfigured provider "${provider}"`, 'unknown_provider');
    return;
  }

  const controller = new AbortController();
  res.on('close', () => controller.abort());

  try {
    const plan = await createPlan(body.goal, adapter, model, controller.signal);
    sendJSON(res, 200, plan);
  } catch (e: any) {
    if (e instanceof PlanValidationError) {
      sendError(res, 502, `Planner produced an invalid plan even after a retry: ${e.message}`, 'plan_invalid');
      return;
    }
    ctx.log.error('plan creation failed', { error: String(e?.message ?? e) });
    sendError(res, 502, `Plan creation failed: ${String(e?.message ?? e)}`, 'plan_creation_failed');
  }
}

export async function handlePostRuntimeRun(req: IncomingMessage, res: ServerResponse, ctx: RuntimeCtx): Promise<void> {
  let body: any;
  try {
    body = await readJSONBody(req);
  } catch (e: any) {
    const status = e instanceof BodyTooLargeError ? 413 : 400;
    sendError(res, status, e.message, e instanceof BodyTooLargeError ? 'payload_too_large' : 'invalid_body');
    return;
  }

  const plan = body?.plan as Plan;
  if (!plan || !Array.isArray(plan.tasks)) {
    sendError(res, 400, '"plan" ({goal, tasks[]}) is required', 'validation_error');
    return;
  }
  try {
    validatePlan(plan);
  } catch (e: any) {
    sendError(res, 400, e.message, 'plan_invalid');
    return;
  }

  const config: RuntimeConfig = {
    ...DEFAULT_RUNTIME_CONFIG,
    ...(body.config && typeof body.config === 'object' ? body.config : {}),
  };
  if (!ctx.providers.has(config.defaultProvider)) {
    sendError(res, 400, `Default provider "${config.defaultProvider}" is not configured on this backend.`, 'unknown_provider');
    return;
  }

  const requestId = randomUUID();
  const controller = new AbortController();
  ctx.buffer.create(requestId, controller);
  res.on('close', () => controller.abort());

  startSSE(res);
  const startFrame = { event: 'start', data: JSON.stringify({ requestId }) };
  const startEntry = ctx.buffer.append(requestId, startFrame.event, startFrame.data)!;
  writeSSEFrame(res, startEntry.id, startEntry.event, startEntry.data);

  try {
    for await (const ev of runPlan(plan, { adapters: ctx.providers, config }, controller.signal)) {
      const frame = toWireFrame(ev);
      const entry = ctx.buffer.append(requestId, frame.event, frame.data);
      if (entry) writeSSEFrame(res, entry.id, entry.event, entry.data);
    }
  } catch (e: any) {
    if (e?.name !== 'AbortError') {
      ctx.log.error('runtime execution failed', { requestId, error: String(e?.message ?? e) });
      const frame = { event: 'plan_error', data: JSON.stringify({ type: 'plan_error', message: String(e?.message ?? e) }) };
      const entry = ctx.buffer.append(requestId, frame.event, frame.data);
      if (entry) writeSSEFrame(res, entry.id, entry.event, entry.data);
    }
  } finally {
    ctx.buffer.markFinished(requestId);
    res.end();
  }
}
