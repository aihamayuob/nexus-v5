import type { Router, RouteContext } from '../../gateway/router.js';
import { listModelsMetadata } from '../../providers/modelRouter.js';
import { getRepos } from '../../persistence/repos.js';
import { BudgetGuard } from '../../orchestrator/budget.js';
import { taskManagerStatus } from '../../orchestrator/taskManager.js';
import { assertNoSecretLeak } from '../../security/secrets.js';

const API_VERSION = 2;

export function registerV2Routes(router: Router) {
  router.get(
    '/v2/health',
    async (ctx: RouteContext) => {
      ctx.res.writeHead(200, { 'Content-Type': 'application/json' });
      ctx.res.end(JSON.stringify({ ok: true, version: API_VERSION, ...taskManagerStatus() }));
    },
    { skipAuth: true }
  );

  router.get('/v2/models', async (ctx: RouteContext) => {
    const payload = { version: API_VERSION, providers: listModelsMetadata() };
    assertNoSecretLeak(payload);
    ctx.res.writeHead(200, { 'Content-Type': 'application/json' });
    ctx.res.end(JSON.stringify(payload));
  });

  router.get('/v2/observability', async (ctx: RouteContext) => {
    const limit = Math.min(200, Number(ctx.query.get('limit') || '50') || 50);
    const route = ctx.query.get('route') || undefined;
    const recent = getRepos().observability.recent(limit, route);
    const aggregate = getRepos().observability.aggregate(limit);
    ctx.res.writeHead(200, { 'Content-Type': 'application/json' });
    ctx.res.end(JSON.stringify({ version: API_VERSION, recent, aggregate }));
  });

  router.get('/v2/budget', async (ctx: RouteContext) => {
    ctx.res.writeHead(200, { 'Content-Type': 'application/json' });
    ctx.res.end(JSON.stringify({ version: API_VERSION, ...BudgetGuard.status() }));
  });
}
