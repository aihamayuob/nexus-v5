import { randomBytes } from 'node:crypto';
import type { IncomingMessage, ServerResponse } from 'node:http';
import { sendError, sendJSON } from '../lib/httpUtil.js';
import type { Logger } from '../lib/logger.js';
import type { Env } from '../config/env.js';
import { buildGoogleAuthUrl, decodeIdToken, exchangeCodeForTokens, GoogleOAuthError } from '../accounts/googleOAuth.js';
import { generateToken } from '../accounts/tokens.js';
import { serializeCookie, serializeExpiredCookie } from '../accounts/cookies.js';
import { SESSION_COOKIE_NAME, resolveIdentity } from '../accounts/authMiddleware.js';
import type { AccountsStore } from '../accounts/store.js';

// Short-lived CSRF state for the OAuth round trip — a few minutes is
// plenty; this never needs to survive a restart, so in-memory is fine
// (same reasoning as the existing StreamBuffer's TTL'd in-memory design).
const OAUTH_STATE_TTL_MS = 5 * 60 * 1000;
const pendingStates = new Map<string, number>();
function sweepStates() {
  const cutoff = Date.now() - OAUTH_STATE_TTL_MS;
  for (const [state, createdAt] of pendingStates) if (createdAt < cutoff) pendingStates.delete(state);
}

export function handleGetAuthGoogleStart(res: ServerResponse, env: Env): void {
  if (!env.GOOGLE_CLIENT_ID || !env.GOOGLE_REDIRECT_URI) {
    sendError(res, 501, 'Google OAuth is not configured on this backend (GOOGLE_CLIENT_ID/GOOGLE_REDIRECT_URI unset).', 'oauth_not_configured');
    return;
  }
  sweepStates();
  const state = randomBytes(24).toString('base64url');
  pendingStates.set(state, Date.now());
  const url = buildGoogleAuthUrl(env.GOOGLE_CLIENT_ID, env.GOOGLE_REDIRECT_URI, state);
  res.writeHead(302, { location: url });
  res.end();
}

export async function handleGetAuthGoogleCallback(
  req: IncomingMessage,
  res: ServerResponse,
  url: URL,
  env: Env,
  store: AccountsStore,
  log: Logger
): Promise<void> {
  const code = url.searchParams.get('code');
  const state = url.searchParams.get('state');
  const errorParam = url.searchParams.get('error');

  const redirectBase = env.PUBLIC_APP_URL_FOR_REDIRECT || '/';

  if (errorParam) {
    res.writeHead(302, { location: `${redirectBase}?auth_error=${encodeURIComponent(errorParam)}` });
    res.end();
    return;
  }
  if (!code || !state || !pendingStates.has(state)) {
    res.writeHead(302, { location: `${redirectBase}?auth_error=invalid_state` });
    res.end();
    return;
  }
  pendingStates.delete(state); // one-time use

  if (!env.GOOGLE_CLIENT_ID || !env.GOOGLE_CLIENT_SECRET || !env.GOOGLE_REDIRECT_URI) {
    sendError(res, 501, 'Google OAuth is not configured on this backend.', 'oauth_not_configured');
    return;
  }

  try {
    const tokens = await exchangeCodeForTokens(code, env.GOOGLE_CLIENT_ID, env.GOOGLE_CLIENT_SECRET, env.GOOGLE_REDIRECT_URI, fetch);
    const claims = decodeIdToken(tokens.idToken, env.GOOGLE_CLIENT_ID);
    if (!claims.emailVerified) {
      res.writeHead(302, { location: `${redirectBase}?auth_error=email_not_verified` });
      res.end();
      return;
    }

    const user = store.findOrCreateUserByGoogle(claims.sub, claims.email, claims.name, claims.picture);
    const session = generateToken();
    store.createSession(user.id, session.hash, env.SESSION_TTL_MS);
    store.logAudit(null, user.id, 'auth.login', { method: 'google' });

    const isHttps = (env.PUBLIC_APP_URL_FOR_REDIRECT ?? '').startsWith('https://');
    res.writeHead(302, {
      location: redirectBase,
      'set-cookie': serializeCookie(SESSION_COOKIE_NAME, session.raw, {
        maxAgeSeconds: Math.floor(env.SESSION_TTL_MS / 1000),
        secure: isHttps,
        // SameSite=Lax (the default) requires the cookie's Secure flag
        // to match reality — Chrome and Firefox both silently drop a
        // Secure cookie set over plain http://, which is exactly what
        // was happening here before this fix (confirmed with a real
        // browser: zero cookies were kept, breaking login completely
        // for local http://localhost development — a Node-based fetch()
        // test never would have caught this, since Node's fetch doesn't
        // enforce browser cookie security policy).
      }),
    });
    res.end();
  } catch (e: any) {
    log.warn('Google OAuth callback failed', { error: String(e?.message ?? e) });
    const code = e instanceof GoogleOAuthError ? 'oauth_failed' : 'internal_error';
    res.writeHead(302, { location: `${redirectBase}?auth_error=${code}` });
    res.end();
  }
}

export function handlePostAuthLogout(req: IncomingMessage, res: ServerResponse, store: AccountsStore, env: Env): void {
  const identity = resolveIdentity(req, store);
  if (identity && !identity.viaApiKeyWorkspaceId) {
    // only clear an actual session (not applicable when authed via API key)
  }
  const isHttps = (env.PUBLIC_APP_URL_FOR_REDIRECT ?? '').startsWith('https://');
  res.setHeader('set-cookie', serializeExpiredCookie(SESSION_COOKIE_NAME, '/', isHttps));
  sendJSON(res, 200, { loggedOut: true });
}

export function handleGetAuthMe(req: IncomingMessage, res: ServerResponse, store: AccountsStore): void {
  const identity = resolveIdentity(req, store);
  if (!identity) {
    sendError(res, 401, 'Not signed in.', 'unauthorized');
    return;
  }
  sendJSON(res, 200, {
    id: identity.user.id,
    email: identity.user.email,
    name: identity.user.name,
    avatarUrl: identity.user.avatarUrl,
  });
}
