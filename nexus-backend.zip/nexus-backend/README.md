# nexus-backend

Central runtime for Neural Nexus AI Agents. The frontend is now a **client /
control plane**: it renders UI and sends requests, but orchestration —
routing, retries, provider fallback, DAG execution, checkpoints, budget
enforcement, tool execution, observability — lives here.

Zero external runtime dependencies. Node.js built-ins only (`node:http`,
`node:sqlite`, `node:crypto`, `node:dns`, native `fetch`). TypeScript via
`tsx`. This was a deliberate constraint, not an accident: it means there is
no `npm install` supply-chain surface for the runtime path, and the whole
thing runs anywhere a recent Node binary does.

## Quick start

```bash
cp .env.example .env        # fill in the provider keys you actually have
npm run typecheck           # tsc --noEmit
npm test                    # node:test, 28 tests, no network required
npm run dev                 # tsx watch src/index.ts
```

Requires Node ≥ 22.5 (for `node:sqlite`). Tested against Node 22.22.2.

## Architecture

```
API Gateway (gateway/router.ts)
  → Auth (gateway/middleware/auth.ts) — Bearer gateway keys, trusted mode if none configured
  → Rate limiting (gateway/middleware/rateLimit.ts) — token bucket per client key
  → Nexus Task Manager (orchestrator/taskManager.ts) — durable task records, concurrency limits, idempotency, cancellation
    → Intent / Routing (intent/intentEngine.ts, providers/modelRouter.ts) — risk/complexity heuristics, provider+model resolution, fallback chain
    → Agent Runtime / DAG (orchestrator/dag.ts + dagRunner.ts + planner.ts) — dependency-aware parallel execution, retry, reflection, failure propagation, resume
    → Model Router → Provider Adapters (providers/*Adapter.ts) — one contract, six vendors
      → Tool Runtime (tools/registry.ts, tools/pipeline.ts) — Registry → Capability Check → Permission Check → Validation → Execution → Timeout → Sanitization → Result
      → Context / Memory (memory/contextFabric.ts, memory/embeddingsService.ts) — server-hostable knowledge retrieval, deduped+cached+batched embeddings
      → Verification (orchestrator/verifier.ts) — independent skeptical review, gated by intent
      → Persistence (persistence/*) — SQLite: tasks, checkpoints, DAG node state, resumable stream events, observability, audit, embeddings cache, sync, schedules
      → Observability (observability/recorder.ts) — durable, queryable, per-task (not a browser ring buffer)
```

### Provider Registry — single source of truth

`src/config/providerRegistry.ts` is the **only** place a model id, base URL,
or capability flag is ever written. Every adapter, the model router, the
capability graph, and `GET /v2/models` all read from it. Defaults are
overridable via env (`NEXUS_MODEL_ANTHROPIC` etc.) specifically so a vendor
shipping a new model is a config change, not a code change — this is the
direct backend-side fix for the exact class of bug the frontend audit found
repeatedly (a hardcoded model string surviving in one forgotten corner).

### Unified provider contract

Every adapter (`providers/{anthropic,openai,deepseek,gemini,ollama,lmstudio}Adapter.ts`)
implements the same `ProviderAdapter` interface and speaks the same
Anthropic-Messages-shaped `ChatRequest`/`ChatResponse` internally — that
specific shape was chosen because it's what the frontend's existing
`/api/chat` contract already expects, so the legacy route is a thin
pass-through rather than a translation layer of its own. OpenAI, DeepSeek,
and LM Studio share one translation module (`providers/openaiCompatible.ts`)
since all three speak OpenAI's Chat Completions API; Gemini and Ollama have
their own adapters since their wire formats genuinely differ (verified
against current API docs, not assumed from memory — see `geminiAdapter.ts`).

### DAG executor

`orchestrator/dag.ts` is pure scheduling logic — dependency resolution,
concurrency limits, retry, cascading failure propagation, optional
reflection/revision, resume from a partial state — with the actual model
calls injected as functions (`runNode`/`reflect`/`synthesize`). This means
the scheduler itself is fully unit-tested (`test/dag.test.ts`, 8 tests) with
zero network and zero real model calls; `orchestrator/dagRunner.ts` is the
thin layer that wires real `chatService` calls into those injection points.

`/api/runtime/plan` and `/api/runtime/run` are no longer a path beside
Nexus Core — they're the DAG executor running as one Task-Manager-governed
task, same as a chat completion. Concurrency limits, budget checks,
observability, and checkpointing all apply uniformly.

### Durable execution, checkpoints, resume

Every DAG node's status/output is persisted to `dag_nodes` as it changes
(not just logged) and the plan's own definition (goal + task list) is
checkpointed once at the start. `resumeInterruptedPlans()` runs once at
process startup, finds any plan left non-terminal by an unclean shutdown,
and picks it back up from its last completed node — `test/dag.test.ts`'s
"resume seeds already-done nodes without re-running them" test covers the
scheduling half of this; the persistence half is exercised by the
integration suite indirectly through `checkpointRepo`.

### Resumable SSE streams

Every event emitted on a task's stream is written to `stream_events`
**before** being broadcast to any live connection (`orchestrator/streamRegistry.ts`).
`GET /api/chat/resume/:requestId?afterId=N` (existing contract) and the new
`GET /api/runtime/resume/:taskId?afterId=N` both replay from that durable
log, then attach live for anything still to come — the same mechanism
backs both endpoints.

### Tool Runtime

`tools/pipeline.ts` is the **only** path by which a tool executes:
Registry lookup → Capability Check → Permission Check → Validation →
Execution → Timeout → Sanitization → Result. It only ever accepts a
`{id, name, input}` triple sourced from a provider's own structured
`tool_use` response block — nothing in this backend scans free text (tool
results, fetched web pages, knowledge content) for command-like phrases
and acts on it. That structural fact is what actually prevents prompt
injection from becoming a tool call; see `security/promptInjectionGuard.ts`'s
header comment for the full reasoning.

Two tools are registered server-side: `web_fetch` (through the SSRF guard)
and `calculate` (a real recursive-descent parser, not `eval`). `create_file`
stays client-only (it writes to the end user's own device — nothing for a
stateless backend to do there); `web_search` is executed natively by
Anthropic itself and never reaches this pipeline.

### Security

- **SSRF guard** (`security/ssrfGuard.ts`): resolves DNS, validates the IP
  isn't in a private/loopback/link-local/metadata/multicast range, then
  **pins the actual TCP connection to that validated IP** via a custom
  `lookup` — this closes the DNS-rebinding gap between "we checked" and
  "we connected", not just a hostname string check. Every redirect hop is
  independently re-validated. Verified live in tests against
  `127.0.0.1` and the `169.254.169.254` cloud-metadata address.
- **Secrets**: API keys are read only from `process.env` inside adapter
  construction, never persisted, never logged, never returned in any
  response — `security/secrets.ts::assertNoSecretLeak()` is a defense-in-depth
  check called before `GET /v2/models` serializes its response, and the
  integration test asserts a live key never appears in that payload.
- **Auth**: Bearer gateway keys, `timingSafeEqual` comparison, binary
  trusted/mandatory — no partial state where a key is "checked if present".
- **Budget guard**: rolling-24h USD cap, enforced before every model call
  and every tool call.
- **Audit trail**: every security-relevant event (auth failure, SSRF block,
  tool denial, budget stop) funnels through one function
  (`security/audit.ts::auditSecurityEvent`) that both logs and durably
  persists.
- **No chain-of-thought logging**: `observability/recorder.ts` only ever
  records metadata (agent ids, model/provider names, tool names, latency,
  token counts, cost, a verification verdict + issue *count*) — never raw
  prompts, completions, or a verifier's critique text. `core/logger.ts` has
  a truncation backstop as defense in depth on top of that discipline.

### Migration — nothing broke

Every endpoint the frontend already calls still exists with the exact same
request/response/SSE shape, now implemented as a thin wrapper over the
unified Task Manager instead of a standalone handler:
`/api/chat` (+ `/api/chat/resume/:id`), `/api/runtime/plan`,
`/api/runtime/run`, `/api/embed`, `/api/tools/fetch`, `/api/market-context`,
`/api/audit/veto`, `/api/schedules`, `/api/sync`. Nothing was deleted.
New, additive-only endpoints: `/api/runtime/resume/:taskId`,
`/api/runtime/:taskId/cancel`, and the `/v2/*` namespace
(`/v2/health`, `/v2/models`, `/v2/observability`, `/v2/budget`).

## Known gaps / honest limitations (flagged, not hidden)

1. **`/api/embed` has no auth check even in an authenticated deployment.**
   The frontend's current `getEmbedding()` call sends no `Authorization`
   header (verified by reading the frontend source directly, not assumed).
   Since this task couldn't touch the frontend, the compatibility-first
   choice was to leave this route `skipAuth: true` rather than break
   embeddings for everyone the moment gateway keys are configured. **This
   should be revisited** the next time the frontend is in scope: add the
   header client-side, then remove `skipAuth` here.
2. **`/api/market-context` is a stub.** No specific market-data vendor was
   specified, so this returns `{available: false}` rather than guessing an
   API and baking in a dependency. It's wired to route through the same
   `safeFetch()` SSRF guard the moment a real provider is chosen.
3. **Provider adapters are verified against real, current API
   documentation and exercised end-to-end against fake servers that speak
   each wire format**, but never against the real hosted APIs — this
   sandbox has no outbound internet access. Before production use, run one
   real request per provider (a single `curl` against `/api/chat` with a
   real key configured is enough) to catch any drift between documented
   and actual behavior.
4. **`node:sqlite` is still an experimental Node API** (stable enough to
   use without a flag as of Node 22.22, but Node itself labels it
   experimental). If your deployment target is an older/different Node
   build where this isn't available, swap `persistence/db.ts`'s import for
   any other embedded SQL store — every repository only talks to that one
   file.
5. **Cost estimates in `orchestrator/budget.ts` are approximate**, not
   billing-grade — they're a safety-guard input, not an invoice.

## Testing

```bash
npm test
```

28 tests, ~3.5s, zero network access required:
- `test/dag.test.ts` (8) — scheduler correctness in isolation: dependency
  order, concurrency limits, failure cascade, retry, reflection, resume,
  cycle detection.
- `test/embeddingsService.test.ts` (4) — dedup, cache reuse across calls,
  batching, mixed hit/miss.
- `test/integration.test.ts` (9) — the **real** HTTP server, started live,
  talking to a fake Anthropic-shaped server over loopback: health, models
  metadata (no key leak), chat non-streaming, chat streaming (real SSE
  parsing, monotonic event ids), a full tool-use round trip (model asks
  for `calculate`, backend executes it, model gets the result and answers),
  a full DAG plan+run (2 dependent nodes, real `task_start`/`task_done`/
  `plan_done` events), SSRF blocks against two real target categories,
  and a malformed-provider validation error.
- `test/authGateway.test.ts` (6) — auth actually enforced with keys
  configured, actually open with none, `skipAuth` routes correctly bypass it.
- `test/providerFallback.test.ts` (1) — primary provider hard-fails (503),
  request transparently falls back to a configured secondary provider and
  still succeeds — verified live, not mocked at the function level.

Two real bugs were caught and fixed by these tests during development, not
just written to pass: an adapter-config-caching interaction that made a
mid-process base-URL change silently ineffective (a test-authoring bug that
also documents genuine adapter caching semantics worth knowing), and raw
network failures (`ECONNREFUSED`, "fetch failed") being misclassified as
non-retryable — which would have silently defeated retry/fallback for the
single most common real-world failure mode. Both fixes are in
`src/core/errors.ts` and `src/providers/index.ts`.
