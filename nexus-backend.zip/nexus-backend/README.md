# nexus-backend

Streaming AI gateway for **Neural Nexus AI Agents** — Phase 1 (real streaming)
of the platform roadmap, plus the Phase 4 provider-adapter foundation as a
byproduct of building streaming correctly.

## What this is

A standalone backend, zero runtime dependencies, that:
- Speaks true SSE streaming to the browser, normalized to one wire format
  regardless of which upstream provider served the request
- Supports Anthropic, OpenAI, DeepSeek, OpenRouter, Mistral, Gemini,
  Ollama, and LM Studio, via 3 adapter implementations
- Preserves the **exact** non-streaming response shape your existing
  frontend's `callClaude()` already parses — every call site that doesn't
  opt into streaming keeps working with zero changes
- Handles cancellation (closing the connection actually aborts the
  upstream provider call — no orphaned billing), reconnection (resume a
  dropped stream from where it left off), rate limiting, and auth
- Provides end-to-end encrypted multi-device sync (`/api/sync`) — the
  server stores exactly one opaque encrypted blob + a version number and
  never sees plaintext, a passphrase, or an encryption key
- Provides a real Agent Runtime (`/api/runtime/*`) — a goal gets
  decomposed into a dependency graph of tasks by an LLM planner, then
  executed with genuine parallelism, retries, a reflection/critique
  loop, and context compression, not just a fixed hand-written sequence

## Cloud Sync — how it actually works

The frontend derives an AES-256-GCM key from the same passphrase used to
unlock "sensitive data" (PBKDF2, 150k iterations — see `deriveKey()` in
the frontend). That key, and the passphrase it comes from, **never reach
this backend**. What the backend stores per sync record:

| field | secret? | purpose |
|---|---|---|
| `ciphertextB64` | opaque | the encrypted app state — meaningless without the key |
| `ivB64` | not secret | AES-GCM IV, safe to store alongside ciphertext |
| `saltB64` | not secret | PBKDF2 salt — its whole purpose is to be public; a second device fetches this to derive the *same* key from the *same* passphrase |
| `version`, `deviceId`, `updatedAt` | not secret | bookkeeping only |

**Conflict handling is real, not hand-waved.** Writes use optimistic
concurrency: a push must include the `baseVersion` it last saw. If
another device pushed in the meantime, the push is rejected with `409`
and the actual current record, and the frontend shows an explicit
"keep this device / keep the cloud" choice — arbitrary JSON app state
(message arrays, knowledge base entries, etc.) is not safe to silently
auto-merge, so this codebase doesn't pretend to.

**Storage**: `node:sqlite` — Node's built-in SQLite module (stable since
Node 22.5, no `npm install` needed). This is why `package.json` now
requires `>=22.5.0` even though only the sync feature needs it.

## Accounts, RBAC & Billing (Phase 7) — additive, doesn't touch anything earlier

This is a real multi-user layer — Google OAuth, workspaces, roles, invites,
workspace-scoped API keys, an audit log, and Paddle subscription billing —
built entirely **alongside** the single-gateway-key model from Phase 1/2,
not replacing it. If `GOOGLE_CLIENT_ID` is unset, none of `/api/auth/*` or
`/api/workspaces/*` are reachable and every earlier route behaves exactly
as before. Routes under those prefixes (plus `/api/billing/*`) are
deliberately exempt from the gateway-key check — they authenticate via
their own session cookie / workspace API key / Paddle signature instead,
since a real signed-in user has no reason to know the deployment's
gateway key at all.

**Why Paddle and not Stripe/LemonSqueezy**: as of when this was built,
LemonSqueezy is being folded into "Stripe Managed Payments" (Stripe's
own MoR product) — meaning it's no longer independent of Stripe's own
merchant-eligibility restrictions. Paddle remains a genuinely separate
company. Neither is guaranteed to work for every jurisdiction; check
current eligibility for your situation before going live.

**RBAC** (`src/accounts/rbac.ts`): four roles — owner > admin > member >
viewer — with every permission check going through one central matrix
rather than scattered role comparisons in route handlers. One rule
beyond simple rank comparison: an admin can never remove or demote the
owner, and nobody can act on a peer of equal rank — both are real
privilege-escalation patterns that a naive "rank >= required rank" check
alone doesn't catch.

**Google OAuth** (`src/accounts/googleOAuth.ts`): standard
authorization-code flow. The id_token's signature is deliberately *not*
re-verified against Google's JWKS — it was obtained by exchanging a code
directly with Google's token endpoint over TLS, authenticated with our
own client_secret, so Google's response is already the trusted source
here (unlike a browser-side Google Sign-In SDK handing a token to a
backend that has no other reason to trust it, which genuinely would need
local signature verification). `aud`/`iss`/`exp` are still checked as
defense-in-depth.

**Sessions**: a random token's SHA-256 hash is stored, never the raw
token — a database read alone can never yield a usable session, same
principle as password hashing. **Real bug found and fixed during
development**: the session cookie was unconditionally marked `Secure`,
which real browsers silently drop when set from a plain `http://`
origin — confirmed with an actual Playwright browser (zero cookies kept,
login completely broken for local `http://localhost` development), not
just a theoretical concern. It's now derived from whether
`PUBLIC_APP_URL_FOR_REDIRECT` is actually `https://`.

**Paddle webhooks** (`src/accounts/paddleWebhook.ts`): signed payload is
`{timestamp}:{raw_body}` — genuinely raw, unparsed bytes; a
JSON.parse-then-stringify round-trip before verifying is a real,
documented way this breaks. Comparison is timing-safe (there's a
tracked CVE-class vulnerability for using a plain `==`/`===` here,
which is exactly why `timingSafeEqual` is used instead), and timestamps
older than 5 minutes are rejected as possible replays.

## Tools (Phase 6, partial) — `/api/tools/fetch`

`POST /api/tools/fetch` with `{url}` fetches a page and returns readable
text (`src/tools/webFetch.ts` + `src/routes/tools.ts`), for use as a
model tool call. This is the one Phase 6 tool built so far, and it's
built with real SSRF protection, not a token gesture:

- **Resolves DNS and checks the actual IP**, not the hostname string —
  blocks loopback, all the RFC1918 private ranges, carrier-grade NAT,
  and specifically `169.254.0.0/16` (where every major cloud provider's
  instance-metadata endpoint lives — the classic SSRF-to-stolen-credentials
  path). IPv4-mapped IPv6 addresses are unwrapped and re-checked too,
  since `::ffff:169.254.169.254` is a well-known way to smuggle a
  blocked target past a check that only looks at IPv6 syntax.
- **Re-validates on every redirect hop**, not just the original URL — a
  request to a legitimate-looking host that 302s to an internal address
  is caught, because the redirect target's DNS gets resolved and checked
  exactly like the original did. (This is the check that actually
  matters; a version that only validated the initial URL would look
  secure and not be.)
- Bounded: 10s timeout, 2MB response cap, max 5 redirects, and the text
  handed to the model is capped at 8000 characters regardless of page
  size.

**Honest scope note**: this is one tool, not "a tools ecosystem." Python
execution, git, filesystem access, SQL, and OCR all need real sandboxing
(containers/gVisor/Firecracker) or a specific integration decision
(which OCR service? filesystem scoped to what?) that I'm not making
unilaterally — see the conversation for the options laid out for each.

## Agent Runtime — how it actually works

`POST /api/runtime/plan` takes `{goal, provider?, model?}` and returns a
validated `{goal, tasks: [{id, description, dependsOn}]}` — a real DAG,
not a linear script. The planner (`src/runtime/planner.ts`) asks the
model for structured JSON, and if the first attempt is malformed (bad
JSON, a dependency cycle, a dangling reference), the *specific* error is
fed back for one corrective retry before giving up.

`POST /api/runtime/run` takes `{plan, config?}` and executes it over SSE
(same normalized-event/reconnect/cancel machinery as Phase 1's chat
streaming — the existing `/api/chat/resume/:id` and `DELETE /api/chat/:id`
routes work for runtime streams too, since both share one `StreamBuffer`
keyed by request id). The executor (`src/runtime/executor.ts`):
- Runs every task whose dependencies are all `done`, up to `maxConcurrency`
  at once — independent tasks genuinely overlap in wall-clock time, not
  just conceptually (verified in tests: two independent tasks start
  within milliseconds of each other, not one after the other).
- Retries a failed task with exponential backoff (`maxRetriesPerTask`,
  default 2), and marks any task whose dependency permanently failed as
  `skipped` — it never silently runs a task with broken/missing context.
- Runs a bounded reflection pass after each task (`src/runtime/reflection.ts`):
  a critic call asks whether the output actually satisfies the task's
  description; a `revise` verdict triggers exactly one retry with the
  critique appended, then moves on regardless (reflection is a quality
  pass, not an infinite-nitpicking gate — a broken critic can never block
  a plan from finishing).
- Compresses accumulated dependency context via one LLM summarization
  call only once it would exceed `contextCompressionThresholdChars`
  (`src/runtime/memory.ts`) — small contexts are passed through verbatim
  with zero extra calls, zero extra cost.
- Finishes with one synthesis call combining every successful task's
  output into a single coherent answer (`plan_done`).

**Honest scope note**: each task is a plain LLM call (with streaming) —
the client-side tool loop from Phase 1 (`create_file`, etc.) is not yet
wired into runtime tasks. A task's `description` can still ask the model
to use a provider's own *server-side* tools (e.g. Anthropic's built-in
web search) if you pass `tools` through, but there's no mechanism yet
for a runtime task to pause, ask the browser to execute a client tool,
and resume with the result — that's a real architectural gap, not an
oversight I'm hiding: it needs the browser to stay in the loop for a
server-orchestrated multi-step plan, which is a genuinely different
integration than the existing single-request tool loop.

## What this deliberately is not (yet)

This is Phase 1 + the Phase 4 foundation + Phase 3 (cloud sync) + Phase 5
(agent runtime) + Phase 6 (partial: one tool) + Phase 7 (accounts/RBAC/
billing), not the full 9-phase brief. Still missing: sandboxed code
execution and the rest of a real tools ecosystem (git, filesystem, SQL,
OCR — each needs its own infrastructure decision, not a unilateral
choice), and Phase 8/9 (performance, restructuring) haven't touched this
backend specifically (Phase 8 was done on the frontend). Those are each
independent efforts with their own decisions that need your input before
I build them — see the roadmap in our conversation.

**Frontend integration status, honestly**: the backend routes above are
complete and tested (276 tests). The frontend (`nexus.html`) does **not**
yet have a login button, workspace switcher, or member-management UI
wired up to any of this — that's real, separate work I haven't done yet,
not something quietly working that I forgot to mention.

## Quick start

```bash
cd nexus-backend
cp .env.example .env
# edit .env: set GATEWAY_API_KEY (openssl rand -hex 32) and at least one provider key
npm install
npm test        # runs all 3 test suites — should print "N passed, 0 failed" three times
npm run dev      # starts on http://localhost:8787
```

Point your frontend at it: in the app's settings, set the backend URL to
`http://localhost:8787` (or wherever you deploy it), and store
`GATEWAY_API_KEY` as the bearer token the frontend sends.

## Auth model, honestly

There's one shared `GATEWAY_API_KEY` for the whole backend — this is a
personal/small-team gateway, not multi-tenant SaaS auth. Every request
needs `Authorization: Bearer <GATEWAY_API_KEY>`. Per-user accounts, OAuth,
and role-based permissions are Phase 7 (Enterprise) territory and are a
separate, much larger piece of work — flagged in the roadmap, not silently
skipped.

## Wire protocol (backend → browser)

**Non-streaming** (`stream` omitted or `false`): response body is exactly
Anthropic's Messages API shape (`content`, `stop_reason`, `usage`) —
regardless of which provider actually served it. Every provider's response
is translated into this shape server-side.

**Streaming** (`stream: true`): `Content-Type: text/event-stream`, one
normalized event type per frame:

| event            | data                                      |
|-------------------|--------------------------------------------|
| `start`            | `{ requestId }`                            |
| `token`            | `{ text }`                                 |
| `tool_use_start`   | `{ id, name }`                             |
| `tool_use_delta`   | `{ id, partialJson }` — accumulate by `id`, `JSON.parse` once complete |
| `usage`            | `{ inputTokens, outputTokens }`            |
| `error`            | `{ message, retryable, code }`             |
| `done`             | `{ stopReason }`                           |

Each frame carries an `id:` (monotonic per request) for resume support.

**Resume a dropped connection:**
`GET /api/chat/resume/:requestId?afterId=<lastReceivedId>` — replays every
buffered event after `afterId`, then keeps streaming live if the original
generation is still running. Buffered for `STREAM_BUFFER_TTL_MS` (default
2 minutes) after the stream starts. Unknown/expired `requestId` → `404`,
meaning: start a new request instead of trying to resume.

**Cancel:** close the connection (covers the common case — navigating
away, closing the tab) or `DELETE /api/chat/:requestId` explicitly.

## Adding a new provider

If it speaks OpenAI's `chat/completions` wire format (most do), it's one
line in `src/providers/registry.ts`:
```ts
registry.set('newprovider', createOpenAICompatAdapter('newprovider', 'https://api.newprovider.com/v1', apiKey));
```
Only a genuinely different wire format needs a new adapter file — copy the
shape of `src/providers/gemini.ts` and implement `ProviderAdapter` from
`src/providers/types.ts`.

## Testing notes

`npm test` runs fifteen suites: SSE/NDJSON parser edge cases (chunk
boundaries, malformed frames), all three adapters against synthetic
upstream responses matching each provider's real documented wire format
(including fragmented tool-call streaming), a full end-to-end test
against a real `http.Server` with the upstream provider call mocked (real
auth, real routing, real SSE writing, real cancellation), two sync
suites (optimistic-concurrency conflict detection at the storage layer,
and the full `/api/sync` HTTP contract including a real 409 conflict),
and three runtime suites (plan validation/cycle-detection, the planner's
JSON-extraction and corrective-retry logic, and — the highest-risk part —
the executor's actual scheduling behavior: verified that independent
tasks start within milliseconds of each other rather than sequentially,
that a dependent task only starts after its dependency reaches `done`
and genuinely receives its output as context, that a permanently-failed
task causes dependents to be `skipped` rather than run with broken
context, that transient failures recover via retry, that a `revise`
reflection verdict actually changes the final output, and that
`maxConcurrency` is a real bound, not just a config value nobody checks).
276 tests total, all executed. Sync was additionally verified with two
independent simulated devices (separate browser contexts, separate local
storage) actually pushing, pulling, decrypting, and resolving a genuine
conflict against a real running instance of this backend — not just each
layer in isolation. There is currently no test against a *real* AI
provider API — that needs your real keys and network access, which I
didn't have while building this.

## Known limitations to know about before you scale this

- **Rate limiter and reconnect buffer are in-process memory** — correct
  and sufficient for one instance, but reset on restart and don't share
  state across multiple instances. Swapping the `Map` in
  `src/lib/rateLimit.ts` for Redis is the whole migration if you ever run
  more than one instance.
- **Sync is one document, not per-object.** The whole app state (all
  conversations, the whole knowledge base, everything in
  `PERSISTABLE_STATE`) syncs as a single encrypted blob. That's why
  conflicts are resolved "keep this device" vs. "keep the cloud" rather
  than per-message or per-note — merging arbitrary nested JSON safely
  would need real CRDT infrastructure, which is a substantially bigger
  (and different) project than this. Fine for personal multi-device use;
  not the right foundation for simultaneous multi-user editing.
- **`SYNC_DB_PATH`'s directory needs to exist or be creatable** — the
  store creates it automatically (`mkdirSync recursive`), but make sure
  the process has write permission wherever you point it, and back the
  file up like you would any database if the data matters to you.
- **No persistent request log / audit trail** — structured logs go to
  stdout/stderr only. Fine for a VPS with log rotation; not enough for
  compliance-grade audit logs (that's Phase 7 territory).
- Built on plain Node `http`, not Fastify, despite the brief's stated
  preference — explained in the main conversation: Fastify wasn't
  installable in the sandbox this was built in, so I couldn't have
  actually executed/proven that version. This one I could, and did. The
  route handlers are already isolated from the transport (`src/app.ts`
  exports a plain `(req, res) => Promise<void>` handler), so porting to
  Fastify later is mechanical, not a rewrite.
