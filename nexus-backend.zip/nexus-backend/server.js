// Neural Nexus AI Agents — Multi-Provider Backend Proxy
// Holds ALL your AI provider API keys safely on the server, and exposes
// one unified endpoint the frontend calls. This is what makes true
// "multi-model consensus" (Claude + GPT + DeepSeek + Gemini all weighing
// in on the same question) possible without ever exposing keys to the browser.

const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const app = express();
app.use(cors()); // In production, restrict this to your app's real domain.
app.use(express.json({ limit: '2mb' }));

// Serve the PWA frontend (index.html, manifest.json, sw.js, icons/) as static
// files from the SAME server/domain as the API. This means one deployment
// (Render/Railway/Fly.io) gives you both a working app AND a working API —
// and it's also what makes "Add to Home Screen" installability reliable,
// since the manifest + service worker need to be real same-origin files.
app.use(express.static(path.join(__dirname, 'public')));

// --- Provider configuration ---
// Model names verified as of July 2026. Override any of these via .env
// without touching code if a provider ships a newer model.
const PROVIDERS = {
  anthropic: {
    apiKey: process.env.ANTHROPIC_API_KEY,
    model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-6',
  },
  openai: {
    apiKey: process.env.OPENAI_API_KEY,
    model: process.env.OPENAI_MODEL || 'gpt-5.5',
  },
  deepseek: {
    apiKey: process.env.DEEPSEEK_API_KEY,
    model: process.env.DEEPSEEK_MODEL || 'deepseek-v4-pro',
  },
  gemini: {
    apiKey: process.env.GEMINI_API_KEY,
    model: process.env.GEMINI_MODEL || 'gemini-3.5-flash',
  },
};

if (!PROVIDERS.anthropic.apiKey) {
  console.error('⚠️  ANTHROPIC_API_KEY is missing. Set it in a .env file (see .env.example).');
  process.exit(1);
}
['openai', 'deepseek', 'gemini'].forEach(p => {
  if (!PROVIDERS[p].apiKey) {
    console.warn(`ℹ️  ${p.toUpperCase()}_API_KEY not set — the ${p} provider will return an error if requested. This is fine if you're not using multi-model consensus yet.`);
  }
});

// --- Simple in-memory rate limiting per IP (swap for Redis in real production) ---
const rateBuckets = new Map();
const RATE_LIMIT = 30;
const RATE_WINDOW_MS = 60000;
function isRateLimited(ip) {
  const now = Date.now();
  const bucket = rateBuckets.get(ip) || [];
  const recent = bucket.filter(ts => now - ts < RATE_WINDOW_MS);
  recent.push(now);
  rateBuckets.set(ip, recent);
  return recent.length > RATE_LIMIT;
}

// --- Per-provider call implementations, all normalized to the same
//     return shape: { content: [{ type: 'text', text: '...' }] }
//     (this is Anthropic's native shape — everything else gets converted to match) ---

async function callAnthropic({ system, messages, max_tokens, tools }) {
  const cfg = PROVIDERS.anthropic;
  const body = { model: cfg.model, max_tokens: Math.min(max_tokens || 1000, 4096), system, messages };
  if (Array.isArray(tools) && tools.length > 0) body.tools = tools;
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': cfg.apiKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify(body),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error?.message || 'Anthropic API error');
  return data; // already in the right shape
}

async function callOpenAICompatible({ system, messages, max_tokens }, providerKey, baseUrl) {
  const cfg = PROVIDERS[providerKey];
  if (!cfg.apiKey) throw new Error(`مزود "${providerKey}" غير مُفعّل — أضف ${providerKey.toUpperCase()}_API_KEY لملف .env على السيرفر ثم أعد تشغيله. راجع .env.example للتفاصيل.`);
  const oaMessages = [{ role: 'system', content: system || '' }, ...messages];
  const res = await fetch(baseUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${cfg.apiKey}` },
    body: JSON.stringify({ model: cfg.model, max_tokens: Math.min(max_tokens || 1000, 4096), messages: oaMessages }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error?.message || `${providerKey} API error`);
  const text = data.choices?.[0]?.message?.content || '';
  // Normalize usage to the same shape as Anthropic's response so the
  // frontend dashboard can read data.usage.{input_tokens,output_tokens}
  // regardless of which provider actually answered.
  const usage = data.usage
    ? { input_tokens: data.usage.prompt_tokens || 0, output_tokens: data.usage.completion_tokens || 0 }
    : undefined;
  return { content: [{ type: 'text', text }], usage };
}

async function callGemini({ system, messages, max_tokens }) {
  const cfg = PROVIDERS.gemini;
  if (!cfg.apiKey) throw new Error('مزود Gemini غير مُفعّل — أضف GEMINI_API_KEY لملف .env على السيرفر ثم أعد تشغيله. راجع .env.example للتفاصيل.');
  // Gemini uses 'model' instead of 'assistant' for the assistant role, and a
  // separate systemInstruction field instead of a system message.
  const contents = messages.map(m => ({
    role: m.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: m.content }],
  }));
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${cfg.model}:generateContent`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-goog-api-key': cfg.apiKey },
    body: JSON.stringify({
      contents,
      systemInstruction: system ? { parts: [{ text: system }] } : undefined,
      generationConfig: { maxOutputTokens: Math.min(max_tokens || 1000, 4096) },
    }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error?.message || 'Gemini API error');
  const text = data.candidates?.[0]?.content?.parts?.map(p => p.text).join('') || '';
  const usage = data.usageMetadata
    ? { input_tokens: data.usageMetadata.promptTokenCount || 0, output_tokens: data.usageMetadata.candidatesTokenCount || 0 }
    : undefined;
  return { content: [{ type: 'text', text }], usage };
}

// --- Unified endpoint ---
app.post('/api/chat', async (req, res) => {
  const ip = req.ip;
  if (isRateLimited(ip)) {
    return res.status(429).json({ error: 'تجاوزت عدد الطلبات المسموح. حاول بعد قليل.' });
  }

  const { provider = 'anthropic', system, messages, max_tokens, tools } = req.body;
  if (!Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ error: 'messages array is required' });
  }
  if (!PROVIDERS[provider]) {
    return res.status(400).json({ error: `Unknown provider: ${provider}` });
  }
  if (Array.isArray(tools) && tools.length > 0 && provider !== 'anthropic') {
    return res.status(400).json({ error: 'Tool use is currently only wired up for the anthropic provider.' });
  }

  try {
    let data;
    switch (provider) {
      case 'anthropic': data = await callAnthropic({ system, messages, max_tokens, tools }); break;
      case 'openai':    data = await callOpenAICompatible({ system, messages, max_tokens }, 'openai', 'https://api.openai.com/v1/chat/completions'); break;
      case 'deepseek':  data = await callOpenAICompatible({ system, messages, max_tokens }, 'deepseek', 'https://api.deepseek.com/chat/completions'); break;
      case 'gemini':    data = await callGemini({ system, messages, max_tokens }); break;
    }
    res.json(data);
  } catch (err) {
    console.error(`[${provider}] Proxy error:`, err.message);
    res.status(502).json({ error: `فشل الاتصال بمزود ${provider}: ${err.message}` });
  }
});

app.get('/health', (req, res) => res.json({
  status: 'ok',
  providers: Object.fromEntries(Object.entries(PROVIDERS).map(([k, v]) => [k, !!v.apiKey])),
}));

// --- Embeddings endpoint (powers long-term memory / semantic retrieval) ---
// Anthropic has no embeddings API, so this uses OpenAI's — the only
// requirement is OPENAI_API_KEY. If it's missing, the frontend's
// long-term-memory feature simply won't retrieve anything (fails gracefully).
const EMBEDDING_MODEL = process.env.OPENAI_EMBEDDING_MODEL || 'text-embedding-3-small';

app.post('/api/embed', async (req, res) => {
  const ip = req.ip;
  if (isRateLimited(ip)) {
    return res.status(429).json({ error: 'تجاوزت عدد الطلبات المسموح. حاول بعد قليل.' });
  }
  const { texts } = req.body;
  if (!Array.isArray(texts) || texts.length === 0) {
    return res.status(400).json({ error: 'texts array is required' });
  }
  if (!PROVIDERS.openai.apiKey) {
    return res.status(400).json({ error: 'الذاكرة طويلة المدى تحتاج OPENAI_API_KEY على السيرفر (Anthropic لا يوفر واجهة تضمين/embeddings).' });
  }
  try {
    const r = await fetch('https://api.openai.com/v1/embeddings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${PROVIDERS.openai.apiKey}` },
      body: JSON.stringify({ model: EMBEDDING_MODEL, input: texts }),
    });
    const data = await r.json();
    if (!r.ok) throw new Error(data.error?.message || 'OpenAI embeddings error');
    res.json({ embeddings: data.data.map(d => d.embedding) });
  } catch (err) {
    console.error('Embeddings error:', err.message);
    res.status(502).json({ error: 'فشل توليد التضمين (embeddings): ' + err.message });
  }
});

// --- Market context endpoint (powers the financial agent's geo/economic
//     context router) — gold spot price + exchange rate, both from genuinely
//     free, keyless public data sources. No API key needed for this feature. ---
const FRANKFURTER_CURRENCIES = ['AUD','BGN','BRL','CAD','CHF','CNY','CZK','DKK','EUR','GBP','HKD','HUF','IDR','ILS','INR','ISK','JPY','KRW','MXN','MYR','NOK','NZD','PHP','PLN','RON','SEK','SGD','THB','TRY','USD','ZAR'];
const GRAMS_PER_TROY_OZ = 31.1035;
const marketContextCache = new Map(); // currency -> { data, timestamp }
const MARKET_CACHE_TTL_MS = 5 * 60 * 1000; // 5 minutes — real prices move, but no need to hit upstream every message

app.get('/api/market-context', async (req, res) => {
  const ip = req.ip;
  if (isRateLimited(ip)) {
    return res.status(429).json({ error: 'تجاوزت عدد الطلبات المسموح. حاول بعد قليل.' });
  }

  const currency = (req.query.currency || 'USD').toUpperCase();
  if (currency !== 'USD' && !FRANKFURTER_CURRENCIES.includes(currency)) {
    return res.status(400).json({
      error: `عملة "${currency}" غير مدعومة من مصدر أسعار الصرف المجاني (Frankfurter/ECB). العملات المدعومة: ${FRANKFURTER_CURRENCIES.join(', ')}.`,
    });
  }

  const cached = marketContextCache.get(currency);
  if (cached && (Date.now() - cached.timestamp < MARKET_CACHE_TTL_MS)) {
    return res.json(cached.data);
  }

  try {
    // Gold spot price in USD per troy ounce — gold-api.com, free, no key.
    const goldRes = await fetch('https://api.gold-api.com/price/XAU');
    const goldData = await goldRes.json();
    const goldPriceUsdPerOz = goldData.price ?? goldData.rate ?? goldData.value ?? goldData.XAU ?? null;
    if (goldPriceUsdPerOz === null) {
      console.error('gold-api.com response did not match expected fields:', JSON.stringify(goldData));
      throw new Error('لم يرجع مصدر أسعار الذهب سعراً صالحاً');
    }

    // Exchange rate — Frankfurter (ECB reference rates), free, no key.
    let usdToLocalRate = null;
    if (currency !== 'USD') {
      const fxRes = await fetch(`https://api.frankfurter.dev/v1/latest?base=USD&symbols=${encodeURIComponent(currency)}`);
      const fxData = await fxRes.json();
      usdToLocalRate = fxData.rates?.[currency] ?? null;
    }

    const goldPriceUsdPerGram = +(goldPriceUsdPerOz / GRAMS_PER_TROY_OZ).toFixed(2);
    const result = {
      currency,
      goldPriceUsdPerOz,
      goldPriceUsdPerGram,
      usdToLocalRate,
      goldPriceLocalPerGram: (usdToLocalRate !== null) ? +(goldPriceUsdPerGram * usdToLocalRate).toFixed(2) : null,
      fetchedAt: new Date().toISOString(),
      sources: { gold: 'gold-api.com (real-time XAU spot)', fx: currency !== 'USD' ? 'frankfurter.dev (ECB daily reference rates)' : null },
    };
    marketContextCache.set(currency, { data: result, timestamp: Date.now() });
    res.json(result);
  } catch (err) {
    console.error('Market context error:', err.message);
    res.status(502).json({ error: 'تعذر جلب بيانات السوق الحالية: ' + err.message });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`✅ NEXUS backend running on http://localhost:${PORT}`));
