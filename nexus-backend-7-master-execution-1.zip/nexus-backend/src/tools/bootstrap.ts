import { getToolRegistry } from './registry.js';
import { webFetchTool } from './builtin/webFetchTool.js';
import { calculateTool } from './builtin/calculateTool.js';

let bootstrapped = false;

export function bootstrapTools(): void {
  if (bootstrapped) return;
  const registry = getToolRegistry();
  registry.register(webFetchTool);
  registry.register(calculateTool);
  // NOTE: 'create_file' and 'web_search' are intentionally NOT registered
  // here. create_file writes to the end user's own device/browser — there
  // is nothing meaningful for a stateless backend to execute; it stays a
  // client-side tool. web_search (type 'web_search_20250305') is executed
  // natively BY Anthropic itself when offered to that provider — it never
  // reaches this pipeline at all, so registering it here would be a no-op
  // at best and misleading at worst (implying we could deny/permission it,
  // when in reality Anthropic's own infrastructure runs it before we ever
  // see a tool_use block for it).
  bootstrapped = true;
}
