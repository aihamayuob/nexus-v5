/**
 * Server-wide configuration. Like providerRegistry.ts, this is the single
 * place these values are read from — nothing else parses process.env
 * directly for these settings.
 */

function num(name: string, fallback: number): number {
  const v = process.env[name];
  if (!v) return fallback;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function mode(): 'CLOUD' | 'HYBRID' | 'LOCAL_ONLY' {
  const value = (process.env.NEXUS_MODE?.trim().toUpperCase() || 'HYBRID');
  if (value === 'CLOUD' || value === 'HYBRID' || value === 'LOCAL_ONLY') return value;
  throw new Error(`Invalid NEXUS_MODE: ${value}. Expected CLOUD, HYBRID, or LOCAL_ONLY.`);
}

function list(name: string): string[] {
  const v = process.env[name];
  if (!v) return [];
  return v.split(',').map((s) => s.trim()).filter(Boolean);
}

export const ServerConfig = {
  port: num('NEXUS_PORT', 8787),
  host: process.env.NEXUS_HOST?.trim() || '0.0.0.0',

  /**
   * Gateway (bearer) keys accepted on protected routes. Mirrors the
   * frontend's syncAuthHeaders()/getGatewayKey() Bearer-token pattern
   * exactly. If this list is EMPTY, the gateway runs in trusted/no-auth
   * mode (e.g. LAN-only self-hosted deployment) — matching the existing
   * frontend behavior of only sending the header when a key is actually
   * configured client-side. If at least one key IS configured here, every
   * protected route requires a valid Bearer match; there is no partial
   * state where auth is "optional but checked".
   */
  gatewayKeys: list('NEXUS_GATEWAY_KEYS'),

  /** Max concurrent in-flight tasks (Agent Runtime DAG tasks + chat completions) across the whole process. */
  maxConcurrency: num('NEXUS_MAX_CONCURRENCY', 8),
  /** Max concurrent tasks within a single DAG run. */
  maxConcurrencyPerPlan: num('NEXUS_MAX_CONCURRENCY_PER_PLAN', 4),

  /** Per-task (single model call) timeout, ms. Provider-specific timeouts in providerRegistry take precedence when set. */
  defaultTaskTimeoutMs: num('NEXUS_TASK_TIMEOUT_MS', 90_000),
  /** Whole-plan wall-clock ceiling, ms — guards against a pathological DAG never finishing. */
  planTimeoutMs: num('NEXUS_PLAN_TIMEOUT_MS', 10 * 60_000),

  /** Retry policy defaults (see orchestrator/resilientCall.ts). */
  maxRetries: num('NEXUS_MAX_RETRIES', 2),
  retryBaseDelayMs: num('NEXUS_RETRY_BASE_DELAY_MS', 500),

  /** Soft USD budget per rolling 24h window, enforced by orchestrator/budget.ts. 0 = disabled. */
  dailyBudgetUsd: num('NEXUS_DAILY_BUDGET_USD', 0),

  /** Rate limiting — token bucket per client key (gateway key, or IP if none). */
  rateLimitPerMinute: num('NEXUS_RATE_LIMIT_PER_MINUTE', 60),
  rateLimitBurst: num('NEXUS_RATE_LIMIT_BURST', 20),

  /** Max request body size, bytes. Protects against oversized payload DoS. */
  maxBodyBytes: num('NEXUS_MAX_BODY_BYTES', 2 * 1024 * 1024), // 2MB — generous for chat/knowledge payloads, not for arbitrary uploads

  /** web_fetch tool: hard cap on fetched content forwarded to the model. */
  webFetchMaxChars: num('NEXUS_WEB_FETCH_MAX_CHARS', 12_000),
  webFetchTimeoutMs: num('NEXUS_WEB_FETCH_TIMEOUT_MS', 10_000),

  /** SQLite file path. ':memory:' is valid (used by the test suite). */
  dbPath: process.env.NEXUS_DB_PATH?.trim() || './data/nexus.db',

  /** CORS allow-list. Empty = same-origin/no browser CORS headers emitted (safe default for a same-host deployment). */
  corsAllowedOrigins: list('NEXUS_CORS_ORIGINS'),

  nodeEnv: process.env.NODE_ENV?.trim() || 'development',
  /** Deployment mode controls provider selection policy: CLOUD, HYBRID, or LOCAL_ONLY. */
  mode: mode(),
  /** Explicit escape hatch for trusted LAN/self-hosted deployments. Never enabled by default in production. */
  allowTrustedMode: process.env.NEXUS_ALLOW_TRUSTED_MODE?.trim().toLowerCase() === 'true',
};

export function isProduction(): boolean {
  return ServerConfig.nodeEnv === 'production';
}

export function isLocalOnlyMode(): boolean {
  return ServerConfig.mode === 'LOCAL_ONLY';
}
