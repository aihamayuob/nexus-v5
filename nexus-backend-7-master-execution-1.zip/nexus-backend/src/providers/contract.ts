import type { ProviderId } from '../config/providerRegistry.js';

export interface TextBlock {
  type: 'text';
  text: string;
}
export interface ImageBlock {
  type: 'image';
  source: { type: 'base64'; media_type: string; data: string };
}
export interface ToolUseBlock {
  type: 'tool_use';
  id: string;
  name: string;
  input: Record<string, unknown>;
}
export interface ToolResultBlock {
  type: 'tool_result';
  tool_use_id: string;
  content: string;
}
export type ContentBlock = TextBlock | ImageBlock | ToolUseBlock | ToolResultBlock;

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string | ContentBlock[];
}

export interface ToolDef {
  type?: string; // server tools like 'web_search_20250305' carry a type instead of an input_schema
  name: string;
  description?: string;
  input_schema?: {
    type: 'object';
    properties: Record<string, { type: string; description?: string }>;
    required?: string[];
  };
}

export interface ChatRequest {
  model: string;
  system?: string;
  messages: ChatMessage[];
  tools?: ToolDef[];
  maxTokens: number;
  signal?: AbortSignal;
}

export type StopReason = 'end_turn' | 'tool_use' | 'max_tokens' | 'stop_sequence' | 'cancelled';

export interface ChatResponse {
  content: ContentBlock[];
  stopReason: StopReason;
  usage: { inputTokens: number; outputTokens: number };
}

export interface StreamHandlers {
  onToken?: (text: string) => void;
  onToolUseStart?: (block: { id: string; name: string }) => void;
  onToolUseDelta?: (block: { id: string; partialJson: string }) => void;
  onUsage?: (usage: { inputTokens: number; outputTokens: number }) => void;
}

export interface EmbedResult {
  embeddings: number[][];
  model: string;
}

export interface ProviderAdapter {
  readonly id: ProviderId;
  chat(req: ChatRequest): Promise<ChatResponse>;
  /** Streams tokens via handlers AND returns the same final aggregated ChatResponse shape chat() would — mirrors the frontend's own requestStream() contract exactly, so callers never care which path was used. */
  chatStream(req: ChatRequest, handlers: StreamHandlers): Promise<ChatResponse>;
  embed(texts: string[], model?: string): Promise<EmbedResult>;
  readonly supportsEmbeddings: boolean;
}

/** Injectable HTTP transport so adapters are unit-testable without real network access. */
export type FetchLike = typeof fetch;
