import type { RouteIntent } from '../providers/modelRouter.js';

const RISK_WORDS = /جرعة|تشخيص|عقد ملزم|دعوى|استثمر كل|طلاق|وصية|عملية جراحية|أعراض خطيرة|dosage|diagnosis|lawsuit|surgery/i;
const COMPLEXITY_WORDS = /قارن|حلل|خطة شاملة|استراتيجية|multi-step|analyze|strategy|compare/i;

export interface AnalyzedIntent extends RouteIntent {
  text: string;
  requiresVerification: boolean;
}

/**
 * Deliberately NOT an extra model call — same design rationale as the
 * frontend's NexusIntentEngine (cheap heuristic scoring on the hot path,
 * not latency/cost-adding). Callers depend only on the returned shape.
 */
export function analyzeIntent(text: string, opts: { needsTools?: boolean; needsImages?: boolean } = {}): AnalyzedIntent {
  const risk: RouteIntent['risk'] = RISK_WORDS.test(text) ? 'high' : 'low';
  const complexity: RouteIntent['complexity'] = COMPLEXITY_WORDS.test(text) || text.length > 800 ? 'high' : 'medium';
  return {
    text,
    risk,
    complexity,
    needsTools: opts.needsTools ?? false,
    needsImages: opts.needsImages ?? false,
    requiresVerification: risk === 'high' || complexity === 'high',
  };
}
