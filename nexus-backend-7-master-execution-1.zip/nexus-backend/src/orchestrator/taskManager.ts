import { ServerConfig } from '../config/env.js';
import { Errors } from '../core/errors.js';
import { newTaskId } from '../core/ids.js';
import { logger } from '../core/logger.js';
import { getRepos } from '../persistence/repos.js';
import type { TaskKind } from '../persistence/repositories/taskRepo.js';
import { TaskObservability } from '../observability/recorder.js';
import type { GatewayContext } from '../capability/permissionModel.js';
import { getStreamRegistry } from './streamRegistry.js';
import { ExecutionCheckpoint } from './checkpoint.js';
import { executeDag } from './dag.js';
import { createDagRunner } from './dagRunner.js';
import type { DagPlan } from './dagTypes.js';
import type { ProviderId } from '../config/providerRegistry.js';

const running = new Map<string, true>();

/**
 * Enforces the process-wide concurrency ceiling. This is a real limit on
 * simultaneously in-flight tasks (not per-provider) — see
 * ServerConfig.maxConcurrency. A task waits here (not rejected outright)
 * up to a short grace period, then is rejected with 429 if the system is
 * still saturated, matching how the rate limiter also communicates
 * backpressure rather than silently queuing forever.
 */
async function acquireGlobalSlot(signal?: AbortSignal): Promise<() => void> {
  const start = Date.now();
  while (running.size >= ServerConfig.maxConcurrency) {
    if (signal?.aborted) throw Errors.cancelled();
    if (Date.now() - start > 5000) throw Errors.rateLimited('الخادم مشغول بأقصى طاقته الآن — أعد المحاولة خلال لحظات.');
    await new Promise((r) => setTimeout(r, 100));
  }
  const key = `${Date.now()}_${Math.random()}`;
  running.set(key, true);
  return () => running.delete(key);
}

export function cancelTask(taskId: string): boolean {
  const t = activeAbortControllers.get(taskId);
  if (!t) return false;
  t.abort();
  return true;
}

const activeAbortControllers = new Map<string, AbortController>();

export interface StartTaskResult {
  taskId: string;
  reusedExisting: boolean;
}

/** Idempotency: if a task with this key already exists, its id is reused instead of starting a duplicate. */
export function claimTask(kind: TaskKind, idempotencyKey: string | null, ctx: GatewayContext, meta: { provider?: string; model?: string; promptLen?: number }): StartTaskResult {
  const repos = getRepos();
  if (idempotencyKey) {
    const existingId = repos.idempotency.find(idempotencyKey);
    if (existingId) {
      const existing = repos.tasks.get(existingId);
      if (existing && (existing.status === 'pending' || existing.status === 'running')) {
        return { taskId: existingId, reusedExisting: true };
      }
    }
  }
  const taskId = newTaskId(kind === 'chat' ? 'chat' : 'plan');
  repos.tasks.create({
    id: taskId,
    kind,
    idempotencyKey,
    provider: meta.provider ?? null,
    model: meta.model ?? null,
    goalOrPromptLen: meta.promptLen ?? null,
    projectId: ctx.projectId,
    userId: ctx.userId,
    errorMessage: null,
  });
  if (idempotencyKey) repos.idempotency.claim(idempotencyKey, taskId);
  return { taskId, reusedExisting: false };
}

export function getAbortSignalFor(taskId: string): AbortSignal {
  let ac = activeAbortControllers.get(taskId);
  if (!ac) {
    ac = new AbortController();
    activeAbortControllers.set(taskId, ac);
  }
  return ac.signal;
}

export function releaseTask(taskId: string) {
  activeAbortControllers.delete(taskId);
}

/**
 * Runs a whole Agent Runtime plan (the DAG) as ONE durable, resumable,
 * observable, budget-and-concurrency-governed task — this is the
 * unification the audit called for: /api/runtime/plan + /api/runtime/run
 * no longer sit beside Nexus Core as a separate path, they ARE a task
 * kind the same Task Manager governs like any other.
 */
export async function runPlanTask(
  taskId: string,
  plan: DagPlan,
  providerId: ProviderId,
  ctx: GatewayContext,
  resumeFrom?: Array<{ nodeId: string; status: 'done'; output: string | null }>
): Promise<void> {
  const repos = getRepos();
  const signal = getAbortSignalFor(taskId);
  const release = await acquireGlobalSlot(signal);
  const streamRegistry = getStreamRegistry();
  const obs = new TaskObservability(taskId, 'runtime_plan');
  repos.tasks.updateStatus(taskId, 'running');

  const planTimeout = setTimeout(() => {
    activeAbortControllers.get(taskId)?.abort();
  }, ServerConfig.planTimeoutMs);

  const runner = createDagRunner(providerId, ctx, obs);
  try {
    // Persist the plan's static shape (goal + task list) ONCE up front —
    // this is what makes resumeInterruptedPlans() below able to
    // reconstruct a MEANINGFUL plan.goal after a restart, instead of the
    // per-node dag_nodes rows alone (which only capture dynamic execution
    // state, not the original goal text). The goal is the user's own
    // request, not model reasoning/output, so persisting it doesn't
    // conflict with the "never log chain-of-thought" rule.
    await ExecutionCheckpoint.save(taskId, 'plan_definition', plan);

    const result = await executeDag({
      taskId,
      plan,
      emit: (event, data) => streamRegistry.emit(taskId, event, data),
      runNode: runner.runNode,
      reflect: runner.reflect,
      reviseNode: runner.reviseNode,
      synthesize: runner.synthesize,
      persistNode: (node) => repos.checkpoints.upsertNode({ taskId, ...node }),
      maxConcurrency: ServerConfig.maxConcurrencyPerPlan,
      signal,
      resumeFrom,
    });

    if (result.allFailed) {
      streamRegistry.emit(taskId, 'plan_error', { message: 'فشلت جميع المهام الفرعية.' });
      repos.tasks.updateStatus(taskId, 'failed', 'all subtasks failed');
      obs.finish('failed');
    } else {
      streamRegistry.emit(taskId, 'plan_done', { finalOutput: result.finalOutput });
      repos.tasks.updateStatus(taskId, 'done');
      await ExecutionCheckpoint.clear(taskId);
      obs.finish('ok');
    }
  } catch (e) {
    const err = e as Error;
    if (err.name === 'AbortError') {
      streamRegistry.emit(taskId, 'plan_error', { message: 'أُلغيت المهمة.' });
      repos.tasks.updateStatus(taskId, 'cancelled');
      obs.finish('cancelled');
    } else {
      logger.error('Plan task failed unexpectedly', { taskId, message: err.message });
      streamRegistry.emit(taskId, 'plan_error', { message: err.message });
      repos.tasks.updateStatus(taskId, 'failed', err.message);
      obs.recordFailure(err.message);
      obs.finish('failed');
    }
  } finally {
    clearTimeout(planTimeout);
    streamRegistry.markDone(taskId);
    releaseTask(taskId);
    release();
  }
}

/**
 * Resumes any plan tasks left non-terminal by an unclean shutdown — real
 * durable execution, not just a "something was interrupted" flag. Called
 * once at process startup (see index.ts).
 */
export async function resumeInterruptedPlans(): Promise<void> {
  const repos = getRepos();
  const taskIds = ExecutionCheckpoint.resumablePlanTaskIds();
  for (const taskId of taskIds) {
    const task = repos.tasks.get(taskId);
    if (!task || !task.provider) continue;
    const checkpoint = ExecutionCheckpoint.latest(taskId);
    if (!checkpoint || checkpoint.phase !== 'plan_definition') {
      logger.warn('Cannot resume plan — no persisted plan definition found, leaving for manual retry', { taskId });
      continue;
    }
    const plan = checkpoint.state as DagPlan;
    const nodes = repos.checkpoints.nodesForTask(taskId);
    logger.info('Resuming interrupted plan', { taskId, nodeCount: nodes.length, goalPreview: plan.goal.slice(0, 60) });
    const resumeFrom = nodes
      .filter((n): n is typeof n & { status: 'done' } => n.status === 'done')
      .map((n) => ({ nodeId: n.nodeId, status: n.status, output: n.output }));
    const ctx: GatewayContext = { authenticated: true, clientKey: 'system-resume', projectId: task.projectId, userId: task.userId };
    void runPlanTask(taskId, plan, task.provider as ProviderId, ctx, resumeFrom).catch((e) =>
      logger.error('Resume failed', { taskId, message: (e as Error).message })
    );
  }
}

export function taskManagerStatus() {
  return { runningCount: running.size, maxConcurrency: ServerConfig.maxConcurrency };
}
