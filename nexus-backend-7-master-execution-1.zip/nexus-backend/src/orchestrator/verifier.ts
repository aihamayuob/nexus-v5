import { getProviderAdapter } from '../providers/index.js';
import { ProviderRegistry } from '../config/providerRegistry.js';
import { logger } from '../core/logger.js';
import { ServerConfig } from '../config/env.js';

export interface VerificationVerdict {
  ran: boolean;
  ok: boolean;
  verdict: 'ok' | 'issues_found' | 'unavailable';
  issues: string[];
}

const VERIFY_SYSTEM_PROMPT = `أنت مراجع مستقل صارم. مهمتك الوحيدة فحص إجابة مقترحة على سؤال، والبحث عن أخطاء واقعية، تناقضات منطقية، أو ادعاءات غير مدعومة. لا تُعد صياغة الإجابة ولا تحسّنها. أجب حصراً بصيغة JSON بالشكل التالي ولا شيء غيره:
{"verdict": "ok" | "issues_found", "issues": ["وصف موجز لكل مشكلة حقيقية، إن وجدت"]}
إن لم تجد أي مشكلة جوهرية، أعد verdict:"ok" وissues:[] فارغة. لا تخترع مشاكل شكلية بسيطة — فقط ما يؤثر فعلياً على صحة أو موثوقية الإجابة.`;

export const Verifier = {
  shouldVerify(intent: { requiresVerification?: boolean }): boolean {
    return !!intent.requiresVerification;
  },

  async verify(question: string, draftAnswer: string): Promise<VerificationVerdict> {
    const judge = selectJudgeProvider();
    if (!judge) {
      return { ran: false, ok: false, verdict: 'unavailable', issues: [] };
    }
    try {
      const adapter = getProviderAdapter(judge.id);
      const res = await adapter.chat({
        model: judge.resolvedModel,
        system: VERIFY_SYSTEM_PROMPT,
        messages: [{ role: 'user', content: `السؤال: ${question}\n\nالإجابة المقترحة:\n${draftAnswer}` }],
        maxTokens: 500,
      });
      const textBlock = res.content.find((b) => b.type === 'text');
      const raw = textBlock && textBlock.type === 'text' ? textBlock.text : '{}';
      const jsonMatch = raw.match(/\{[\s\S]*\}/);
      const parsed = JSON.parse(jsonMatch ? jsonMatch[0] : '{}') as { verdict?: string; issues?: string[] };
      const verdict = parsed.verdict === 'issues_found' ? 'issues_found' : 'ok';
      return { ran: true, ok: true, verdict, issues: Array.isArray(parsed.issues) ? parsed.issues.slice(0, 10) : [] };
    } catch (e) {
      logger.warn('Verifier call failed (non-fatal — treated as did-not-run)', { message: (e as Error).message });
      return { ran: false, ok: false, verdict: 'unavailable', issues: [] };
    }
  },
};

function selectJudgeProvider() {
  const candidates = ProviderRegistry.resolveAll().filter((p) =>
    (p.capabilities.isLocal || !!p.apiKey) && !!p.resolvedModel
  );
  if (ServerConfig.mode === 'LOCAL_ONLY') {
    return candidates.find((p) => p.capabilities.isLocal) ?? null;
  }
  // Prefer Anthropic when configured for continuity, then other cloud
  // providers. The verifier is provider-agnostic and never a hard Anthropic dependency.
  return candidates.find((p) => p.id === 'anthropic') ??
    candidates.find((p) => p.id === 'openai') ??
    candidates.find((p) => p.id === 'gemini') ??
    candidates.find((p) => p.id === 'deepseek') ??
    candidates.find((p) => p.capabilities.isLocal) ??
    null;
}
