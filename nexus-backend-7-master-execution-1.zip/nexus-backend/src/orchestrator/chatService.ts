import type { ChatRequest, ChatResponse, StreamHandlers, ToolDef, ContentBlock } from '../providers/contract.js';
import type { ProviderId } from '../config/providerRegistry.js';
import { routeModel } from '../providers/modelRouter.js';
import { getProviderAdapter } from '../providers/index.js';
import { resilientCall } from '../providers/resilientCall.js';
import { executeToolCalls } from '../tools/pipeline.js';
import type { GatewayContext } from '../capability/permissionModel.js';
import { PermissionModel } from '../capability/permissionModel.js';
import { analyzeIntent } from '../intent/intentEngine.js';
import type { TaskObservability } from '../observability/recorder.js';
import { Errors } from '../core/errors.js';

const MAX_TOOL_LOOP_ITERATIONS = 4;

export interface ChatServiceRequest {
  provider: ProviderId;
  model?: string; // if omitted, ModelRouter resolves the registry default for `provider`
  system?: string;
  messages: ChatRequest['messages'];
  tools?: ToolDef[];
  maxTokens: number;
  signal?: AbortSignal;
}

export interface ChatServiceResult extends ChatResponse {
  providerUsed: ProviderId;
  modelUsed: string;
}

/**
 * Runs one full completion, including the tool-use loop, against
 * whichever provider/model ModelRouter resolves — with automatic retry
 * and provider fallback via resilientCall. Feeds observability as it
 * goes. `handlers`, if provided, receives live token/tool-use/usage
 * events (streaming); omit it for a plain non-streaming call.
 */
export async function runChatCompletion(
  req: ChatServiceRequest,
  ctx: GatewayContext,
  obs: TaskObservability,
  handlers?: StreamHandlers
): Promise<ChatServiceResult> {
  const needsTools = !!req.tools && req.tools.length > 0;
  const needsImages = req.messages.some(
    (m) => Array.isArray(m.content) && (m.content as ContentBlock[]).some((b) => b.type === 'image')
  );
  const intent = analyzeIntent(typeof req.messages.at(-1)?.content === 'string' ? (req.messages.at(-1)!.content as string) : '', {
    needsTools,
    needsImages,
  });

  if (needsImages) PermissionModel.assertImageAllowed(req.provider, ctx);
  PermissionModel.assertBudgetAllowed();

  const routed = routeModel(req.provider, intent);
  const model = req.model || routed.model;

  let messages = [...req.messages];
  let finalResponse: ChatResponse | null = null;
  let providerUsed: ProviderId = routed.provider;

  for (let iteration = 0; iteration < MAX_TOOL_LOOP_ITERATIONS; iteration++) {
    const attempts = [routed.provider, ...routed.fallbacks].map((p) => ({
      label: p,
      run: async () => {
        const adapter = getProviderAdapter(p);
        const providerModel = p === routed.provider ? model : undefined; // fallback providers use THEIR OWN registry default, never the primary's model string — different vendors don't share model namespaces
        const runReq: ChatRequest = {
          model: providerModel || model,
          system: req.system,
          messages,
          tools: req.tools,
          maxTokens: req.maxTokens,
          signal: req.signal,
        };
        const response = handlers ? await adapter.chatStream(runReq, handlers) : await adapter.chat(runReq);
        providerUsed = p;
        return response;
      },
    }));

    const response = await resilientCall({
      attempts,
      signal: req.signal,
      onRetry: () => obs.recordRetry(),
    });

    obs.recordModelCall(providerUsed, model, response.usage.inputTokens, response.usage.outputTokens);

    if (response.stopReason !== 'tool_use') {
      finalResponse = response;
      break;
    }

    const toolUseBlocks = response.content.filter((b): b is Extract<ContentBlock, { type: 'tool_use' }> => b.type === 'tool_use');
    if (toolUseBlocks.length === 0) {
      finalResponse = response;
      break;
    }
    for (const b of toolUseBlocks) obs.recordTool(b.name);

    messages = [...messages, { role: 'assistant', content: response.content }];
    const results = await executeToolCalls(
      toolUseBlocks.map((b) => ({ id: b.id, name: b.name, input: b.input })),
      providerUsed,
      ctx
    );
    messages = [
      ...messages,
      {
        role: 'user',
        content: results.map((r) => ({ type: 'tool_result' as const, tool_use_id: r.id, content: r.content })),
      },
    ];
  }

  if (!finalResponse) throw Errors.internal('تجاوزت المحادثة الحد الأقصى لحلقات استدعاء الأدوات.');

  return { ...finalResponse, providerUsed, modelUsed: model };
}
