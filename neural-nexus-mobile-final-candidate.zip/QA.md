# QA / Release Gate

## P0 — يجب اجتيازها
- [ ] `npm install`
- [ ] `npm run typecheck`
- [ ] Backend health check
- [ ] Google OAuth callback إلى `neuralnexus://auth/callback`
- [ ] One-time code exchange
- [ ] SecureStore token restore بعد إعادة تشغيل التطبيق
- [ ] Logout + token revocation
- [ ] `/api/chat` SSE on Android
- [ ] `/api/chat` SSE on iOS
- [ ] 401 handling and session expiry
- [ ] Collective mode with 2+ agents
- [ ] Situation Room
- [ ] Mirror Mode
- [ ] Cross-Examination
- [ ] Deep Analysis
- [ ] Multi-Model Consensus
- [ ] Bias Watcher
- [ ] Runtime plan/run

## P1
- [ ] Camera
- [ ] Gallery
- [ ] File picker
- [ ] Notifications in development build
- [ ] Deep link from notification
- [ ] Workspaces
- [ ] Cloud Sync E2E compatibility
- [ ] Offline cache / retry

## Current blocker
ملف Backend الفعلي غير موجود ضمن الملفات المتاحة في هذه الجلسة؛ الموجود القابل للمراجعة هو نسخة HTML للمنصة. لذلك لا يجوز الادعاء أن تغييرات Backend الخاصة بـ mobile authentication أو sync قد تم تطبيقها فعلياً. ملفات `src/api/backend.ts` هي adapters للـ endpoints الموجودة/المتوقعة، ويجب مطابقة أسماء endpoints مع Backend الحقيقي قبل production.
