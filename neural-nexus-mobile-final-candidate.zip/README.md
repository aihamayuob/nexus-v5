# Neural Nexus AI Agents — Mobile Final Candidate

## الحالة
هذا مشروع React Native + Expo + TypeScript مصمم لربط تطبيق الهاتف بالـ Backend الحالي عبر HTTPS، مع SecureStore للجلسة، SSE للمحادثة، أوضاع Neural Nexus المتقدمة، قاعدة معرفة محلية، Push Notifications، Camera/Gallery/Location permissions وDeep Linking.

## أهم ما تم نقله
- جميع الوكلاء الموجودين في نسخة HTML الحالية، بما في ذلك Domain Expert Groups وBias Watcher.
- Single Chat + SSE.
- Collective Intelligence + Synthesis.
- Situation Room.
- Mirror Mode.
- Cross-Examination.
- Deep Analysis متعدد المراحل.
- Multi-Model Consensus.
- Bias Watcher.
- Knowledge Base مع فصل العناصر الحساسة محلياً.
- Runtime adapters `/api/runtime/plan` و`/api/runtime/run`.
- Workspace/Sync adapters.
- Secure session storage.
- Deep-link scheme `neuralnexus://`.
- Native permission adapters.

## تشغيل
```bash
npm install
npx expo start
```

أنشئ `.env` من `.env.example`:
```env
EXPO_PUBLIC_API_BASE_URL=https://YOUR-BACKEND-DOMAIN
EXPO_PUBLIC_APP_SCHEME=neuralnexus
```

## Development Build
Push Notifications والـ native modules التي تتطلب binary يجب اختبارها في Development Build، وليس الاعتماد على Expo Go. استخدم:
```bash
npx expo install expo-dev-client
eas build --profile development --platform android
eas build --profile development --platform ios
```

## Authentication contract
التطبيق يتوقع:
- `GET /api/auth/me`
- `POST /api/auth/logout`
- `POST /api/auth/mobile/exchange` مع `{code}` وإرجاع `{token}`
- OAuth يبدأ من `/api/auth/google/start`

**مهم:** لا تضع `GATEWAY_API_KEY` أو مفاتيح OpenAI/Anthropic/DeepSeek داخل التطبيق.

## Chat contract
`POST /api/chat` مع:
```json
{
  "provider":"anthropic",
  "model":"claude-sonnet-4-6",
  "system":"...",
  "messages":[{"role":"user","content":"..."}],
  "stream":true
}
```
ويجب أن يعيد `text/event-stream`.

## Runtime contract
- `POST /api/runtime/plan`
- `POST /api/runtime/run`

## Sync
الـ Web الحالي يستخدم AES-GCM مع passphrase وsalt وIV وciphertext. هذه النسخة لا تدّعي أن Native Sync متوافق إنتاجياً مع Web إلى أن تتم مطابقة تنفيذ اشتقاق المفتاح AES-GCM حرفياً مع Backend/Web crypto implementation. لا تُفعّل cross-device E2E sync في الإنتاج اعتماداً على adapter مبسط.

## ملاحظة إنتاجية
قبل إصدار Store build يجب تشغيل `npm run typecheck` بعد تثبيت dependencies، ثم اختبارات Backend الفعلية، ثم E2E على جهاز Android وiPhone حقيقيين.
