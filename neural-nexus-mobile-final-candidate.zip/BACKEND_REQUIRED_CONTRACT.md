# Backend Contract Required for Final Production Sign-off

هذه ليست نسخة بديلة من Backend. هذه قائمة العقود التي يجب مطابقتها مع المصدر الفعلي قبل الدمج.

## Authentication

`POST /api/auth/mobile/exchange`

Request:
```json
{"code":"one-time-code"}
```

Response:
```json
{"token":"opaque-mobile-access-token"}
```

The token must be short-lived or revocable and must never be logged. If the existing backend already has a secure session-token table, reuse it rather than introducing a second credential store.

## Chat

`POST /api/chat`

Headers:
`Authorization: Bearer <mobile-token>`

Body includes `provider`, `model`, `system`, `messages`, `stream` and optional tools.

Response when `stream=true`: `text/event-stream`.

## Runtime

`POST /api/runtime/plan`
`POST /api/runtime/run`

The exact request/response schema must be taken from the existing Backend source; do not guess it.

## Sync

The Web implementation currently derives a key from the passphrase and salt and sends `{baseVersion,deviceId,saltB64,ivB64,ciphertextB64}`. Mobile must use the identical KDF and AES-GCM parameters before cross-device sync is enabled.

## Notifications

`POST /api/notifications/token`

Body:
```json
{"token":"ExponentPushToken[...]","platform":"android|ios"}
```

The Backend should associate the token with the authenticated user and support revocation on logout/device removal.
