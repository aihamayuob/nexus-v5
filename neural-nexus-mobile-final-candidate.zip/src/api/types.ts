export type Provider='anthropic'|'openai'|'deepseek'|'gemini'|'openrouter'|'mistral'|'ollama'|'lmstudio';
export type ChatMessage={role:'user'|'assistant'|'system';content:string};
export type ChatRequest={provider:Provider;model:string;system?:string;messages:ChatMessage[];max_tokens?:number;stream?:boolean;tools?:unknown[]};
export type SSEFrame={event:string|null;data:string;id:string|null};
