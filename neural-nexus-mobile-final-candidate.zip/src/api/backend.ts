import {api} from './client';
export const auth={me:()=>api<any>('/api/auth/me'),logout:()=>api<any>('/api/auth/logout',{method:'POST'}),exchange:(code:string)=>api<any>('/api/auth/mobile/exchange',{method:'POST',body:JSON.stringify({code})})};
export const runtime={plan:(goal:string)=>api<any>('/api/runtime/plan',{method:'POST',body:JSON.stringify({goal})}),run:(plan:any)=>api<any>('/api/runtime/run',{method:'POST',body:JSON.stringify(plan})})};
export const sync={get:()=>api<any>('/api/sync'),put:(body:any)=>api<any>('/api/sync',{method:'PUT',body:JSON.stringify(body)})};
export const workspaces={list:()=>api<any[]>('/api/workspaces')};
export const embed=(text:string)=>api<{embedding:number[]}>('/api/embed',{method:'POST',body:JSON.stringify({input:text})});
