export const API_BASE_URL=(process.env.EXPO_PUBLIC_API_BASE_URL||'').replace(/\/$/,'');
export const APP_SCHEME=process.env.EXPO_PUBLIC_APP_SCHEME||'neuralnexus';
export function requireApiBase(){if(!API_BASE_URL) throw new Error('لم يتم ضبط EXPO_PUBLIC_API_BASE_URL.');return API_BASE_URL;}
