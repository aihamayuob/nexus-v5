import { ServerConfig } from '../config/env.js';
import { Errors } from '../core/errors.js';

export type DataClass = 'PUBLIC'|'INTERNAL'|'PRIVATE'|'SENSITIVE';
export interface BoundaryDecision { classification: DataClass; allowCloud: boolean; reason: string; sanitized: string; }

const secretPatterns = [
  /-----BEGIN [A-Z ]+PRIVATE KEY-----/i,
  /(?:api[_-]?key|secret|password|token)\s*[:=]\s*[^\s,;]{12,}/i,
  /\bsk-[A-Za-z0-9_-]{16,}\b/,
  /\bAQ\.[A-Za-z0-9._-]{12,}\b/,
];
const privatePatterns = [/\b(?:ssn|passport|national[_ -]?id|credit[_ -]?card)\b/i, /\b\+?\d[\d ()-]{8,}\d\b/];

export function classifyData(text: string): DataClass {
  if (secretPatterns.some((p) => p.test(text))) return 'SENSITIVE';
  if (privatePatterns.some((p) => p.test(text))) return 'PRIVATE';
  return text.length > 4000 ? 'INTERNAL' : 'PUBLIC';
}

export function enforceDataBoundary(text: string, wantsCloud: boolean): BoundaryDecision {
  const classification = classifyData(text);
  if (ServerConfig.mode === 'LOCAL_ONLY' && wantsCloud) throw Errors.capabilityDenied('LOCAL_ONLY يمنع الإرسال إلى مزود سحابي.');
  const allowCloud = ServerConfig.mode === 'CLOUD' || (ServerConfig.mode === 'HYBRID' && classification === 'PUBLIC');
  const sanitized = classification === 'SENSITIVE' || classification === 'PRIVATE'
    ? text.replace(secretPatterns[0]!, '[REDACTED_PRIVATE_DATA]')
    : text;
  return { classification, allowCloud, reason: allowCloud ? 'policy_allows_cloud' : 'private_data_requires_local', sanitized };
}
