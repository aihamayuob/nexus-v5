import { ServerConfig } from '../config/env.js';
import { Errors } from '../core/errors.js';

function isLocalHost(hostname: string): boolean {
  const h = hostname.toLowerCase();
  return h === 'localhost' || h === '127.0.0.1' || h === '::1' || h.endsWith('.localhost') || h.endsWith('.local');
}

export function assertOutboundAllowed(input: string | URL): void {
  if (ServerConfig.mode !== 'LOCAL_ONLY') return;
  const url = typeof input === 'string' ? new URL(input) : input;
  if (url.protocol !== 'http:' && url.protocol !== 'https:') throw Errors.capabilityDenied('LOCAL_ONLY يسمح فقط باتصالات HTTP المحلية.');
  if (!isLocalHost(url.hostname)) throw Errors.capabilityDenied(`LOCAL_ONLY منع الاتصال الخارجي إلى ${url.hostname}.`);
}

export function policyFetch(fetchImpl: typeof fetch = fetch): typeof fetch {
  return ((input: string | URL | Request, init?: RequestInit) => {
    assertOutboundAllowed(typeof input === 'string' ? input : input instanceof URL ? input : input.url);
    return fetchImpl(input, init);
  }) as typeof fetch;
}
