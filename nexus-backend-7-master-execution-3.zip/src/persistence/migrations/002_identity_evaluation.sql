-- Nexus Identity / OAuth sessions. Tokens are opaque, hashed and never returned from storage.
CREATE TABLE IF NOT EXISTS nexus_users (
  id TEXT PRIMARY KEY, google_subject TEXT UNIQUE, email TEXT, display_name TEXT, avatar_url TEXT,
  created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS identity_sessions (
  id TEXT PRIMARY KEY, user_id TEXT NOT NULL, token_hash TEXT UNIQUE NOT NULL, expires_at INTEGER NOT NULL,
  created_at INTEGER NOT NULL, last_seen_at INTEGER NOT NULL,
  FOREIGN KEY(user_id) REFERENCES nexus_users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_identity_sessions_expiry ON identity_sessions(expires_at);
CREATE TABLE IF NOT EXISTS oauth_states (
  state_hash TEXT PRIMARY KEY, user_id TEXT, purpose TEXT NOT NULL, redirect_uri TEXT NOT NULL,
  expires_at INTEGER NOT NULL, created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_oauth_states_expiry ON oauth_states(expires_at);
CREATE TABLE IF NOT EXISTS oauth_credentials (
  user_id TEXT NOT NULL, provider TEXT NOT NULL, scopes_json TEXT NOT NULL, access_token_enc TEXT,
  refresh_token_enc TEXT, expires_at INTEGER, updated_at INTEGER NOT NULL,
  PRIMARY KEY(user_id, provider), FOREIGN KEY(user_id) REFERENCES nexus_users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS evaluation_runs (
  id TEXT PRIMARY KEY, benchmark TEXT NOT NULL, agent_id TEXT, provider TEXT, model TEXT,
  metrics_json TEXT NOT NULL, passed INTEGER NOT NULL, created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_evaluation_created ON evaluation_runs(created_at DESC);
CREATE TABLE IF NOT EXISTS agent_versions (
  agent_id TEXT NOT NULL, version INTEGER NOT NULL, definition_json TEXT NOT NULL, benchmark_score REAL,
  status TEXT NOT NULL, created_at INTEGER NOT NULL, promoted_at INTEGER,
  PRIMARY KEY(agent_id, version)
);
CREATE TABLE IF NOT EXISTS routing_feedback (
  id TEXT PRIMARY KEY, provider TEXT NOT NULL, model TEXT NOT NULL, task_class TEXT NOT NULL,
  score REAL NOT NULL, latency_ms INTEGER, cost_usd REAL, success INTEGER NOT NULL, created_at INTEGER NOT NULL
);
