import type { Router, RouteContext } from '../../gateway/router.js';
import { listModelsMetadata } from '../../providers/modelRouter.js';
import { getRepos } from '../../persistence/repos.js';
import { BudgetGuard } from '../../orchestrator/budget.js';
import { taskManagerStatus } from '../../orchestrator/taskManager.js';
import { assertNoSecretLeak } from '../../security/secrets.js';
import { checkAllProviders } from '../../providers/health.js';
import { ServerConfig } from '../../config/env.js';
import { startMission, missionStatus } from '../../autonomy/missionCore.js';
import { listAgents } from '../../autonomy/agentRegistry.js';
import { listTools, listMcpServers } from '../../autonomy/toolFabric.js';
import { runCouncil } from '../../autonomy/council.js';
import { googleStartUrl, googleCallback, extractSessionToken, resolveSession, revokeSession, sessionCookie, clearSessionCookie } from '../../identity/googleOAuth.js';
import { recentEvaluations } from '../../autonomy/evaluation.js';
import { listAgentVersions, promoteAgentVersion, rollbackAgentVersion, registerAgentVersion } from '../../autonomy/evolution.js';
import { getAgent } from '../../autonomy/agentRegistry.js';

const API_VERSION = 2;


async function readJson(req: import('node:http').IncomingMessage): Promise<Record<string, any>> {
  const chunks: Buffer[] = [];
  for await (const chunk of req) chunks.push(Buffer.from(chunk));
  const text = Buffer.concat(chunks).toString('utf8');
  if (!text) return {};
  const parsed = JSON.parse(text);
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error('JSON object required');
  return parsed;
}

export function registerV2Routes(router: Router) {

  router.get('/v2/auth/google/start', async (ctx: RouteContext) => {
    const purpose = ctx.query.get('purpose') === 'gemini' ? 'gemini' : 'identity';
    const user = resolveSession(extractSessionToken(ctx.req));
    if (purpose === 'gemini' && !user) throw new Error('Sign in with Google before authorizing Gemini.');
    const url = googleStartUrl(purpose, user?.userId);
    ctx.res.writeHead(302, { Location: url, 'Cache-Control': 'no-store' }); ctx.res.end();
  }, { skipAuth: true });

  router.get('/v2/auth/google/callback', async (ctx: RouteContext) => {
    const code = ctx.query.get('code'); const state = ctx.query.get('state');
    if (!code || !state) throw new Error('Google OAuth callback requires code and state');
    const result = await googleCallback(code, state);
    ctx.res.writeHead(302, { Location: ServerConfig.identitySuccessRedirect, 'Set-Cookie': sessionCookie(result.sessionToken, Math.floor(ServerConfig.identitySessionTtlMs/1000)), 'Cache-Control': 'no-store' }); ctx.res.end();
  }, { skipAuth: true });

  router.get('/v2/auth/me', async (ctx: RouteContext) => {
    const user = resolveSession(extractSessionToken(ctx.req));
    if (!user) { ctx.res.writeHead(401, {'Content-Type':'application/json'}); ctx.res.end(JSON.stringify({authenticated:false})); return; }
    ctx.res.writeHead(200, {'Content-Type':'application/json','Cache-Control':'no-store'}); ctx.res.end(JSON.stringify({authenticated:true,user}));
  }, { skipAuth: true });

  router.post('/v2/auth/logout', async (ctx: RouteContext) => {
    revokeSession(extractSessionToken(ctx.req)); ctx.res.writeHead(204, {'Set-Cookie': clearSessionCookie()}); ctx.res.end();
  }, { skipAuth: true });

  router.get('/v2/evaluation/recent', async (ctx: RouteContext) => {
    const limit=Math.min(100,Math.max(1,Number(ctx.query.get('limit')||30))); ctx.res.writeHead(200,{'Content-Type':'application/json'}); ctx.res.end(JSON.stringify({version:API_VERSION,results:recentEvaluations(limit)}));
  });

  router.get('/v2/evolution/agents/:id', async (ctx: RouteContext) => { ctx.res.writeHead(200,{'Content-Type':'application/json'}); ctx.res.end(JSON.stringify({version:API_VERSION,versions:listAgentVersions(ctx.params.id)})); });
  router.post('/v2/evolution/agents/:id/:version/promote', async (ctx: RouteContext) => { const approval=ctx.req.headers['x-nexus-approval']; if(!ServerConfig.evolutionApprovalKey || typeof approval!=='string' || approval!==ServerConfig.evolutionApprovalKey) throw new Error('Explicit evolution approval is required.'); const version=Number(ctx.params.version); const result=promoteAgentVersion(ctx.params.id!,version,true); ctx.res.writeHead(200,{'Content-Type':'application/json'}); ctx.res.end(JSON.stringify(result)); });
  router.post('/v2/evolution/agents/:id/candidate', async (ctx: RouteContext) => { const agent=getAgent(ctx.params.id!); if(!agent) { ctx.res.writeHead(404,{'Content-Type':'application/json'}); ctx.res.end(JSON.stringify({error:'agent_not_found'})); return; } const result=registerAgentVersion(agent,null); ctx.res.writeHead(202,{'Content-Type':'application/json'}); ctx.res.end(JSON.stringify(result)); });
  router.post('/v2/evolution/agents/:id/:version/rollback', async (ctx: RouteContext) => { const version=Number(ctx.params.version); const result=rollbackAgentVersion(ctx.params.id!,version); ctx.res.writeHead(200,{'Content-Type':'application/json'}); ctx.res.end(JSON.stringify(result)); });
  router.get(
    '/v2/health',
    async (ctx: RouteContext) => {
      ctx.res.writeHead(200, { 'Content-Type': 'application/json' });
      ctx.res.end(JSON.stringify({ ok: true, version: API_VERSION, ...taskManagerStatus() }));
    },
    { skipAuth: true }
  );

  router.get('/v2/models', async (ctx: RouteContext) => {
    const payload = { version: API_VERSION, providers: listModelsMetadata() };
    assertNoSecretLeak(payload);
    ctx.res.writeHead(200, { 'Content-Type': 'application/json' });
    ctx.res.end(JSON.stringify(payload));
  });


  router.get('/v2/providers/health', async (ctx: RouteContext) => {
    const providers = await checkAllProviders();
    assertNoSecretLeak(providers);
    ctx.res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
    ctx.res.end(JSON.stringify({ version: API_VERSION, mode: ServerConfig.mode, providers }));
  });

  router.get('/v2/observability', async (ctx: RouteContext) => {
    const limit = Math.min(200, Number(ctx.query.get('limit') || '50') || 50);
    const route = ctx.query.get('route') || undefined;
    const recent = getRepos().observability.recent(limit, route);
    const aggregate = getRepos().observability.aggregate(limit);
    ctx.res.writeHead(200, { 'Content-Type': 'application/json' });
    ctx.res.end(JSON.stringify({ version: API_VERSION, recent, aggregate }));
  });

  router.get('/v2/budget', async (ctx: RouteContext) => {
    ctx.res.writeHead(200, { 'Content-Type': 'application/json' });
    ctx.res.end(JSON.stringify({ version: API_VERSION, ...BudgetGuard.status() }));
  });
  router.get('/v2/autonomy/agents', async (ctx: RouteContext) => {
    ctx.res.writeHead(200, { 'Content-Type': 'application/json' });
    ctx.res.end(JSON.stringify({ version: API_VERSION, agents: listAgents() }));
  });

  router.get('/v2/autonomy/tools', async (ctx: RouteContext) => {
    ctx.res.writeHead(200, { 'Content-Type': 'application/json' });
    ctx.res.end(JSON.stringify({ version: API_VERSION, tools: listTools(), mcp: listMcpServers() }));
  });

  router.post('/v2/missions', async (ctx: RouteContext) => {
    const raw = await readJson(ctx.req);
    const objective = typeof raw.objective === 'string' ? raw.objective.trim() : '';
    if (!objective) throw new Error('objective is required');
    const result = await startMission({ objective, policy: (raw.policy || 'BEST'), provider: raw.provider, requireApproval: !!raw.requireApproval, projectId: ctx.gw.projectId, userId: ctx.gw.userId }, ctx.gw);
    ctx.res.writeHead(202, { 'Content-Type': 'application/json' });
    ctx.res.end(JSON.stringify(result));
  });

  router.get('/v2/missions/:id', async (ctx: RouteContext) => {
    const result = missionStatus(ctx.params.id || '');
    if (!result) { ctx.res.writeHead(404, { 'Content-Type': 'application/json' }); ctx.res.end(JSON.stringify({ error: 'mission_not_found' })); return; }
    ctx.res.writeHead(200, { 'Content-Type': 'application/json' });
    ctx.res.end(JSON.stringify(result));
  });

  router.post('/v2/council', async (ctx: RouteContext) => {
    const raw = await readJson(ctx.req);
    if (typeof raw.objective !== 'string' || !raw.objective.trim()) throw new Error('objective is required');
    const result = await runCouncil(raw.objective, ctx.gw, raw.provider, Math.min(4, Math.max(2, Number(raw.maxParticipants) || 3)));
    ctx.res.writeHead(200, { 'Content-Type': 'application/json' });
    ctx.res.end(JSON.stringify(result));
  });

}
