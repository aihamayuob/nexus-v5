import type { ProviderId, ResolvedProvider } from '../config/providerRegistry.js';
import { ProviderRegistry } from '../config/providerRegistry.js';
import { ServerConfig } from '../config/env.js';

export type ProviderHealthStatus = 'READY' | 'DEGRADED' | 'UNAVAILABLE' | 'NOT_CONFIGURED';

export interface ProviderHealth {
  provider: ProviderId;
  status: ProviderHealthStatus;
  configured: boolean;
  latencyMs: number | null;
  model: string;
  checkedAt: string;
  detail?: string;
}

function endpoint(cfg: ResolvedProvider): { url: string; headers: Record<string, string> } {
  switch (cfg.id) {
    case 'ollama':
      return { url: `${cfg.baseUrl}/api/tags`, headers: {} };
    case 'lmstudio':
      return { url: `${cfg.baseUrl}/v1/models`, headers: cfg.apiKey ? { Authorization: `Bearer ${cfg.apiKey}` } : {} };
    case 'openai':
    case 'deepseek':
      return { url: `${cfg.baseUrl}/v1/models`, headers: cfg.apiKey ? { Authorization: `Bearer ${cfg.apiKey}` } : {} };
    case 'anthropic':
      return { url: `${cfg.baseUrl}/v1/models`, headers: cfg.apiKey ? { 'x-api-key': cfg.apiKey, 'anthropic-version': '2023-06-01' } : {} };
    case 'gemini':
      return { url: `${cfg.baseUrl}/v1beta/models`, headers: cfg.apiKey ? { 'x-goog-api-key': cfg.apiKey } : {} };
  }
}

export async function checkProviderHealth(id: ProviderId, fetchImpl: typeof fetch = fetch): Promise<ProviderHealth> {
  const cfg = ProviderRegistry.resolve(id);
  const checkedAt = new Date().toISOString();
  const configured = cfg.capabilities.isLocal || !!cfg.apiKey;
  if (ServerConfig.mode === 'LOCAL_ONLY' && !cfg.capabilities.isLocal) return { provider: id, status: 'UNAVAILABLE', configured: false, latencyMs: null, model: cfg.resolvedModel, checkedAt, detail: 'blocked_by_local_only' };
  if (!configured) return { provider: id, status: 'NOT_CONFIGURED', configured: false, latencyMs: null, model: cfg.resolvedModel, checkedAt };

  const started = Date.now();
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), Math.min(cfg.timeoutMs, 10_000));
  try {
    const { url, headers } = endpoint(cfg);
    const res = await fetchImpl(url, { method: 'GET', headers, signal: controller.signal });
    const latencyMs = Date.now() - started;
    if (res.status >= 200 && res.status < 300) {
      return { provider: id, status: 'READY', configured, latencyMs, model: cfg.resolvedModel, checkedAt };
    }
    if (res.status === 401 || res.status === 403 || res.status === 429 || res.status >= 500) {
      return { provider: id, status: 'DEGRADED', configured, latencyMs, model: cfg.resolvedModel, checkedAt, detail: `upstream_http_${res.status}` };
    }
    return { provider: id, status: 'DEGRADED', configured, latencyMs, model: cfg.resolvedModel, checkedAt, detail: `upstream_http_${res.status}` };
  } catch (e) {
    const latencyMs = Date.now() - started;
    const detail = e instanceof Error ? e.name === 'AbortError' ? 'timeout' : e.message.slice(0, 160) : 'unknown_error';
    return { provider: id, status: 'UNAVAILABLE', configured, latencyMs, model: cfg.resolvedModel, checkedAt, detail };
  } finally {
    clearTimeout(timer);
  }
}

export async function checkAllProviders(fetchImpl: typeof fetch = fetch): Promise<ProviderHealth[]> {
  return Promise.all(ProviderRegistry.list().map((id) => checkProviderHealth(id, fetchImpl)));
}
