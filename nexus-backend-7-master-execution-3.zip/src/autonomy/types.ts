import type { ProviderId } from '../config/providerRegistry.js';
import type { GatewayContext } from '../capability/permissionModel.js';
export type RoutingPolicy='BEST'|'CHEAPEST'|'FASTEST'|'LOCAL_ONLY'|'PRIVATE'|'USER_SELECTED';
export type EvidenceStatus='verified'|'supported'|'uncertain'|'conflicting'|'unverified';
export type Permission='READ'|'WRITE'|'EXECUTE'|'EXTERNAL_NETWORK'|'DELETE'|'MESSAGE'|'ADMIN';
export interface MissionObjective { objective:string; policy?:RoutingPolicy; provider?:ProviderId; maxBudgetUsd?:number; requireApproval?:boolean; projectId?:string|null; userId?:string|null; }
export interface MissionTask { id:string; description:string; dependsOn:string[]; agentId:string; status:'pending'|'running'|'done'|'failed'|'blocked'; provider?:ProviderId; model?:string; result?:string; evidence?:EvidenceStatus; }
export interface AgentDefinition { id:string; role:string; skills:string[]; models:string[]; tools:string[]; memoryScopes:string[]; policies:RoutingPolicy[]; constraints:string[]; evaluationProfile:{correctness:number;completeness:number;evidence:number}; failureHistory:number; }
export interface RouteDecision { provider:ProviderId; model:string; score:number; reasons:string[]; fallbacks:Array<{provider:ProviderId;model:string}>; }
export interface EvaluationResult { correctness:number; completeness:number; hallucinationRisk:number; instructionCompliance:number; evidenceQuality:number; toolSuccess:number; status:EvidenceStatus; issues:string[]; }
export interface MissionResult { missionId:string; status:'accepted'|'running'|'completed'|'failed'|'cancelled'; objective:string; tasks:MissionTask[]; finalOutput?:string; evaluation?:EvaluationResult; replans:number; }
export interface MissionContext { gateway:GatewayContext; objective:MissionObjective; }
