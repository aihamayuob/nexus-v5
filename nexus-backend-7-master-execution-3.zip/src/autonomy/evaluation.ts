import { randomUUID } from 'node:crypto';
import { getDb } from '../persistence/db.js';
import type { EvaluationResult } from './types.js';

export interface BenchmarkCase { id:string; category:'reasoning'|'coding'|'research'|'planning'|'extraction'|'tool_use'|'multi_agent'; input:string; expected?:string; evaluator?:(output:string)=>number; }
export interface BenchmarkResult { id:string; benchmark:string; score:number; metrics:Record<string,number>; passed:boolean; }

export async function runBenchmark(name:string,cases:BenchmarkCase[],runner:(input:string)=>Promise<string>):Promise<BenchmarkResult>{
  const results:number[]=[]; for(const c of cases){const out=await runner(c.input);let score=c.evaluator?c.evaluator(out):c.expected?similarity(out,c.expected):out.trim().length?1:0;results.push(Math.max(0,Math.min(1,score)));}
  const score=results.length?results.reduce((a,b)=>a+b,0)/results.length:0; const metrics={correctness:score,completeness:score,reliability:score}; const passed=score>=0.8; getDb().prepare('INSERT INTO evaluation_runs(id,benchmark,metrics_json,passed,created_at) VALUES(?,?,?,?,?)').run(randomUUID(),name,JSON.stringify(metrics),passed?1:0,Date.now()); return {id:randomUUID(),benchmark:name,score,metrics,passed};
}
function similarity(a:string,b:string){const aa=new Set(a.toLowerCase().split(/\W+/).filter(Boolean)),bb=new Set(b.toLowerCase().split(/\W+/).filter(Boolean));if(!aa.size&&!bb.size)return 1;let hit=0;for(const x of aa)if(bb.has(x))hit++;return hit/Math.max(aa.size,bb.size);}
export function recentEvaluations(limit=30){return getDb().prepare('SELECT * FROM evaluation_runs ORDER BY created_at DESC LIMIT ?').all(Math.min(100,Math.max(1,limit)));}
