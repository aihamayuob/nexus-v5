import test from 'node:test';
import assert from 'node:assert/strict';
import { bootstrapAgents, listAgents } from '../src/autonomy/agentRegistry.js';
import { evaluateOutput } from '../src/autonomy/evaluator.js';
import { assertToolPolicy } from '../src/autonomy/toolFabric.js';
import { getDb } from '../src/persistence/db.js';
getDb();

bootstrapAgents();
test('agent registry exposes structured autonomous agents', () => {
  const ids = listAgents().map(a => a.id);
  assert.deepEqual(ids, ['researcher','analyst','executor','synthesizer']);
});

test('evaluator flags conflicting evidence', () => {
  const r = evaluateOutput('A sufficiently long answer that contains evidence.', 3, 0, 0, 2);
  assert.equal(r.status, 'conflicting');
  assert.ok(r.hallucinationRisk > 0);
});

test('tool fabric enforces least privilege', () => {
  assert.throws(() => assertToolPolicy('web_fetch', ['READ','EXECUTE']), /EXTERNAL_NETWORK/);
});
