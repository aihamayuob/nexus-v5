import { cpSync, existsSync, mkdirSync } from 'node:fs';
mkdirSync('dist/src/persistence', { recursive: true });
if (existsSync('src/persistence/migrations')) cpSync('src/persistence/migrations', 'dist/src/persistence/migrations', { recursive: true });
