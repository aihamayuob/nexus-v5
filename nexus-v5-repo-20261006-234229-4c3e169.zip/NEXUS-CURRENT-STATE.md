# NEXUS-CURRENT-STATE

> Dynamic state document. Written ONLY from evidence gathered in the session
> that produced it (2026-10-07). Not a plan. If the repository disagrees with
> this file, the repository wins. This file did not exist before this commit;
> it is created here for the first time.

## Current Phase
Phase 2 — Modularization (`/nexus-modularize`): **PARTIAL**
(branch `v5.0-polish`).

## Current Boundary
Boundary 5/9 "core": **PARTIAL** (slice 1 VERIFIED; everything else in core PENDING).
Boundaries 1–4 (security, storage, utilities, settings): VERIFIED (earlier work,
historical evidence; re-confirmed only indirectly by this session's regression runs).
Boundaries 6–9 (agents, modes, ops-center, workspace) and the UI-remainder: PENDING.

## Current TARGET SLICE
Core slice 1 — move `encryptState` / `decryptState` into `modules/security.mjs`,
bridge on `window` in `main.js`: **VERIFIED**. Stopped at its stop point.

## Latest Verified Commit
Parent (base): `3a2796f`. The slice commit is the one that adds this file
(HEAD of `v5.0-polish` at ZIP time; a file cannot contain its own hash — read it
with `git log -1`).

## Working Tree State
Clean immediately after the slice commit (verified with `git status --short`
after committing). Environment note: the E2E scripts hard-code
`/home/claude/nexus-v5/`; a symlink to the unpacked repo was created OUTSIDE
the repository to run them.

## Verified Work (this slice)
- Both functions moved byte-for-byte (only `export` added), proven by the
  extraction script (`byte-identical-after-export-strip: true`).
- Behavior equivalence with the ORIGINAL implementation: byte-identical
  envelopes for the same key+IV, cross-decrypt both directions, identical error
  classes, golden vector generated from the original code.
- Module/bridge integration in real Chromium, including the real
  persist → reload → restore pipeline through `autoInitApp`.
- Execution-order safety re-derived from the AST (no new ordering assumption).

## Current Test Evidence (all fresh, final tree)
- Vitest: **132/132** (security.test.mjs: 35). security.mjs coverage: 100% lines/funcs.
- E2E `phase2-core-seed-flows.mjs`: **16/16** post; **15/16** pre-extraction
  (only the patch-specific `bridge-identity` fails, by design).
- E2E `baseline-flows.mjs`: **12/12**. E2E `phase1-security-flows.mjs`: **16/16**.
- Backend `npm test`: **406/406**; `tsc --noEmit`: no errors printed. Backend
  untouched (run only to confirm no collateral change).
- Fault injection: 5 function mutations (2–6 failing Vitest tests each) and 2
  bridge mutations (11/17 and 13/17 E2E checks failing); all files restored
  byte-identical by sha256 and re-passed.
- Logs: `baseline/evidence/phase2-core-slice1-*`. Details: `docs/checkpoints/CP-7.md`.

## Unverified Items
- Behavior in Firefox/Safari (Chromium only).
- ADR-003's statement vs. a V8 `vm.SourceTextModule` probe (see Known Risks).
- `NexusContext.buildAgentContext` live-caller status (static scan found no
  caller in the monolith; not investigated further, not reopened).

## Blocked Items
- `sw.js` is not among the provided artifacts: cumulative cache-manifest
  follow-up (5 files: `/main.js`, `/modules/security.mjs`, `/modules/storage.mjs`,
  `/modules/utilities.mjs`, `/modules/settings.mjs`) cannot be applied. This
  slice added no new file. Must be finalized before Phase 2's Exit Gate.

## Known Risks
- **Deferred documentation finding (ADR-003):** a V8 probe showed an ES module
  reading/writing a classic script's top-level `let`/`const` by bare name,
  which conflicts with ADR-003's wording. NOT acted on; ADR-003 NOT edited;
  nothing was built on the probe. Needs browser-level evidence. Chromium IS
  available here (`PLAYWRIGHT_BROWSERS_PATH=/opt/pw-browsers`; an earlier
  statement that it was unavailable was wrong — only `~/.cache` had been checked).
- `autoInitApp` swallows decrypt failures and "starts fresh"; any future change
  to the crypto seam can silently drop user data. The new E2E guards this.
- Remaining core is state-heavy (`PERSISTABLE_STATE`, 16 variables, `selectedAgentIds`
  has 15 write sites in 8 functions).

## Remaining Scope
Core: `PERSISTABLE_STATE` + 16 state vars, `NexusContext`, `ContextFabric`.
Then agents, modes, ops-center, workspace, UI-remainder; `sw.js`; Phase 2 Exit Gate.

## Next Safe Slice
Core slice 2 — evidence-only, no production-code change: run a browser-level
(Chromium) probe of whether an ES module can read/write classic-script top-level
`let`/`const` by bare name, to resolve the ADR-003 discrepancy. Do NOT edit
ADR-003 inside that slice; record the result and stop.
