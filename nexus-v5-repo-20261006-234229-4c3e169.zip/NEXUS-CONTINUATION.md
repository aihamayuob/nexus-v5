# NEXUS-CONTINUATION

How to resume. Repository state beats this file and beats chat memory.

## 1. Reconstruct first (do not skip)
1. Unpack the latest ZIP; `git branch --show-current` (expect `v5.0-polish`),
   `git status --short`, `git log --oneline | head`.
2. Read `NEXUS-CURRENT-STATE.md`, then `docs/checkpoints/CP-7.md`
   (latest), then `PHASE2-MODULARIZE.md` (section "Boundary 5 — core, slice 1").
3. Read ADR-002 (bridge pattern) and ADR-003 (storage boundary; see the
   deferred finding in CURRENT-STATE before relying on its wording).

## 2. Environment (this repo's tests need it)
- `cd frontend && npm ci && npx vitest run --coverage`
- Backend: `cd src-baseline/nexus-backend && npm ci && npm run build && npm test`
- E2E: scripts hard-code `/home/claude/nexus-v5/`, so create a symlink to the
  unpacked repo there (outside the repo). Chromium is provided by
  `PLAYWRIGHT_BROWSERS_PATH=/opt/pw-browsers`; verify with a real
  `chromium.launch()`, do not infer availability from `~/.cache`.
- `cd e2e && npm ci && node baseline-flows.mjs && node phase1-security-flows.mjs && node phase2-core-seed-flows.mjs`
- Expected on this commit: Vitest 132, E2E 12 / 16 / 16, backend 406 — as
  numbers to RE-MEASURE, not to trust.

## 3. Rules that bit us this session
- A classic-script `let`/`const` is not a `window` property; bridge pattern =
  `main.js` import + `window.x = x`, assigned BEFORE the startup calls.
- Extraction scripts must abort if the monolith differs from HEAD or the target
  block is not found exactly once.
- Prove tests can fail (mutation) and restore byte-identical (sha256).
- E2E scripts must report failures, not crash: a crash is detection but not evidence.
- `autoInitApp` swallows decrypt errors: assert restored DATA, not absence of errors.

## 4. Next slice
Core slice 2 (evidence-only): browser-level probe for the ADR-003 discrepancy.
Stop after recording the result; do not edit ADR-003 or extract anything.

## 5. Exact Arabic command for the next conversation
```
NEXUS v5.0 — Continue من الحالة الموثقة الحالية في المستودع (NEXUS-CURRENT-STATE.md و CP-7)، ولا تعِد ما تم ولا تعيد التخطيط.
نفّذ فقط: Boundary 5 — Core — Slice 2: اختبار browser-level (Chromium الحقيقي) لحسم تعارض ADR-003 — هل تستطيع وحدة ES قراءة/كتابة let/const العلوية في سكربت classic بالاسم المجرد؟
دليل فقط: بدون أي تعديل على كود الإنتاج، وبدون تعديل ADR-003، وبدون استخراج.
سجّل النتيجة كـ finding موثَّق (CP-8 + تحديث CURRENT-STATE/CONTINUATION)، ثم commit وأنشئ ZIP، واكتب الخلاصة بالعربية (STATUS / COMMIT / TESTS / E2E / CHECKPOINT / ما بقي / الشريحة التالية)، ثم STOP.
```
