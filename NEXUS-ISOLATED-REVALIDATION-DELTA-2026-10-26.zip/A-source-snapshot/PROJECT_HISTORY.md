# PROJECT_HISTORY.md — الفهرس التاريخي الموحَّد لـNEXUS

> **الدور:** فهرس بمعرّفات ثابتة (PH-*) يربط المراحل والشرائح والحزم والتقارير بقراراتها (`DECISIONS.md`: OD/CF/PD) وأدلتها (`VERIFICATION.md`: V-*). لا ينسخ المحادثات؛ يحيل إلى المصدر. أُنشئ 2026-10-25 (OD-C2).
> **ما لا يغطيه:** نصوص المحادثات السابقة لم تُسترجع (CF-07). التواريخ المذكورة من الوثائق؛ «≈» = تقدير من تاريخ وثيقة مجاورة. hash الـcommit المذكور **من وثيقة** لا من git (CF-06).
> **الحالة** بالمفردات الست، كما تصفها المصادر ضمن حدودها؛ لا رفع من عندي.

## 1) خريطة المسارات
| المسار | المحتوى | أين حالته الحالية |
|---|---|---|
| A — الواجهة/Core (Phase 0–2) | baseline، أمن Phase 1، نمذجة الواجهة (حدود 1–4 ثم core)، Evidence Integrity | `NEXUS-CURRENT-STATE.md` (السجل) + `docs/checkpoints/CP-1…19` |
| B — Release V1 (محلي/LAN) | Service Worker (B1)، أمن النشر والمفتاح في الذاكرة وCSP (B4) | `docs/DEPLOYMENT-LAN.md` + `baseline/evidence/release-v1-*` |
| C — الخلفية: خصوصية/VEL/أدوات/جينوم | GAP-1، GAP-1B، VEL، G8، G8.1، G8.2، CLOSURE، GENOME-GATE | تقارير الشرائح + `B-evidence/*` + قسم UNIFIED STATE |
| D — الاستمرارية والحوكمة | تعليمات دائمة، سياسة UI/UX/TDD، تأسيس الاستمرارية | `CLAUDE.md`، `DECISIONS.md`، هذا الملف |

## 2) مسار A — الواجهة/Core
| ID | العنصر | التاريخ | المصدر | القرارات | الأدلة | الحالة |
|---|---|---|---|---|---|---|
| PH-A00 | Phase 0 `/nexus-baseline` (فرع `v5.0-polish`، لقطة 233 ملفًا) | 2026-09-16 | `CP-1`، `BASELINE.md`، `baseline/` | OD-P1 | V-A01 | VERIFIED (تاريخي؛ لفظ «DONE» الأصلي محفوظ — انظر DONE audit) |
| PH-A01 | Phase 1 `/nexus-security` (CP-2، ADR-001، `PHASE1-SECURITY.md`) | ≈2026-09 | `CP-2` | OD-P1 | phase1-security-flows 16/16 | VERIFIED (تاريخي) |
| PH-A02 | Phase 2 — الحد 1 security (CP-3) | ≈2026-09/10 | `CP-3`، `PHASE2-MODULARIZE.md` | OD-P1 | Vitest 19→ | VERIFIED (تاريخي) |
| PH-A03 | الحد 2 storage (CP-4) | ≈2026-10 | `CP-4`، ADR-003 | — | | VERIFIED (تاريخي) |
| PH-A04 | الحد 3 utilities (CP-5) | ≈2026-10 | `CP-5` | — | | VERIFIED (تاريخي) |
| PH-A05 | الحد 4 settings (CP-6) | ≈2026-10 | `CP-6` | — | | VERIFIED (تاريخي) |
| PH-A06 | core slice 1 (CP-7): `encryptState/decryptState` → `security.mjs` — commit `4c3e169` | ≈2026-10-07 | `CP-7` | OD-K1 | | VERIFIED |
| PH-A07 | core slice 2 (CP-8): دليل فقط؛ commit `0520af7` | ≈2026-10-08 | `CP-8` | OD-K2 | | VERIFIED (دليل فقط) |
| PH-A08 | Evidence Integrity — فحص (CP-9)؛ commit `b9d4808` | 2026-10-09 | `CP-9` | OD-P3 | | VERIFIED (توثيق) |
| PH-A09 | core slice 3 (CP-10): خريطة حالة؛ commit `9c95fbd` | 2026-10-09 | `CP-10` | OD-K3 | | VERIFIED (ساكن؛ السلوك وقت التشغيل UNVERIFIED عندها) |
| PH-A10 | core slice 4 / C1 (CP-11): snapshot/restore/reset؛ commit `669386b` | 2026-10-09/10 | `CP-11` | | slice4 21/21، طفرات 16/16 | VERIFIED (Chromium 141) |
| PH-A11 | core slice 5 (CP-12): I-1 مؤكَّد = مفقود؛ commit `fbd7236` | 2026-10-10 | `CP-12` | OD-K4 | 27/27 | VERIFIED (دليل فقط) |
| PH-A12 | core slice 6 (CP-13): I-1 عبر O2؛ commit `5770104` | 2026-10-10 | `CP-13` | | 35/35 | VERIFIED (`activityLog` فقط) |
| PH-A13 | core slice 7 (CP-14): `isSendingMessage` عالق مؤكَّد؛ commit `389813f` | 2026-10-10/11 | `CP-14` | | 40/40 | VERIFIED (دليل فقط) |
| PH-A14 | core slice 8 (CP-15): إصلاح `isSendingMessage`؛ commit `b811065` | 2026-10-11 | `CP-15` | | 79/79، طفرات 7/7 | VERIFIED (Chromium 141) |
| PH-A15 | Evidence Integrity guard (CP-16، ADR-004، هجرة 016)؛ commit `bc05f58` | 2026-10-11 | `CP-16` | OD-K5 | V-A04 | VERIFIED ضمن حدود CP-16 |
| PH-A16 | core slice 9 (CP-17): قياس ملكية C2/C3 + مراجعة ADR-003 | 2026-10-12/13 | `CP-17` | OD-K6 (مقدّمة) | V-A06 | VERIFIED (دليل/توثيق)؛ الآلية كانت BLOCKED على المالك |
| PH-A17 | core slice 10 (CP-18، ADR-005): `agentOrder` عبر accessor؛ commit `e17c76d` (مع slice 9) | 2026-10-13/14 | `CP-18` | OD-K6 | slice10 28/28، طفرات 8 | VERIFIED محليًا (متغير واحد)؛ الإصدار كان BLOCKED على `sw.js` ← CF-01 |
| PH-A18 | core slice 11 (CP-19): توصيف `fullAgentPrompt`؛ commit `80c558a` | 2026-10-14/15 | `CP-19` | OD-K7، OD-K8 | VALID 19/19، PRES 42/42 | VERIFIED ضمن حدوده؛ الطفرات PARTIAL |
| PH-A99 | **الحالة الإجمالية** Phase 2 / boundary 5 core / boundaries 6–9 | — | `NEXUS-CURRENT-STATE.md` | PD-08، PD-09 | | **PARTIAL / PARTIAL / PENDING** |

## 3) مسار B — Release V1
| ID | العنصر | التاريخ | المصدر | القرارات | الأدلة | الحالة |
|---|---|---|---|---|---|---|
| PH-B01 | B1: `frontend/sw.js` مُؤلَّف من خريطة الاعتماديات، يشمل `state.mjs`؛ E2E بـSW حقيقي | 2026-10-16 | `release-v1-b1-acceptance-criteria.md` | OD-R1، CF-01 | V-B01 | VERIFIED ضمن حدود B1 |
| PH-B02 | B2، B3 | — | لا أثر | PD-14 | — | UNVERIFIED (نطاقهما غير معروف) |
| PH-B04 | B4: حارس النشر، مفتاح البوابة في الذاكرة، CSP، اختبار الترويسات، `DEPLOYMENT-LAN.md` | 2026-10-16 | `release-v1-b4-acceptance-criteria.md`، `docs/DEPLOYMENT-LAN.md` | OD-R2، OD-R3 | V-B02…V-B05 | VERIFIED ضمن حدود B4 |
| PH-B05 | جهاز LAN آخر عبر HTTP | 2026-10-16 | `release-v1-lan-secure-context-probe-*` | PD-11 | V-B06 | BLOCKED |

## 4) مسار C — الخلفية الأمنية
| ID | العنصر | التاريخ | المصدر | القرارات | الأدلة | الحالة |
|---|---|---|---|---|---|---|
| PH-C01 | GAP-1 (توجيه الخصوصية؛ إصلاح fallback في `modelRouter.ts`) | 2026-10-18/19 | ذاكرة؛ كود اللقطة | OD-G1، OD-G2، OD-G3 | V-C01 | UNVERIFIED (لا تقرير) |
| PH-C02 | GAP-1B (Verifier وEvaluationEngine وagentGenome وfreshnessEngine) | 2026-10-19/20 | `NEXUS-GAP1B-HANDOFF-2026-10-20.zip` (غير متاحة)؛ كود اللقطة | OD-G3 | V-C01 | UNVERIFIED |
| PH-C03 | VEL vertical slice (طبقة التنفيذ الموثَّق: سياسة، إيصالات write-ahead، قراءة مستقلة) | 2026-10-20/21 | `NEXUS-VEL-VERTICAL-SLICE-REPORT.md`، `ADR/PROPOSED-VEL-…` | OD-V1 | V-C02 | PARTIAL |
| PH-C04 | G8: تصنيف أثر الأدوات الإلزامي | 2026-10-21 | `NEXUS-G8-REPORT.md` | OD-V1 | V-C03 | PARTIAL |
| PH-C05 | G8.1: `code_execution` خارج التسجيل الافتراضي | 2026-10-21 | `NEXUS-G8.1-REPORT.md` | OD-V2 | V-C04 | VERIFIED ضمن الحدود؛ PARTIAL/BLOCKED لما تبقى |
| PH-C06 | G8.2: إزالة وعد `code_execution` من وكيل `data` | 2026-10-22 | `NEXUS-G8.2-REPORT.md` | OD-V3 | V-C05 | VERIFIED ضمن حدود بيئة الاختبار؛ BLOCKED لإثبات git |
| PH-C07 | G8.2-CLOSURE: سياسة ثابتة لوكيل `data` لا يتجاوزها الجينوم | 2026-10-24 | `NEXUS-G8.2-CLOSURE-REPORT.md` | OD-V4 | V-C06 | PARTIAL |
| PH-C08 | G8.2-GENOME-GATE: فحص ادعاءات القدرات عند propose/approve/rollback لكل الوكلاء | 2026-10-24/25 | `NEXUS-G8.2-GENOME-GATE-REPORT.md`؛ الحزمة (V-P02) | OD-V5، OD-C4 | V-C07 | **PARTIAL** |

## 5) مسار D — الحوكمة والاستمرارية
| ID | العنصر | التاريخ | المصدر | القرارات | الحالة |
|---|---|---|---|---|---|
| PH-D01 | تعليمات المشروع الدائمة + `MASTER-CONTEXT-2` + مرجع 15 أكتوبر | 2026-10-05…15 | وثائق Project | OD-P1 | معتمد (تاريخي جزئيًا ← CF-04) |
| PH-D02 | سياسة UI/UX/TDD/صدق القدرات (ملحق مرجع 15 أكتوبر + ملحق اللصق) | 2026-10-24 | وثائق Project | OD-P2 | معتمد؛ تثبيت الإعدادات PENDING |
| PH-CONT | **تأسيس الاستمرارية** (هذا المجموعة الوثائقية) | 2026-10-25 | حزمة `NEXUS-CONTINUITY-FOUNDATION-2026-10-25` | OD-C1…OD-C10 | PARTIAL: كُتب في نسخة معزولة وProject؛ تحميل `CLAUDE.md` تلقائيًا وتثبيت الإعدادات UNVERIFIED/PENDING |
| PH-REV01 | **إعادة تحقق GENOME-GATE في النسخة المعزولة** (tsc/build/61/681/dist-check/طفرات 18) | 2026-10-26 | `VERIFICATION.md` §E؛ سجل `GENOME-GATE-09-isolated-revalidation-2026-10-26.log` | OD-C11 | VERIFIED داخل النسخة المعزولة فقط؛ GENOME-GATE يبقى PARTIAL؛ الحي BLOCKED |

## 6) حزم التسليم المعروفة
| ID | الحزمة | البصمة | الإتاحة |
|---|---|---|---|
| PH-PKG-CP19 | `NEXUS-CP19-HANDOFF-2026-10-15.zip` | غير معروفة | غير متاحة (UNVERIFIED) |
| PH-PKG-GAP1B | `NEXUS-GAP1B-HANDOFF-2026-10-20.zip` (أساس VEL) | غير معروفة | غير متاحة |
| PH-PKG-VEL…G82 | حزم VEL وG8 وG8.1 وG8.2 المنفردة | غير معروفة | غير متاحة (مضمَّنة تراكميًا) |
| PH-PKG-CLOSURE | `NEXUS-G8.2-CLOSURE-HANDOFF-2026-10-24.zip` | `7dfa8492…67f0` | مرفق المالك في هذه الجلسة |
| PH-PKG-GG | `NEXUS-G8.2-GENOME-GATE-HANDOFF-2026-10-24.zip` | `24a04441…5be25` | مُسلَّمة في الجلسة؛ داخل Project: انظر سجل الحفظ في `NEXUS-CURRENT-STATE.md` (UNIFIED STATE §حفظ) |
| PH-PKG-CF | `NEXUS-CONTINUITY-FOUNDATION-2026-10-25.zip` | يُسجَّل في تقرير المهمة | تُسلَّم بعد التحقق |

## 7) وثائق Project (مساحة المعرفة) وعلاقتها بالمجموعة الوثائقية
`NEXUS-PROJECT-MASTER-CONTEXT-2.md` (العقد الهندسي)، `NEXUS-CLAUDE-PROJECT-INSTRUCTIONS-REFERENCE-2026-10-15.md` (تاريخي + سياسة 2026-10-24 + تصحيح 2026-10-25)، `NEXUS-PROJECT-INSTRUCTIONS-ADDENDUM-FOR-MANUAL-PASTE.md`، تقارير G8/G8.1/G8.2/CLOSURE، `CP-10/12/13/14/15/17/18`، والوثيقة الفارغة (CF-08). النسخ المرجعية الجديدة تحت `continuity/` (تفاصيلها في تقرير المهمة).
