# NEXUS-ISOLATED-REVALIDATION-REPORT — تقرير التحقق من النسخة المعزولة (2026-10-26)

**القرار:** OD-C11 «ISOLATED SNAPSHOT VALIDATION» (مسجَّل في `DECISIONS.md`). **النطاق:** النسخة المعزولة فقط؛ ليست بديلًا عن المستودع الحي ولا تثبت مطابقتها له. لم يُعدَّل مصدر ولا اختبار؛ لم تُطبَّق رقعة؛ لا commit/push؛ لا بيانات اعتماد ولا قواعد إنتاج.

## 1) النسخة المختبرة
- `NEXUS-CONTINUITY-FOUNDATION-2026-10-25.zip` — SHA-256 الفعلي `489aeec65d31632aac7b4d64cde0f89182b4a6548bf6465c8aa4258b1f9114d6` = المسجَّل. `testzip` سليم؛ 1043 مدخلًا؛ `SHA256SUMS.txt` 1042/1042؛ `C-originals` 6/6؛ الملفات الـ12 12/12.
- الشجرة المختبرة: `A-source-snapshot/src-baseline/nexus-backend` (الباكند). مفكوكة في مجلد مؤقت ثانٍ منفصل عن الأرشيف وعن الفك الأول.

## 2) هل الرقعة والاختبارات موجودة فعلًا؟ — **نعم، مطبّقة داخل الشجرة**
- `patch -R -p1 --dry-run --batch -s` على الشجرة غير المعدّلة: exit 0 على الملفات الستة (`agentRunner.ts`، `agentToolResolution.ts`، `agentGenome.ts`، `genomeCapabilityCheck.ts`، `test/agentDataFixedPolicy.test.ts`، `test/genomeCapabilityGate.test.ts`)؛ الاتجاه الأمامي يرفض لأن الملفات موجودة.
- ملف الرقعة موجود (`B-evidence/G8.2-GENOME-GATE/…changes.patch`) وبصمته `00fa8c3d…a40e` = `05-patch-sha.txt`. حدّ: فحص dry-run فقط؛ لم تُطبَّق ولم تُعكَس فعليًا.

## 3) الأوامر الفعلية والنتائج
| الفحص | الأمر | النتيجة |
|---|---|---|
| الاعتماديات | `npm ci --no-audit --no-fund` | 4 حزم؛ TypeScript 7.0.2 و`@types/node` 22.20.1 من الـlockfile |
| TypeScript | `npm run typecheck` ثم `tsc` العام 6.0.3 | exit 0 في الحالتين (220 ملفًا) |
| البناء | `npm run build` | exit 0 |
| اختبارات البوابة | `tsx --test test/genomeCapabilityGate.test.ts` ×4 | **61/61** في كل مرة |
| المجموعة الكاملة | `tsx --test 'test/**/*.test.ts' 'test/*.test.ts'` | **681/681**، 160.3 ث |
| `npm test` | السكربت الموثّق | **681/681**، 156.5 ث |
| dist-check | `dist-check-gate.mjs file://…/dist` | **PASS** |
| سجل الأدوات في dist | probe قراءة فقط (`:memory:`) | `["calculate","web_fetch"]`؛ لا `code_execution`؛ 24 وكيلًا؛ لا وكيل يعلن أدوات |
| طفرات البوابة | `run_mutations_gate.py $PWD 61` على نسخة منفصلة | **18/18** قُتلت، واستُعيدت الملفات بايتيًا |
| سلامة المصدر | `diff -rq` أصل↔نسخة العمل | **0 فروق** بعد كل التشغيلات |

Node v22.23.4، npm 10.9.9، tsx 4.23.12 (عام). السجل المجمّع: `GENOME-GATE-09-isolated-revalidation-2026-10-26.log`.

## 4) نجح / فشل / لم يُشغَّل
- **نجح:** كل ما في الجدول أعلاه. **فشل:** لا شيء.
- **لم يُشغَّل:** اختبار RED للاختبارات الستة المضافة بعد التنفيذ؛ طفرات الشرائح السابقة (G8 12، G8.1 7، G8.2 6، CLOSURE 12)؛ Vitest للواجهة؛ E2E/Chromium؛ `audit-genomes-readonly.mjs` على قاعدة؛ التزام نموذج حقيقي؛ تدقيق قاعدة حية؛ تطبيق/عكس فعلي للرقعة.

## 5) الفروق عن تقرير 24 أكتوبر
- **لا فروق عددية:** 61، 681، 18/18، tsc/build 0، dist-check PASS.
- فروق غير عددية: إصدارا TypeScript وtsx لم يُسجَّلا في سجلات 24 أكتوبر (Node مطابق)، والمدة 160.3 ث مقابل 152.2 ث.
- فروق وثائقية: `NEXUS-CONTINUATION.md` §2 يذكر `npm test` = 472/472 (رقم حقبة CP-16)، والفعلي الآن 681.
- **ملاحظة إعادة إنتاج:** `tsx` غير معلن في `devDependencies`، فـ`npm ci` وحده لا يكفي لـ`npm test`؛ لزم `tsx` عام على الـPATH (الوثيقة تأمر `npm i --no-save tsx …`).

## 6) الملفات التي تغيّرت (وثائق فقط، إضافات مؤرخة، 0 أسطر محذوفة)
`DECISIONS.md` (OD-C11 + ملاحظة)، `VERIFICATION.md` §E، `NEXUS-CURRENT-STATE.md` (ملاحظة إعادة التحقق)، `PROJECT_HISTORY.md` (PH-REV01)، `CHANGELOG.md`، `NEXUS-CONTINUATION.md` §6، `NEXT-SESSION-START-HERE.md` (كتلة مؤرخة)، وجديد: سجل GENOME-GATE-09 وهذا التقرير. المصدر والاختبارات لم تتغير.

## 7) الحالات
- **VERIFIED داخل النسخة المعزولة فقط:** الرقعة مطبّقة في الشجرة؛ 61/61؛ 681/681؛ tsc وbuild؛ dist-check؛ سجل الأدوات بلا `code_execution`؛ طفرات البوابة 18/18؛ سلامة الأرشيف.
- **GENOME-GATE يبقى PARTIAL:** تدقيق القاعدة الحية BLOCKED؛ التزام النموذج UNVERIFIED؛ القيود L1–L3؛ in-sample؛ الاختبارات الستة بلا RED؛ لم تُطبَّق على الحي.
- **BLOCKED بخصوص الحي:** الفرع/HEAD/status، هل طُبِّقت الرقع (VEL…GENOME-GATE، GAP-1/1B، Release V1)، ADR-006، B2/B3، تثبيت `CLAUDE.md`، اختبار التحميل التلقائي. **PENDING:** لصق الملحق v2 في إعدادات Project.

**توقّف:** لا مرحلة هندسية جديدة دون قرار منفصل.
