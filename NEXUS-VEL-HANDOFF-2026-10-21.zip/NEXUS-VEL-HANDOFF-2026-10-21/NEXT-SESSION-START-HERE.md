# NEXT-SESSION-START-HERE — NEXUS VEL (Verified Execution Layer), شريحة رأسية أولى

> وثيقة ذاتية الاكتفاء. المصدر الأعلى للحقيقة: المستودع والأدلة القابلة لإعادة التشغيل لا ذاكرة المحادثة. **الحالة الإجمالية: PARTIAL.** لا commit ولا push. لا تُعلن «آمن/موثوق/جاهز تجاريًا».

## 1) أين نحن
- نُفِّذت شريحة VEL واحدة على **نسخة عمل مستعادة** من `NEXUS-GAP1B-HANDOFF-2026-10-20.zip` (لا `.git`، ليست المستودع الحي). `A-source-snapshot/` = الشجرة الكاملة بعد GAP-1 وGAP-1B **وVEL**.
- التقرير الكامل: `NEXUS-VEL-VERTICAL-SLICE-REPORT.md` (اقرأه أولًا). دليل التشغيل: `A-source-snapshot/docs/VEL-VERTICAL-SLICE.md`. ADR مقترح بلا رقم: `A-source-snapshot/ADR/PROPOSED-VEL-verified-execution-layer.md`.
- **ADR-006 غير موجود** في المصدر المتاح؛ لم يُعدَّل ولم يُعتبر معتمدًا؛ لم تُفحص علاقته بـVEL.
- أدلة GAP-1/GAP-1B التاريخية بقيت في الحزمة السابقة (`NEXUS-GAP1B-HANDOFF-2026-10-20.zip`) وليست هنا.

## 2) الموثَّق فعليًا (هذه الجولة، موصل اختبار فقط)
- خط الأساس قبل التعديل: 546/546، tsc exit 0. بعد: **590/590**، 0 فشل؛ `tsc` و`npm run build` exit 0؛ `dist` يعمل. اختبارات VEL: 44/44 (5 تشغيلات). طفرات: 12/12 اكتُشفت.
- 20 ملفًا (8 معدّلة، 12 جديدة): `B-evidence/VEL/VEL-changes.patch` (تُطبَّق نظيفة على اللقطة الأصلية بـ`patch -p1`) وبصماتها في `changed-file-hashes.txt`.
- **تعديل اختبار قائم واحد** يحتاج تأكيدك: `evidenceIntegrity.test.ts` AC-7 (سطر «016 هي آخر هجرة» ⇒ «لا هجرة بعد 016 تلمس claim_evaluations»). السبب والتفاصيل في التقرير.

## 3) PENDING / BLOCKED / UNVERIFIED
- **BLOCKED:** تطبيق الرقعة على مستودعك الحي (لا وصول)؛ ADR-006.
- **PENDING:** عرض حالات الإيصال في الواجهة؛ موافقة بشرية لكل فعل؛ مسارات أثر خارج خط الأدوات (IoT push، رفع fine-tuning، webResearch، `/api/tools/fetch`، المجدول)؛ إلزام تصريح `effect` للأدوات الجديدة.
- **UNVERIFIED:** موصل حقيقي؛ e2e Chromium (15 سكربتًا لم تُشغَّل)؛ قتل عملية فعلي أثناء إرسال؛ بيئات أبطأ؛ vitest.

## 4) أوامر إعادة التشغيل
```bash
cd A-source-snapshot/src-baseline/nexus-backend
npm i --no-save tsx typescript @types/node
npx tsx --test test/verifiedExecution.test.ts                     # 44/44
npx tsx --test 'test/**/*.test.ts' 'test/*.test.ts'               # المتوقع 590 / 0 فشل
npx tsc -p tsconfig.json --noEmit && npm run build
# رقعة على لقطة نظيفة:  patch -p1 --dry-run < B-evidence/VEL/VEL-changes.patch   (من جذر نسخة من لقطة 2026-10-20)
```
(الاختبارات تُنشئ مجلد `data/` أحيانًا؛ احذفه قبل أي حزمة.)

## 5) قرارات تنتظر المالك
1. تعريف `VERIFIED` المحصور بالإيصالات + رقم ADR (وتزويد ADR-006).
2. قبول تعديل AC-7 أو بديله.
3. إلزام `effect` للأدوات الجديدة عند الإقلاع (G8).
4. الشريحة التالية: (أ) ضم IoT/fine-tuning إلى VEL، (ب) واجهة الحالات، (ج) موافقة لكل فعل (D1.3)، (د) موصل حقيقي منخفض المخاطر.
5. سياسة الأفعال الخارجية للمهام LOCAL_ONLY/PRIVATE.
6. سلسلة تجزئة/توقيع للإيصالات إن لزم.
7. commit/push.

## 6) الخطوة الوحيدة المسموحة تالياً
انتظر قرار المالك. بعده **شريحة واحدة صغيرة** على بند واحد من §5 → INSPECT→MAP→DIAGNOSE→PATCH→TEST→VERIFY→DOCUMENT → **توقّف**.

## 7) ممنوعات
لا تبدأ من الصفر ولا تُعِد ما اكتمل؛ لا commit/push؛ لا GAP-2 ولا عميل MCP بلا قرار؛ لا تُضعف اختبارًا لإنجاح تغيير؛ لا «DONE»؛ لا تنسب نتائج موصل الاختبار لموصل حقيقي؛ لا تدّعِ وصولًا للمستودع الحي؛ لا تعتمد GitHub مصدرًا.
