# NEXUS-CONTINUATION

How to resume. Repository state beats this file and beats chat memory.

## 1. Reconstruct first (do not skip)
1. Unpack the latest ZIP; `git branch --show-current` (expect `v5.0-polish`),
   `git status --short`, `git log --oneline | head`.
2. Read `NEXUS-CURRENT-STATE.md`, then `docs/checkpoints/CP-10.md` (latest; core slice 3 — read-only
   state map, facts vs inferences, candidate seams), then `docs/checkpoints/CP-9.md` (Evidence
   Integrity inspection — guard BLOCKED on owner decisions, no production change), then
   `docs/checkpoints/CP-8.md` (slice 2, evidence-only), then `docs/checkpoints/CP-7.md` (slice 1), then
   `PHASE2-MODULARIZE.md` (section "Boundary 5 — core, slice 1"; its "DONE" wording for
   boundaries 1–4 is historical — see the Terminology note in CURRENT-STATE).
3. Read ADR-002 (bridge pattern) and ADR-003 (storage boundary; see the
   documentation finding in CURRENT-STATE / CP-8 before relying on its wording).
   Verify the chain: `git rev-parse HEAD~1` should be `b9d4808`, `HEAD~2` = `0520af7`, `HEAD~3` = `4c3e169`.

## 2. Environment (this repo's tests need it)
- `cd frontend && npm ci && npx vitest run --coverage`
- Backend: `cd src-baseline/nexus-backend && npm ci && npm run build && npm test`
- E2E: scripts hard-code `/home/claude/nexus-v5/`, so create a symlink to the
  unpacked repo there (outside the repo). Chromium is provided by
  `PLAYWRIGHT_BROWSERS_PATH=/opt/pw-browsers`; verify with a real
  `chromium.launch()`, do not infer availability from `~/.cache`.
- E2E setup (learned in slice 3): `e2e/` has no lockfile, so `npm ci` fails — use
  `PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1 npm install --no-package-lock --no-save playwright@1.56.1`
  (the unpinned latest playwright does not match the browsers in `/opt/pw-browsers`), and build the backend first
  (`cd src-baseline/nexus-backend && npm run build`) or `backend-boot` fails. Do not commit `node_modules`/lockfiles.
- `cd e2e && node baseline-flows.mjs && node phase1-security-flows.mjs && node phase2-core-seed-flows.mjs`
- Slice 3 analyzer (read-only, self-locating; acorn is not a repo dependency — `npm i acorn@8.19.0` in a scratch
  dir and point `ACORN_DIR` at its `node_modules` parent): `ACORN_DIR=<dir> node baseline/evidence/phase2-core-slice3-state-map.mjs`
  (expects 22/22; rewrites `…-state-map-results.json`, which must stay byte-identical on an unchanged tree).
- Slice 2 probe (self-locating, no hard-coded path):
  `PLAYWRIGHT_BROWSERS_PATH=/opt/pw-browsers node baseline/evidence/phase2-core-slice2-adr003-probe.mjs`
  (expects 19/19; it rewrites `…-probe-results.json` and the generated module — if you
  re-run it, `git diff` shows only timestamps/scratch path changes in the JSON).
- Expected on this commit: Vitest 132, E2E 12 / 16 / 16, backend 406, slice 2 probe 19 —
  as numbers to RE-MEASURE, not to trust.

## 3. Rules that bit us this session
- A classic-script `let`/`const` is not a `window` property; bridge pattern =
  `main.js` import + `window.x = x`, assigned BEFORE the startup calls.
- Extraction scripts must abort if the monolith differs from HEAD or the target
  block is not found exactly once.
- Prove tests can fail (mutation) and restore byte-identical (sha256).
- E2E scripts must report failures, not crash: a crash is detection but not evidence.
- `autoInitApp` swallows decrypt errors: assert restored DATA, not absence of errors.
- Slice 2 finding (Chromium 141): module code can read/write classic top-level `let`/`var`
  by bare name (const: read OK, write TypeError; let/const not on `window`). This is a
  FINDING, not a design authorization: ADR-003 and the bridge pattern are unchanged until
  a separate explicit decision. Evidence-probe helpers must use collision-proof names
  (a helper called `R` or `p` could shadow a monolith global and corrupt a read).

## 4. Next slice
**Core slice 4 (PROPOSED, PENDING — the first code-changing core slice):** candidate **C1** from `CP-10.md` §4 —
pure registry-parameter versions of `snapshotPersistableState` / `restorePersistableState` /
`resetPersistableState` in a module, bridged per ADR-002 under their existing names. Does not move
`PERSISTABLE_STATE` or any of the 16 variables, does not touch `persistState`/`autoInitApp`, does not need ADR-003
edited. Define acceptance criteria first (unit tests, byte-level extraction proof, real `autoInitApp` restore E2E,
mutation proof, 132/12/16/16 re-measured), then execute, verify, document, STOP. Moving variable ownership
(C2/C3) stays blocked on an owner decision about the mechanism and a separate ADR-003 revision.

Separate and owner-gated (do NOT mix with core): the Evidence Integrity guard is
BLOCKED until the decisions in `docs/checkpoints/CP-9.md` §4 are made (fail-closed policy for
`EvidenceItem` without a declared kind; kind for Ops Center manual evidence rows; reason
persistence; ADR-004). The recommended minimal seam is in CP-9 §5.

## 5. Exact Arabic command for the next conversation
```
NEXUS v5.0 — Continue من الحالة الموثقة الحالية في المستودع (NEXUS-CURRENT-STATE.md و CP-10)، ولا تعِد ما تم ولا تعيد التخطيط.
أولاً: أعد بناء الحالة من المستودع (Git، الشجرة، الـ HEAD، الوثائق) وأعد قياس الاختبارات ولا تثق بالأرقام المكتوبة.
ثم نفّذ فقط: Boundary 5 — Core — Slice 4 (المرشّح C1 في CP-10 §4): دوال نقيّة تأخذ السجل كمعامل صريح لـ snapshot/restore/reset الخاصة بـ PERSISTABLE_STATE، بنمط bridge (ADR-002) وبأسمائها الحالية، دون نقل PERSISTABLE_STATE أو أي من المتغيرات الـ16، ودون لمس persistState/autoInitApp، ودون تعديل ADR-003.
عرّف معايير القبول أولاً (اختبارات وحدة تشمل مفتاحاً غائباً ⇒ قيمة افتراضية طازجة، إثبات استخراج على مستوى البايت، E2E للاستعادة عبر autoInitApp الحقيقي، إثبات mutation، وإعادة قياس 132/12/16/16)، ثم نفّذ وتحقق ووثّق (CP-11 + تحديث CURRENT-STATE/CONTINUATION/CHANGELOG).
Evidence Integrity يبقى BLOCKED ولا يُخلط بهذه الشريحة.
ثم commit وأنشئ ZIP بعد الـ commit، وتحقق أن الشجرة نظيفة والـ HEAD المُوثَّق يطابق الـ commit، واكتب الخلاصة بالعربية (STATUS / COMMIT / TESTS / E2E / CHECKPOINT / ما بقي / الشريحة التالية)، ثم STOP.
```
