# NEXUS-CURRENT-STATE

> Dynamic state document. Written ONLY from evidence gathered in the session
> that produced it (2026-10-07; Evidence Integrity and core slice 3 entries: 2026-10-09). Not a plan.
> If the repository disagrees with this file, the repository wins. Created in the
> core slice 1 commit (`4c3e169`); updated by the core slice 2 commit and by the
> Evidence Integrity inspection commit (docs/evidence only — see `docs/checkpoints/CP-9.md`) and by
> the core slice 3 commit (read-only state map, docs/evidence only — see `docs/checkpoints/CP-10.md`).

## Current Phase
Phase 2 — Modularization (`/nexus-modularize`): **PARTIAL**
(branch `v5.0-polish`).

## Current Boundary
Boundary 5/9 "core": **PARTIAL** (slice 1 VERIFIED; slice 2 VERIFIED as an evidence-only
slice; slice 3 VERIFIED as a static read-only map — runtime behavior UNVERIFIED; everything else in core PENDING).
Boundaries 1–4 (security, storage, utilities, settings): VERIFIED (earlier work,
historical evidence; re-confirmed only indirectly by this session's regression runs).
Boundaries 6–9 (agents, modes, ops-center, workspace) and the UI-remainder: PENDING.

## Current TARGET SLICE
**Core slice 3 — read-only ownership / initialization / mutation map of `PERSISTABLE_STATE` and its 16 state
variables: VERIFIED (static map only; runtime UNVERIFIED).** Evidence/docs only; no production code, test,
ADR or contract changed (`git diff --stat HEAD -- frontend src-baseline e2e ADR PHASE2-MODULARIZE.md` empty).
Reproducible analyzer `baseline/evidence/phase2-core-slice3-state-map.mjs` (22/22 self-checks, deterministic JSON).
Key FACTS (details + inferences in `docs/checkpoints/CP-10.md`): all 16 are col-0 `let` in the main classic script,
literal-initialized, and the registry's `default()` text equals each initializer (16/16); 15 are declared before
`PERSISTABLE_STATE` (L4931), `errorLog` (L5530) after it — TDZ-safe today because no load-time code touches any;
32 rebind sites outside the registry setters, 47 distinct writer units, 85 reader units; `selectedAgentIds` has 14
rebinds in 7 units (+ setter) and `messages` 17 writer units / 73 in-place mutations; `restorePersistableState` has
3 callers (`autoInitApp`, `pullSyncIfNewer`, `resolveSyncConflict`); `persistState` has 38 caller units and itself
splices `messages` before the snapshot; 0 inline handlers reference the 16 names directly; `main.js`/modules do not
reference them; E2E `phase1-security-flows.mjs` reads and ASSIGNS `messages` by bare name (L169/L175).
Evidence Integrity remains **BLOCKED** (below) and was not touched.
Previous: **Evidence Integrity micro-invariant** (inside Phase 2; NOT a new phase, NOT part of core):
inspect + map + measured experiment + documentation only — guard **BLOCKED** pending owner
decisions (CP-9 §4). No production code, test, API or UI changed. Seam identified:
`EvaluationEngine.evaluate()` (`evaluationEngine.ts` L82–123), the only producer of the
5-state verdict/confidence and the shared choke point of its 2 callers
(`webResearch.ts:165`, `evaluation.ts:43`). Enforcement needs fail-closed on the `EvidenceItem`
contract; a scratch (not applied) experiment broke 9/24 existing tests, and the Ops Center UI
sends evidence with no kind. (Core slice 3 was not started in that session and was not mixed in; it ran later — see above.)
Previous (unchanged below): Core slice 2 — evidence-only browser-level (real Chromium) probe of module access to
classic-script top-level `let`/`const`/`var` by bare name, plus a strictly read-only
check against the real monolith: **VERIFIED**. No production code changed. Stopped at
its stop point.
Previous: Core slice 1 — move `encryptState` / `decryptState` into
`modules/security.mjs`, bridge on `window` in `main.js`: **VERIFIED** (commit `4c3e169`).

## Latest Verified Commit
Latest commit that changed verified production behavior: `4c3e169` (core slice 1, VERIFIED).
`0520af7` = core slice 2 commit (evidence-only, VERIFIED, no production change); `b9d4808` = Evidence
Integrity inspection commit (docs/evidence only). The core slice 3 commit is docs/evidence only and is HEAD
of `v5.0-polish` at ZIP time (a file cannot contain its own hash — read it with `git log -1`); chain check:
`git rev-parse HEAD~1` must be `b9d4808`, `HEAD~2` = `0520af7`, `HEAD~3` = `4c3e169`.

## Working Tree State
Clean immediately after the core slice 3 commit (verified with `git status --short`
after committing; see the session report). Environment note: the E2E scripts hard-code
`/home/claude/nexus-v5/`; this session ran them from a COPY of the unpacked repo at
that path (outside the original extraction). The slice 2 runner resolves its paths
relative to its own location and needs no hard-coded path.

## Verified Work (slice 2 — commit `0520af7`)
- Real Chromium **141.0.7390.37**. Synthetic classic+module page (layout mirrors the
  monolith), served from a scratch temp dir. Module code reads/writes by bare name:
  - **let**: read OK, write OK (seen by classic), NOT on `window`.
  - **var**: read OK, write OK (seen by classic and `window`), on `window`.
  - **const**: read OK, write throws **TypeError** (value unchanged), NOT on `window`.
  - Live binding both directions (classic write → module read). Module-declared
    `let`/`var` are invisible to the classic script (reverse isolation).
  - Negative controls: undeclared read and write → **ReferenceError**; `typeof` → `"undefined"`.
  - Modules-only control (module B reading module A's `let`/`const`/`var`) → ReferenceError
    ×3, showing the probe distinguishes shared-global from private scope.
- Read-only check on the REAL monolith (no assignments, no calls): 56/56 `let`,
  57/57 `const`, 370/370 functions readable by bare name from an injected module;
  0 mismatches vs. classic global scope; `let`/`const` on `window`: 0; functions: 370/370.
  Integrity: 13 frontend files SHA-256 identical before/after, `git status` on
  production paths empty, app-state fingerprint unchanged.
- Acceptance: **19/19** probe checks; two runs gave identical findings.
- Not exercised by design: writes on the real monolith; `var` on the real monolith
  (it has no column-0 top-level `var`).
- Interpretation and limits: `docs/checkpoints/CP-8.md`. The positive result does NOT
  authorize editing ADR-003, changing the bridge pattern, or changing production code.

## Verified Work (slice 1 — earlier commit `4c3e169`)
- Both functions moved byte-for-byte (only `export` added), proven by the
  extraction script (`byte-identical-after-export-strip: true`).
- Behavior equivalence with the ORIGINAL implementation: byte-identical
  envelopes for the same key+IV, cross-decrypt both directions, identical error
  classes, golden vector generated from the original code.
- Module/bridge integration in real Chromium, including the real
  persist → reload → restore pipeline through `autoInitApp`.
- Execution-order safety re-derived from the AST (no new ordering assumption).

## Test Evidence — core slice 3 session (2026-10-09, production tree unmodified since `4c3e169`; all fresh)
- Slice 3 analyzer: **22/22**, two consecutive runs → identical JSON (sha256 `a1046086…`); a mutation of the
  new handler check made it fail (21/22) and the script was restored byte-identical (sha256).
- Frontend Vitest **132/132** (4 files). E2E `baseline-flows` **12/12**, `phase1-security-flows` **16/16**,
  `phase2-core-seed-flows` **16/16**. Logs: `baseline/evidence/phase2-core-slice3-*`.
- Backend: `npm run build` exit 0 (needed for E2E `backend-boot`). NOT run: backend `npm test`/`tsc --noEmit`
  (backend untouched), slice 2 probe.
- Environment lessons: `e2e/` has no lockfile (`npm ci` fails) and the unpinned `playwright` is newer than
  `/opt/pw-browsers` → install `playwright@1.56.1` with `--no-save --no-package-lock`; the backend must be built.

## Test Evidence — Evidence Integrity session (2026-10-09, unmodified production tree at `0520af7`)
- Backend: `npm ci` exit 0; `tsc -p tsconfig.json --noEmit` exit 0 (no output); `npm test`
  **406/406** pass, 0 fail (120.0 s). Logs: `baseline/evidence/phase2-evidence-integrity-baseline-*.log`.
- Scratch fail-closed experiment (NOT applied; patch + log kept as evidence): 3 test files,
  24 tests → 15 pass / 9 fail. Proves only the effect of the policy on existing tests.
- NOT run in this session: `npm run build`, frontend Vitest, E2E (12/16/16), slice 2 probe.
  The figures in the next section are from the slice 2 session and are NOT re-measured here.

## Current Test Evidence — slice 2 session (all fresh at that time, final tree of that session)
- Slice 2 probe: `baseline/evidence/phase2-core-slice2-adr003-probe.mjs` → **19/19**
  (log: `…-probe.log`; raw JSON: `…-probe-results.json`).
- Slice 2 regression on the final tree (production paths show NO diff vs `4c3e169`, proven
  with `git diff --stat HEAD`): Vitest **132/132** (4 files; `security.mjs` 100% lines,
  100% funcs, 96.87% stmts, 85.71% branches); E2E `baseline-flows` **12/12**,
  `phase1-security-flows` **16/16**, `phase2-core-seed-flows` **16/16** — all re-run
  after the final documentation edits.
- Vitest: **132/132** (security.test.mjs: 35). security.mjs coverage: 100% lines/funcs.
- E2E `phase2-core-seed-flows.mjs`: **16/16** post; **15/16** pre-extraction
  (only the patch-specific `bridge-identity` fails, by design).
- E2E `baseline-flows.mjs`: **12/12**. E2E `phase1-security-flows.mjs`: **16/16**.
- Backend `npm test`: **406/406**; `tsc --noEmit`: no errors printed. Backend
  untouched (run only to confirm no collateral change).
- Fault injection: 5 function mutations (2–6 failing Vitest tests each) and 2
  bridge mutations (11/17 and 13/17 E2E checks failing); all files restored
  byte-identical by sha256 and re-passed.
- Logs: `baseline/evidence/phase2-core-slice1-*`. Details: `docs/checkpoints/CP-7.md`.
- Backend (re-measured earlier in the same slice 2 session, on the identical production
  tree; not re-run after the documentation-only edits, which cannot affect it):
  `tsc --noEmit` exit 0, `npm run build` exit 0, `npm test` **406/406**.

## Unverified Items
- Behavior in Firefox/Safari (Chromium only).
- ADR-003 still reads "cannot close over a `let` declared in a different script's scope".
  Browser-level evidence (slice 2, Chromium 141) does not support that wording for bare-name
  access from module code, but ADR-003 is UNEDITED and the decision to revise it is
  **PENDING** (separate decision). Not tested: moving `PERSISTABLE_STATE` itself, TDZ /
  initialization order in other layouts, closures stored and invoked later from classic,
  writes on the real monolith, Firefox/Safari.
- `NexusContext.buildAgentContext` live-caller status (static scan found no
  caller in the monolith; not investigated further, not reopened).

## Blocked Items
- **Evidence Integrity guard — BLOCKED** (owner decision): fail-closed policy for `EvidenceItem`
  without a declared Evidence-Delta `kind`; which `kind` the Ops Center manual evidence rows
  carry (UI = boundary 8, PENDING); how the state-change reason is persisted (migration 016
  column vs. derived from `evidence_json`); ADR-004. Details and the recommended minimal seam:
  `docs/checkpoints/CP-9.md` §4–§5.
- `sw.js` is not among the provided artifacts: cumulative cache-manifest
  follow-up (5 files: `/main.js`, `/modules/security.mjs`, `/modules/storage.mjs`,
  `/modules/utilities.mjs`, `/modules/settings.mjs`) cannot be applied. This
  slice added no new file. Must be finalized before Phase 2's Exit Gate.

## Known Risks
- **Latent "agent agreement → evidence upgrade" path (found by code reading, NOT exercised with a
  live judge):** `EvaluationEngine.evaluate()` cannot distinguish Agent outputs from independent
  sources, and its judge prompt (L59) rewards multiple "independent" sources. No internal caller
  feeds it agent outputs today (2 callers only), but `POST /v2/evaluation/claim` accepts any
  `{source, content}` and migration 012's own comment anticipates council syntheses as future
  subjects. Independence would remain *declared, not verified* even after a guard (CP-9 §6).
- **Documentation finding (ADR-003), now with browser-level evidence:** real Chromium 141
  shows module code reading/writing classic top-level `let`/`var` (and reading `const`)
  by bare name, which conflicts with ADR-003's wording. ADR-003 NOT edited; bridge pattern
  NOT changed; nothing was built on the result. Any revision is a separate future decision.
  Chromium is available here (`PLAYWRIGHT_BROWSERS_PATH=/opt/pw-browsers`).
- `autoInitApp` swallows decrypt failures and "starts fresh"; any future change
  to the crypto seam can silently drop user data. The new E2E guards this.
- Remaining core is state-heavy (`PERSISTABLE_STATE`, 16 variables, `selectedAgentIds`
  has 15 write sites in 8 functions — re-derived by slice 3: 14 rebinds in 7 units + the registry setter).
- **Possible startup write-before-restore (INFERENCE from code order, NOT exercised):** `autoInitApp()` is not
  awaited; an offline boot runs `updateOnlineStatus → logActivity` (rebinds `activityLog`) before the async
  `restorePersistableState` overwrites it, so that boot-time entry may be lost. Low product impact; see CP-10 I-1.
- **Test coupling:** moving ownership of `messages` would break/require editing `e2e/phase1-security-flows.mjs`
  (bare-name reads and `messages = …` assignments).
- Slice 3 limits: static analysis only; alias mutation (escape sites) and indirect persistence are not tracked.

## Terminology note (historical "DONE")
`PHASE2-MODULARIZE.md` uses the word "DONE" for boundaries 1–4. That is **historical
wording from before the current six-state status vocabulary** and has intentionally NOT
been rewritten. The authoritative current status model is only:
`VERIFIED / PARTIAL / PENDING / BLOCKED / FAILED / UNVERIFIED`. Read the historical
"DONE" for boundaries 1–4 as the historical claim that they were VERIFIED at the time
(not freshly re-measured here, apart from indirect regression coverage).

## Remaining Scope
Core: `PERSISTABLE_STATE` + 16 state vars, `NexusContext`, `ContextFabric`.
Then agents, modes, ops-center, workspace, UI-remainder; `sw.js`; Phase 2 Exit Gate.

## Next Safe Slice
(Separate, owner-gated: a dedicated Evidence Integrity slice may be opened only after the
decisions in `CP-9.md` §4 are made; it must not be mixed with core work.)
**Core slice 4 — PROPOSED, PENDING (first code-changing slice of core; smallest candidate C1 in `CP-10.md` §4):**
move the persistence-registry iteration logic (`snapshotPersistableState` / `restorePersistableState` /
`resetPersistableState`, L4953–4966) into a module as pure functions taking the registry as an explicit parameter,
keeping the existing names available through the ADR-002 bridge. It does NOT move `PERSISTABLE_STATE` or any of the
16 variables, does NOT touch `persistState`/`autoInitApp`, and does NOT depend on the slice 2 finding or on editing
ADR-003. Acceptance must be defined in the slice (unit tests incl. missing-key → fresh default, byte-level
extraction proof, E2E restore through the real `autoInitApp`, mutation proof, 132/12/16/16 re-measured). Interface
details are decided inside that slice, not here. Moving ownership of any variable (C2/C3) remains blocked on an
owner decision about the mechanism and on a separate ADR-003 revision.
