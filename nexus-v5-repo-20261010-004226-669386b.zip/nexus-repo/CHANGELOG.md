# CHANGELOG.md

## [v5.0-polish / Phase 0] — 2026-09-16

### Added
- `v5.0-polish` git branch, baseline snapshot commit.
- `baseline/INVENTORY.md`, `baseline/FLOWS.md`, `baseline/METRICS.md`,
  `BASELINE.md`, `PLAN.md`, `ROADMAP.md`, `ADR/000-baseline.md`.
- `e2e/baseline-flows.mjs` — reusable Playwright regression script driving
  the real compiled backend + the real, untouched HTML frontend.
- `baseline/evidence/` — build log, npm audit log, server boot logs, full
  E2E run log, extracted API route list.

### Changed
- Nothing in application code (frontend HTML or backend `src/`). Phase 0
  is documentation- and evidence-only, per protocol §9's absolute rule.

### Verified (no fix needed)
- Backend: 406/406 tests, clean typecheck, clean build, 0 npm audit
  vulnerabilities — matches the state already established at the end of
  the prior session on `nexus-backend-resilience-verified.zip`.
- Frontend: no `eval()`, no `document.write`, real-browser load with zero
  uncaught page errors across the flows tested.

### Not yet started (as of Phase 0)
- `/nexus-security`, `/nexus-modularize`, `/nexus-reliability`,
  `/nexus-commercial`, `/nexus-research` — all pending explicit approval
  per protocol §6.

## [v5.0-polish / Phase 1] — 2026-09-16

### Added
- `jsStr()` — JS-string-safe escaping for the 11 onclick sites that embed
  an id inside a single-quoted JS argument.
- `stripInternalMarkers()` — strips internal parsing markers before
  conversation history is sent back to the model.
- `ImageStore` — attached images now live in their own IndexedDB keys
  instead of embedded inline in the main encrypted state blob.
- `MessageArchive` + `MESSAGE_CAP` (300) — bounds the live `messages`
  array; overflow is archived, never deleted.
- `localStore.listKeys(prefix)` — new capability needed by
  `ImageStore.gcAll()`.
- `e2e/phase1-security-flows.mjs` — 16 new regression checks.
- `PHASE1-SECURITY.md` — full audit findings + actions for all 11 items
  in protocol §10's checklist.

### Changed
- `sendMessage()` — pushes `imageRef` instead of the raw base64 `image`.
- `renderMessages()` — resolves `imageRef` via `ImageStore` (cache-first);
  `m.image` kept as a read-only fallback for pre-existing conversations.
- `persistState()` — enforces `MESSAGE_CAP`, archives overflow.
- `resetAllData()` — now also clears `ImageStore` and `MessageArchive` so
  its own "permanently erases everything" promise stays true.
- `buildHistoryForAgent()` — content passed through `stripInternalMarkers()`.
- `importCustomAgentPasted()`, `applyNomadicPayload()` — both now show a
  `confirm()` preview before committing imported content.
- 11 onclick sites — `escapeHtml(id)` → `jsStr(id)`.

### Verified (no fix needed)
- XSS/unsafe DOM sinks: all 153 `.innerHTML` sites classified safe.
- PromptInjectionGuard: already correctly fencing knowledge
  base/docs/market-context content.
- Secure external content import: JSON.parse only, no code-exec risk in
  either import path.

### Not applicable
- Safe Markdown rendering / DOMPurify — no markdown rendering exists in
  the current codebase; nothing to sanitize.

### Regression
- Backend: 406/406, clean typecheck (untouched, re-verified).
- `e2e/baseline-flows.mjs` (Phase 0): 12/12, zero regressions.
- `e2e/phase1-security-flows.mjs` (Phase 1, new): 16/16.

### Not yet started
- `/nexus-modularize`, `/nexus-reliability`, `/nexus-commercial`,
  `/nexus-research` — pending explicit approval per protocol §6.

## [v5.0-polish / Phase 2, boundary 1/9 "security"] — 2026-09-17

### Added
- `frontend/modules/security.mjs` — first ES module extraction:
  `escapeHtml`, `jsStr`, `deriveKey`, `b64ToBuf`, `bufToB64`,
  `PromptInjectionGuard`. Byte-identical to prior inline definitions
  (diff-verified).
- `frontend/main.js` — real bootstrap/orchestration entry point: sets up
  the window bridge, then runs the app's startup sequence.
- `frontend/package.json`, `vitest.config.js` — Vitest 4.1.11 + jsdom,
  0 vulnerabilities (pinned above the `@vitest/mocker`/`esbuild`
  advisory range without a breaking major-version jump).
- `frontend/modules/security.test.mjs` — 19 tests, 95.83%/100%/100%/
  85.71% coverage (stmts/funcs/lines/branch) on the new module.
- `PHASE2-MODULARIZE.md` — full findings, the regression found+fixed,
  and the 8-boundary roadmap.

### Changed
- Removed the 6 extraction targets from the monolith, replaced with
  pointer comments (23 insertions / 91 deletions net).
- Moved the 5-call app-startup sequence (`applyTheme`,
  `applyTranslations`, `autoInitApp`, `registerServiceWorker`,
  `updateOnlineStatus`) from the end of the classic script into
  `main.js`, same order, run right after the window bridge — required
  fix for a real regression found this round (see below).
- `e2e/baseline-flows.mjs`, `e2e/phase1-security-flows.mjs` — static
  file servers extended to serve the whole `frontend/` directory with
  correct JS MIME types (test-harness change only, not app behavior).

### Regression found and fixed this round
- `autoInitApp()` (+ 4 other startup calls) ran as top-level statements
  in the classic script, executing *before* the deferred module script
  could set `window.jsStr`/`window.bufToB64` — caused
  `chat-send-no-crash` to fail with `ReferenceError`. Root-caused via a
  direct Playwright debug session, fixed by relocating the startup
  sequence into `main.js`. Full 3-suite regression re-run clean after
  the fix (see Regression section below).

### Regression (full re-run, after the fix)
- Backend: 406/406, clean typecheck (untouched).
- `e2e/baseline-flows.mjs` (Phase 0): 12/12.
- `e2e/phase1-security-flows.mjs` (Phase 1): 16/16.
- New Vitest suite: 19/19.

### Disclosed follow-up (not a regression, a required manual step)
- `sw.js` (not among the provided artifacts) needs `/main.js` and
  `/modules/security.mjs` added to its cache manifest before deploying,
  for offline/PWA support to keep covering these two new files.

### Not yet started
- 8 of 9 modularization boundaries (storage, utilities, core, agents,
  modes, ops-center, workspace, UI) — see PHASE2-MODULARIZE.md's
  roadmap. `/nexus-reliability`, `/nexus-commercial`, `/nexus-research`
  — pending explicit approval per protocol §6.

## [v5.0-polish / Phase 2, boundary 2/9 "storage"] — 2026-09-17

### Added
- `frontend/modules/storage.mjs` — second ES module extraction:
  `localStore`, `ExecutionCheckpoint`, `ImageStore`, `MessageArchive`.
  Byte-identical to prior inline definitions (diff-verified).
- `frontend/modules/storage.test.mjs` — 27 tests, 89.2%/82.6%/86.11%/96%
  coverage (stmts/branch/funcs/lines). Added `fake-indexeddb` (0 new
  vulnerabilities) to test the real raw-IndexedDB path — the one that
  actually runs in Aiham's deployed app, since `window.storage` only
  exists in Claude's own artifact-preview environment.
- `ADR/003-phase2-storage-boundary.md` — records why `PERSISTABLE_STATE`
  is deliberately NOT extracted this round (closes over 16 scattered
  top-level state variables; moving it now would mean folding in most of
  "core"/"agents"/"workspace" at once).

### Changed
- Removed the 4 extraction targets from the monolith, replaced with
  pointer comments (net: 15 insertions / 190 deletions across the
  monolith + `main.js`).
- `main.js` — added the `storage.mjs` import and window-bridge
  assignments, placed before the existing startup-sequence call (learned
  from boundary 1: `autoInitApp()` calls into all 4 of these).

### Regression (full re-run, fresh)
- Backend: 406/406, clean typecheck (untouched).
- Vitest (security + storage combined): 46/46.
- `e2e/baseline-flows.mjs` (Phase 0): 12/12.
- `e2e/phase1-security-flows.mjs` (Phase 1): 16/16 — exercises
  ImageStore/MessageArchive through real app flows, not just units.
- No regression this round (boundary 1's ordering lesson applied
  proactively).

### Disclosed follow-up (cumulative)
- `sw.js` cache-list additions now needed: `/main.js`,
  `/modules/security.mjs`, and `/modules/storage.mjs`.

### Not yet started
- 7 of 9 modularization boundaries remain (utilities, core, agents,
  modes, ops-center, workspace, UI) — see PHASE2-MODULARIZE.md's
  roadmap. `/nexus-reliability`, `/nexus-commercial`, `/nexus-research`
  — pending explicit approval per protocol §6.

## [v5.0-polish / Phase 2, boundary 3/9 "utilities"] — 2026-09-18

### Added
- `frontend/modules/utilities.mjs` — third ES module extraction: 11
  general-purpose pure helpers (`evaluateMathExpression`, `chunkText`,
  `agentShortDesc`, `cosineSimilarity`, `parseOneSSEFrame`,
  `estimateQuestionComplexity`, `reEl`, `localTimeStringToUTCHourMinute`,
  `describeRecurrence`, `truncateText`, `wsUid`). Byte-identical to prior
  inline definitions (diff-verified, extraction+verification scripted
  end-to-end).
- `frontend/modules/utilities.test.mjs` — 38 tests, 91.13%/83.01%/
  90.9%/98.27% coverage (stmts/branch/funcs/lines).

### Changed
- Removed the 11 extraction targets from the monolith, replaced with
  pointer comments (27 insertions / 172 deletions across the monolith +
  `main.js`). Explanatory comments that preceded some functions were
  left in place rather than moved.
- `main.js` — added the `utilities.mjs` import and 11 window-bridge
  assignments.

### Regression (full re-run, fresh)
- Backend: 406/406, clean typecheck (untouched).
- Vitest (security + storage + utilities combined): 84/84.
- `e2e/baseline-flows.mjs` (Phase 0): 12/12.
- `e2e/phase1-security-flows.mjs` (Phase 1): 16/16.
- No regression this round.

### Disclosed follow-up (cumulative)
- `sw.js` cache-list additions now needed: `/main.js`,
  `/modules/security.mjs`, `/modules/storage.mjs`, and
  `/modules/utilities.mjs`.

### Not yet started
- 6 of 9 modularization boundaries remain (core, agents, modes,
  ops-center, workspace, UI) — see PHASE2-MODULARIZE.md's roadmap.
  `/nexus-reliability`, `/nexus-commercial`, `/nexus-research` —
  pending explicit approval per protocol §6.

## [v5.0-polish / Phase 2, boundary 4/9 "settings"] — 2026-09-18

### Added
- `frontend/modules/settings.mjs` — fourth ES module extraction: 23
  settings getters/setters (`getBackendUrl`, `getChatModel`,
  `getDeviceId`, `getEnabledExtraProviders`, `getGatewayKey`,
  `getLastKnownSyncVersion`, `getLocalModelName`,
  `getMarketContextCurrency`, `getStoredWebAuthnCredentialId`,
  `getThemePreference`, `getUILang`, `getVoiceLang`, `getVoiceRate`,
  `isCloudSyncEnabled`, `isLongTermMemoryEnabled`,
  `isMarketContextEnabled`, `isThoughtTreeEnabled`, `isToolsEnabled`,
  `isVoiceToVoiceMode`, `isWebAuthnSupported`, `isStandaloneDisplay`,
  `setLastKnownSyncVersion`, `saveLocalModelSetting`). Byte-identical to
  prior inline definitions (diff-verified).
- `frontend/modules/settings.test.mjs` — 32 tests, 98.5%/100%/100%/
  97.77% coverage, including forced-failure tests proving every getter
  degrades to its documented default when `localStorage` throws (Safari
  private browsing, quota exceeded).

### Changed
- Removed the 23 extraction targets from the monolith, replaced with
  pointer comments (52 insertions / 95 deletions across the monolith +
  `main.js`).
- `main.js` — added the `settings.mjs` import and 23 window-bridge
  assignments, placed before the startup-sequence call (3 of these 23
  are called from that sequence: `isCloudSyncEnabled`,
  `getThemePreference`, `getUILang`).

### Regression (full re-run, fresh)
- Backend: 406/406, clean typecheck (untouched).
- Vitest (security + storage + utilities + settings combined): 116/116.
- `e2e/baseline-flows.mjs` (Phase 0): 12/12.
- `e2e/phase1-security-flows.mjs` (Phase 1): 16/16.
- No regression this round.

### Disclosed follow-up (cumulative)
- `sw.js` cache-list additions now needed: `/main.js`,
  `/modules/security.mjs`, `/modules/storage.mjs`,
  `/modules/utilities.mjs`, and `/modules/settings.mjs`.

### Not yet started
- 5 of 9 modularization boundaries remain (core, agents, modes,
  ops-center, workspace, UI-remainder) — see PHASE2-MODULARIZE.md's
  roadmap. `/nexus-reliability`, `/nexus-commercial`, `/nexus-research`
  — pending explicit approval per protocol §6.

## [v5.0-polish / Phase 2 / boundary 5 "core", slice 1] — 2026-10-07

### Changed
- `encryptState` / `decryptState` moved byte-for-byte from the monolith to
  `frontend/modules/security.mjs` (only `export` added); bridged on `window`
  in `main.js` before the startup calls. Behavior, contracts, state
  semantics and initialization order unchanged.

### Added
- 16 Vitest tests (behavior, rejection cases, equivalence with the original
  implementation, golden vector from the original). Total 132.
- `e2e/phase2-core-seed-flows.mjs` — real-Chromium E2E including a real
  persist → reload → restore cycle (16 checks).
- Evidence: `baseline/evidence/phase2-core-slice1-*`.

### Not changed (explicitly)
- `PERSISTABLE_STATE`, the 16 state variables, `NexusContext`,
  `ContextFabric`, ADR-003, `sw.js`, backend.

### Deferred findings (recorded, not acted on)
- ADR-003 wording vs. V8 probe (needs browser-level evidence).
- `NexusContext.buildAgentContext` has no caller in the monolith (static scan).


## [v5.0-polish / Phase 2 / boundary 5 "core", slice 2] — 2026-10-07

Evidence-only slice. **No production code changed** (`frontend/`, `src-baseline/`, `e2e/`,
ADRs, `PHASE2-MODULARIZE.md` are byte-identical to `4c3e169`).

### Added
- `baseline/evidence/phase2-core-slice2-adr003-probe.mjs` — real-Chromium probe runner
  (synthetic classic+module page served from a scratch dir; modules-only control; strictly
  read-only check against the real monolith with SHA-256 / `git status` integrity proof).
- `baseline/evidence/phase2-core-slice2-fixtures/` — synthetic page sources.
- `baseline/evidence/phase2-core-slice2-adr003-probe.log`, `…-probe-results.json`,
  `…-real-readonly-probe.generated.mjs` — raw, reproducible output.
- `docs/checkpoints/CP-8.md`.

### Result (Chromium 141.0.7390.37; 19/19 acceptance checks; identical on re-run)
- Module code reads/writes classic top-level `let` and `var` by bare name; reads `const`
  (write → `TypeError`); `let`/`const` are not on `window`, `var` is; bindings are live in
  both directions; names declared in the module are invisible to classic code.
- Negative controls: undeclared read/write → `ReferenceError`. Modules-only control →
  `ReferenceError` for `let`/`const`/`var`.
- Real monolith (read-only): 56 `let`, 57 `const`, 370 functions all readable from an
  injected module, 0 mismatches vs classic global scope; no files or app state changed.

### Changed
- `NEXUS-CURRENT-STATE.md`, `NEXUS-CONTINUATION.md`: slice 2 state, next slice (core
  slice 3, read-only), and a clarification that `PHASE2-MODULARIZE.md`'s "DONE" wording for
  boundaries 1–4 is historical wording from before the six-state vocabulary (the historical
  report was NOT rewritten).

### Not changed / not authorized
- ADR-003 is **unedited**; the bridge pattern is unchanged. The positive browser result does
  not authorize either change; any revision is a separate future decision.


## [v5.0-polish / Phase 2 / Evidence Integrity micro-invariant — inspection] — 2026-10-09

Inspection / evidence / documentation only. **No production code, test, API or UI changed**
(`frontend/`, `src-baseline/`, `e2e/`, ADRs are byte-identical to `0520af7`). Not a new phase;
core slice 3 was not started and is not mixed in. Guard status: **BLOCKED** (owner decisions).

### Added
- `docs/checkpoints/CP-9.md` — seam analysis, data-flow map, measured experiment, required
  decisions, recommended minimal seam, remaining limits.
- `baseline/evidence/phase2-evidence-integrity-baseline-backend-test.log`,
  `…-baseline-typecheck.log` — backend baseline re-measured this session (tsc exit 0; 406/406).
- `baseline/evidence/phase2-evidence-integrity-failclosed-experiment.log` and
  `…-failclosed-experiment.NOT-APPLIED.patch` — scratch experiment (never applied to the tree).

### Findings
- Only producer of the 5-state verdict/confidence: `EvaluationEngine.evaluate()`
  (`evaluationEngine.ts` L82–123); 2 callers (`webResearch.ts:165`, `evaluation.ts:43`).
  Council/Missions use `Verifier` (ok/issues_found), not this engine.
- `EvidenceItem` carries no provenance/kind, so the engine cannot tell Agent outputs from
  independent sources: a latent "agent agreement → upgrade" path exists via
  `POST /v2/evaluation/claim` (code reading; not exercised with a live judge).
- Fail-closed enforcement (scratch only): 3 evaluation-related test files, 24 tests →
  15 pass / 9 fail; the Ops Center UI sends evidence with no kind (code reading).

### Changed
- `NEXUS-CURRENT-STATE.md`, `NEXUS-CONTINUATION.md`: Evidence Integrity entry (BLOCKED), new
  commit chain (`HEAD~1` = `0520af7`, `HEAD~2` = `4c3e169`), next-command checkpoint number
  CP-9 → CP-10 for core slice 3.

## 2026-10-09 — Phase 2 / boundary 5 core, slice 3 (read-only state map; docs/evidence only)

Status: slice 3 **VERIFIED** as a static read-only map (runtime behavior UNVERIFIED); core **PARTIAL**; Phase 2 **PARTIAL**;
Evidence Integrity unchanged (**BLOCKED**). No production code, test, ADR or contract changed
(`frontend/`, `src-baseline/`, `e2e/`, ADRs, `PHASE2-MODULARIZE.md` identical to `b9d4808`).

### Added
- `docs/checkpoints/CP-10.md` — facts vs inferences, per-variable table, candidate seams, limits.
- `baseline/evidence/phase2-core-slice3-state-map.mjs` (+ `.log`, `-results.json`) — deterministic acorn-based analyzer, 22/22 self-checks.
- `baseline/evidence/phase2-core-slice3-regression-*.log` — fresh Vitest 132/132 and E2E 12/16/16.

### Findings
- 16 col-0 classic `let`s; registry defaults equal initializers (16/16); `errorLog` declared after `PERSISTABLE_STATE` (TDZ-safe today).
- 32 rebind sites outside registry setters, 47 writer units, 85 reader units; `restorePersistableState` has 3 callers; `persistState` has 38 caller units and splices `messages` before snapshotting.
- 0 inline handlers reference the variables directly; E2E assigns `messages` by bare name (test coupling).
- Analyzer corrections recorded honestly: refuted "all declared before the registry" assumption; fixed 2 handler false positives.
- Inference (not exercised): offline-boot `activityLog` write may be overwritten by the later restore.

### Changed
- `NEXUS-CURRENT-STATE.md`, `NEXUS-CONTINUATION.md`: slice 3 result, commit chain (`HEAD~1`=`b9d4808`), E2E environment lessons, next slice proposed (C1, PENDING), next-command CP-10 → CP-11.


## 2026-10-10 — Phase 2 / boundary 5 core, slice 4 / C1 (registry-parameter snapshot/restore/reset)

Status: slice 4 / C1 **VERIFIED** (Chromium 141 only); core **PARTIAL**; Phase 2 **PARTIAL**; Evidence Integrity unchanged (**BLOCKED**).
`PERSISTABLE_STATE`, its 16 variables, `persistState`, `autoInitApp`, `resetAllData` and ADR-003 are byte-identical to `9c95fbd`.

### Added
- `snapshotPersistableState(registry)` / `restorePersistableState(registry, decrypted)` / `resetPersistableState(registry)` at the end of `frontend/modules/storage.mjs`
  (original bodies; `export` added, `PERSISTABLE_STATE`→`registry`, parameter added — proved byte-level).
- `window.PersistableStateCore` bridge in `frontend/main.js` (namespaced; the plain names stay as one-line classic wrappers in the monolith).
- `frontend/modules/persistable-state.test.mjs` (36 tests incl. a differential test against the verbatim original), `e2e/phase2-core-slice4-flows.mjs` (21 checks through the real `autoInitApp`).
- `docs/checkpoints/CP-11.md`; `baseline/evidence/phase2-core-slice4-*` (acceptance criteria written before the patch, extraction/exec-order/mutation scripts + results, PRE/POST logs).

### Changed
- Monolith: the 3 function bodies (old L4953–4966) replaced by 3 one-line wrappers with the original names/signatures. `main.js`: import line, header sentence, bridge line.
- `NEXUS-CURRENT-STATE.md`, `NEXUS-CONTINUATION.md`: slice 4 result, chain (`HEAD~1`=`9c95fbd`), next slice (core slice 5, evidence-only, PENDING).

### Verified (fresh)
- Extraction proof 17/17; Vitest 168/168; E2E 12/12, 16/16, 16/16 and new 21/21 (19/21 pre-patch); mutation 16/16 killed; exec-order 9/9; backend `tsc --noEmit` exit 0 and `npm test` 406/406 (confirmatory).

### Not changed / limits
- Shallow snapshot and by-reference restore preserved as-is (characterized, not protected). I-1 untested. `sw.js` still unavailable (no new module file added). ADR-003 wording unrevised.
