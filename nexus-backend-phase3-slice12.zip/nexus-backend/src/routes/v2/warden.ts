import type { Router, RouteContext } from '../../gateway/router.js';
import { Warden } from '../../warden/warden.js';

export function registerWardenRoutes(router: Router) {
  /** Single operational snapshot: budget + active mission/council/approval counts. Read-only — Warden's mutating actions (cancel) live on the resource's own route (POST /v2/missions/:id/cancel, POST /v2/council/:id/cancel), now routed through Warden underneath rather than calling taskManager/councilRunner directly, so every cancellation is audited. */
  router.get('/v2/warden/status', async (ctx: RouteContext) => {
    ctx.res.writeHead(200, { 'Content-Type': 'application/json' });
    ctx.res.end(JSON.stringify(Warden.status()));
  });
}
