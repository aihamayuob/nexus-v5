import { getRepos } from '../persistence/repos.js';
import { cancelTask } from '../orchestrator/taskManager.js';
import { cancelCouncilSession, getCouncilSession } from '../council/councilRunner.js';
import { BudgetGuard } from '../orchestrator/budget.js';
import { auditSecurityEvent } from '../security/audit.js';
import { Errors } from '../core/errors.js';

/**
 * Warden — the single control surface for pausing/cancelling running work
 * and observing system-wide operational state (Phase 3 §Warden).
 *
 * IMPORTANT, VERIFIED DESIGN FACT (documented here rather than papered
 * over): every route in this backend — including every Warden route added
 * in this slice — already passes through `authenticate()`
 * (gateway/middleware/auth.ts) BEFORE the route handler runs at all. That
 * middleware either returns `{authenticated: true, ...}` or throws
 * Errors.auth() (401); it can never hand a route an unauthenticated
 * GatewayContext. This means:
 *   (a) There is no separate "elevated" Warden bypass path — Warden
 *       actions are bound by the exact same gateway key requirement as
 *       every other endpoint, which is precisely what "Warden لا يستطيع
 *       تجاوز... security boundary" requires structurally.
 *   (b) Re-checking `ctx.authenticated === true` inside Warden functions
 *       would be dead code that can never be false by the time it runs —
 *       adding it would be security theater, not a real control. It is
 *       deliberately NOT added here for that reason; this comment (and
 *       PHASE3_SLICE2_REPORT.md) is the honest record of that decision.
 *
 * What THIS slice actually adds beyond what already existed pre-Warden:
 *   1. An AUDITED cancel path — routes/v2/missions.ts and
 *      routes/v2/council.ts previously called cancelTask()/
 *      cancelCouncilSession() directly with zero audit trail. Every
 *      Warden.cancel* call now logs a real security-audit event
 *      (queryable via GET /v2/observability or auditRepo.listSecurity()).
 *   2. A single operational status view (budget + active mission/council
 *      counts) that did not exist as one call before.
 *   3. requireApprovalOnIssues human-approval gating for Missions — see
 *      missionRunner.ts and approvalGate.ts's decideApproval().
 */
export const Warden = {
  cancelMission(missionId: string, reason: string): { cancelled: boolean } {
    const mission = getRepos().missions.get(missionId);
    if (!mission) throw Errors.notFound('Mission غير موجودة.');
    const cancelled = cancelTask(missionId);
    auditSecurityEvent('info', 'Warden: mission cancellation requested', { missionId, reason, cancelled, priorState: mission.state });
    return { cancelled };
  },

  cancelCouncilSession(sessionId: string, reason: string): { cancelled: boolean } {
    const session = getCouncilSession(sessionId);
    if (!session) throw Errors.notFound('جلسة المجلس غير موجودة.');
    const cancelled = cancelCouncilSession(sessionId);
    auditSecurityEvent('info', 'Warden: council session cancellation requested', { sessionId, reason, cancelled, priorState: session.state });
    return { cancelled };
  },

  status() {
    const repos = getRepos();
    return {
      budget: BudgetGuard.status(),
      activeMissions: repos.missions.resumableMissionIds().length,
      activeCouncilSessions: repos.council.activeCount(),
      pendingApprovals: repos.approvals.pending(200).length,
    };
  },
};
