# NEXUS — Operational Test Build R3 (2026-11-15)

Successor of R2. **Archive tree without `.git`**: nothing was committed, tagged, pushed, released or deployed; the live repository is not modified. Delta vs R2: F-03 and F-04 closed (plus a related fix — fallback providers now receive their own model, not the primary's), `verify-all.sh` run end-to-end (exit 0), frontend dev-tooling vulnerabilities closed (audit 0/0), a deterministic replacement for one intermittent E2E check (**needs owner ratification**, original preserved), embedded-image count corrected (2, not 6).

**Run**: `./run.sh` (or `run.cmd`) → open the printed URL; paste the printed gateway key in Settings. Node >= 22.5. LAN/loopback HTTP only — not for the internet.

| File/folder | Content |
|---|---|
| `F03-F04-CLOSURE-2026-11-15.md` | start here: what changed, evidence, behaviour changes, owner decisions needed |
| `BUYER-EVIDENCE-AND-IP-FILE-2026-11-15.md` (R3 revision), `OPERATIONAL-BUILD.md` (§8), `IP-LICENSE-SECURITY-DELTA-2026-11-14.md` (R3 addendum), `REAL-PROVIDER-VALIDATION-2026-11-15.md` | evidence / register documents |
| `source/` | full tree (no node_modules/dist/DB/secrets): `NEXUS-CONTINUATION.md` (Addendum 22), `NEXUS-CURRENT-STATE.md`, `CHANGELOG.md`, `ADR/007` (PROPOSED), e2e, scripts |
| `prebuilt/backend-dist.tar.gz` | backend `dist/` built from this source |
| `verification/verify-2026-11-15-r3/` | `verify-all.sh` run 2 (exit 0): raw logs, `real-provider/`, `mcp-interop/`, `scenario/` |
| `verification/verify-r3-run1-flaky-seed/` | run 1 (one intermittent E2E failure, explained in the closure doc §4) |
| `verification/backend-after-F04.log` | backend suite 653/653 |
| `verification/deps-before/`, `verification/seed-flows.mjs.before-2026-11-15` | originals of the files changed (revert = copy back) |
| `verification/historical-*` | R2 and earlier logs, unchanged |

Results (all model completions SIMULATED): backend 653/653, Vitest 186/186, 17 E2E, scenarios 39/39, UI demo 7/7, real-provider harness PASS 23 / FAIL 0 / BLOCKED 10, MCP interop 10/10. Real providers: UNVERIFIED (BLOCKED here). MCP client / A2A / Connector SDK: PENDING (ADR-007 awaiting approval; nothing implemented).
