# NEXUS — Function/Evidence Matrix, Readiness Levels and Blockers (2026-11-13)

Technical assessment only; no legal claim. Four separate questions per row: **code exists / test exists / integrated path passed (this session) / available to a real user**.
Row status words: VERIFIED / PARTIAL / PENDING / BLOCKED / FAILED / UNVERIFIED, plus SIMULATED (answered by a fake model server) and NOT_CONFIGURED (no keys/runtime supplied).
Source = G8.2-CLOSURE snapshot + F-UI-1/F-UI-2 patch, isolated working copy (NOT the live repo — that is BLOCKED/UNVERIFIED).

| Area | Code | Test | Integrated path this session | Real-user availability | Status |
|---|---|---|---|---|---|
| Gateway (auth, CORS, `/v2/*`) | yes | yes (backend 626, E2E real-auth) | key required → 401 without key; `/v2/health`, `/v2/models`, `/v2/providers/health` answered | needs a gateway key + host | VERIFIED (local, isolated) |
| Provider registry / health states | yes | yes | READY(ollama, simulated) / NOT_CONFIGURED ×5 reported correctly | depends on user's keys/runtimes | VERIFIED for state reporting; real providers NOT_CONFIGURED |
| Router (LOCAL_ONLY / PRIVATE, no cloud fallback, GAP-1) | yes | yes | `/v2/route` → local provider, `cloudFallbackBlocked:true` | yes if a local runtime exists | VERIFIED (routing decision); real local runtime UNVERIFIED |
| Adapters — Ollama / LM Studio | yes | yes (fake servers) | task + chat via simulated Ollama protocol | needs real Ollama/LM Studio | SIMULATED |
| Adapters — Anthropic / OpenAI / DeepSeek / Gemini | yes | yes (fake) | no-key call fails clearly (validation_error); no real call | needs paid keys | NOT_CONFIGURED |
| Local/private mode egress (frontend F-UI-1) | yes | yes (FUI1 + 7 mutations) | VERIFIED on listed paths | yes, on tested paths | PARTIAL (real runtimes + untested paths) |
| Embeddings `/api/embed` | yes | yes (6) | local-only path tested with fakes | endpoint still unauthenticated (F-01) | PARTIAL |
| Agent runtime / tasks (`/v2/tasks`, SSE, persistence) | yes | yes | task completed with simulated model; persisted `done`; readable after stop/restart | needs a real model | SIMULATED + VERIFIED persistence |
| Missions / Council / Swarm / Warden / VEL | yes | yes (backend + E2E suites, GAP/VEL/G8*) | exercised only by the inherited suites (all re-run green); no real-model mission run here | needs real models | PARTIAL (suite-level only) |
| Memory / storage (node:sqlite) | yes | yes | DB survived stop/restart (task persisted) | yes | VERIFIED (local) |
| Security (key storage, CSP, auth, egress guard) | yes | yes (phase1, b4 suites) | re-run green | gaps: F-01 `/api/embed` unauth, CSP `connect-src` broad, CDN scripts without SRI | PARTIAL |
| Observability | yes | yes (suites) | not exercised separately | — | PARTIAL |
| Offline / PWA (`sw.js`) | yes | yes (b1 suite 18) | re-run green | QR/PDF libs need the CDN | PARTIAL |
| i18n / RTL (Arabic-first) | yes | yes + FUI2 matrix | ar-RTL/en-LTR, 7 widths + tablet/desktop | no WCAG audit | PARTIAL |
| Frontend (original single-file UI) | yes | Vitest 186 + E2E | served unmodified-by-harness; UI→backend→simulated local model reply rendered | yes | VERIFIED (isolated) / real model UNVERIFIED |
| Tools (agent tools) | yes | suites | not exercised with real side-effect tools | — | PARTIAL |
| **Preview page** | earlier-session harness code **not available** | — | the original frontend was run against the real backend; no separate preview/status page was rebuilt | — | PENDING (not claimed) |

## Readiness levels (judged independently)

| # | Level | Verdict | Basis / limit |
|---|---|---|---|
| 1 | Buildable | **VERIFIED** (isolated) | `npm ci` + typecheck + build exit 0; `dist/` runs. Needs undeclared `tsx` only for tests. |
| 2 | Testable | **VERIFIED** (isolated) | 626 backend, 186 Vitest, 17 E2E scripts, FUI1/FUI2, mutation check — single runs. Fragile: tests need global tsx/Playwright; E2E pollutes `baseline/evidence`. |
| 3 | Internally trialable | **PARTIAL** | Runs end-to-end with a simulated model; real trial needs a local runtime (Ollama/LM Studio) the team controls. |
| 4 | Demonstrable | **PARTIAL** | UI + local-mode flow demonstrable with a simulated model (must be labelled SIMULATED); no real-model demo evidence this session. |
| 5 | Really usable within proven capabilities | **PARTIAL / UNVERIFIED** | Proven: gateway, routing, persistence, local-mode egress control, UI layout. Not proven: any real model answer, real cloud call, real device. |
| 6 | Public-deployment eligible | **BLOCKED** | `/api/embed` unauthenticated (F-01) and F-02…F-13 open; no SRI; no hosting/TLS/rate-limit evidence; no owner approval for exposure; no license decision. |
| 7 | Technical-commercial evaluation eligible | **PARTIAL** | Reproducible evidence and SBOM exist; blocked by missing live repo/`.git` provenance, unknown-provenance assets, no license/NOTICE, no real-provider evidence, 6 open dev-dependency advisories. |

## Blockers and owner decisions needed

| ID | Blocker | Needs |
|---|---|---|
| B-1 | Live source repo with `.git` not available (GitHub repo = archive deposit) | Owner: provide/point to the source repo; then apply the patch under OD-C5 approval |
| B-2 | Patch not committed/pushed/applied anywhere | Owner approval (commit/push/merge) |
| B-3 | No real model runtime / API keys here | Owner: run on a machine with Ollama/LM Studio, or supply keys (paid services need approval) |
| B-4 | `/api/embed` is `skipAuth` (F-01) and static findings F-02…F-13 | Owner decision (public-contract/security change) |
| B-5 | 6 base64 images of unknown provenance; no LICENSE/NOTICE | Owner/legal |
| B-6 | CDN scripts without SRI; `typescript:"*"`; undeclared `tsx`/Playwright; no e2e lockfile | Small hardening slice (needs authorization) |
| B-7 | Frontend dev-dependency advisories (6, dev-only) | Authorize lockfile update slice |
| B-8 | E2E scripts overwrite `baseline/evidence` | Authorize an output-dir parameter |
| B-9 | Public deployment / internet exposure | Separate owner approval (not done, not attempted) |

Single next priority: **B-1 + B-2 — obtain the real source repository and, with owner approval, apply the 5-file patch there and re-run the same suites**; then B-4 (`/api/embed` auth).
