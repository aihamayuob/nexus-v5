# NEXUS — Operational copy: how to run it (local only)

Artifact: `operational/nexus-runnable-FUI-patched.tgz` — SHA-256 `b88e5c53df7316121db26c5187e71a25d44120d84417f1d53915a35504197243`; backend `dist/` tree fingerprint `3a37d536cec1c9f78f2119dc23348800e49bb4bae5e3c424bd66d12c2ded4534` (sha256 of sorted per-file sha256 list).
Contents: ORIGINAL frontend (`frontend/neural_nexus_ai_agents-4-3-5-3.html`, sha256 `e9eb0e82…2bb28`, includes the F-UI-1/F-UI-2 patch), built backend, backend source.
It is a **working-copy build of the G8.2-CLOSURE snapshot + patch**, not a release, not tagged, not the live repo.
**Local use only. Do not expose to the internet** (no separate approval exists; `/api/embed` is unauthenticated — F-01).

## Run
```bash
tar -xzf nexus-runnable-FUI-patched.tgz && cd src-baseline/nexus-backend     # Node >= 22.5 required; no npm install needed at runtime
export NEXUS_HOST=127.0.0.1 NEXUS_PORT=8787
export NEXUS_GATEWAY_KEYS='<choose a long random key>'          # required; never commit it
export NEXUS_CORS_ORIGINS='http://127.0.0.1:8080'               # origin that serves the frontend
export NEXUS_DB_PATH="$HOME/nexus-data/nexus.db"                # persistent SQLite file (directory must exist)
# local model (real Ollama): 
export NEXUS_OLLAMA_BASE_URL='http://127.0.0.1:11434' NEXUS_MODEL_OLLAMA='<a model you have pulled>'
node --experimental-sqlite --enable-source-maps dist/index.js
# in another shell: serve the frontend folder (any static server), e.g.
cd ../../frontend && python3 -m http.server 8080 --bind 127.0.0.1
```
Open `http://127.0.0.1:8080/neural_nexus_ai_agents-4-3-5-3.html` → Settings → backend URL `http://127.0.0.1:8787` and the gateway key → choose provider "Ollama" (🔒 local mode).
Cloud providers stay NOT_CONFIGURED unless you export their `*_API_KEY` variables (paid; your decision).

## Check it
`GET /v2/health` (no key) ; `GET /v2/models`, `GET /v2/providers/health?probe=1` (Bearer key) ; states: READY / DEGRADED / UNAVAILABLE / NOT_CONFIGURED. There is no `/health` route.
Stop = Ctrl-C/SIGTERM; restart with the same `NEXUS_DB_PATH` and tasks persist (verified).

## What has and has not been run
- RUN, with a **SIMULATED** model (fake Ollama-protocol server): the commands above on a clean extraction; 19-row check, 0 failed (`logs/OPERATIONAL-CHECK-run3-from-tarball.raw.log`, `logs/operational-from-tarball/operational-check.json`); UI→backend→simulated model reply; stop/restart persistence; 401 without key; LOCAL_ONLY/PRIVATE routing.
- NOT run: a real Ollama/LM Studio model, any real cloud provider, any real phone/device, any public host.
- Re-run the check yourself: `node tools/operational-check.mjs <repoRoot> <outDir>` (needs Playwright + Chromium).
