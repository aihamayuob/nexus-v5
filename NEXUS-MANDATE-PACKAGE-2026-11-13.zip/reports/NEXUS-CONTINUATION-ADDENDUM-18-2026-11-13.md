# NEXUS-CONTINUATION — §18 (append-only dated record; intended to follow §17 `continuity/NEXUS-CONTINUATION-ADDENDUM-17-2026-11-11.md`)

**Date:** 2026-11-13 (Damascus). **Authority:** owner "MASTER ENGINEERING, RECOVERY, REPAIR, OPERATIONALIZATION & TECHNICAL AUDIT MANDATE" (2026-11-11): routine fixes, tests, docs and audit tools authorized; commit/push/merge/tag/release, public exposure, architecture/public-contract change, license change and overriding Owner Decisions are NOT authorized. OD-C5 and OD-C13 respected; GENOME-GATE excluded; historical §27 evidence unmodified.
**Why a separate file:** same reason as §17 — the 45 KB `continuity/NEXUS-CONTINUATION.md` is not available as local bytes, so it was **NOT modified**. This record does not claim it was updated. Paste after §17 when a byte-exact copy exists.

## 18.1 Source / HEAD (honest)
- GitHub `aihamayuob/nexus-v5` `main` HEAD `28ad53887573c9be66c524607622eeaeedf30854`: reached read-only; **archive deposit, no source tree, no project `.git`** → live source repo **BLOCKED/UNVERIFIED**.
- Built/tested source = G8.2-CLOSURE snapshot (`A-source-snapshot`, 877 files) cross-checked with the git bundle (`cbdc898`). A ZIP/snapshot, **not** "the live repo". V1 fingerprint still UNVERIFIED. Pre-change tree fingerprint `abd33066721a12ff9e315370ed36c5e53ce42b9f3d602908234e6875d007c588`.

## 18.2 Work performed (isolated copy; strict TDD RED→GREEN; one main agent)
1. **F-UI-1** (local/private mode must not send user text to a cloud provider): root causes = helper defaults hard-coded `anthropic` (manager, Verifier, ask-team picker, multi-model judge), unauthenticated `getEmbedding()`→`/api/embed` choosing a cloud embedder, multi-model consensus cloud fallback. Fix: frontend single choke point `assertEgressAllowed` in `callClaude` (fail closed), `utilityProvider()` for helpers, consensus refuses in local mode, `getEmbedding` sends `{provider:<local>, localOnly:true}`; backend `/api/embed` accepts optional `localOnly:boolean` that only tightens (non-boolean rejected; cloud refused; no cloud fallback; fails closed). Tests: `embedLocalOnly.test.ts` (6) + `e2e/fui1-local-mode-egress-flow.mjs` (VALID 7/7, PS 27/27, 3 runs; 7/7 mutations caught).
2. **F-UI-2** (`#chatModelRow` overflow, advanced mode + local provider): CSS-only fix (`flex-wrap`, `min-width:0`, `max-width:100%`); `e2e/fui2-model-row-overflow-flow.mjs` 160/160 cells (7 phone widths + tablet + desktop × RTL/LTR × simple/advanced × local/cloud); RED reproduced first.
3. Full regression after both fixes: backend **626/626** (was 620), Vitest **186/186**, **17/17** E2E scripts exit 0 (15 original + 2 new). Operational check against the built backend + ORIGINAL frontend with a SIMULATED Ollama-protocol server: 19 rows, 0 failed (also from a clean tarball extraction); stop/restart persistence verified.
4. Dependencies/SBOM (CycloneDX, 149 components), `npm audit` (backend 0; frontend 6 dev-only: 3 moderate, 3 high — not fixed), IP-gap report, function/readiness matrix, run instructions, patch, raw logs.
5. Hygiene finding: existing E2E scripts overwrite `baseline/evidence/*` and tests create `nexus-backend/data/nexus.db`; originals restored from `pristine/`, regenerated outputs quarantined. No historical evidence was modified.

## 18.3 Statuses (scoped to the isolated copy; single runs; nothing raised beyond evidence)
- F-UI-1: **PARTIAL** — VERIFIED on simple/advanced/smart-routing/manager/Verifier/picker/judge/embeddings/local-failure paths with fake providers; **NOT verified**: real Ollama/LM Studio, real cloud APIs, schedules/ops panels, remote hosting, backend `contextFabric` defaults, LM Studio-specific run. `/api/embed` still `skipAuth` (F-01) — unchanged.
- F-UI-2: **VERIFIED** for the 160-cell measured matrix only (no text-zoom, other browsers, real devices, WCAG audit). Open cosmetic items: header-title overlap en-320, right-edge shadow, select label truncation.
- Platform operational copy: **PARTIAL** (SIMULATED model only). Real model: **UNVERIFIED**. Cloud providers: **NOT_CONFIGURED**. Preview page from §17: harness code not available this session → **PENDING** (not rebuilt, not claimed).
- Readiness (7 levels, independent): buildable VERIFIED; testable VERIFIED (fragile: undeclared tsx/Playwright); internally trialable PARTIAL; demonstrable PARTIAL; really usable PARTIAL/UNVERIFIED; public-deployment **BLOCKED**; technical-commercial evaluation PARTIAL.
- Open discrepancy: §17 recorded E2E "442 PASS"; per-script sums this session = 430 — **UNVERIFIED which is right**; no document edited.

## 18.4 Patch and fingerprints
`nexus-fui1-fui2.patch` (5 files: frontend HTML, `embed.ts`, `embedLocalOnly.test.ts`, 2 E2E scripts) — applying it to a fresh copy of `pristine/` reproduces the working copy byte-for-byte. Post-change SHA-256: frontend HTML `e9eb0e8207ffe927d306fb119ad41272caf3d38872411d7e8272bc511bbb2b28` (pre `0a017c03…b836e`); `embed.ts` `cca275ce…2726` (pre `9d2aea0e…92a1`). Runnable tarball SHA-256 `b88e5c53df7316121db26c5187e71a25d44120d84417f1d53915a35504197243`; `dist/` tree fingerprint `3a37d536cec1c9f78f2119dc23348800e49bb4bae5e3c424bd66d12c2ded4534`. **Not applied to any repo; not committed; not pushed.**

## 18.5 Blockers / risks
B-1 live source repo with `.git` missing · B-2 patch awaits OD-C5 approval · B-3 no real model runtime/keys · B-4 `/api/embed` unauthenticated + F-02…F-13 open · B-5 6 base64 images of unknown provenance, no LICENSE/NOTICE · B-6 CDN scripts without SRI, `typescript:"*"`, undeclared `tsx`/Playwright · B-7 6 dev-only npm advisories · B-8 E2E overwrites `baseline/evidence` · B-9 public exposure not approved/attempted.

## 18.6 Latest owner decisions in force
No commit/push/merge/tag/release; no public deployment/link; no license change; OD-C5 gate for Git operations; unproven statuses are never raised.

## 18.7 Exact stopping point / next authorized action
Stopped after the package, reports and this record. **Next authorized action: none beyond reading/verifying.** Owner decisions needed, in priority order: (1) provide the real source repo (with `.git`) and approve applying the 5-file patch there under OD-C5, then re-run the same suites; (2) authorize `/api/embed` authentication slice (F-01); (3) real Ollama/LM Studio test on the owner's machine; (4) authorize hardening slice (SRI, pin `typescript`, declare `tsx`/Playwright + e2e lockfile, evidence output-dir parameter); (5) provenance of the 6 embedded images and a license decision (owner/legal). On "continue": read §17 and §18 and `continuity/NEXUS-CONTINUATION.md` §15–§16, verify, **STOP**.
