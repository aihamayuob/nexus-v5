# NEXUS — Source, Tests and Fixes Report (Master Engineering Mandate of 2026-11-11, executed through 2026-11-13)

Status words only: VERIFIED / PARTIAL / PENDING / BLOCKED / FAILED / UNVERIFIED (+ SIMULATED / NOT_CONFIGURED for runtime rows).
Every VERIFIED below is scoped to **an isolated working copy**, single run per command unless stated, and to what the named test actually exercises.

## 1. Source and HEAD (what was actually used)

| Question | Answer |
|---|---|
| Was the live repo reached? | **PARTIAL.** `aihamayuob/nexus-v5` was reached (read-only shallow clone, branch `main`, HEAD `28ad53887573c9be66c524607622eeaeedf30854`, 1 commit, 181 files). It is an **archive deposit** (handoff zips/docs), **not** a source tree and has no project `.git`. |
| Live source repository (with `.git`) | **BLOCKED / UNVERIFIED** — not present in the GitHub repo. Nothing here claims it was read, modified or matched. |
| Source actually built and tested | The G8.2-CLOSURE snapshot (`A-source-snapshot`, restored tree, 877 files, no `.git`), cross-checked against the git bundle (HEAD `cbdc898`) and the recorded file-list hash. **A ZIP/snapshot — not "the live repo".** |
| V1 content fingerprint reproduction | UNVERIFIED (not reproduced). File list matched; see `evidence/`. |
| Working copy | `work/` (copy of untouched `pristine/`). `pristine/` and the cloned repo were never modified. |
| Archives inventoried | 44 zip files hashed (`evidence/all-zip-sha256.txt`), bundle hash `evidence/bundle-sha256.txt`, pristine file list (877) and per-file SHA-256 (`evidence/PRE-CHANGE-SHA256-pristine.txt`). |
| Pre-change tree fingerprint | `abd33066721a12ff9e315370ed36c5e53ce42b9f3d602908234e6875d007c588` (`evidence/PRE-CHANGE-tree-fingerprint.txt`) |
| Post-change SHA-256 (changed files) | `patch/POST-CHANGE-SHA256-changed-files.txt` |

Environment: Node v22.23.4, npm 10.9.9, TypeScript 7.0.2, tsx 4.23.12 (global, **undeclared** in the project), Playwright 1.63.0 (global; e2e/package.json declares ^1.56.0, no lockfile), Chromium (pre-installed).

## 2. Test re-run results

Pre = before any change. Post = after F-UI-1 + F-UI-2. Raw logs in `logs/`.

| Suite | Pre | Post | Notes |
|---|---|---|---|
| Backend `npm ci` | exit 0 | — | `B-npm-ci-backend.raw.log` |
| Backend typecheck (tsc) | exit 0 | exit 0 | needed `undici-types` via lockfile (first run before install failed — recorded) |
| Backend build | exit 0 | exit 0 | `dist/` produced |
| Backend tests (node:test) | 620/620 | **626/626** | +6 new (`embedLocalOnly.test.ts`) |
| Frontend Vitest | 186/186 (7 files) | 186/186 | unchanged |
| E2E (real Chromium + real backend) | 15 scripts exit 0 (gap1b first run exit 1: `tsx` ENOENT, passed after global tsx symlink — environment, not product) | **17/17 scripts exit 0** (15 existing + FUI1 + FUI2) | `E2E-summary-PRE.all.tsv`, `E2E-summary-POST.tsv` |
| FUI1 (new) | RED: failed as predicted | GREEN: VALID 7/7, PS 27/27 (3 consecutive runs) | harness-validity checks (VALID) separated from product behavior (PS) |
| FUI1 mutation check | — | 7/7 mutations caught | `FUI1-mutations*.raw.log` |
| FUI2 (new) | RED: overflow reproduced | GREEN: 160/160 matrix cells | `fui2-results-*.json` |
| Operational check (simulated local model) | — | 19 rows, 0 failed | `logs/operational/operational-check.json` |

What these do **not** prove: any real model, any real cloud API, other browsers, real phones, load, or concurrency.
Known inconsistency (not resolved): historical documents mention an E2E count of 442 where this run's per-script sums to 430 — **UNVERIFIED which is right**; documents were not edited.

Repo-hygiene finding: several **existing** E2E scripts write result files into `baseline/evidence/` (slice5-i1, slice6, slice7, slice8, slice10 results) and tests create `src-baseline/nexus-backend/data/nexus.db`. I restored every historical file from `pristine/` and quarantined the regenerated outputs in `logs/regression-regenerated-evidence/` so **historical §27 evidence is unmodified** (verified: `diff -rq pristine work` lists only the 5 intended files). Running the E2E suite in-place on a real repo would overwrite historical evidence — recommend an output-directory env var (not changed, scope).

## 3. Fixes log

### F-UI-1 — local/private mode must never send user text to a cloud provider  — **PARTIAL (VERIFIED on the paths listed; unverified paths listed)**

Definition used: frontend "local mode" = `isLocalProvider(getChatModel())` (same condition that shows the 🔒 badge).

Root causes found (reproduced RED in real Chromium with a metering fake cloud):
1. Internal helper calls defaulted to `provider='anthropic'`: smart-manager (auto-route), Verifier, ask-team picker, multi-model comparison judge.
2. `getEmbedding()` posted to the unauthenticated `/api/embed` with no provider → backend chose the first cloud embedder with a key; text left the machine.
3. Multi-model consensus tried cloud providers while in local mode.
4. No single choke point; labels (🔒) did not describe behavior.

Change (working copy only):
- `frontend/neural_nexus_ai_agents-4-3-5-3.html`: `isLocalOnlyActive()`, `utilityProvider()` (local when in local mode), `assertEgressAllowed()` as first statement of `callClaude` (fail closed, before knowledge/embeddings), helper defaults switched to `utilityProvider()`, `runMultiModelConsensus` refuses in local mode, `getEmbedding` sends `{provider:<local>, localOnly:true}` in local mode.
- `src-baseline/nexus-backend/src/routes/legacy/embed.ts`: new optional `localOnly:boolean` — can only **tighten**: non-boolean rejected, cloud provider refused, no cloud-embedder fallback, local-unavailable fails closed. Legacy (no field) behavior unchanged (control test).
- Tests: `test/embedLocalOnly.test.ts` (6, RED→GREEN), `e2e/fui1-local-mode-egress-flow.mjs`.

Paths VERIFIED (isolated, fake providers): simple mode, advanced mode, smart/auto routing + manager, Verifier (direct and chat-gated, incl. high-risk text), ask-team picker, multi-model comparison/judge, embeddings (knowledge), local provider failing/absent (fails closed, nothing to cloud), explicit cloud fallback removed, mode switching local↔cloud (cloud mode still works — control).

Paths **NOT verified**: real Ollama / LM Studio runtimes; any real cloud API; scheduled/ops-panel features not on the tested paths; remote hosted backend; backend `contextFabric` defaults; LM Studio-specific E2E; any other code path that does not go through `callClaude`/`getEmbedding`/the patched helpers (none found by search, but a search is not a proof).

Residual (documented, **not changed**): `/api/embed` is still `skipAuth` (static finding F-01) — now local-only-capable, but an unauthenticated caller can still choose cloud embedding without `localOnly`. Needs an owner decision (public-contract/security change).

### F-UI-2 — `#chatModelRow` / send button horizontal overflow (advanced mode + local provider) — **VERIFIED for the measured matrix**

Root cause: `.model-pill-bar` was a non-wrapping flex row; the local model name input had no `min-width:0`, so the row exceeded the viewport and pushed the send button off-screen (RTL scrolls leftwards).
Change: CSS only (`flex-wrap`, `row-gap`, `min-width:0`, `max-width:100%`, `flex:1 1 auto` on the input). Design/tokens/colors unchanged.
Test: `e2e/fui2-model-row-overflow-flow.mjs` — widths 320/360/375/390/412/430/480 + tablet + desktop × ar-RTL/en-LTR × simple/advanced × local/cloud = **160 cells**, measuring scrollWidth, bounding rects and `elementFromPoint` hit-tests on the send button; harness validated by an injected-overflow control (made RTL-aware after an INVALID first harness). RED reproduced, GREEN 160/160.
Not verified: browser text-zoom, other browsers, real devices, WCAG audit.
Documented, not fixed: header title overlap at en-320, right-edge shadow, select label truncation.

### Other findings (documented, no change — need scope/owner decision)
F-01…F-13 static findings (see Project docs); CDN scripts (qrcode 1.0.0, jsQR 1.4.0, pdf.js 3.11.174) loaded **without SRI**; CSP `connect-src` allows any `http:/https:/ws:`; `tsx` and Playwright undeclared/unpinned (`typescript: "*"` in backend devDependencies); no LICENSE file.

## 4. Patch

`patch/nexus-fui1-fui2.patch` (sha256 in `patch/nexus-fui1-fui2.patch.sha256`) — 5 files: frontend HTML, `embed.ts`, `embedLocalOnly.test.ts`, two E2E scripts. Verified: applying it to a fresh copy of `pristine/` reproduces `work/` byte-for-byte (`diff -rq` clean). **Not applied to any repository. Not committed. Not pushed** (OD-C5).
