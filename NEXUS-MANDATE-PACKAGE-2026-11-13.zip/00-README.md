# NEXUS mandate package (2026-11-13)
reports/01 source+tests+fixes · 02 dependencies/licenses/IP · 03 function matrix/readiness/blockers · 04 run instructions · NEXUS-CONTINUATION-ADDENDUM-18 · sbom.cdx.json
patch/ the 5-file patch + pre/post SHA-256 · operational/ runnable tarball + fingerprints · tools/ harnesses (operational-check, sbom, mutate, probes, new tests)
logs/ all raw logs (pre/post, RED/GREEN, E2E, operational, deps, screenshots) · evidence/ pre-change fingerprints and archive hashes
Scope: isolated working copy of the G8.2-CLOSURE snapshot + patch. NOT the live repo (BLOCKED). Nothing committed/pushed/deployed. Simulated model only; no real model or cloud call.
