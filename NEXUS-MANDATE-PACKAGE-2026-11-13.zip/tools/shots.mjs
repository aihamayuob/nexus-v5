import { chromium } from '/home/claude/.npm-global/lib/node_modules/playwright/index.mjs';
import http from 'node:http'; import { readFile } from 'node:fs/promises'; import path from 'node:path';
const S=process.argv[2];
const serve=(dir)=>new Promise(res=>{const s=http.createServer(async(q,r)=>{const u=new URL(q.url,'http://x');const rel=u.pathname==='/'?'neural_nexus_ai_agents-4-3-5-3.html':decodeURIComponent(u.pathname.slice(1));try{const b=await readFile(path.join(dir,rel));r.writeHead(200,{'content-type':rel.endsWith('.html')?'text/html; charset=utf-8':'text/javascript; charset=utf-8','cache-control':'no-store'});r.end(b)}catch{r.writeHead(404);r.end()}});s.listen(0,'127.0.0.1',()=>res(s))});
const A=await serve(`${S}/pristine/frontend`), B=await serve(`${S}/work/frontend`);
const b=await chromium.launch();
for(const [tag,srv] of [['before',A],['after',B]]){
  const origin=`http://127.0.0.1:${srv.address().port}/`;
  for(const lang of ['ar','en']) for(const w of [320,375,480]) {
    const ctx=await b.newContext({viewport:{width:w,height:700},deviceScaleFactor:2});
    await ctx.addInitScript((lang)=>{localStorage.setItem('nexus_ui_lang',lang);localStorage.setItem('nexus_simple_mode','false');localStorage.setItem('nexus_backend_url','http://127.0.0.1:9');localStorage.setItem('nexus_chat_model','ollama');localStorage.setItem('nexus_local_model_name','llama3.1');},lang);
    const p=await ctx.newPage(); await p.goto(origin,{waitUntil:'load'});
    await p.waitForFunction(()=>typeof encryptionKey!=='undefined'&&encryptionKey!==null,null,{timeout:15000});
    await p.evaluate(()=>{renderChatModelSelect();for(const id of ['deepAnalysisToggle','toolsToggle','thoughtTreeToggle']){const e=document.getElementById(id);if(e){e.checked=true;e.dispatchEvent(new Event('change',{bubbles:true}))}}updateActiveModesCount();});
    await p.waitForTimeout(150);
    await p.screenshot({path:`${S}/logs/visual/${tag}_${lang}_${w}.png`});
    await ctx.close();
  }
}
await b.close(); A.close(); B.close(); console.log('ok');
