import { readFileSync, writeFileSync, copyFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
const S = process.argv[2];
const FILE = `${S}/work/frontend/neural_nexus_ai_agents-4-3-5-3.html`;
const BAK = `${S}/logs/frontend.pre-mutation.bak`;
const sha = (f) => createHash('sha256').update(readFileSync(f)).digest('hex');
const orig = readFileSync(FILE, 'utf8'); const origSha = sha(FILE); copyFileSync(FILE, BAK);
const M = [
  ['M1 utilityProvider always anthropic', "return isLocalOnlyActive() ? getChatModel() : 'anthropic';", "return 'anthropic';"],
  ['M2 remove choke point assertEgressAllowed in callClaude', "assertEgressAllowed(provider); // F-UI-1: first statement", "/*mut*/ // F-UI-1: first statement"],
  ['M3 remove multi-model local refusal', "if(isLocalOnlyActive()){\n    messages.push({ role:'assistant', agentId:'error', agentName:'🔒 الوضع المحلي'", "if(false){\n    messages.push({ role:'assistant', agentId:'error', agentName:'🔒 الوضع المحلي'"],
  ['M4 getEmbedding without localOnly', "isLocalOnlyActive() ? { texts:[text], provider:getChatModel(), localOnly:true } : { texts:[text] }", "{ texts:[text] }"],
  ['M5 Verifier pinned to anthropic', "const vProvider = utilityProvider();", "const vProvider = 'anthropic';"],
  ['M6 team picker pinned to anthropic', "const pickProvider = utilityProvider();", "const pickProvider = 'anthropic';"],
  ['M7 manager pinned to anthropic', "const mgrProvider = utilityProvider();", "const mgrProvider = 'anthropic';"],
];
const out = [];
try {
  for (const [name, from, to] of M) {
    const n = orig.split(from).length - 1;
    if (n !== 1) { out.push(`${name}: SKIPPED (pattern occurs ${n}x)`); continue; }
    writeFileSync(FILE, orig.replace(from, to));
    const r = spawnSync('node', ['fui1-local-mode-egress-flow.mjs'], { cwd: `${S}/work/e2e`, encoding: 'utf8', timeout: 280000, env: { ...process.env, NEXUS_FUI1_RESULTS: `${S}/logs/fui1-mut.json` } });
    const fails = (r.stdout.match(/^\[FAIL\] \[(?:PS|VALID)\] [A-Z]\d+/gm) || []).map((x) => x.replace('[FAIL] ', ''));
    const verdict = (r.stdout.match(/FUI1-VERDICT = (\w+)/) || [])[1];
    out.push(`${name}: exit=${r.status} verdict=${verdict} caught_by=${fails.length ? fails.join(' ') : 'NOTHING'}`);
  }
} finally {
  writeFileSync(FILE, orig);
}
out.push(`restored sha equal: ${sha(FILE) === origSha}`);
console.log(out.join('\n'));
