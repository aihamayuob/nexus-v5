import { chromium } from '/home/claude/.npm-global/lib/node_modules/playwright/index.mjs';
import http from 'node:http'; import { readFile } from 'node:fs/promises'; import path from 'node:path';
const S=process.argv[2];
const serve=(dir)=>new Promise(res=>{const s=http.createServer(async(q,r)=>{const u=new URL(q.url,'http://x');const rel=u.pathname==='/'?'neural_nexus_ai_agents-4-3-5-3.html':decodeURIComponent(u.pathname.slice(1));try{const b=await readFile(path.join(dir,rel));r.writeHead(200,{'content-type':rel.endsWith('.html')?'text/html; charset=utf-8':'text/javascript; charset=utf-8'});r.end(b)}catch{r.writeHead(404);r.end()}});s.listen(0,'127.0.0.1',()=>res(s))});
const A=await serve(`${S}/pristine/frontend`), B=await serve(`${S}/work/frontend`);
const b=await chromium.launch();
for(const [tag,srv] of [['pristine',A],['modified',B]]){
  const ctx=await b.newContext({viewport:{width:375,height:700},deviceScaleFactor:2});
  await ctx.addInitScript(()=>{localStorage.setItem('nexus_simple_mode','true');localStorage.setItem('nexus_ui_lang','ar')});
  const p=await ctx.newPage(); await p.goto(`http://127.0.0.1:${srv.address().port}/`,{waitUntil:'load'});
  await p.waitForFunction(()=>typeof encryptionKey!=='undefined'&&encryptionKey!==null,null,{timeout:15000});
  await p.waitForTimeout(200);
  const m=await p.evaluate(()=>({sw:document.documentElement.scrollWidth,vw:document.documentElement.clientWidth}));
  console.log(tag,'SIMPLE mode ar 375:',JSON.stringify(m));
  await p.screenshot({path:`${S}/logs/visual/${tag}_simple_ar_375.png`});
  await ctx.close();
}
await b.close(); A.close(); B.close();
