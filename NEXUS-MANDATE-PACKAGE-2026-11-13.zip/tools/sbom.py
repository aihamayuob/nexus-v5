import json,sys,hashlib,datetime,uuid
out=sys.argv[1]; comps=[]; summary=[]
for label,lock in [('frontend','frontend/package-lock.json'),('backend','src-baseline/nexus-backend/package-lock.json')]:
    d=json.load(open(lock)); pk=d.get('packages',{}); root=pk.get('',{})
    direct=set(list(root.get('dependencies',{}))+list(root.get('devDependencies',{})))
    n=0; lic={}; nolic=[]
    for path,p in pk.items():
        if not path: continue
        name=p.get('name') or path.split('node_modules/')[-1]
        ver=p.get('version'); l=p.get('license')
        scope='optional' if p.get('optional') else ('excluded' if p.get('dev') else 'required')
        c={'type':'library','bom-ref':f'{label}:{name}@{ver}','name':name,'version':ver,'purl':f'pkg:npm/{name.replace("@","%40",1) if name.startswith("@") else name}@{ver}',
           'scope':scope,'properties':[{'name':'nexus:workspace','value':label},{'name':'nexus:dev','value':str(bool(p.get('dev'))).lower()},{'name':'nexus:direct','value':str(name in direct).lower()}]}
        if l: c['licenses']=[{'license':{'name':l if isinstance(l,str) else json.dumps(l)}}]
        else: nolic.append(name)
        if p.get('integrity'): c['hashes']=[{'alg':'SHA-512' if p['integrity'].startswith('sha512') else 'SHA-1','content':p['integrity'].split('-',1)[1]}]
        comps.append(c); n+=1; lic[str(l)]=lic.get(str(l),0)+1
    summary.append({'workspace':label,'lockfileVersion':d.get('lockfileVersion'),'packages':n,'direct':sorted(direct),'licenses':lic,'noLicenseField':sorted(set(nolic))})
bom={'bomFormat':'CycloneDX','specVersion':'1.5','serialNumber':'urn:uuid:'+str(uuid.uuid4()),'version':1,
 'metadata':{'timestamp':datetime.datetime.utcnow().isoformat()+'Z','component':{'type':'application','name':'nexus-v5 (working copy, G8.2-CLOSURE + F-UI-1/F-UI-2 patch)','version':'2.0.0/5.0.0-modularize'},
 'properties':[{'name':'nexus:note','value':'Generated from package-lock.json files (declared closure). Licenses are the lockfile "license" field only (not independently verified). Not a legal review.'}]},
 'components':comps}
json.dump(bom,open(out+'/sbom.cdx.json','w'),indent=1); json.dump(summary,open(out+'/sbom-summary.json','w'),indent=1,ensure_ascii=False)
print(json.dumps(summary,indent=1,ensure_ascii=False)[:3500])
