/* operational-check.mjs — runs the BUILT NEXUS backend (dist/) + serves the ORIGINAL frontend file, against a SIMULATED local model (Ollama wire protocol) and NO cloud keys.
   Usage: node operational-check.mjs <repoRoot> <outDir>      (repoRoot contains frontend/ and src-baseline/nexus-backend/ with dist/ already built)
   Everything it proves is stated in the output JSON; "SIMULATED" = the model is a fake HTTP server, NOT a real model. It never contacts the internet. */
import { spawn } from 'node:child_process';
import http from 'node:http';
import net from 'node:net';
import { createHash } from 'node:crypto';
import { readFile, writeFile, mkdir, mkdtemp } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { chromium } from 'playwright';

const ROOT = path.resolve(process.argv[2]); const OUT = path.resolve(process.argv[3]);
const BACKEND = path.join(ROOT, 'src-baseline/nexus-backend'); const FRONT = path.join(ROOT, 'frontend');
const HTML = 'neural_nexus_ai_agents-4-3-5-3.html'; const KEY = 'op-check-key-Zx81Lm20Qa77Vb34-0001';
await mkdir(OUT, { recursive: true });
const rows = []; const rec = (area, check, status, evidence) => { rows.push({ area, check, status, evidence }); console.log(`[${status}] ${area} :: ${check} — ${typeof evidence === 'string' ? evidence : JSON.stringify(evidence)}`); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const freePort = () => new Promise((res, rej) => { const s = net.createServer(); s.once('error', rej); s.listen(0, '127.0.0.1', () => { const p = s.address().port; s.close(() => res(p)); }); });
const up = async (port) => { for (let i = 0; i < 300; i++) { const ok = await new Promise((r) => { const c = net.connect({ port, host: '127.0.0.1' }); c.once('connect', () => { c.destroy(); r(true); }); c.once('error', () => r(false)); }); if (ok) return true; await sleep(100); } return false; };

// SIMULATED local model (Ollama protocol)
const localLog = [];
const fake = http.createServer(async (req, res) => {
  const c = []; for await (const x of req) c.push(x); const body = Buffer.concat(c).toString('utf8'); localLog.push(req.url);
  let j = {}; try { j = JSON.parse(body); } catch { /* ignore */ }
  if (req.url === '/api/tags') { res.writeHead(200, { 'content-type': 'application/json' }); return res.end(JSON.stringify({ models: [{ name: 'llama3.1' }] })); }
  if (req.url === '/api/embed') { res.writeHead(200, { 'content-type': 'application/json' }); return res.end(JSON.stringify({ embeddings: (j.input || []).map(() => [0.1, 0.2, 0.3]) })); }
  const text = 'إجابة محاكاة محلية (SIMULATED) — ليست نموذجًا حقيقيًا.';
  if (j.stream) { res.writeHead(200, { 'content-type': 'application/x-ndjson' }); res.write(JSON.stringify({ message: { content: text }, done: false }) + '\n'); return res.end(JSON.stringify({ message: { content: '' }, done: true, prompt_eval_count: 4, eval_count: 6 }) + '\n'); }
  res.writeHead(200, { 'content-type': 'application/json' }); res.end(JSON.stringify({ message: { content: text }, prompt_eval_count: 4, eval_count: 6 }));
});
const localPort = await freePort(); await new Promise((r) => fake.listen(localPort, '127.0.0.1', r));

const dbDir = await mkdtemp(path.join(os.tmpdir(), 'nexus-op-')); const dbPath = path.join(dbDir, 'nexus.db');
const bePort = await freePort(); const fePort = await freePort(); const feOrigin = `http://127.0.0.1:${fePort}`; const be = `http://127.0.0.1:${bePort}`;
let proc; let logs = '';
const start = async () => {
  proc = spawn('node', ['--experimental-sqlite', '--enable-source-maps', 'dist/index.js'], { cwd: BACKEND, stdio: ['ignore', 'pipe', 'pipe'],
    env: { PATH: process.env.PATH, HOME: process.env.HOME, NEXUS_DB_PATH: dbPath, NEXUS_HOST: '127.0.0.1', NEXUS_PORT: String(bePort), NEXUS_GATEWAY_KEYS: KEY, NEXUS_CORS_ORIGINS: feOrigin, NEXUS_LOG_LEVEL: 'warn',
      NEXUS_OLLAMA_BASE_URL: `http://127.0.0.1:${localPort}`, NEXUS_MODEL_OLLAMA: 'llama3.1' } });
  proc.stdout.on('data', (d) => (logs += d)); proc.stderr.on('data', (d) => (logs += d));
  return up(bePort);
};
const stop = async () => { proc.kill('SIGTERM'); await sleep(1500); try { proc.kill('SIGKILL'); } catch { /* gone */ } };
const auth = { 'content-type': 'application/json', Authorization: 'Bearer ' + KEY };
const getj = async (p, h = auth) => { const r = await fetch(be + p, { headers: h }); let b = null; try { b = await r.json(); } catch { /* not json */ } return { status: r.status, body: b }; };

const feSrv = http.createServer(async (req, res) => { const u = new URL(req.url, 'http://x'); const rel = u.pathname === '/' ? HTML : decodeURIComponent(u.pathname.slice(1)); try { const b = await readFile(path.join(FRONT, rel)); res.writeHead(200, { 'content-type': rel.endsWith('.html') ? 'text/html; charset=utf-8' : 'text/javascript; charset=utf-8', 'cache-control': 'no-store' }); res.end(b); } catch { res.writeHead(404); res.end(); } });
await new Promise((r) => feSrv.listen(fePort, '127.0.0.1', r));

try {
  const sha = createHash('sha256').update(await readFile(path.join(FRONT, HTML))).digest('hex');
  rec('Frontend', 'original single-file frontend is the one served (not replaced)', 'VERIFIED', { file: HTML, sha256: sha });
  const ok = await start(); rec('Backend', 'built backend (dist/) starts and listens', ok ? 'VERIFIED' : 'FAILED', ok ? `port ${bePort}` : logs.slice(0, 300));
  if (!ok) throw new Error('backend did not start');

  for (const p of ['/health', '/healthz', '/api/health', '/v2/health']) { const r = await getj(p, {}); if (r.status === 200) { rec('Health', `GET ${p}`, 'VERIFIED', r.body); break; } else rec('Health', `GET ${p}`, 'INFO', `status ${r.status}`); }
  const noauth = await getj('/v2/models', {}); rec('Security', 'protected route without a gateway key is rejected', noauth.status === 401 || noauth.status === 403 ? 'VERIFIED' : 'FAILED', `status ${noauth.status}`);
  const models = await getj('/v2/models'); rec('Gateway', 'GET /v2/models lists providers', models.status === 200 ? 'VERIFIED' : 'FAILED', { status: models.status, providers: (models.body?.providers || []).map((p) => `${p.id}${p.configured ? ':configured' : ''}`) });
  const ph = await getj('/v2/providers/health?probe=1'); rec('Gateway', 'GET /v2/providers/health (live probe)', ph.status === 200 ? 'VERIFIED' : 'FAILED', (ph.body?.providers || []).map((p) => `${p.id}=${p.status ?? p.state}`));
  for (const mode of ['LOCAL_ONLY', 'PRIVATE']) { const r = await fetch(be + '/v2/route', { method: 'POST', headers: auth, body: JSON.stringify({ mode }) }); const b = await r.json().catch(() => ({})); rec('Router', `mode ${mode} resolves to a LOCAL provider and blocks cloud fallback`, r.status === 200 && b.provider === 'ollama' && b.cloudFallbackBlocked === true ? 'VERIFIED' : 'FAILED', { status: r.status, provider: b.provider, cloudFallbackBlocked: b.cloudFallbackBlocked }); }

  const t = await fetch(be + '/v2/tasks', { method: 'POST', headers: auth, body: JSON.stringify({ input: 'اختبار تشغيلي: لخّص جملة واحدة', provider: 'ollama' }) });
  const stream = await t.text(); const taskId = (/"taskId"\s*:\s*"([^"]+)"/.exec(stream) || [])[1];
  rec('Task execution', 'POST /v2/tasks with the simulated local model completes and streams an answer', t.status === 200 && stream.includes('محاكاة') ? 'SIMULATED' : 'FAILED', { status: t.status, taskId, answerSeen: stream.includes('محاكاة') });
  const taskRow = taskId ? await getj('/v2/tasks/' + taskId) : { status: 0 }; rec('Task execution', 'the task is persisted with a terminal status', taskRow.body?.task?.status === 'done' ? 'VERIFIED' : 'FAILED', { status: taskRow.status, taskStatus: taskRow.body?.task?.status });
  const cloud = await fetch(be + '/api/chat', { method: 'POST', headers: auth, body: JSON.stringify({ provider: 'anthropic', max_tokens: 10, messages: [{ role: 'user', content: 'x' }] }) });
  const cb = await cloud.json().catch(() => ({})); rec('Providers', 'a cloud provider with NO key fails clearly (NOT_CONFIGURED), no silent fallback', cloud.status >= 400 ? 'NOT_CONFIGURED' : 'FAILED', { status: cloud.status, code: cb?.error?.code });

  await stop(); const restarted = await start(); rec('Lifecycle', 'stop then restart on the same database', restarted ? 'VERIFIED' : 'FAILED', restarted ? 'listening again' : logs.slice(-300));
  const again = taskId && restarted ? await getj('/v2/tasks/' + taskId) : { status: 0 }; rec('Storage/Recovery', 'the task written before the restart is still readable after it', again.body?.task?.status === 'done' ? 'VERIFIED' : 'FAILED', { status: again.status, taskStatus: again.body?.task?.status });

  const browser = await chromium.launch(); const ctx = await browser.newContext({ viewport: { width: 390, height: 800 } }); const page = await ctx.newPage();
  const errs = []; page.on('pageerror', (e) => errs.push(String(e)));
  await page.goto(feOrigin + '/', { waitUntil: 'load' }); await page.waitForFunction(() => typeof encryptionKey !== 'undefined' && encryptionKey !== null, null, { timeout: 15000 });
  await page.evaluate(() => openSettingsPanel()); await page.fill('#backendUrlInput', be); await page.fill('#gatewayKeyInput', KEY); await page.click('button[onclick="saveBackendUrl()"]');
  await page.evaluate(() => { localStorage.setItem('nexus_local_model_name', 'llama3.1'); const s = document.getElementById('chatModelSelect'); if (isSimpleMode()) toggleSimpleMode(); s.value = 'ollama'; saveChatModelSetting(); toggleSimpleMode(); });
  await page.fill('#msgInput', 'مرحبا — اختبار من الواجهة الأصلية'); await page.click('#sendBtn');
  await page.waitForFunction(() => !isSendingMessage && !document.getElementById('sendBtn').disabled, null, { timeout: 60000 }).catch(() => {}); await sleep(400);
  const last = await page.evaluate(() => (messages[messages.length - 1] || {}).content || ''); await page.screenshot({ path: path.join(OUT, 'frontend-local-chat-390.png') });
  rec('Frontend↔Backend', 'original UI, local mode, a message goes UI → backend → (simulated) local model and the answer renders', last.includes('محاكاة') ? 'SIMULATED' : 'FAILED', { reply: last.slice(0, 90), pageErrors: errs.length });
  await browser.close();
  rec('Real model', 'a REAL local model (Ollama/LM Studio) answered', 'UNVERIFIED', 'no real model runtime is available in this environment; every model answer above came from the simulated server');
  rec('Cloud providers', 'any real cloud provider call', 'NOT_CONFIGURED', 'no API keys supplied; none were contacted (the sandbox network is allow-listed)');
} catch (e) { rec('Harness', 'operational check aborted', 'FAILED', String(e && e.message)); }
finally { try { await stop(); } catch { /* ignore */ } fake.close(); feSrv.close(); feSrv.closeAllConnections?.(); }
await writeFile(path.join(OUT, 'operational-check.json'), JSON.stringify({ generatedAt: new Date().toISOString(), node: process.version, rows }, null, 2));
const failed = rows.filter((r) => r.status === 'FAILED').length; console.log(`DONE rows=${rows.length} failed=${failed}`); process.exit(failed ? 1 : 0);
