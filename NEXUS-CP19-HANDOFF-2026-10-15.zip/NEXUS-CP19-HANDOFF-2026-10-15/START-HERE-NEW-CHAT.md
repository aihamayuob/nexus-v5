# START HERE — استئناف NEXUS من حالة CP-19

## ما هذه الحزمة
لقطة عمل (working snapshot) بتاريخ 2026-10-15 **تشمل التغييرات غير الملتزمة** (Slice 9/10) — وليست `git archive` ولا نسخة HEAD وحدها، وليست «نسخة مطابقة للمستودع الكامل» (استُبعدت المولَّدات والاعتماديات؛ انظر الاستثناءات).

| المسار | المحتوى |
|---|---|
| `NEXUS-CP19-DETAILED-HANDOFF-2026-10-15.md` | التقرير التفصيلي (اقرأه بعد هذا الملف) |
| `CLAUDE-NEW-CHAT-PROMPT-AR.md` | أمر جاهز للصق في المحادثة الجديدة |
| `MANIFEST-SHA256.txt` | بصمة كل ملف في الحزمة (عدا نفسه) |
| `nexus-v5/` | المستودع: 583 ملفًا (501 متتبَّع + 82 غير متتبَّع) + `.git` |
| `CP19-evidence/` | المعايير المجمّدة، سجل الانحرافات، لقطات الحالة، سجلات الاختبار والطفرات والانحدار |

## الحالة المرجعية (تحقّق منها أولًا، ولا تفترضها)
- الفرع `v5.0-polish` · HEAD `80c558a2378eefc7748fe0af41d4a381e41c19d9` · الأب `bc05f58247ea837f3df4fd8343fdc52ed21eeedd`.
- الشجرة: **8 M + 82 ??** (Slice 10 وما قبله غير ملتزم).
- ملف CP-19: `nexus-v5/e2e/phase2-core-slice11-context-characterization-flows.mjs`، SHA-256 `89842de0c5e71ed9c1d43cd7ab4c601e4d4554b9f411a31a3e6266077a840093`.
- `CP19-evidence/FROZEN-CRITERIA.md`: `b82d27c2a52667becb72b29b72d0e094fd2e0915c5614fb5d147b93978d98979`.
- CP-19: **VERIFIED** ضمن Chromium 141 headless وخلفية وهمية؛ الطفرات **PARTIAL** (24 REJECTED، MU23 ناجية متوقعة، **MU05 = INVALID** — قرار مالك لا يُعاد)؛ الاستقلال عن Slice 10 **VERIFIED**.
- Core وPhase 2: **PARTIAL** (ليسا مغلقين). `sw.js`: **BLOCKED/UNVERIFIED**. نقل `NexusContext`/`ContextFabric`: **لم يبدأ** (قرار D5).

## ما تفعله أولًا
1. فكّ الحزمة في مجلد جديد فارغ، ثم `sha256sum -c MANIFEST-SHA256.txt`.
2. في `nexus-v5/`: `git rev-parse HEAD HEAD^` و`git status --porcelain | awk '{print substr($0,1,2)}' | sort | uniq -c` وقارن بالحالة أعلاه. **سجّل أي اختلاف بدل افتراض الصحة.**
3. اقرأ بالترتيب: التقرير التفصيلي ← `nexus-v5/NEXUS-CURRENT-STATE.md` ← `nexus-v5/docs/checkpoints/CP-18.md` ← `nexus-v5/ADR/005-…` ← `CP19-evidence/FROZEN-CRITERIA.md` و`DEVIATIONS-LOG.md`.
4. ثم اقترح **أقصر مسار آمن** للخطوة التالية واطلب قرار المالك. **لا تبدأ شريحة قبل ذلك.**

## ما يجب ألا تعيده
- لا تُعد اختبارات CP-19 أو الانحدار دون سبب فني محدد (نتائجها محفوظة في `CP19-evidence/`).
- لا تُعد فتح: MU05=INVALID، المعايير المجمّدة، استقلال CP-19 عن Slice 10، Evidence Integrity، `isSendingMessage`، I-1/O2، قرار D5.
- لا تنقل `messages` أو `selectedAgentIds`؛ لا تنقل `NexusContext`/`ContextFabric` بلا قرار جديد (الحقن الصريح أ فقط؛ الاسم المجرد ب ممنوع).
- لا commit ولا ZIP دون طلب صريح؛ لا تعتمد GitHub شرطًا افتراضيًا؛ لا تستخدم `git reset --hard` ولا `git clean`.
- لا تشغّل سكربتات E2E القديمة داخل المستودع الحقيقي (تثبّت المسار وتكتب في `baseline/evidence`)؛ استخدم نسخة معزولة.

## الاستثناءات المهمة
مستبعد: `node_modules` (e2e/frontend/backend)، `src-baseline/nexus-backend/dist` و`data`، النسخ المعزولة. غير متاح: `sw.js`، وثائق مشروع claude.ai. الحزمة تحتاج `npm ci` (+ `npm run build` للـbackend) لتشغيل أي شيء.
