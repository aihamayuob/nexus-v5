import '../test/helpers/setMissionTestEnv.js';
import { test, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { createServer, type Server } from 'node:http';
import { openTestDb } from '../src/persistence/db.js';
import { buildRepos, resetReposSingletonForTests } from '../src/persistence/repos.js';
import { createNexusServer } from '../src/gateway/server.js';

let nexusServer: Server;
let nexusUrl: string;
let fakeAnthropic: Server;
let hangForever = false;

function listen(server: Server): Promise<string> {
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => {
      const addr = server.address();
      resolve(`http://127.0.0.1:${typeof addr === 'object' && addr ? addr.port : 0}`);
    });
  });
}

function anthropicTextResponse(text: string) {
  return JSON.stringify({ content: [{ type: 'text', text }], stop_reason: 'end_turn', usage: { input_tokens: 5, output_tokens: 5 } });
}

before(async () => {
  fakeAnthropic = createServer(async (req, res) => {
    if (req.method === 'GET') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ data: [] }));
      return;
    }
    if (hangForever) return;
    const chunks: Buffer[] = [];
    for await (const c of req) chunks.push(c as Buffer);
    let body: { system?: string } = {};
    try {
      body = JSON.parse(Buffer.concat(chunks).toString('utf-8') || '{}');
    } catch {
      /* ignore */
    }
    if ((body.system ?? '').includes('أنت مخطط مهام')) {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(anthropicTextResponse(JSON.stringify({ tasks: [{ id: 'only_task', description: 'أنجز المهمة', dependsOn: [] }] })));
      return;
    }
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(anthropicTextResponse('ناتج عبر HTTP.'));
  });
  process.env.NEXUS_ANTHROPIC_BASE_URL = await listen(fakeAnthropic);
  process.env.NEXUS_ANTHROPIC_API_KEY = 'fake-anthropic-key';
  nexusServer = createNexusServer();
  nexusUrl = await listen(nexusServer);
});

after(async () => {
  fakeAnthropic.closeAllConnections();
  await Promise.all([new Promise((r) => nexusServer.close(r)), new Promise((r) => fakeAnthropic.close(r))]);
});

beforeEach(() => {
  resetReposSingletonForTests(buildRepos(openTestDb()));
  hangForever = false;
});

test('POST /v2/missions/:id/pause then /resume actually pauses and resumes a real mission over HTTP', async () => {
  hangForever = true;
  const createRes = await fetch(`${nexusUrl}/v2/missions`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ objective: 'مهمة HTTP للإيقاف والاستئناف' }),
  });
  const { missionId } = (await createRes.json()) as { missionId: string };
  await new Promise((r) => setTimeout(r, 150));

  const pauseRes = await fetch(`${nexusUrl}/v2/missions/${missionId}/pause`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ reason: 'اختبار HTTP' }),
  });
  assert.equal(pauseRes.status, 200);
  const pauseBody = (await pauseRes.json()) as { paused: boolean };
  assert.equal(pauseBody.paused, true);

  const statusRes = await fetch(`${nexusUrl}/v2/missions/${missionId}`);
  const status = (await statusRes.json()) as { state: string };
  assert.equal(status.state, 'PAUSED');

  hangForever = false;
  const resumeRes = await fetch(`${nexusUrl}/v2/missions/${missionId}/resume`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ reason: 'استئناف HTTP' }),
  });
  assert.equal(resumeRes.status, 202);
  await new Promise((r) => setTimeout(r, 400));

  const finalRes = await fetch(`${nexusUrl}/v2/missions/${missionId}`);
  const final = (await finalRes.json()) as { state: string };
  assert.equal(final.state, 'COMPLETED');
});

test('POST /v2/missions/:id/pause on an unknown mission is a real 404', async () => {
  const res = await fetch(`${nexusUrl}/v2/missions/does-not-exist/pause`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
  assert.equal(res.status, 404);
});

test('POST /v2/missions/:id/resume on a non-PAUSED mission is a real 400', async () => {
  const createRes = await fetch(`${nexusUrl}/v2/missions`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ objective: 'مهمة ستكتمل فوراً' }),
  });
  const { missionId } = (await createRes.json()) as { missionId: string };
  await new Promise((r) => setTimeout(r, 300));
  const res = await fetch(`${nexusUrl}/v2/missions/${missionId}/resume`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
  assert.equal(res.status, 400);
});

test('POST /v2/warden/agents/:id/isolate then real enforcement over HTTP, then /release lifts it', async () => {
  const isolateRes = await fetch(`${nexusUrl}/v2/warden/agents/financial/isolate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ reason: 'اختبار HTTP', isolatedBy: 'tester' }),
  });
  assert.equal(isolateRes.status, 200);

  const listRes = await fetch(`${nexusUrl}/v2/warden/agents/isolated`);
  const listBody = (await listRes.json()) as { agents: Array<{ agentId: string }> };
  assert.ok(listBody.agents.some((a) => a.agentId === 'financial'));

  const statusRes = await fetch(`${nexusUrl}/v2/warden/status`);
  const status = (await statusRes.json()) as { isolatedAgents: number };
  assert.equal(status.isolatedAgents, 1);

  const releaseRes = await fetch(`${nexusUrl}/v2/warden/agents/financial/release`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ reason: 'تحرير' }),
  });
  assert.equal(releaseRes.status, 200);
  const releaseBody = (await releaseRes.json()) as { released: boolean };
  assert.equal(releaseBody.released, true);

  const statusAfter = await fetch(`${nexusUrl}/v2/warden/status`);
  const statusAfterBody = (await statusAfter.json()) as { isolatedAgents: number };
  assert.equal(statusAfterBody.isolatedAgents, 0);
});

test('POST /v2/warden/agents/:id/isolate with a missing reason is a validation error', async () => {
  const res = await fetch(`${nexusUrl}/v2/warden/agents/financial/isolate`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
  assert.equal(res.status, 400);
});

test('POST /v2/warden/agents/:id/isolate for an unknown agent id is a real 404', async () => {
  const res = await fetch(`${nexusUrl}/v2/warden/agents/not_real/isolate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ reason: 'x' }),
  });
  assert.equal(res.status, 404);
});
