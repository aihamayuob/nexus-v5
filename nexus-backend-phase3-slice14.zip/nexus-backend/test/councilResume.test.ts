import '../test/helpers/setMissionTestEnv.js';
import { test, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { createServer, type Server } from 'node:http';
import { openTestDb } from '../src/persistence/db.js';
import { buildRepos, resetReposSingletonForTests, getRepos } from '../src/persistence/repos.js';
import { getCouncilSession, resumeInterruptedCouncilSessions } from '../src/council/councilRunner.js';

function freshDb() {
  resetReposSingletonForTests(buildRepos(openTestDb()));
}

let server: Server;
let serverUrl: string;
let callCount = 0;

function anthropicTextResponse(text: string) {
  return JSON.stringify({ content: [{ type: 'text', text }], stop_reason: 'end_turn', usage: { input_tokens: 10, output_tokens: 10 } });
}

before(async () => {
  server = createServer(async (req, res) => {
    callCount++;
    const chunks: Buffer[] = [];
    for await (const c of req) chunks.push(c as Buffer);
    let body: { system?: string; messages?: Array<{ content?: string }> } = {};
    try {
      body = JSON.parse(Buffer.concat(chunks).toString('utf-8') || '{}');
    } catch {
      /* ignore */
    }
    const system = body.system ?? '';
    const userMsg = body.messages?.[0]?.content ?? '';
    if (system.includes('مراجع مستقل صارم')) {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(anthropicTextResponse(JSON.stringify({ verdict: 'ok', issues: [] })));
      return;
    }
    if (userMsg.includes('هاجم الاقتراح')) {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(anthropicTextResponse('نقد حقيقي بعد الاستئناف.'));
      return;
    }
    if (userMsg.includes('رد على نقد زميلك')) {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(anthropicTextResponse('رد حقيقي بعد الاستئناف.'));
      return;
    }
    if (userMsg.includes('اصغ الحل النهائي')) {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(anthropicTextResponse('التركيب النهائي بعد الاستئناف.'));
      return;
    }
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(anthropicTextResponse('اقتراح حقيقي.'));
  });
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', () => resolve()));
  const addr = server.address();
  serverUrl = `http://127.0.0.1:${typeof addr === 'object' && addr ? addr.port : 0}`;
  process.env.NEXUS_ANTHROPIC_BASE_URL = serverUrl;
  process.env.NEXUS_ANTHROPIC_API_KEY = 'fake-anthropic-key';
});

after(async () => {
  await new Promise((r) => server.close(r));
});

beforeEach(() => {
  freshDb();
  callCount = 0;
});

async function waitForTerminal(sessionId: string, timeoutMs = 5000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const s = getCouncilSession(sessionId);
    if (s && (s.state === 'COMPLETED' || s.state === 'FAILED' || s.state === 'CANCELLED')) return s;
    await new Promise((r) => setTimeout(r, 30));
  }
  throw new Error('timed out waiting for terminal state');
}

test('resumeInterruptedCouncilSessions genuinely continues a cross_exam session from a real persisted partial round history — the pre-existing proposal is reused verbatim, not regenerated', async () => {
  const repos = getRepos();
  // Deterministic simulation of "process crashed right after the
  // proposal round completed": create the session row + ONE real
  // proposal round directly via the exact same repo calls
  // executeCrossExam() itself makes, and leave state as RUNNING —
  // exactly what a real unclean shutdown would leave behind.
  const session = repos.council.create({
    id: 'council_test_resume_1',
    mode: 'cross_exam',
    topic: 'موضوع للاستئناف الحقيقي',
    proposerAgentId: 'financial',
    criticAgentId: 'legal',
    supervisorAgentId: 'supervisor',
  });
  repos.council.appendRound(session.id, 'proposal', 'financial', 'اقتراح محفوظ مسبقاً قبل الانقطاع', 'anthropic', 'claude-x');
  assert.equal(getCouncilSession(session.id)!.state, 'RUNNING');

  const { resumed, failed } = await resumeInterruptedCouncilSessions();
  assert.deepEqual(failed, []);
  assert.ok(resumed.includes(session.id));

  const finalSession = await waitForTerminal(session.id);
  assert.equal(finalSession.state, 'COMPLETED');

  const rounds = repos.council.rounds(session.id);
  assert.equal(rounds.length, 5, 'exactly 5 rounds total — the pre-existing proposal plus 4 newly generated, no duplicate proposal');
  assert.equal(rounds.filter((r) => r.kind === 'proposal').length, 1);
  assert.equal(
    rounds.find((r) => r.kind === 'proposal')!.content,
    'اقتراح محفوظ مسبقاً قبل الانقطاع',
    'the pre-existing proposal content must be reused verbatim, not regenerated'
  );
  assert.ok(rounds.some((r) => r.kind === 'critique' && r.content.includes('بعد الاستئناف')));
  assert.ok(rounds.some((r) => r.kind === 'rebuttal' && r.content.includes('بعد الاستئناف')));
  assert.ok(rounds.some((r) => r.kind === 'synthesis' && r.content.includes('بعد الاستئناف')));
});

test('resumeInterruptedCouncilSessions makes ZERO new agent calls when every round was already persisted before the crash — only re-verifies and finalizes completion', async () => {
  const repos = getRepos();
  const session = repos.council.create({
    id: 'council_test_resume_2',
    mode: 'cross_exam',
    topic: 'موضوع اكتمل قبل الانقطاع',
    proposerAgentId: 'financial',
    criticAgentId: 'legal',
    supervisorAgentId: 'supervisor',
  });
  repos.council.appendRound(session.id, 'proposal', 'financial', 'اقتراح كامل', 'anthropic', 'claude-x');
  repos.council.appendRound(session.id, 'critique', 'legal', 'نقد كامل', 'anthropic', 'claude-x');
  repos.council.appendRound(session.id, 'rebuttal', 'financial', 'رد كامل', 'anthropic', 'claude-x');
  repos.council.appendRound(session.id, 'synthesis', 'supervisor', 'التركيب الكامل المحفوظ مسبقاً', 'anthropic', 'claude-x');

  callCount = 0;
  const { resumed } = await resumeInterruptedCouncilSessions();
  assert.ok(resumed.includes(session.id));
  const finalSession = await waitForTerminal(session.id);
  assert.equal(finalSession.state, 'COMPLETED');
  assert.equal(finalSession.finalOutput, 'التركيب الكامل المحفوظ مسبقاً', 'the pre-existing synthesis must be used verbatim as the final output');
  assert.equal(callCount, 1, 'only the always-rerun verification call should hit the provider — zero agent rounds re-generated');
});

test('resumeInterruptedCouncilSessions marks a stuck situation_room session FAILED with a clear, honest reason — NOT silently resumed, NOT left stuck forever', async () => {
  const repos = getRepos();
  const session = repos.council.create({
    id: 'council_test_resume_3',
    mode: 'situation_room',
    topic: 'غرفة عمليات انقطعت',
    participantAgentIds: ['financial', 'legal'],
    supervisorAgentId: 'supervisor',
  });
  repos.council.appendRound(session.id, 'round1_opinion', 'financial', 'رأي جزئي قبل الانقطاع', null, null);
  assert.equal(getCouncilSession(session.id)!.state, 'RUNNING');

  const { resumed, failed } = await resumeInterruptedCouncilSessions();
  assert.deepEqual(resumed, []);
  assert.ok(failed.includes(session.id));

  const finalSession = getCouncilSession(session.id)!;
  assert.equal(finalSession.state, 'FAILED');
  assert.match(finalSession.errorMessage ?? '', /استئناف situation_room/);
});

test('resumeInterruptedCouncilSessions does not touch sessions already in a terminal state', async () => {
  const repos = getRepos();
  const session = repos.council.create({
    id: 'council_test_resume_4',
    mode: 'cross_exam',
    topic: 'مكتملة مسبقاً',
    proposerAgentId: 'financial',
    criticAgentId: 'legal',
    supervisorAgentId: 'supervisor',
  });
  repos.council.complete(session.id, 'ناتج نهائي قديم', 'ok', 0);
  assert.equal(getCouncilSession(session.id)!.state, 'COMPLETED');

  const { resumed, failed } = await resumeInterruptedCouncilSessions();
  assert.ok(!resumed.includes(session.id));
  assert.ok(!failed.includes(session.id));
  assert.equal(getCouncilSession(session.id)!.finalOutput, 'ناتج نهائي قديم', 'an already-terminal session must be completely untouched');
});
