import '../test/helpers/setMissionTestEnv.js';
import { test, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { createServer, type Server } from 'node:http';
import { openTestDb } from '../src/persistence/db.js';
import { buildRepos, resetReposSingletonForTests, getRepos } from '../src/persistence/repos.js';
import { createMission, runMission, resumeInterruptedMissions } from '../src/orchestrator/missionRunner.js';
import { runAgentTask } from '../src/agents/agentRunner.js';
import { Warden } from '../src/warden/warden.js';
import type { GatewayContext } from '../src/capability/permissionModel.js';

const ctx: GatewayContext = { authenticated: true, clientKey: 'test', projectId: null, userId: null };

function freshDb() {
  resetReposSingletonForTests(buildRepos(openTestDb()));
}

let server: Server;
let serverUrl: string;
let behavior: { hangForever: boolean };

function resetBehavior() {
  behavior = { hangForever: false };
}

function anthropicTextResponse(text: string) {
  return JSON.stringify({ content: [{ type: 'text', text }], stop_reason: 'end_turn', usage: { input_tokens: 10, output_tokens: 10 } });
}

function writeSse(res: import('node:http').ServerResponse, text: string) {
  res.writeHead(200, { 'Content-Type': 'text/event-stream' });
  const frame = (event: string, data: unknown) => res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
  frame('message_start', { type: 'message_start', message: { usage: { input_tokens: 10 } } });
  frame('content_block_start', { type: 'content_block_start', index: 0, content_block: { type: 'text' } });
  frame('content_block_delta', { type: 'content_block_delta', index: 0, delta: { type: 'text_delta', text } });
  frame('message_delta', { type: 'message_delta', delta: { stop_reason: 'end_turn' }, usage: { output_tokens: 10 } });
  frame('message_stop', { type: 'message_stop' });
  res.end();
}

before(async () => {
  server = createServer(async (req, res) => {
    if (req.method === 'GET') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ data: [] }));
      return;
    }
    if (behavior.hangForever) return;
    const chunks: Buffer[] = [];
    for await (const c of req) chunks.push(c as Buffer);
    let body: { system?: string; stream?: boolean } = {};
    try {
      body = JSON.parse(Buffer.concat(chunks).toString('utf-8') || '{}');
    } catch {
      /* ignore */
    }
    if ((body.system ?? '').includes('أنت مخطط مهام')) {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(anthropicTextResponse(JSON.stringify({ tasks: [{ id: 'only_task', description: 'أنجز المهمة', dependsOn: [] }] })));
      return;
    }
    if (body.stream) {
      writeSse(res, 'ناتج نهائي.');
      return;
    }
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(anthropicTextResponse('ناتج نهائي.'));
  });
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', () => resolve()));
  const addr = server.address();
  serverUrl = `http://127.0.0.1:${typeof addr === 'object' && addr ? addr.port : 0}`;
  process.env.NEXUS_ANTHROPIC_BASE_URL = serverUrl;
  process.env.NEXUS_ANTHROPIC_API_KEY = 'fake-anthropic-key';
});

after(async () => {
  server.closeAllConnections();
  await new Promise((r) => server.close(r));
});

beforeEach(() => {
  freshDb();
  resetBehavior();
});

// ---- PAUSE / RESUME ----

test('Warden.pauseMission actually aborts an in-flight mission and transitions it to PAUSED, not CANCELLED', async () => {
  behavior.hangForever = true;
  const { missionId } = createMission('مهمة سنوقفها مؤقتاً', ctx);
  const runPromise = runMission(missionId, ctx);
  await new Promise((r) => setTimeout(r, 150));

  const { paused } = Warden.pauseMission(missionId, 'اختبار الإيقاف المؤقت');
  assert.equal(paused, true);
  await runPromise;

  const mission = getRepos().missions.get(missionId)!;
  assert.equal(mission.state, 'PAUSED');

  const events = getRepos().audit.listSecurity(20);
  assert.ok(events.some((e) => e.message.includes('Warden: mission paused')));
});

test('Warden.pauseMission on a mission not in a pausable state is a real validation error', async () => {
  const { missionId } = createMission('مهمة ستكتمل فوراً', ctx);
  await runMission(missionId, ctx);
  assert.equal(getRepos().missions.get(missionId)!.state, 'COMPLETED');
  assert.throws(() => Warden.pauseMission(missionId, 'x'), /لا يمكن إيقاف مهمة/);
});

test('Warden.pauseMission on an unknown mission is a real not_found', () => {
  assert.throws(() => Warden.pauseMission('does-not-exist', 'x'), /Mission غير موجودة/);
});

test('Warden.resumeMission actually re-executes a PAUSED mission through to a real COMPLETED state', async () => {
  behavior.hangForever = true;
  const { missionId } = createMission('مهمة سنستأنفها', ctx);
  const runPromise = runMission(missionId, ctx);
  await new Promise((r) => setTimeout(r, 150));
  Warden.pauseMission(missionId, 'إيقاف قبل الاستئناف');
  await runPromise;
  assert.equal(getRepos().missions.get(missionId)!.state, 'PAUSED');

  behavior.hangForever = false;
  const { resumed } = await Warden.resumeMission(missionId, ctx, 'استئناف حقيقي');
  assert.equal(resumed, true);
  await new Promise((r) => setTimeout(r, 300));

  const mission = getRepos().missions.get(missionId)!;
  assert.equal(mission.state, 'COMPLETED', 'a resumed mission should genuinely re-plan and re-execute to completion');
});

test('Warden.resumeMission on a mission that is NOT PAUSED is a real validation error', async () => {
  const { missionId } = createMission('مهمة ستكتمل', ctx);
  await runMission(missionId, ctx);
  await assert.rejects(() => Warden.resumeMission(missionId, ctx, 'x'), /يجب أن تكون متوقفة مؤقتاً/);
});

test('Warden.resumeMission on an unknown mission is a real not_found', async () => {
  await assert.rejects(() => Warden.resumeMission('does-not-exist', ctx, 'x'), /Mission غير موجودة/);
});

test('a deliberately PAUSED mission is NEVER auto-resumed by resumeInterruptedMissions() — the exact bug this slice fixes', async () => {
  behavior.hangForever = true;
  const { missionId } = createMission('مهمة متوقفة عمداً قبل إعادة تشغيل الخادم', ctx);
  const runPromise = runMission(missionId, ctx);
  await new Promise((r) => setTimeout(r, 150));
  Warden.pauseMission(missionId, 'إيقاف متعمد قبل محاكاة إعادة تشغيل');
  await runPromise;
  assert.equal(getRepos().missions.get(missionId)!.state, 'PAUSED');

  await resumeInterruptedMissions();
  await new Promise((r) => setTimeout(r, 100));

  const mission = getRepos().missions.get(missionId)!;
  assert.equal(mission.state, 'PAUSED', 'a deliberate pause must survive an automatic crash-recovery sweep untouched');
});

// ---- ISOLATE / RELEASE ----

test('Warden.isolateAgent actually prevents runAgentTask from executing that agent at all — real enforcement, not a status flag', async () => {
  Warden.isolateAgent('financial', 'سلوك مشبوه أثناء الاختبار', 'test_operator');
  await assert.rejects(
    () => runAgentTask('financial', { agentId: 'financial', missionId: null, taskNodeId: null, taskDescription: 'x', upstreamOutputs: {}, gwCtx: ctx }),
    /معزول حالياً/
  );
});

test('isolation is scoped to ONE agent — an unrelated agent is completely unaffected', async () => {
  Warden.isolateAgent('financial', 'عزل تجريبي', null);
  const result = await runAgentTask('legal', { agentId: 'legal', missionId: null, taskNodeId: null, taskDescription: 'x', upstreamOutputs: {}, gwCtx: ctx });
  assert.ok(result.output.length > 0);
});

test('Warden.releaseAgent actually lifts the isolation, and the agent can run again', async () => {
  Warden.isolateAgent('financial', 'عزل مؤقت', null);
  const { released } = Warden.releaseAgent('financial', 'تم التحقق، لا خطر فعلي');
  assert.equal(released, true);
  const result = await runAgentTask('financial', {
    agentId: 'financial',
    missionId: null,
    taskNodeId: null,
    taskDescription: 'x',
    upstreamOutputs: {},
    gwCtx: ctx,
  });
  assert.ok(result.output.length > 0);
});

test('Warden.isolateAgent on an unknown agent id is a real not_found', () => {
  assert.throws(() => Warden.isolateAgent('not_a_real_agent', 'x', null), /وكيل غير معروف/);
});

test('Warden.releaseAgent on an agent that was never isolated returns released:false, not an error', () => {
  const { released } = Warden.releaseAgent('legal', 'لم يكن معزولاً أصلاً');
  assert.equal(released, false);
});

test('Warden.status() reflects a real isolatedAgents count', () => {
  assert.equal(Warden.status().isolatedAgents, 0);
  Warden.isolateAgent('financial', 'x', null);
  Warden.isolateAgent('legal', 'y', null);
  assert.equal(Warden.status().isolatedAgents, 2);
});

test('isolating the same agent twice is idempotent (updates reason, no duplicate row, no error)', () => {
  Warden.isolateAgent('financial', 'سبب أول', null);
  Warden.isolateAgent('financial', 'سبب محدَّث', null);
  const list = Warden.listIsolatedAgents();
  assert.equal(list.filter((r) => r.agentId === 'financial').length, 1);
  assert.equal(list.find((r) => r.agentId === 'financial')!.reason, 'سبب محدَّث');
});
