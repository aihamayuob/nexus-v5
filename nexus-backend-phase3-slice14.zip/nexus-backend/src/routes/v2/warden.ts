import type { Router, RouteContext } from '../../gateway/router.js';
import { readJsonBody } from '../../gateway/middleware/bodyLimit.js';
import { Warden } from '../../warden/warden.js';
import { Errors } from '../../core/errors.js';

export function registerWardenRoutes(router: Router) {
  /** Single operational snapshot: budget + active mission/council/approval/isolated-agent counts. Read-only — Warden's mutating actions live on their own resource routes (POST /v2/missions/:id/{cancel,pause,resume}, POST /v2/council/:id/cancel, and the agent-isolation routes below), all routed through Warden so every action is audited. */
  router.get('/v2/warden/status', async (ctx: RouteContext) => {
    ctx.res.writeHead(200, { 'Content-Type': 'application/json' });
    ctx.res.end(JSON.stringify(Warden.status()));
  });

  router.get('/v2/warden/agents/isolated', async (ctx: RouteContext) => {
    ctx.res.writeHead(200, { 'Content-Type': 'application/json' });
    ctx.res.end(JSON.stringify({ agents: Warden.listIsolatedAgents() }));
  });

  /** Phase 3 §Warden (ISOLATE) — real enforcement begins the instant this returns; see agentRunner.ts's runAgentTask() for the check. */
  router.post('/v2/warden/agents/:id/isolate', async (ctx: RouteContext) => {
    const body = await readJsonBody<{ reason?: string; isolatedBy?: string }>(ctx.req);
    if (!body.reason || !body.reason.trim()) throw Errors.validation('الحقل "reason" مطلوب.');
    const row = Warden.isolateAgent(ctx.params.id!, body.reason, body.isolatedBy ?? null);
    ctx.res.writeHead(200, { 'Content-Type': 'application/json' });
    ctx.res.end(JSON.stringify(row));
  });

  router.post('/v2/warden/agents/:id/release', async (ctx: RouteContext) => {
    const body = await readJsonBody<{ reason?: string }>(ctx.req).catch(() => ({}) as { reason?: string });
    const result = Warden.releaseAgent(ctx.params.id!, body.reason ?? 'requested via API');
    ctx.res.writeHead(200, { 'Content-Type': 'application/json' });
    ctx.res.end(JSON.stringify(result));
  });
}
