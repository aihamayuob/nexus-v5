import type { DatabaseSync } from 'node:sqlite';

export interface IsolatedAgentRow {
  agentId: string;
  reason: string;
  isolatedAt: number;
  isolatedBy: string | null;
}

export class AgentIsolationRepo {
  constructor(private db: DatabaseSync) {}

  isolate(agentId: string, reason: string, isolatedBy: string | null): IsolatedAgentRow {
    const isolatedAt = Date.now();
    this.db
      .prepare(
        `INSERT INTO isolated_agents (agent_id, reason, isolated_at, isolated_by) VALUES (?, ?, ?, ?)
         ON CONFLICT(agent_id) DO UPDATE SET reason = excluded.reason, isolated_at = excluded.isolated_at, isolated_by = excluded.isolated_by`
      )
      .run(agentId, reason, isolatedAt, isolatedBy);
    return { agentId, reason, isolatedAt, isolatedBy };
  }

  release(agentId: string): boolean {
    const result = this.db.prepare('DELETE FROM isolated_agents WHERE agent_id = ?').run(agentId);
    return result.changes > 0;
  }

  get(agentId: string): IsolatedAgentRow | null {
    const row = this.db.prepare('SELECT * FROM isolated_agents WHERE agent_id = ?').get(agentId) as Record<string, unknown> | undefined;
    if (!row) return null;
    return {
      agentId: row.agent_id as string,
      reason: row.reason as string,
      isolatedAt: row.isolated_at as number,
      isolatedBy: (row.isolated_by as string) ?? null,
    };
  }

  isIsolated(agentId: string): boolean {
    return this.get(agentId) !== null;
  }

  listAll(): IsolatedAgentRow[] {
    const rows = this.db.prepare('SELECT * FROM isolated_agents ORDER BY isolated_at DESC').all() as Record<string, unknown>[];
    return rows.map((row) => ({
      agentId: row.agent_id as string,
      reason: row.reason as string,
      isolatedAt: row.isolated_at as number,
      isolatedBy: (row.isolated_by as string) ?? null,
    }));
  }
}
