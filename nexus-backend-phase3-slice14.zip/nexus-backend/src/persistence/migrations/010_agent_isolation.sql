CREATE TABLE IF NOT EXISTS isolated_agents (
  agent_id TEXT PRIMARY KEY,
  reason TEXT NOT NULL,
  isolated_at INTEGER NOT NULL,
  isolated_by TEXT
);
