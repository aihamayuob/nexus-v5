import { getDb } from './persistence/db.js';
import { bootstrapTools } from './tools/bootstrap.js';
import { resumeInterruptedPlans } from './orchestrator/taskManager.js';
import { resumeInterruptedMissions } from './orchestrator/missionRunner.js';
import { resumeInterruptedCouncilSessions } from './council/councilRunner.js';
import { startServer } from './gateway/server.js';
import { startRetentionSweeper, runRetentionSweep } from './observability/retention.js';
import { startSchedulerLoop } from './scheduler/schedulerRunner.js';
import { logger } from './core/logger.js';

async function main() {
  getDb(); // runs migrations
  bootstrapTools();
  const server = startServer();

  // Real durable-execution resume — not just detecting that something was
  // interrupted, but actually picking plans back up from their last
  // completed DAG node. Runs after the server starts listening so health
  // checks succeed immediately even while resume work is still catching up.
  resumeInterruptedPlans().catch((e) => logger.error('resumeInterruptedPlans failed at startup', { message: (e as Error).message }));
  resumeInterruptedMissions().catch((e) => logger.error('resumeInterruptedMissions failed at startup', { message: (e as Error).message }));
  resumeInterruptedCouncilSessions().catch((e) => logger.error('resumeInterruptedCouncilSessions failed at startup', { message: (e as Error).message }));

  // Bounds unlimited growth of operational tables over a long-running
  // process (see observability/retention.ts) — one sweep at startup, then
  // hourly.
  runRetentionSweep();
  const retentionTimer = startRetentionSweeper();

  // Real execution loop for /api/schedules (previously CRUD-only — see
  // scheduler/schedulerRunner.ts's file doc comment) + a periodic,
  // zero-LLM-cost Meta-Cognition repeated-failure-pattern sweep sharing
  // the same tick.
  const schedulerTimer = startSchedulerLoop();

  const shutdown = (signal: string) => {
    logger.info('Shutting down', { signal });
    clearInterval(retentionTimer);
    clearInterval(schedulerTimer);
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(1), 5000).unref();
  };
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

main().catch((e) => {
  logger.error('Fatal startup error', { message: (e as Error).message, stack: (e as Error).stack });
  process.exit(1);
});
