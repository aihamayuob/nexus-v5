import { getRepos } from '../persistence/repos.js';
import { cancelTask } from '../orchestrator/taskManager.js';
import { cancelCouncilSession, getCouncilSession } from '../council/councilRunner.js';
import { runMission } from '../orchestrator/missionRunner.js';
import { AgentRegistry } from '../agents/agentRegistry.js';
import { BudgetGuard } from '../orchestrator/budget.js';
import { auditSecurityEvent } from '../security/audit.js';
import { Errors } from '../core/errors.js';
import type { GatewayContext } from '../capability/permissionModel.js';
import type { IsolatedAgentRow } from '../persistence/repositories/agentIsolationRepo.js';

/** States from which a mission can genuinely be paused — mirrors the terminal-state guard everywhere else in this codebase (can't pause something that's already finished, and can't pause something already paused). */
const PAUSABLE_MISSION_STATES = new Set(['PLANNING', 'RUNNING', 'REPLANNING', 'AWAITING_APPROVAL']);

/**
 * Warden — the single control surface for pausing/cancelling running work,
 * isolating misbehaving agents, and observing system-wide operational
 * state (Phase 3 §Warden).
 *
 * IMPORTANT, VERIFIED DESIGN FACT (documented here rather than papered
 * over): every route in this backend — including every Warden route added
 * in this slice — already passes through `authenticate()`
 * (gateway/middleware/auth.ts) BEFORE the route handler runs at all. That
 * middleware either returns `{authenticated: true, ...}` or throws
 * Errors.auth() (401); it can never hand a route an unauthenticated
 * GatewayContext. This means:
 *   (a) There is no separate "elevated" Warden bypass path — Warden
 *       actions are bound by the exact same gateway key requirement as
 *       every other endpoint, which is precisely what "Warden لا يستطيع
 *       تجاوز... security boundary" requires structurally.
 *   (b) Re-checking `ctx.authenticated === true` inside Warden functions
 *       would be dead code that can never be false by the time it runs —
 *       adding it would be security theater, not a real control. It is
 *       deliberately NOT added here for that reason; this comment (and
 *       PHASE3_SLICE2_REPORT.md) is the honest record of that decision.
 *
 * PAUSE/RESUME (this slice) is built entirely on top of ALREADY-PROVEN
 * mechanisms, not new interruption machinery inside dag.ts:
 *   - pauseMission() transitions the mission to PAUSED (a new, explicitly
 *     non-terminal MissionState) BEFORE calling the exact same
 *     cancelTask() every cancel path already uses — missionRunner.ts's
 *     abort catch-block checks for this and does NOT overwrite PAUSED
 *     back to CANCELLED.
 *   - resumeMission() re-invokes runMission() — the SAME restart path
 *     resumeInterruptedMissions() already uses after an unclean shutdown
 *     (a fresh plan + fresh execute, using whatever checkpoint exists;
 *     NOT true mid-DAG-node resumption, which this codebase has never
 *     implemented for missions at any point). A deliberately PAUSED
 *     mission is explicitly EXCLUDED from the automatic crash-recovery
 *     sweep (see missionRepo.ts's interruptedMissionIds()) — resuming it
 *     is always a human decision via this function, never automatic.
 *
 * ISOLATE (this slice) gives real teeth, not just a status flag:
 *   agentRunner.ts's runAgentTask() checks Warden.isAgentIsolated() as
 *   its very first step, before selecting a provider or spending any
 *   budget — an isolated agent cannot run ANY task, in Mission, Council,
 *   or Swarm context, since all three funnel through runAgentTask().
 */
export const Warden = {
  cancelMission(missionId: string, reason: string): { cancelled: boolean } {
    const mission = getRepos().missions.get(missionId);
    if (!mission) throw Errors.notFound('Mission غير موجودة.');
    const cancelled = cancelTask(missionId);
    auditSecurityEvent('info', 'Warden: mission cancellation requested', { missionId, reason, cancelled, priorState: mission.state });
    return { cancelled };
  },

  cancelCouncilSession(sessionId: string, reason: string): { cancelled: boolean } {
    const session = getCouncilSession(sessionId);
    if (!session) throw Errors.notFound('جلسة المجلس غير موجودة.');
    const cancelled = cancelCouncilSession(sessionId);
    auditSecurityEvent('info', 'Warden: council session cancellation requested', { sessionId, reason, cancelled, priorState: session.state });
    return { cancelled };
  },

  /** Aborts in-flight execution and marks the mission PAUSED (not CANCELLED, not FAILED) — a deliberate, resumable stop. */
  pauseMission(missionId: string, reason: string): { paused: boolean } {
    const repos = getRepos();
    const mission = repos.missions.get(missionId);
    if (!mission) throw Errors.notFound('Mission غير موجودة.');
    if (!PAUSABLE_MISSION_STATES.has(mission.state)) {
      throw Errors.validation(`لا يمكن إيقاف مهمة في حالة "${mission.state}" مؤقتاً — يجب أن تكون قيد التنفيذ فعلياً.`);
    }
    // Transition BEFORE aborting — missionRunner.ts's catch block checks
    // this to decide PAUSED-vs-CANCELLED when the abort is actually caught.
    repos.missions.transition(missionId, 'PAUSED', reason);
    const cancelled = cancelTask(missionId);
    auditSecurityEvent('info', 'Warden: mission paused', { missionId, reason, priorState: mission.state, hadActiveExecution: cancelled });
    return { paused: true };
  },

  /** Re-invokes runMission() — a real restart from the last checkpoint, the SAME path crash-recovery already uses, now triggered by explicit human decision instead of a server restart. */
  async resumeMission(missionId: string, ctx: GatewayContext, reason: string): Promise<{ resumed: boolean }> {
    const repos = getRepos();
    const mission = repos.missions.get(missionId);
    if (!mission) throw Errors.notFound('Mission غير موجودة.');
    if (mission.state !== 'PAUSED') {
      throw Errors.validation(`لا يمكن استئناف مهمة في حالة "${mission.state}" — يجب أن تكون متوقفة مؤقتاً (PAUSED) فعلياً.`);
    }
    auditSecurityEvent('info', 'Warden: mission resume requested', { missionId, reason });
    void runMission(missionId, ctx).catch((e) => auditSecurityEvent('warn', 'Warden: resumed mission failed', { missionId, message: (e as Error).message }));
    return { resumed: true };
  },

  /** Real enforcement, not a status flag — see runAgentTask()'s first real check against this. */
  isolateAgent(agentId: string, reason: string, isolatedBy: string | null = null): IsolatedAgentRow {
    if (!AgentRegistry.has(agentId)) throw Errors.notFound(`وكيل غير معروف: ${agentId}`);
    const row = getRepos().agentIsolation.isolate(agentId, reason, isolatedBy);
    auditSecurityEvent('warn', 'Warden: agent isolated', { agentId, reason, isolatedBy });
    return row;
  },

  releaseAgent(agentId: string, reason: string): { released: boolean } {
    const released = getRepos().agentIsolation.release(agentId);
    auditSecurityEvent('info', 'Warden: agent released from isolation', { agentId, reason, wasIsolated: released });
    return { released };
  },

  isAgentIsolated(agentId: string): boolean {
    return getRepos().agentIsolation.isIsolated(agentId);
  },

  listIsolatedAgents(): IsolatedAgentRow[] {
    return getRepos().agentIsolation.listAll();
  },

  status() {
    const repos = getRepos();
    return {
      budget: BudgetGuard.status(),
      activeMissions: repos.missions.resumableMissionIds().length,
      activeCouncilSessions: repos.council.activeCount(),
      pendingApprovals: repos.approvals.pending(200).length,
      isolatedAgents: repos.agentIsolation.listAll().length,
    };
  },
};
