# TEST-EVIDENCE-INDEX — ADDENDUM (PROPOSED) — second-session read-only checks, 2026-10-17

يُلحق بعد القسم G من `TEST-EVIDENCE-INDEX.md` (الذي يقع داخل حزمة التسليم، ولم يُعدَّل). لا يضم إلا ادعاءات لكل منها قسم محدد في `evidence/readonly-checks.log` (سكربت `evidence/run-readonly-checks.sh`). **لا شيء هنا إعادة تشغيل لاختبارات NEXUS**؛ هي قراءة ملفات وعدّ وحساب بصمات. بيئة التنفيذ: النسخة المستعادة من الحزمة (ليست المستودع الحي).

## H. فحوص الاستعادة والمطابقة (قراءة فقط)
| # | الادعاء | النتيجة المقروءة | القسم في السجل | الحالة |
|---|---|---|---|---|
| H1 | بصمات الحزمة المرفوعة | ZIP `c7f40b58…8cbf`؛ التقرير `be555608…58fbb0`؛ التقرير داخل الـZIP مطابق بايتًا | C01، C02 | VERIFIED (فحص بصمات) |
| H2 | سلامة محتويات الـZIP | `sha256sum -c`: 944 OK، 0 غير ذلك | C02 | VERIFIED |
| H3 | الـbundle يستعيد التاريخ | `git bundle verify` سليم؛ فرع `v5.0-polish`، HEAD `cbdc898a…`، 23 commit، 854 ملفًا متتبعًا، 0 ملفات متتبعة معدّلة، 7 غير متتبعة (`eval/arabic-v1/*`) | C03 | VERIFIED على النسخة المستعادة؛ حالة المستودع الحي UNVERIFIED |
| H4 | سلامة ملفات B6 | `sha256sum -c` للملفات الستة المدرجة: OK | C04 | VERIFIED |
| H5 | بيانات B6 | 38 عنصرًا، 7 فئات (8/6/6/6/4/4/4) مقابل «8 categories» في `criteria.frozen.md` | C04 | VERIFIED (العدّ)؛ انظر errata B6 |
| H6 | غياب سجلات `release-v1-b6-*.log` | لا ملف بهذا الاسم في المستودع المستعاد ولا في `evidence-external/logs`؛ الوحيد المتعلق بـB6: `b6-self-test-rerun-at-packaging.log` | C05 | VERIFIED (غياب ضمن الحزمة المستعادة) |
| H7 | الاعتماديات | `tsx` في سكربتي `test`/`dev`، غير موجود في `package.json` ولا في lockfile الخلفية (0 مطابقات)؛ `typescript: "*"`؛ لا `e2e/package-lock.json` | C06 | VERIFIED (قراءة ملفات)؛ أثره على `npm test` UNVERIFIED |
| H8 | الترخيص | لا `LICENSE` في الجذر؛ `package.json` الواجهة والخلفية `private:true` بلا حقل ترخيص | C06 | VERIFIED (قراءة ملفات)؛ دلالته القانونية غير مقيَّمة |
| H9 | تراخيص lockfiles (تصريحات الحزم) | الواجهة: 126 مدخلًا كلها `dev` (MIT 95، MIT-0 2، Apache-2.0 4، BSD-2 2، BSD-3 5، MPL-2.0 12 = حزم `lightningcss*`، BlueOak-1.0.0 1، CC0-1.0 1، ISC 4)؛ الخلفية: 23 مدخلًا (Apache-2.0 21، MIT 2) | C07 | VERIFIED كقراءة؛ ليست مراجعة قانونية؛ cdnjs غير مشمول |
| H10 | أرقام الانحدار والأدوات المقروءة من السجلات | تتطابق مع القسمين A وD من هذا الفهرس (14 × exit=0؛ extract-verify 11/17 وعند `711f353` 14/17) | C08، C09 | سجلات تاريخية أُعيدت قراءتها، لم تُعَد |
| H11 | مسارات `frontend/` التي غيّرها كل commit | `711f353`: `sw.js` (جديد) فقط؛ `cbdc898`: `main.js`، `modules/settings.mjs`، `modules/settings.test.mjs`، المونوليث، + `modules/gatewayKey.test.mjs` (جديد) | C10 | VERIFIED (حقيقة)؛ يدعم الاستنتاج في القسم D لكنه لا يحوّله إلى تشخيص |
| H12 | محتوى `sw.js` | `SHELL` = `main.js` + 5 وحدات تشمل `state.mjs`؛ سجلات B1: PRE REJECTED PS 2/11، POST وafter-b4 ACCEPTED PS 11/11، ضابط V4a موجود | C11 | VERIFIED كقراءة؛ نتائج B1 سجلات تاريخية |
| H13 | غياب أي أثر لـB2/B3/B5 | لا ملف `release-v1-b[235]*` في `baseline/evidence`؛ لا commit يذكرها | C13 | VERIFIED (غياب ضمن الحزمة المستعادة) |
| H14 | E-1 | CP-14 §E-1 يوثّق سببًا مقيسًا (700/20000، 691/20000)؛ ملف المسبار وسجله موجودان | C14 | VERIFIED (التوثيق موجود)؛ القياس لم يُعَد |

## تصحيح مقترح على نص الفهرس/التقرير (دون حذف الأصل)
- التقرير §8 بند 8 («سببه لم يُشخَّص» لـE-1): يُقرأ مع CP-14 §E-1 الذي يسجّل تشخيصًا مقيسًا. لا يُحذف نص التقرير؛ يُعلَّم أنه تجاوزه CP-14.
