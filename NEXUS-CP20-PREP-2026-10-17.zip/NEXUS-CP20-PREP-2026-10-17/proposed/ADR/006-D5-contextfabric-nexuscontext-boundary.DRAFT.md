# ADR 006 — Owner decision D5: `ContextFabric` / `NexusContext` boundary (DRAFT — not accepted)

**Status**: **DRAFT, proposed for the owner's review.** It records a decision the owner already gave on 2026-10-14; it does not create or change a decision. The ADR number (006) is a suggestion: it is the next free number after ADR-005 in the restored repository.
**Date of the decision being recorded**: 2026-10-14 (owner decision "D5").
**Date of this draft**: 2026-10-17 (CP-20 preparation, from the restored handoff package; the live repository was not consulted).
**Scope**: documentation only. No production, test or frozen-criteria file is touched by this draft.

## 0) Provenance and honesty note (read first)

The **literal text of the original D5 options is not available** in the restored repository, in the project documents attached to the Claude project, or in the handoff package. The option letters (ج / أ / ب) are known only through (a) the owner's recorded decision summary kept in the project notes (dated 2026-10-14; a summary, not the verbatim message), and (b) the owner's restatement in the CP-20 preparation request of 2026-10-17. This draft therefore keeps two things apart:

- **Confirmed substance** — each item names where it is confirmed.
- **Proposed restatement** — wording written for this draft; it is NOT historical text and must not be cited as the owner's words.

Nothing here reconstructs the original option list. Whether the original list contained options beyond ج / أ / ب is UNKNOWN.

## 1) Confirmed substance

| # | Substance | Confirmed in |
|---|---|---|
| 1 | `ContextFabric` stays in its classic form (classic script). | `NEXUS-CURRENT-STATE.md` (core slice 11 entry); `docs/checkpoints/CP-19.md` header; owner's restatement 2026-10-17 |
| 2 | `NexusContext` is **not moved now**. | same sources |
| 3 | A characterization test covering context composition via `fullAgentPrompt` is a prerequisite for any later move. It was written and verified within its limits (CP-19, commit `80c558a`; mutation testing PARTIAL; MU05 INVALID by owner decision). | `CP-19.md` §1, §3 |
| 4 | Any later move is to be done by **explicit dependency injection**. | `NEXUS-CURRENT-STATE.md` (core slice 11 entry: "any later move only by explicit injection"); owner's restatement 2026-10-17 |
| 5 | The status "move of `NexusContext`/`ContextFabric`: not started" holds as of the handoff. | `CP-19.md` header; `PHASE2-MODULARIZE.md` and the project reference of 2026-10-15 are consistent |

## 2) Recorded only in the owner's decision note (not in repository documents)

- The letter mapping: ج = `ContextFabric` stays classic; أ = explicit dependency injection (the preferred direction for a later move); ب = access by bare name (forbidden).
- Execution of anything beyond the characterization test needs a **later explicit approval**; earlier items reserved for owner decisions (ADR-005 R5, `PERSISTABLE_STATE` and the 16 variables) must not be skipped.

Status of these two points: stated by the owner in a recorded note and repeated in the 2026-10-17 request; **not yet written into any repository document**. Writing them down is the purpose of this draft.

## 3) Proposed restatement (wording NOT historical; for the owner to confirm, correct or reject)

1. `ContextFabric` remains a classic-script object until its dependencies are settled within the proper architectural boundaries.
2. `NexusContext` is not moved in the current phase.
3. If a later slice moves either object, the dependencies must be passed in explicitly (dependency injection). Reaching them by bare global name from a module is not allowed.
4. Such a slice requires a separate explicit approval, frozen acceptance criteria written before any production edit, PRE/POST evidence and a full regression run, and must not bypass the open owner decisions D1–D4 / ADR-005 R5 on `PERSISTABLE_STATE` and the 16 variables.
5. The characterization test of CP-19 is the behavioural baseline for such a slice. It describes behaviour; it does not judge it correct (CP-19 §5).

## 4) Consequences and limits

- No code, ADR-003 Decision, ADR-005 Decision or evidence changes follow from this draft.
- The CP-19 baseline is VERIFIED only within its limits: Chromium 141 headless, a fake backend with two endpoints, no live LLM, no real fetch.
- ADR-003 (the 16 variables stay in the classic script) and ADR-005 (accessor mechanism for `agentOrder` only; no generalization without a decision) remain in force.

## 5) Owner actions requested

- Confirm, correct or reject §3.
- Supply the original D5 text if it exists somewhere outside the material reviewed.
- Decide whether this becomes ADR-006 or is folded into CP-20 only.
