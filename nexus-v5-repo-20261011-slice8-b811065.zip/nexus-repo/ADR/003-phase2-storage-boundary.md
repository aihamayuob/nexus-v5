# ADR 003 — Phase 2 Storage Boundary: Why PERSISTABLE_STATE Stays Behind

**Status**: Accepted
**Date**: 2026-09-17

## Context

The "storage" boundary's obvious candidate list (from PHASE2-MODULARIZE.md's
own roadmap) was `localStore`, `PERSISTABLE_STATE`, `ExecutionCheckpoint`,
`ImageStore`, `MessageArchive`. A dependency-graph script run before
touching anything showed a sharp split:

| Item | External dependencies found |
|---|---|
| `localStore` | none |
| `ExecutionCheckpoint` | `autoInitApp`, `showToast` (both remain global) |
| `ImageStore` | none (its only real dependency, `localStore`, is in-boundary) |
| `MessageArchive` | none |
| `PERSISTABLE_STATE` | 16 scattered top-level `let` bindings: `messages`, `customAgents`, `workflows`, `knowledgeBase`, `activeGroupId`, `agentOrder`, `selectedAgentIds`, `projects`, `decisionJournal`, `topicMonitors`, `longTermMemory`, `uploadedDocs`, `activityLog`, `errorLog`, `usageLog`, `briefingLastSeenAt` |

## Decision

Extract the four zero/external-only-dependency items into
`modules/storage.mjs` this round. Leave `PERSISTABLE_STATE` in the
monolith, undocumented as a "gap" but explicitly deferred with reasoning
recorded here.

## Why PERSISTABLE_STATE can't move the same way

`PERSISTABLE_STATE` is a registry of `{ get, set, default }` closures,
one per piece of app state, e.g. (illustrative):
```js
messages: { get: () => messages, set: (v) => { messages = v; }, default: () => [] }
```
Each closure captures a `let` binding declared elsewhere in the same
classic-script scope. An ES module has its own separate top-level scope —
it cannot close over a `let` declared in a different script's scope. Moving
`PERSISTABLE_STATE` alone, without also moving the 16 variables it wraps,
would require either:
1. Passing those bindings into the module by reference somehow (not
   possible for primitive/array/object `let` bindings across script
   boundaries in JS — there is no shared-reference mechanism for this).
2. Rewriting the storage layer to use getter/setter functions defined in
   the monolith and imported the "wrong way" (module importing from a
   classic script isn't meaningful), or
3. Moving all 16 state variables into the module too — which would mean
   extracting most of "core"/"agents"/"workspace"'s actual data at the
   same time as "storage", collapsing multiple protocol-named boundaries
   into one oversized, high-risk change. This is exactly the kind of
   "broad rewrite" Aiham's rules forbid, and the opposite of "استخراج
   تدريجي" (incremental extraction).

## Consequences

- `PERSISTABLE_STATE` remains in the classic script for now. It already
  references `ImageStore`/`MessageArchive`/`localStore` by their
  window-bridged names (unchanged call sites — the bridge means this
  needs no edit at all), so this round's extraction is fully
  behavior-transparent to it.
- The natural point to revisit `PERSISTABLE_STATE` is once its wrapped
  state variables have a module home of their own — most likely
  alongside "core" (session/state bootstrap) or split further once
  "agents"/"workspace" are extracted and each owns its own slice of that
  state. Recorded here so a future boundary doesn't have to
  re-discover this constraint from scratch.
- This is the second time (after ADR 002's `autoInitApp` finding) that
  the actual extraction work surfaced a structural fact not visible from
  reading function signatures alone. The dependency-graph script is now
  treated as a mandatory first step for every remaining boundary, not an
  optional nicety.

## Verification

See `PHASE2-MODULARIZE.md` for the full evidence table: backend 406/406
(untouched), Vitest 46/46 (27 new storage tests, 89.2%/82.6%/86.11%/96%
coverage on `storage.mjs`), both E2E suites re-run clean (Phase 0: 12/12,
Phase 1: 16/16) — the Phase 1 suite in particular exercises
`ImageStore`/`MessageArchive` through real app flows (image attach/send,
message cap, reset-all-data GC), not just unit-level.
