# NEXUS-CURRENT-STATE

> Dynamic state document. Written ONLY from evidence gathered in the session
> that produced it (2026-10-07; Evidence Integrity and core slice 3 entries: 2026-10-09). Not a plan.
> If the repository disagrees with this file, the repository wins. Created in the
> core slice 1 commit (`4c3e169`); updated by the core slice 2 commit and by the
> Evidence Integrity inspection commit (docs/evidence only — see `docs/checkpoints/CP-9.md`) and by
> the core slice 3 commit (read-only state map, docs/evidence only — see `docs/checkpoints/CP-10.md`) and by
the core slice 4 / C1 commit (first code-changing core slice — see `docs/checkpoints/CP-11.md`) and by
the core slice 5 commit (evidence-only runtime test of I-1, no production change — see `docs/checkpoints/CP-12.md`) and by
the core slice 6 commit (I-1 handled via option O2; production change = `frontend/main.js` startup tail only — see `docs/checkpoints/CP-13.md`) and by
the core slice 7 commit (evidence-only runtime test of the `isSendingMessage` finding of CP-13 §8: CONFIRMED STUCK; no production change — see `docs/checkpoints/CP-14.md`) and by
the core slice 8 commit (fix of the stuck `isSendingMessage`; production change = `sendMessage()` in the HTML monolith only, +5/−2 — see `docs/checkpoints/CP-15.md`).

## Current Phase
Phase 2 — Modularization (`/nexus-modularize`): **PARTIAL**
(branch `v5.0-polish`).

## Current Boundary
Boundary 5/9 "core": **PARTIAL** (slice 1 VERIFIED; slice 2 VERIFIED as an evidence-only
slice; slice 3 VERIFIED as a static read-only map — runtime behavior UNVERIFIED; slice 4 / C1 VERIFIED (Chromium 141 only);
slice 5 VERIFIED as an evidence-only runtime test (I-1 CONFIRMED = LOST, Chromium 141 + emulated offline only);
slice 6 VERIFIED (I-1 handled via O2 for `activityLog`, Chromium 141 headless + emulated offline only; other variables UNVERIFIED);
slice 7 VERIFIED as an evidence-only runtime test (`isSendingMessage` stuck after an offline send attempt — CONFIRMED, Chromium 141 headless + emulated offline only);
slice 8 VERIFIED (that defect FIXED in `sendMessage()`, Chromium 141 headless + emulated offline + injected faults only);
everything else in core PENDING).
Boundaries 1–4 (security, storage, utilities, settings): VERIFIED (earlier work,
historical evidence; re-confirmed only indirectly by this session's regression runs).
Boundaries 6–9 (agents, modes, ops-center, workspace) and the UI-remainder: PENDING.

## Current TARGET SLICE
**Core slice 8 — fix of the stuck `isSendingMessage` (CP-14 finding): VERIFIED (Chromium 141.0.7390.37 headless + Playwright offline emulation + injected faults only). Production change: `frontend/neural_nexus_ai_agents-4-3-5-3.html`, `sendMessage()` only (+5/−2, 3-line comment included).**
Fix (candidate F3, chosen from three by measurement on scratch copies, tie-break written before the runs): the `try{` of `sendMessage()` now starts right after the lock `isSendingMessage = true;` and `let taskOutcome = 'ok';` is hoisted above it, so the EXISTING `catch`/`finally` release the lock and the send button on every exit — the offline early `return` and any failure in the preparation code (`ImageStore.save`, `resolveActiveMode`, `startTask`, a missing DOM element). No statement was reordered; `main.js`, modules, backend, ADR, `updateOnlineStatus`, `PERSISTABLE_STATE`, C2/C3 untouched.
Acceptance criteria were written BEFORE the patch (`baseline/evidence/phase2-core-slice8-acceptance-criteria.md`; updated successors of slice 7 AC-4/AC-5/AC-7 plus AC-8 preparation failures, AC-9 offline mid-flight). New `e2e/phase2-core-slice8-flows.mjs` (79 checks: VALID 44, PRES 12, PS 23; click and Enter paths; offline→reconnect; double/in-flight sends; faults E1–E4):
PRE (unmodified `389813f`) **56/79 REJECTED** (PS 0/23); POST **79/79 ACCEPTED** (VALID 44/44, PRES 12/12, PS 23/23), deterministic. Candidates: F1 (lock after the offline check) REJECTED (PS 7/23 — leaves E1–E4), F2 and F3 ACCEPTED. Slice 7 script on the patched tree: `S7-VERDICT = NOT-STUCK` 40/40.
Discrimination (`phase2-core-slice8-mutation-script.mjs`, scratch copies of the patched tree, production sha256 unchanged): 7/7 as expected — CTRL ACCEPTED; K1 revert, K2 offline-only fix, K3 guard condition removed, K4 lock after the `await` → REJECTED; K5 reset removed from `finally`, K6 offline check disabled → INVALID (K6 was predicted REJECTED, measured INVALID; first-run log kept).
Intentional behavior changes (AC-14): (1) an offline send attempt no longer leaves the lock set; (2) a failure in the preparation code is now handled by the existing `catch` (error message in chat, `logActivity`, `logError`; lock and button released; the `sendMessage()` promise resolves instead of rejecting).
New facts: preparation failures E2–E4 left BOTH the lock and `sendBtn.disabled` stuck (E1 only the lock); in the plain path the guard condition `isSendingMessage ||` is redundant because `sendBtn.disabled` is set synchronously — the lock is the only barrier in the `await ImageStore.save` window (image attached).
Evidence-tool regressions caused by the patch were measured and fixed minimally: slice 4 extract-script P2b now reverses the slice 8 block before comparing with the base monolith (15/17 → 16/17, only the time-bound P7); the slice 7 mutation script and the slice 8 candidates script are bound to the pre-fix tree and now exit 2 with a message on a patched tree.
Details, honesty log and limits: `docs/checkpoints/CP-15.md`. Evidence Integrity remains **BLOCKED** and untouched; C2/C3, `PERSISTABLE_STATE`, ADR-003 untouched. Phase 2 is **not** complete.
Previous: **Core slice 7 — runtime test (real Chromium) of the static `isSendingMessage` finding (CP-13 §8): VERIFIED as evidence-only (Chromium 141.0.7390.37 headless + Playwright offline emulation only; NO production change; no patch applied at that time; the defect was fixed by slice 8).**
Result: **`S7-VERDICT = STUCK` — CONFIRMED.** One send attempt while offline (button or Enter) leaves `isSendingMessage === true` (set at monolith L8227, offline early `return` at L8229–8232 precedes the `try/finally` whose `finally` is the only reset, L8436).
After the connection is really back (banner hidden, `navigator.onLine === true`, button enabled, text still in the input) every further send (same entry point, same text) does nothing: Δmessages 0, 0 network requests, no toast — 4/4 runs (3 click + 1 Enter), 47/47 validity checks, deterministic results JSON.
Controls: a normal online send completes and resets the flag; an offline period WITHOUT an attempt does not break sending. Causal check: resetting only the flag makes the very same send work (3/3). A page reload recovers (flag is not persisted). A second offline attempt while stuck shows no toast at all.
Discrimination: scratch mutants 5/5 as expected (CTRL STUCK; M1/M4 = candidate fixes → NOT-STUCK 40/40; M2/M3 → INCONCLUSIVE); production tree sha256 identical before/after. M1/M4 are NOT applied — applying a fix is an owner decision (CP-14 §6).
Remaining evidence checks of CP-13 §9 were run fresh: backend `tsc --noEmit` exit 0 and `npm test` 406/406; slice 4 mutation 16/16 killed, 0 survivors; slice 2 probe 19/19 and slice 3 analyzer 22/22 (clean production tree); exec-order 9/9; unit-vs-original 36/36; slice 4 `verify 9c95fbd` 16/17 (P7 time-bound); Vitest 168/168; E2E 12/16/21/27(`SURVIVES`)/35. Slice 1 extract script is a one-shot migration: N/A, not a gap.
**New finding in evidence tooling (not product):** `e2e/phase2-core-seed-flows.mjs` check `ciphertext-hides-plaintext` is intermittent (`!payload.data.includes('42')` on random base64 ⇒ ≈3.5% false failure; measured 700/20000 and 691/20000; 8/8 reruns 16/16). Script NOT edited (CP-14 §E-1).
Static notes, not run: other exceptions between L8227 and the `try` can also leave the flag `true` (CP-14 §7-N2).
Details, honesty log and limits: `docs/checkpoints/CP-14.md`. Evidence Integrity remains **BLOCKED** and untouched; C2/C3, `PERSISTABLE_STATE`, ADR-003 untouched. Phase 2 is **not** complete.
Previous: **Core slice 6 — I-1 handled via option O2 (`updateOnlineStatus()` runs after `autoInitApp()` settles): VERIFIED (Chromium 141.0.7390.37 headless + Playwright offline emulation only).**
Production change: `frontend/main.js` only (+6/−2): `const bootInit = window.autoInitApp(); window.registerServiceWorker(); … bootInit.finally(() => window.updateOnlineStatus());`
(`.finally` so the call still happens if `autoInitApp` rejects, and the rejection stays an unhandled rejection). Applied only after the pre-written acceptance criteria held
(`baseline/evidence/phase2-core-slice6-acceptance-criteria.md`): new `e2e/phase2-core-slice6-flows.mjs` was 24/35 REJECTED on the unpatched tree (VALID 12/12, PRES 12/12, PS 0/11) and is **35/35 ACCEPTED** after the patch.
Result: the boot-time offline `activityLog` entry now survives on top of the restored log (5/5 plain, 3/3 traced; no-blob, blob-without-key, corrupt-blob and online boots behave as specified); the slice 5 script now reports `SURVIVES` (27/27 validity).
Accepted side effect: the offline banner appears after init completes (measured median ≈ +19…+39 ms, headless only; real-device timing UNVERIFIED). Erratum to CP-12 §6: `updateOnlineStatus` never disables the send button.
Evidence-tool regressions caused by the patch were found by measurement and fixed minimally (slice 4 exec-order A7 and extract P5, slice 3 analyzer startup scan, slice 5 mutation M1) — CP-13 §6. Slice 4 `verify 9c95fbd` P7 was already failing at `fbd7236` (time-bound proof).
Details, honesty log and limits: `docs/checkpoints/CP-13.md`. Evidence Integrity remains **BLOCKED** and untouched; C2/C3, `PERSISTABLE_STATE`, ADR-003 untouched. Phase 2 is **not** complete.
Previous: **Core slice 5 — runtime test (real Chromium) of inference I-1: VERIFIED (evidence-only; Chromium 141.0.7390.37 with Playwright network-offline emulation; no production change; PATCH not executed).**
Result: **I-1 CONFIRMED — LOST.** On an offline boot with a persisted decryptable blob, the boot-time `activityLog` entry (`انقطع الاتصال`) written by
`updateOnlineStatus → logActivity` is overwritten by the later `restorePersistableState` (final `activityLog` == the seeded list exactly; blob lacking the key → `[]`).
Plain run 5/5 LOST, traced run 3/3 LOST with order `offline-entry-write → restore-begin (activityLog=[entry]) → restore-end (=decrypted)`;
positive control (offline boot, no blob) keeps the entry; negative control (online boot + blob) restores exactly and has no offline entry; a post-boot `offline` event survives.
27/27 validity checks; scratch mutants 3/3 behave as expected (M1 scratch reorder → SURVIVES; M2/M3 sabotage → INCONCLUSIVE); production `frontend/` tree sha256 unchanged.
Side observations (inside the same limits): the `#activityList` DOM still shows the entry after boot while memory lacks it; the next `persistState()` persists the log without it; the offline banner itself still shows.
Handling of I-1 was PENDING at the end of slice 5 (CP-12 §6); it was then handled by slice 6 via O2 (above). Nothing was applied in slice 5 itself.
Details, honesty log and limits: `docs/checkpoints/CP-12.md`. Evidence Integrity remains **BLOCKED** and was not touched; C2/C3, `PERSISTABLE_STATE`, ADR-003 untouched.
Previous: **Core slice 4 / candidate C1 — registry-parameter `snapshotPersistableState` / `restorePersistableState` / `resetPersistableState`:
VERIFIED (Chromium 141 only).** The iteration logic moved from the monolith (old L4953–4966) to the end of `modules/storage.mjs`
as pure functions taking the registry explicitly; the monolith keeps three one-line wrappers with the ORIGINAL names/signatures that
pass `PERSISTABLE_STATE`; `main.js` bridges the pure functions as `window.PersistableStateCore` (namespaced on purpose — the plain
names belong to the wrappers). `PERSISTABLE_STATE`, the 16 variables, `persistState`, `autoInitApp`, `resetAllData`, ADR-003: byte-identical.
Evidence (fresh): byte-level extraction proof 17/17; Vitest 168/168 (+36 new, 34 red pre-patch); new real-`autoInitApp` E2E 21/21
(19/21 pre-patch, only the 2 patch-specific checks failing); E2E 12/16/16 unchanged; mutation 16/16 killed, 0 survivors;
execution-order check 9/9; backend `tsc --noEmit` exit 0 and `npm test` 406/406 (confirmatory — change surface excludes backend).
Details, honesty log and limits: `docs/checkpoints/CP-11.md`. Evidence Integrity remains **BLOCKED** and was not touched.
Previous: **Core slice 3 — read-only ownership / initialization / mutation map of `PERSISTABLE_STATE` and its 16 state
variables: VERIFIED (static map only; runtime UNVERIFIED).** Evidence/docs only; no production code, test,
ADR or contract changed (`git diff --stat HEAD -- frontend src-baseline e2e ADR PHASE2-MODULARIZE.md` empty).
Reproducible analyzer `baseline/evidence/phase2-core-slice3-state-map.mjs` (22/22 self-checks, deterministic JSON).
Key FACTS (details + inferences in `docs/checkpoints/CP-10.md`): all 16 are col-0 `let` in the main classic script,
literal-initialized, and the registry's `default()` text equals each initializer (16/16); 15 are declared before
`PERSISTABLE_STATE` (L4931), `errorLog` (L5530) after it — TDZ-safe today because no load-time code touches any;
32 rebind sites outside the registry setters, 47 distinct writer units, 85 reader units; `selectedAgentIds` has 14
rebinds in 7 units (+ setter) and `messages` 17 writer units / 73 in-place mutations; `restorePersistableState` has
3 callers (`autoInitApp`, `pullSyncIfNewer`, `resolveSyncConflict`); `persistState` has 38 caller units and itself
splices `messages` before the snapshot; 0 inline handlers reference the 16 names directly; `main.js`/modules do not
reference them; E2E `phase1-security-flows.mjs` reads and ASSIGNS `messages` by bare name (L169/L175).
Evidence Integrity remains **BLOCKED** (below) and was not touched.
Previous: **Evidence Integrity micro-invariant** (inside Phase 2; NOT a new phase, NOT part of core):
inspect + map + measured experiment + documentation only — guard **BLOCKED** pending owner
decisions (CP-9 §4). No production code, test, API or UI changed. Seam identified:
`EvaluationEngine.evaluate()` (`evaluationEngine.ts` L82–123), the only producer of the
5-state verdict/confidence and the shared choke point of its 2 callers
(`webResearch.ts:165`, `evaluation.ts:43`). Enforcement needs fail-closed on the `EvidenceItem`
contract; a scratch (not applied) experiment broke 9/24 existing tests, and the Ops Center UI
sends evidence with no kind. (Core slice 3 was not started in that session and was not mixed in; it ran later — see above.)
Previous (unchanged below): Core slice 2 — evidence-only browser-level (real Chromium) probe of module access to
classic-script top-level `let`/`const`/`var` by bare name, plus a strictly read-only
check against the real monolith: **VERIFIED**. No production code changed. Stopped at
its stop point.
Previous: Core slice 1 — move `encryptState` / `decryptState` into
`modules/security.mjs`, bridge on `window` in `main.js`: **VERIFIED** (commit `4c3e169`).

## Latest Verified Commit
Latest commit that changed production code: the core slice 8 commit (HEAD of `v5.0-polish` at ZIP time; read it with `git log -1`) — `sendMessage()` in the HTML monolith only (+5/−2). Slice 8 chain check: `git rev-parse HEAD~1` must be `389813f` (slice 7, evidence-only), `HEAD~2` = `5770104` (slice 6), `HEAD~3` = `fbd7236`, `HEAD~4` = `669386b`, `HEAD~5` = `9c95fbd`, `HEAD~6` = `b9d4808`, `HEAD~7` = `0520af7`, `HEAD~8` = `4c3e169`. Before slice 8: the core slice 6 commit `5770104` (`frontend/main.js` startup tail only). The core slice 7 commit `389813f` is evidence/docs/test-only (production tree sha256 identical to `5770104`). Before slice 6: the core slice 4 / C1 commit (`669386b`); the core slice 5 commit (`fbd7236`) is evidence/docs/test-only.
Slice 7 chain check (historical, valid when slice 7 was HEAD): `git rev-parse HEAD~1` must be `5770104`, `HEAD~2` = `fbd7236`, `HEAD~3` = `669386b`, `HEAD~4` = `9c95fbd`, `HEAD~5` = `b9d4808`, `HEAD~6` = `0520af7`, `HEAD~7` = `4c3e169`.
Previously: `4c3e169` (core slice 1, VERIFIED).
`0520af7` = core slice 2 commit (evidence-only, VERIFIED, no production change); `b9d4808` = Evidence
Integrity inspection commit (docs/evidence only). `9c95fbd` = core slice 3 commit (docs/evidence only). `669386b` = core slice 4 commit. The core slice 6 commit is HEAD at ZIP time
(a file cannot contain its own hash — read it with `git log -1`); chain check:
`git rev-parse HEAD~1` must be `fbd7236` (slice 5), `HEAD~2` = `669386b`, `HEAD~3` = `9c95fbd`, `HEAD~4` = `b9d4808`, `HEAD~5` = `0520af7`, `HEAD~6` = `4c3e169`.

## Working Tree State
(Slice 8: clean at session start — HEAD = `389813f`, verified against the ZIP name and `git status --short`; the final report states the end check (clean tree, ZIP = HEAD).) Earlier note:
(Slice 7: clean at session start — verified `git status --short` empty; HEAD = `57701044f730e627f62bc43a8d27e87c71ef66d8`; production tree unchanged by the slice; the final report states the end check.) Earlier note:
(Slice 6: clean at session start — verified `git status --short` empty; HEAD = `fbd7236e2b29fbe0f9f4b26c58dc5b1fa967c6f6` as requested; the final report states the end check.) Earlier note:
(Slice 5: clean at session start — verified; the report of the slice 5 commit states the final check.) Earlier note: clean immediately after the core slice 3 commit (verified with `git status --short`
after committing; see the session report). Environment note: the E2E scripts hard-code
`/home/claude/nexus-v5/`; this session ran them from a COPY of the unpacked repo at
that path (outside the original extraction). The slice 2 runner resolves its paths
relative to its own location and needs no hard-coded path.

## Verified Work (slice 2 — commit `0520af7`)
- Real Chromium **141.0.7390.37**. Synthetic classic+module page (layout mirrors the
  monolith), served from a scratch temp dir. Module code reads/writes by bare name:
  - **let**: read OK, write OK (seen by classic), NOT on `window`.
  - **var**: read OK, write OK (seen by classic and `window`), on `window`.
  - **const**: read OK, write throws **TypeError** (value unchanged), NOT on `window`.
  - Live binding both directions (classic write → module read). Module-declared
    `let`/`var` are invisible to the classic script (reverse isolation).
  - Negative controls: undeclared read and write → **ReferenceError**; `typeof` → `"undefined"`.
  - Modules-only control (module B reading module A's `let`/`const`/`var`) → ReferenceError
    ×3, showing the probe distinguishes shared-global from private scope.
- Read-only check on the REAL monolith (no assignments, no calls): 56/56 `let`,
  57/57 `const`, 370/370 functions readable by bare name from an injected module;
  0 mismatches vs. classic global scope; `let`/`const` on `window`: 0; functions: 370/370.
  Integrity: 13 frontend files SHA-256 identical before/after, `git status` on
  production paths empty, app-state fingerprint unchanged.
- Acceptance: **19/19** probe checks; two runs gave identical findings.
- Not exercised by design: writes on the real monolith; `var` on the real monolith
  (it has no column-0 top-level `var`).
- Interpretation and limits: `docs/checkpoints/CP-8.md`. The positive result does NOT
  authorize editing ADR-003, changing the bridge pattern, or changing production code.

## Verified Work (slice 1 — earlier commit `4c3e169`)
- Both functions moved byte-for-byte (only `export` added), proven by the
  extraction script (`byte-identical-after-export-strip: true`).
- Behavior equivalence with the ORIGINAL implementation: byte-identical
  envelopes for the same key+IV, cross-decrypt both directions, identical error
  classes, golden vector generated from the original code.
- Module/bridge integration in real Chromium, including the real
  persist → reload → restore pipeline through `autoInitApp`.
- Execution-order safety re-derived from the AST (no new ordering assumption).

## Test Evidence — core slice 8 session (2026-10-11; PRE = unmodified `389813f`, POST = patched tree; all fresh)
- New `e2e/phase2-core-slice8-flows.mjs` (79 checks): PRE **56/79 REJECTED** (PS 0/23); candidates F1 REJECTED (PS 7/23), F2/F3 ACCEPTED; POST **79/79 ACCEPTED** (deterministic). Slice 7 script on the patched tree: NOT-STUCK 40/40 (it was STUCK 47/47 before).
- Mutation `phase2-core-slice8-mutation-script.mjs`: 7/7 as expected (CTRL ACCEPTED; K1–K4 REJECTED; K5, K6 INVALID), production tree sha256 identical before/after.
- Regression POST: Vitest 168/168; E2E `baseline-flows` 12/12, `phase1-security-flows` 16/16, `phase2-core-seed-flows` 16/16, `phase2-core-slice4-flows` 21/21, slice 5 27/27 (`SURVIVES`), slice 6 35/35; backend `tsc --noEmit` exit 0 and `npm test` 406/406; slice 2 probe 19/19 and slice 3 analyzer 22/22 (clean committed production tree); exec-order 9/9; unit-vs-original 36/36; slice 4 mutation 16/16, 0 survivors; slice 4 `verify 9c95fbd` 16/17 (P7 time-bound; it was 15/17 right after the patch until P2b was adapted).
- NOT run: slice 1 extract script (one-shot migration, N/A). Logs: `baseline/evidence/phase2-core-slice8-*`.

## Test Evidence — core slice 7 session (2026-10-10/11; production tree = `5770104`, unmodified; all fresh)
- New `e2e/phase2-core-slice7-flows.mjs`: 47/47 validity, `S7-VERDICT = STUCK` (4/4 runs); deterministic results JSON (2 runs byte-identical). Mutation `baseline/evidence/phase2-core-slice7-mutation-script.mjs`: 5/5 as expected, production tree sha256 unchanged.
- Vitest 168/168; E2E `baseline-flows` 12/12, `phase1-security-flows` 16/16, `phase2-core-slice4-flows` 21/21, slice 5 27/27 (`SURVIVES`), slice 6 35/35 (`ACCEPTED`); `phase2-core-seed-flows` 16/16 on 8/8 reruns but 15/16 on the FIRST run (intermittent test defect, CP-14 §E-1).
- Backend: `tsc --noEmit` exit 0; `npm test` 406/406. Slice 4 mutation 16/16 killed, 0 survivors, files restored by sha256. Slice 2 probe 19/19, slice 3 analyzer 22/22 (clean production tree; 18/19 and 21/22 on the first run only because the new uncommitted `e2e/` file counted as a production-path change). Exec-order 9/9, unit-vs-original 36/36, slice 4 `verify 9c95fbd` 16/17 (P7 time-bound).
- Not run (by design): slice 1 extract script (one-shot migration, N/A). Logs: `baseline/evidence/phase2-core-slice7-*`.

## Test Evidence — core slice 6 session (2026-10-10; all fresh; PRE = unmodified `fbd7236`, POST = patched tree)
- PRE: E2E 12/12, 16/16, 16/16, 21/21, slice 5 27/27 (`LOST`), Vitest 168/168; slice 6 acceptance **24/35 REJECTED** (VALID 12/12, PRES 12/12, PS 0/11). One test defect (`hasBlob` read after a `persistState`) was caught by a VALID check and fixed before any verdict.
- POST: slice 6 acceptance **35/35 ACCEPTED**; E2E 12/12, 16/16, 16/16, 21/21; slice 5 script 27/27 with `I1-VERDICT = SURVIVES`; Vitest 168/168; slice 6 mutants K1–K6 **6/6 caught**; slice 5 mutants 3/3 (M1 adapted); slice 4 exec-order 9/9 and unit-vs-original 36/36; slice 3 analyzer 22/22 and slice 2 probe 19/19 (both on a clean committed tree; first run on the uncommitted tree gave 20/22 and 18/19 — see CP-13 §6).
- Slice 4 `extract verify 9c95fbd`: 16/17 (P7 only; identical on the clean `fbd7236` — time-bound proof).
- NOT run: backend `tsc --noEmit`/`npm test` (backend untouched; only `npm run build`), slice 4 mutation script (~7 min), slice 1 extract script.
- Logs: `baseline/evidence/phase2-core-slice6-*`; banner timing observation: `…-banner-delay-observation.log`.

## Test Evidence — core slice 5 session (2026-10-10; production tree unmodified since `669386b`; all fresh)
- Step 1 (E2E runnable from the extracted archive): backend `npm ci` exit 0 + `npm run build` exit 0; `e2e/` `npm ci` fails as before (no lockfile) → `npm install --no-save --no-package-lock playwright@1.56.1`;
  real `chromium.launch()` = 141.0.7390.37; E2E via symlink `/home/claude/nexus-v5` → the extracted dir: `baseline-flows` 12/12, `phase1-security-flows` 16/16, `phase2-core-seed-flows` 16/16, `phase2-core-slice4-flows` 21/21 (PRE), identical POST.
- New `e2e/phase2-core-slice5-flows.mjs`: 27/27 validity, `I1-VERDICT = LOST`; `baseline/evidence/phase2-core-slice5-mutation-script.mjs`: 3/3 mutants as expected, production tree sha256 unchanged.
- Frontend Vitest 168/168 (5 files, after `npm ci` in `frontend/`). NOT run: backend `tsc --noEmit`/`npm test` (backend untouched; only `npm run build`), slice 2 probe, slice 3 analyzer, slice 4 extract/exec-order/mutation scripts.
- Logs: `baseline/evidence/phase2-core-slice5-*` (PRE/POST E2E, i1-run, i1-results.json, mutation, code-sha256).

## Test Evidence — core slice 4 session (2026-10-09/10; all fresh; PRE = unmodified `9c95fbd`, POST = final tree)
- Vitest: PRE 132/132 (4 files); with the new test file on the unpatched tree 34 failed / 134 passed; POST **168/168** (5 files). `storage.mjs` 96.26% lines.
- E2E: `baseline-flows` 12/12, `phase1-security-flows` 16/16, `phase2-core-seed-flows` 16/16 both PRE and POST; new `phase2-core-slice4-flows` PRE 19/21 → POST **21/21**.
- Byte-level extraction proof `phase2-core-slice4-extract-script.mjs verify 9c95fbd`: **17/17**; exec-order check (acorn) **9/9**; unit tests vs the ORIGINAL implementation 36/36.
- Mutation: 10 unit + 6 E2E, **0 survivors**, files restored (sha256). Backend: `tsc --noEmit` exit 0; `npm test` **406/406** (confirmatory).
- NOT run: slice 2 probe, slice 3 analyzer (neither affected). Logs: `baseline/evidence/phase2-core-slice4-{PRE,POST}-*`.

## Test Evidence — core slice 3 session (2026-10-09, production tree unmodified since `4c3e169`; all fresh)
- Slice 3 analyzer: **22/22**, two consecutive runs → identical JSON (sha256 `a1046086…`); a mutation of the
  new handler check made it fail (21/22) and the script was restored byte-identical (sha256).
- Frontend Vitest **132/132** (4 files). E2E `baseline-flows` **12/12**, `phase1-security-flows` **16/16**,
  `phase2-core-seed-flows` **16/16**. Logs: `baseline/evidence/phase2-core-slice3-*`.
- Backend: `npm run build` exit 0 (needed for E2E `backend-boot`). NOT run: backend `npm test`/`tsc --noEmit`
  (backend untouched), slice 2 probe.
- Environment lessons: `e2e/` has no lockfile (`npm ci` fails) and the unpinned `playwright` is newer than
  `/opt/pw-browsers` → install `playwright@1.56.1` with `--no-save --no-package-lock`; the backend must be built.

## Test Evidence — Evidence Integrity session (2026-10-09, unmodified production tree at `0520af7`)
- Backend: `npm ci` exit 0; `tsc -p tsconfig.json --noEmit` exit 0 (no output); `npm test`
  **406/406** pass, 0 fail (120.0 s). Logs: `baseline/evidence/phase2-evidence-integrity-baseline-*.log`.
- Scratch fail-closed experiment (NOT applied; patch + log kept as evidence): 3 test files,
  24 tests → 15 pass / 9 fail. Proves only the effect of the policy on existing tests.
- NOT run in this session: `npm run build`, frontend Vitest, E2E (12/16/16), slice 2 probe.
  The figures in the next section are from the slice 2 session and are NOT re-measured here.

## Current Test Evidence — slice 2 session (all fresh at that time, final tree of that session)
- Slice 2 probe: `baseline/evidence/phase2-core-slice2-adr003-probe.mjs` → **19/19**
  (log: `…-probe.log`; raw JSON: `…-probe-results.json`).
- Slice 2 regression on the final tree (production paths show NO diff vs `4c3e169`, proven
  with `git diff --stat HEAD`): Vitest **132/132** (4 files; `security.mjs` 100% lines,
  100% funcs, 96.87% stmts, 85.71% branches); E2E `baseline-flows` **12/12**,
  `phase1-security-flows` **16/16**, `phase2-core-seed-flows` **16/16** — all re-run
  after the final documentation edits.
- Vitest: **132/132** (security.test.mjs: 35). security.mjs coverage: 100% lines/funcs.
- E2E `phase2-core-seed-flows.mjs`: **16/16** post; **15/16** pre-extraction
  (only the patch-specific `bridge-identity` fails, by design).
- E2E `baseline-flows.mjs`: **12/12**. E2E `phase1-security-flows.mjs`: **16/16**.
- Backend `npm test`: **406/406**; `tsc --noEmit`: no errors printed. Backend
  untouched (run only to confirm no collateral change).
- Fault injection: 5 function mutations (2–6 failing Vitest tests each) and 2
  bridge mutations (11/17 and 13/17 E2E checks failing); all files restored
  byte-identical by sha256 and re-passed.
- Logs: `baseline/evidence/phase2-core-slice1-*`. Details: `docs/checkpoints/CP-7.md`.
- Backend (re-measured earlier in the same slice 2 session, on the identical production
  tree; not re-run after the documentation-only edits, which cannot affect it):
  `tsc --noEmit` exit 0, `npm run build` exit 0, `npm test` **406/406**.

## Unverified Items
- Slice 8 limits: Chromium headless 141 + emulated offline + monkey-patched/DOM-removed faults only (models, does not prove, which faults occur in the field); no real device, Firefox/Safari, `sw.js`; the streaming/stop (`AbortError`) branch needs a real backend stream and was not exercised (it is inside the unchanged `try`); exceptions thrown inside the `catch`/`finally` themselves are not tested; the online send reaches only an aborted external request.
- Slice 7 limits: Chromium headless 141 + Playwright network emulation only (no real device, Firefox/Safari, `sw.js`); online follow-up reaches only an aborted external request (no real provider/backend); only the offline early return was tested — other exceptions between `isSendingMessage = true` and the `try` (e.g. `ImageStore.save`, `resolveActiveMode`, `startTask`) are static notes (CP-14 §7-N2).
- Slice 6 limits: Chromium headless 141 + Playwright network emulation only; real-device/slow-IndexedDB banner delay and an IndexedDB promise that never settles are UNVERIFIED; only `activityLog` covered (other variables written before restore remain INFERENCE); `sw.js`-served boot untested.
- Slice 5 limits: Chromium headless 141 + Playwright network emulation only (no real-device offline, no Firefox/Safari); `sw.js`-served boot path untested; DOM entry disappearing on opening the activity panel is an INFERENCE from code; other variables' write-before-restore not tested.
- Behavior in Firefox/Safari (Chromium only).
- ADR-003 still reads "cannot close over a `let` declared in a different script's scope".
  Browser-level evidence (slice 2, Chromium 141) does not support that wording for bare-name
  access from module code, but ADR-003 is UNEDITED and the decision to revise it is
  **PENDING** (separate decision). Not tested: moving `PERSISTABLE_STATE` itself, TDZ /
  initialization order in other layouts, closures stored and invoked later from classic,
  writes on the real monolith, Firefox/Safari.
- `NexusContext.buildAgentContext` live-caller status (static scan found no
  caller in the monolith; not investigated further, not reopened).

## Blocked Items
- **Evidence Integrity guard — BLOCKED** (owner decision): fail-closed policy for `EvidenceItem`
  without a declared Evidence-Delta `kind`; which `kind` the Ops Center manual evidence rows
  carry (UI = boundary 8, PENDING); how the state-change reason is persisted (migration 016
  column vs. derived from `evidence_json`); ADR-004. Details and the recommended minimal seam:
  `docs/checkpoints/CP-9.md` §4–§5.
- `sw.js` is not among the provided artifacts: cumulative cache-manifest
  follow-up (5 files: `/main.js`, `/modules/security.mjs`, `/modules/storage.mjs`,
  `/modules/utilities.mjs`, `/modules/settings.mjs`) cannot be applied. This
  slice added no new file. Must be finalized before Phase 2's Exit Gate.

## Known Risks
- **Latent "agent agreement → evidence upgrade" path (found by code reading, NOT exercised with a
  live judge):** `EvaluationEngine.evaluate()` cannot distinguish Agent outputs from independent
  sources, and its judge prompt (L59) rewards multiple "independent" sources. No internal caller
  feeds it agent outputs today (2 callers only), but `POST /v2/evaluation/claim` accepts any
  `{source, content}` and migration 012's own comment anticipates council syntheses as future
  subjects. Independence would remain *declared, not verified* even after a guard (CP-9 §6).
- **Documentation finding (ADR-003), now with browser-level evidence:** real Chromium 141
  shows module code reading/writing classic top-level `let`/`var` (and reading `const`)
  by bare name, which conflicts with ADR-003's wording. ADR-003 NOT edited; bridge pattern
  NOT changed; nothing was built on the result. Any revision is a separate future decision.
  Chromium is available here (`PLAYWRIGHT_BROWSERS_PATH=/opt/pw-browsers`).
- `autoInitApp` swallows decrypt failures and "starts fresh"; any future change
  to the crypto seam can silently drop user data. The new E2E guards this.
- Remaining core is state-heavy (`PERSISTABLE_STATE`, 16 variables, `selectedAgentIds`
  has 15 write sites in 8 functions — re-derived by slice 3: 14 rebinds in 7 units + the registry setter).
- **Startup write-before-restore — MITIGATED for the offline `activityLog` entry by slice 6 (O2, CP-13); historical description follows (CP-12, slice 5):** `autoInitApp()` is not awaited; on an offline boot `updateOnlineStatus → logActivity`
  rebinds `activityLog` before the async `restorePersistableState` overwrites it, so the boot-time entry is LOST whenever a persisted blob exists (5/5 + 3/3 runs). Low product impact (one informational
  activity-log entry; the offline banner still works). Only `activityLog` was tested; generalizing to other variables is INFERENCE. O2 was applied in slice 6; the generalization to other variables is still INFERENCE.
- **`sendMessage` stuck flag — FIXED by slice 8 (CP-15), VERIFIED within the slice 8 limits (Chromium 141 headless, emulated offline, injected faults).** History: confirmed at runtime by slice 7 (CP-14; `S7-VERDICT = STUCK`): the lock was set before the offline early `return` and the preparation code, outside the `try/finally` that resets it. Now the `try` starts right after the lock. Residual: exceptions inside `catch`/`finally` and the real-stream abort branch UNVERIFIED; real devices/other browsers UNVERIFIED.
- **Evidence-tool defect (CP-14 §E-1):** `e2e/phase2-core-seed-flows.mjs` `ciphertext-hides-plaintext` fails ≈3.5% of runs by chance (substring "42" in random base64). A single 15/16 there is not by itself a product regression; re-run and compare. Not fixed (owner/tools-slice decision).
- **Slice 4 characterization (existing behavior, preserved, NOT protected):** `snapshotPersistableState` is shallow (values are live references) and
  `restorePersistableState` assigns by reference; any deep-copy "improvement" is a deliberate future decision (tests fail on it by design).
- **Test coupling:** moving ownership of `messages` would break/require editing `e2e/phase1-security-flows.mjs`
  (bare-name reads and `messages = …` assignments).
- Slice 3 limits: static analysis only; alias mutation (escape sites) and indirect persistence are not tracked.

## Terminology note (historical "DONE")
`PHASE2-MODULARIZE.md` uses the word "DONE" for boundaries 1–4. That is **historical
wording from before the current six-state status vocabulary** and has intentionally NOT
been rewritten. The authoritative current status model is only:
`VERIFIED / PARTIAL / PENDING / BLOCKED / FAILED / UNVERIFIED`. Read the historical
"DONE" for boundaries 1–4 as the historical claim that they were VERIFIED at the time
(not freshly re-measured here, apart from indirect regression coverage).

## Remaining Scope
Core: `PERSISTABLE_STATE` + 16 state vars, `NexusContext`, `ContextFabric`.
Then agents, modes, ops-center, workspace, UI-remainder; `sw.js`; Phase 2 Exit Gate.

## Next Safe Slice
**No slice is auto-approved.** Core slice 6 (I-1 via O2) and slice 8 (stuck `isSendingMessage` FIXED) are VERIFIED within their stated limits; slice 7 was the evidence-only confirmation. Owner decisions needed before the next code slice:
(a) (closed by slice 6 — I-1/O2 applied; do not redo);
(d) (closed by slice 8 — isSendingMessage fixed; do not redo). Still open and optional: whether to fix the intermittent seed-flows check (CP-14 §E-1) as a separate tools slice;
(b) ownership mechanism for C2/C3 + a separate ADR-003 revision (moving ownership of any variable stays blocked on this);
(c) the Evidence Integrity decisions in `CP-9.md` §4 (separate, must not be mixed with core work).
Remaining core: `PERSISTABLE_STATE` + 16 variables (ownership), `NexusContext`, `ContextFabric`; then boundaries 6–9, `sw.js`, Phase 2 Exit Gate.
