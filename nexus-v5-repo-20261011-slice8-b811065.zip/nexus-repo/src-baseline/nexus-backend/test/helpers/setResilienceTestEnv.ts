process.env.NEXUS_JUDGE_CALL_TIMEOUT_MS = '600';
process.env.NEXUS_TASK_TIMEOUT_MS = '600';
process.env.NEXUS_MAX_RETRIES = '1';
process.env.NEXUS_DB_PATH = ':memory:';
process.env.NEXUS_GATEWAY_KEYS = '';
process.env.NEXUS_LOG_LEVEL = 'warn';
