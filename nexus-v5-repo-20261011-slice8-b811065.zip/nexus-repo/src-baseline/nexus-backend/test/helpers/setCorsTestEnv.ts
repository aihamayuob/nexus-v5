process.env.NEXUS_CORS_ORIGINS = 'http://localhost:9999';
process.env.NEXUS_DB_PATH = ':memory:';
process.env.NEXUS_GATEWAY_KEYS = '';
process.env.NEXUS_LOG_LEVEL = 'warn';
