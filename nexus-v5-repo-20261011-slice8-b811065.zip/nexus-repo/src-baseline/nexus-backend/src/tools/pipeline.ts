import type { ProviderId } from '../config/providerRegistry.js';
import { getToolRegistry, validateAgainstSchema } from './registry.js';
import { PermissionModel, type GatewayContext } from '../capability/permissionModel.js';
import { Errors, normalizeError } from '../core/errors.js';
import { logger } from '../core/logger.js';

export interface ToolCallRequest {
  /** The tool_use block id from the model's own response — never derived from free text. */
  id: string;
  name: string;
  input: Record<string, unknown>;
}

export interface ToolCallResult {
  id: string;
  content: string;
  isError: boolean;
}

const MAX_RESULT_CHARS = 20_000;

/** Strips control characters and caps length — defense in depth so a misbehaving tool can't smuggle terminal-escape sequences or blow out context with an unbounded result. */
function sanitize(text: string): string {
  // eslint-disable-next-line no-control-regex
  const stripped = text.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g, '');
  return stripped.length > MAX_RESULT_CHARS ? stripped.slice(0, MAX_RESULT_CHARS) + '…[مقتطع]' : stripped;
}

function withTimeout<T>(promise: Promise<T>, ms: number, toolName: string): Promise<T> {
  return new Promise((resolve, reject) => {
    const t = setTimeout(() => reject(Errors.timeout(`انتهت مهلة تنفيذ الأداة "${toolName}".`)), ms);
    promise.then(
      (v) => {
        clearTimeout(t);
        resolve(v);
      },
      (e) => {
        clearTimeout(t);
        reject(e);
      }
    );
  });
}

export async function executeToolCall(req: ToolCallRequest, providerId: ProviderId, ctx: GatewayContext): Promise<ToolCallResult> {
  // 1. Registry lookup
  const registered = getToolRegistry().get(req.name);
  if (!registered || !registered.execute) {
    return { id: req.id, content: `الأداة "${req.name}" غير مسجّلة أو لا تُنفَّذ من هذا الخادم.`, isError: true };
  }

  try {
    // 2. Capability check + 3. Permission check (auth/budget)
    PermissionModel.assertToolAllowed(providerId, req.name, ctx);
    PermissionModel.assertBudgetAllowed();

    // 4. Validation
    const errors = validateAgainstSchema(registered.def.input_schema, req.input);
    if (errors.length) throw Errors.toolValidation(errors.join(' '), { errors });

    // 5. Execution + 6. Timeout
    const raw = await withTimeout(registered.execute(req.input), registered.timeoutMs, req.name);

    // 7. Sanitization
    const clean = sanitize(raw);

    logger.info('Tool executed', { tool: req.name, provider: providerId, resultChars: clean.length });
    // 8. Result
    return { id: req.id, content: clean, isError: false };
  } catch (e) {
    const err = normalizeError(e);
    logger.warn('Tool execution failed', { tool: req.name, provider: providerId, message: err.message });
    return { id: req.id, content: `فشل تنفيذ الأداة: ${err.message}`, isError: true };
  }
}

export async function executeToolCalls(reqs: ToolCallRequest[], providerId: ProviderId, ctx: GatewayContext): Promise<ToolCallResult[]> {
  return Promise.all(reqs.map((r) => executeToolCall(r, providerId, ctx)));
}
