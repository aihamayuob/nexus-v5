import type { ToolDef } from '../providers/contract.js';

export interface RegisteredTool {
  def: ToolDef;
  /** Absent for server-native tools the provider itself executes (e.g. Anthropic's web_search_20250305) — those never reach our pipeline at all. */
  execute?: (input: Record<string, unknown>) => Promise<string>;
  timeoutMs: number;
}

class ToolRegistryImpl {
  private tools = new Map<string, RegisteredTool>();

  register(tool: RegisteredTool) {
    this.tools.set(tool.def.name, tool);
  }

  get(name: string): RegisteredTool | undefined {
    return this.tools.get(name);
  }

  list(): ToolDef[] {
    return [...this.tools.values()].map((t) => t.def);
  }

  clear() {
    this.tools.clear();
  }
}

let singleton: ToolRegistryImpl | null = null;
export function getToolRegistry(): ToolRegistryImpl {
  if (!singleton) singleton = new ToolRegistryImpl();
  return singleton;
}

/** Minimal JSON-schema-lite validator — deliberately not a general-purpose engine (zero external deps), just enough to validate our own tool input_schema shapes (object/string/number/boolean properties + required). */
export function validateAgainstSchema(schema: ToolDef['input_schema'], input: unknown): string[] {
  const errors: string[] = [];
  if (!schema) return errors;
  if (typeof input !== 'object' || input === null || Array.isArray(input)) {
    return ['المدخل يجب أن يكون كائن (object).'];
  }
  const obj = input as Record<string, unknown>;
  for (const required of schema.required ?? []) {
    if (!(required in obj)) errors.push(`الحقل المطلوب "${required}" مفقود.`);
  }
  for (const [key, propSchema] of Object.entries(schema.properties)) {
    if (!(key in obj)) continue;
    const value = obj[key];
    const actualType = Array.isArray(value) ? 'array' : typeof value;
    if (propSchema.type === 'string' && actualType !== 'string') errors.push(`الحقل "${key}" يجب أن يكون نصاً.`);
    if (propSchema.type === 'number' && actualType !== 'number') errors.push(`الحقل "${key}" يجب أن يكون رقماً.`);
    if (propSchema.type === 'boolean' && actualType !== 'boolean') errors.push(`الحقل "${key}" يجب أن يكون قيمة منطقية.`);
    if (propSchema.type === 'object' && actualType !== 'object') errors.push(`الحقل "${key}" يجب أن يكون كائناً.`);
  }
  return errors;
}
