import type { Router, RouteContext } from '../../gateway/router.js';
import { readJsonBody } from '../../gateway/middleware/bodyLimit.js';
import { embedTexts } from '../../memory/embeddingsService.js';
import { ProviderRegistry, type ProviderId } from '../../config/providerRegistry.js';
import { Errors } from '../../core/errors.js';

export function registerEmbedRoutes(router: Router) {
  router.post(
    '/api/embed',
    async (ctx: RouteContext) => {
      const body = await readJsonBody<{ texts?: string[]; provider?: string; model?: string }>(ctx.req);
      if (!Array.isArray(body.texts) || body.texts.length === 0) throw Errors.validation('الحقل "texts" مطلوب ويجب أن يكون مصفوفة غير فارغة.');
      if (body.texts.some((t) => typeof t !== 'string')) throw Errors.validation('كل عنصر في "texts" يجب أن يكون نصاً.');
      // The frontend's current getEmbedding() call doesn't send a
      // provider — default to the first embeddings-capable configured
      // provider so the legacy contract keeps working unmodified while
      // still routing through the SAME unified service future callers
      // (that DO specify a provider) use.
      const providerId = (body.provider && ProviderRegistry.has(body.provider) ? body.provider : firstEmbeddingProvider()) as ProviderId;
      const result = await embedTexts(body.texts, providerId, ctx.gw, body.model);
      ctx.res.writeHead(200, { 'Content-Type': 'application/json' });
      ctx.res.end(JSON.stringify({ embeddings: result.embeddings }));
    },
    { skipAuth: true } // matches the frontend's current getEmbedding(), which sends no Authorization header — see routes/legacy/embed.ts header note in the delivery README about this gap
  );
}

function firstEmbeddingProvider(): ProviderId {
  const candidates = ProviderRegistry.resolveAll().filter((p) => p.capabilities.embeddings && (p.capabilities.isLocal || p.apiKey));
  if (candidates.length === 0) throw Errors.capabilityDenied('لا يوجد أي مزود تضمين (embeddings) مُعدّ على السيرفر.');
  return candidates[0]!.id;
}
