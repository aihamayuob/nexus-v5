# NEXT-SESSION-START-HERE — NEXUS GAP-1 / GAP-1B

> وثيقة ذاتية الاكتفاء. اقرأها كاملة قبل لمس أي ملف. المصدر الأعلى للحقيقة: المستودع والأدلة القابلة لإعادة التشغيل، لا ذاكرة المحادثة.
> الحالة الإجمالية للشريحة: **PARTIAL**. لا يوجد commit ولا push. لا يجوز إعلان "أمن الخصوصية مكتمل".

## 1) الهدف والحالة الفعلية

- **الهدف (قرار المالك):** (أ) تطبيق رقعة GAP-1 (منع الرجوع السحابي التلقائي في LOCAL_ONLY/PRIVATE/المزوّد المحلي الصريح) والتحقق منها؛ (ب) تصميم D1.3 (حماية مزدوجة: سياسة إدارية مركزية افتراضها منع + موافقة صريحة مرتبطة بالمهمة) **بدون تنفيذها**؛ (ج) GAP-1B: إغلاق مسارات الخروج السحابي المباشرة في Verifier وEvaluationEngine وagentGenome وfreshnessEngine؛ (د) فحص تعامل الواجهة مع `local_provider_unavailable`؛ (هـ) حزمة تسليم ZIP.
- **أين نحن:** كل ما سبق نُفّذ ووُثّق على **نسخة عمل مستعادة** من حزمة التسليم (ليست مستودع المالك الحي). الرقعة مُسلَّمة كملفات patch + لقطة مصدرية.
- **المرجع:** الفرع `v5.0-polish`، HEAD الأساس `cbdc898a3ba605211d9791979a6415f314ba1c8f` (لم يتغيّر؛ لا commit). الـ commit `80c558a…` المذكور في الإحاطة الأولى سلف لـHEAD (HEAD أحدث بـ4 commits).
- **قرارات المالك الثابتة:** D1 (LOCAL_ONLY/PRIVATE لا تسمح بخروج سحابي تلقائي، ولا رجوع صامت) · D2 · D1.3 = حماية مزدوجة (سياسة إدارية افتراضها deny + موافقة مرتبطة بالمهمة؛ الخادم هو المرجع، ولا يُعتد بحقل في الطلب أو إعداد بالواجهة لتجاوزه) · لا commit/push.

## 2) ما الذي تغيّر منذ `cbdc898` (19 ملفاً: 12 معدّلاً + 7 جديدة؛ +1187/−22)

| الملف | السبب |
|---|---|
| `src-baseline/nexus-backend/src/providers/modelRouter.ts` | GAP-1: `cloudFallbackBlocked`؛ المزوّد الأساسي المحلي لا يرجع إلا إلى محلي |
| `src-baseline/nexus-backend/src/orchestrator/chatService.ts` | GAP-1: تحويل فشل المحلي إلى `local_provider_unavailable` (503)؛ GAP-1B: وسم المهمة المقيّدة (`markTaskRestricted`) قبل/بعد التوجيه |
| `src-baseline/nexus-backend/src/core/errors.ts` | رمزا خطأ: `local_provider_unavailable` (503, قابل لإعادة المحاولة) و`cloud_egress_denied` (403, غير قابل لإعادتها) |
| `src-baseline/nexus-backend/src/security/cloudEgressGuard.ts` (جديد) | حارس مركزي: `decideCloudEgress/checkCloudEgress/assertCloudEgressAllowed`؛ تدقيق الرفض بلا محتوى |
| `src-baseline/nexus-backend/src/orchestrator/verifier.ts` | يتحقق من الحارس قبل استدعاء المزوّد؛ يعيد `ran:false` + `blockedReason` |
| `src-baseline/nexus-backend/src/orchestrator/missionRunner.ts`, `src/council/councilRunner.ts` | تمرير `taskId` إلى `Verifier.verify`؛ نص الجولة عند الحجب |
| `src-baseline/nexus-backend/src/evaluation/evaluationEngine.ts`, `src/routes/v2/evaluation.ts` | حارس قبل الاستدعاء؛ `privacyMode` اختياري في الجسم (يشدّد فقط) |
| `src-baseline/nexus-backend/src/evolution/agentGenome.ts` | `assertCloudEgressAllowed` على مسار genome-judge |
| `src-baseline/nexus-backend/src/knowledge/freshnessEngine.ts`, `src/routes/v2/knowledgeFreshness.ts` | حارس على check/refresh(research)/scan؛ جسم JSON اختياري (جسم مشوّه = 400) |
| `frontend/neural_nexus_ai_agents-4-3-5-3.html` | إصلاح عيب قائم: خطأ مُبلَّغ من الخادم أثناء البث كان يُعاد كنجاح بردّ فارغ؛ الآن يُرمى (`serverReported`) |
| `test/privateRoutingEgress.test.ts`, `privateRoutingEgressRetry.test.ts`, `helpers/setPrivacyRetryTestEnv.ts` (جديدة) | اختبارات GAP-1 (15) |
| `test/cloudEgressGuard.test.ts`, `test/cloudEgressMission.test.ts` (جديدتان) | اختبارات GAP-1B (29) |
| `e2e/gap1b-local-provider-unavailable-flow.mjs` (جديد) | e2e بـChromium حقيقي + خادم حقيقي + مزوّدين وهميين |

## 3) المُتحقَّق منه مقابل المعلّق

**VERIFIED (ضمن حدود: مزوّدات وهمية، نسخة مستعادة، Node 22.22، Chromium 141 headless)**
- اختبارات إعادة الإنتاج الخمسة 5/5؛ اختبارات GAP-1 المضافة 15/15؛ اختبارات GAP-1B المضافة 29/29؛ المجموعة الكاملة 546/546 (0 فشل، 0 ملغى)؛ `tsc` ومفحص البناء exit 0؛ اختبارات الطفرات 13/13 أُسقطت (والملفات أُعيدت مطابقة بايت-ببايت).
- لا خروج سحابي (عدّاد طلبات المزوّد الوهمي = 0 مع ضابط يُثبت أن العدّاد حيّ) في: Verifier وEvaluationEngine وgenome وfreshness (check/refresh/scan) تحت LOCAL_ONLY/PRIVATE، وفي مسار المهام/المجلس.
- الواجهة: `local_provider_unavailable` تُظهر رسالة مفهومة، بلا نجاح كاذب، بلا إعادة توجيه تلقائية للسحابة (e2e: VALID 5/5, PS 8/8) — على مستوى استدعاء دوال الصفحة، لا نقرات واجهة كاملة.
- الرقعة الكاملة تُطبَّق نظيفة على checkout نقي من `cbdc898`.

**PARTIAL**
- وسم المهمة المقيّدة: في الذاكرة فقط (يضيع عند إعادة التشغيل؛ مفتاحه `taskId`).
- تحديث نضارة عناصر الذاكرة (memory-item freshness): لا وسم خصوصية للعنصر.

**PENDING (قرار مالك مطلوب)**
- **D1.3**: تصميم فقط (`docs/D1.3-DESIGN.md`)؛ لا تنفيذ. لا مسار سماح في هذا الإصدار.
- `reflect/synthesize/planner` داخل المهام، والمسارات السحابية الصريحة (`webResearch`/Gemini، `embeddingsService`، `benchmarkTasks`).

**UNVERIFIED**
- Ollama الحقيقي؛ حجب خروج شبكي حقيقي؛ vitest (فشل `ERR_MODULE_NOT_FOUND` — انظر `B-evidence/vitest-attempt.log`)؛ سكربتات e2e الـ14 الموجودة مسبقاً؛ إعادة المحاولة داخل المحوّلات (adapter-internal).

**BLOCKED**
- تطبيق الرقعة على مستودع المالك الحي المحلي (لا وصول من هذه الجلسة).

## 4) أوامر إعادة التشغيل

```bash
cd <repo-root>/src-baseline/nexus-backend
npm i --no-save tsx typescript @types/node          # tsx/typescript غير مُصرَّحَين كـdevDependencies
# اختبارات مستهدفة
npx tsx --test test/privateRoutingEgress.test.ts test/privateRoutingEgressRetry.test.ts
npx tsx --test test/cloudEgressGuard.test.ts test/cloudEgressMission.test.ts
# المجموعة الكاملة (المتوقع: 546 ناجح / 0 فاشل)
npx tsx --test 'test/**/*.test.ts' 'test/*.test.ts'
# فحص الأنواع
npx tsc -p tsconfig.json --noEmit ; npx tsc -p tsconfig.build.json --noEmit
# e2e الواجهة (يحتاج Chromium/Playwright)
node <repo-root>/e2e/gap1b-local-provider-unavailable-flow.mjs
# التحقق من قابلية تطبيق الرقعة على checkout نقي لـcbdc898
git apply --check B-evidence/patches/FULL-CHANGES-incl-new-files.patch
```
> اختبار إعادة الإنتاج الخمسة: `B-evidence/zz-repro-private-mode-fallback.test.ts` يُنسخ مؤقتاً إلى `test/` ثم يُشغَّل ثم يُحذف.
> الأوامر الدقيقة المنفَّذة ونتائجها: `TEST-EVIDENCE.md` + `B-evidence/final/*.log`.

## 5) قرارات غير محسومة (تحتاج المالك)

1. نطاق التلويث (taint) داخل المهام: هل يشمل `reflect/synthesize/planner`؟
2. D1.3: مصدر الهوية/الأدوار، تصنيف البيانات، مخزن الموافقات `egress_approvals`، مدة الاحتفاظ بالتدقيق.
3. تخزين وسم المهمة المقيّدة بشكل دائم (جدول) بدل الذاكرة؟
4. صياغة تلميح الواجهة "جرّب التبديل إلى <مزوّد>" (يدوي فقط؛ لا إعادة إرسال تلقائية).
5. المسارات السحابية الصريحة (`webResearch`/Gemini، embeddings، benchmarkTasks).
6. commit/push (لم يُقرَّر).

## 6) الخطوة الوحيدة المسموحة تالياً

انتظر قرار المالك الجديد. بعده: **شريحة واحدة صغيرة** على بند واحد من §5 → INSPECT→MAP→DIAGNOSE→PATCH→TEST→VERIFY→DOCUMENT → **توقّف**.

## 7) ممنوعات صريحة

- لا تبدأ من الصفر ولا تُعِد تنفيذ ما اكتمل (GAP-1، GAP-1B، فحص الواجهة)؛ أعد فقط تشغيل التحقق عند الحاجة.
- لا commit ولا push ولا GAP-2 ولا عميل MCP بدون قرار جديد من المالك.
- لا تُضعف أو تحذف اختباراً لإنجاح تغيير؛ لا تستخدم "DONE".
- لا تنسب نتائج المزوّدات الوهمية إلى Ollama الحقيقي أو الإنتاج.
- لا تدّعِ الوصول إلى مستودع المالك الحي، ولا تعتمد GitHub مصدراً.
- لا تُعلن "NEXUS آمن للخصوصية" — الأدلة الحالية لا تدعم ذلك.
