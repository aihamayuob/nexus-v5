# TEST-EVIDENCE — ما نُفِّذ فعليًا وما لم يُنفَّذ

التاريخ: 2026-10-19 · HEAD الأساس `cbdc898a…` · Node v22.22.0 · **كل النتائج من جلسة 2026-10-19** (لا من سجلات تاريخية)، مزودون وهميون، نسخة مستعادة. السجلات الخام في `B-evidence/final/`.

## A. نُفِّذ ونجح (أو أُسقط كما هو متوقع)

| # | الفحص | الأمر (من `src-baseline/nexus-backend` ما لم يُذكر) | النتيجة | السجل |
|---|---|---|---|---|
| 1 | اختبارات إعادة الإنتاج الخمسة (GAP-1) | `npx tsx --test test/zz-repro-private-mode-fallback.test.ts (ملف مؤقت يُنسخ من evidence/ ثم يُحذف)` | 5/5 تنجح | `B-evidence/final/1-repro-5.log` |
| 2 | اختبارات GAP-1 المضافة | `npx tsx --test test/privateRoutingEgress.test.ts test/privateRoutingEgressRetry.test.ts` | 15/15 تنجح | `B-evidence/final/2-gap1-new-15.log` |
| 3 | اختبارات GAP-1B (حارس + mission + council) | `npx tsx --test test/cloudEgressGuard.test.ts test/cloudEgressMission.test.ts` | 29/29 تنجح (24 + 5) | `B-evidence/final/3-gap1b-new.log` |
| 4 | الحزمة الكاملة للـbackend | `npx tsx --test test/**/*.test.ts test/*.test.ts` | 546/546 تنجح، 0 فشل | `B-evidence/final/4-full-suite.log` |
| 5 | فحص الأنواع | `npx tsc -p tsconfig.json --noEmit ; npx tsc -p tsconfig.build.json --noEmit` | typecheck-exit=0; build-typecheck-exit=0 | `B-evidence/final/5-typecheck.log` |
| 6 | e2e الواجهة+الخلفية الحقيقية (بعد إصلاح الواجهة) | `node e2e/gap1b-local-provider-unavailable-flow.mjs (يتطلب playwright + Chromium)` | ACCEPTED — VALID 5/5، PS 8/8 | `B-evidence/final/6-ui-e2e.log` |
| 7 | نفس e2e قبل إصلاح الواجهة (إثبات العيب) | `نفس الأمر على الواجهة غير المعدّلة` | REJECTED — PS 6/8 (U3/U4 فشلا: رد فارغ كنجاح) | `B-evidence/final/6-ui-e2e-BEFORE-frontend-fix.log` |

### طفرات (mutation) — كل طفرة تُدخل عيبًا واحدًا ثم تُعاد الملفات متطابقة بايتًا (`cmp`)

| الطفرة | ناجح | فاشل (المطلوب ≥1) |
|---|---|---|
| G1-M1-router-no-local-only-filter | 3 | 12 |
| G1-M2-no-error-wrap | 8 | 7 |
| G1B-M1-guard-always-allows | 10 | 19 |
| G1B-M10-freshness-check-guard-removed | 27 | 2 |
| G1B-M11-council-no-taskid | 28 | 1 |
| G1B-M2-no-mode-taint | 26 | 3 |
| G1B-M3-no-local-provider-taint | 28 | 1 |
| G1B-M4-genome-guard-removed | 26 | 3 |
| G1B-M5-refresh-guard-removed | 28 | 1 |
| G1B-M6-mission-no-taskid | 27 | 2 |
| G1B-M7-evaluation-guard-removed | 26 | 3 |
| G1B-M8-verifier-guard-removed | 19 | 10 |
| G1B-M9-eval-route-drops-privacymode | 27 | 2 |

النتيجة: 13 طفرة، 13 أُسقطت. السجلات: `B-evidence/final/mutations/`. ملاحظة منهجية: أول ظهور لـG1B-M2 (حذف وسم الوضع) **نجا** لأن وسم المزود المحلي كان يغطي الحالة نفسها، فقوّيتُ اختبارين قائمين (كلٌّ يتحقق الآن من سبب الرفض المسجَّل في التدقيق) وأضفتُ اختباراً واحداً لطلب يفشل في التوجيه قبل اختيار المزوّد، حتى أُسقطت.

## B. لم يُنفَّذ أو لم يُتحقَّق منه (لا تعتبره ناجحًا)

| البند | الحالة | السبب |
|---|---|---|
| Ollama / LM Studio حقيقي | UNVERIFIED | كل المحلّي في الاختبارات خوادم HTTP وهمية |
| حجب شبكي فعلي (جدار ناري/عزل) | UNVERIFIED | الإثبات بعدّاد الطلبات على خادم سحابي وهمي فقط |
| بيئة إنتاج / المستودع الحي | BLOCKED/UNVERIFIED | لا وصول؛ نسخة مستعادة فقط |
| vitest للواجهة (`frontend/modules/*.test.mjs`) | UNVERIFIED | vitest غير مثبّت (`ERR_MODULE_NOT_FOUND`) — السجل `B-evidence/vitest-attempt.log` |
| 14 سكربت e2e القائمة (`e2e/*.mjs` عدا الجديد) | UNVERIFIED | لم تُشغَّل؛ التعديل في `callClaude` (بثّ الأخطاء) لم يُفحص ضدها |
| واجهة المستخدم الرسومية (النقر/الـtoast) | UNVERIFIED | استُدعيت دوال الصفحة مباشرة لا الأزرار |
| إعادة المحاولة داخل محوّلات المزودين للمسارات الأربعة | UNVERIFIED | لم تُفحص |
| تحمّل إعادة التشغيل (وسم المهمة) | UNVERIFIED/معروف الحد | الوسم في الذاكرة فقط |
| مسار `reflect`/`synthesize`/`planner` للمهام المختلطة | PENDING | غير مغطّى ولم يُعدَّل |
| حالات «سماح» وتعارض سياسة المدير (D1.3) | PENDING | غير منفَّذة |
