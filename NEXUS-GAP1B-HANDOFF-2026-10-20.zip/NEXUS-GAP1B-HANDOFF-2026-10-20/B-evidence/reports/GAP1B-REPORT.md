# تقرير GAP-1B — إغلاق مسارات الخروج السحابي الداخلية المباشرة

التاريخ: 2026-10-19 · الفرع `v5.0-polish` · HEAD الأساس `cbdc898a3ba605211d9791979a6415f314ba1c8f` (العمل غير مُسجَّل بـcommit) · **الحالة الإجمالية: PARTIAL**
الأدلة: [تشغيل] = نُفِّذ في هذه الجلسة وسجله في `evidence/` · [قراءة] = قراءة كود · [استنتاج].
كل الاختبارات بـ**مزودين وهميين** على نسخة مستعادة، Node v22.22.0. لا شيء منها يثبت سلوكًا على Ollama حقيقي أو شبكة حقيقية أو بيئة إنتاج.

## 1. جرد المسارات الأربعة (كما طلب المالك)

| المسار | الموضع [قراءة] | المزود | ما يُرسَل | إعادة محاولة/احتياط في موضع الاستدعاء | قبل | بعد GAP-1B |
|---|---|---|---|---|---|---|
| Verifier | `orchestrator/verifier.ts` (يُستدعى من `missionRunner.ts` ×2 و`councilRunner.ts` ×2) | anthropic ثابت | السؤال/الهدف + المخرَج الكامل | لا `resilientCall` ولا احتياط؛ مهلة `judgeCallTimeoutMs`؛ يفشل مفتوحًا (`unavailable`) | يتجاهل الخصوصية كليًا | يرفض عند نطاق مقيَّد ويعيد `ran:false, blockedReason:'cloud_egress_denied'` دون استدعاء سحابي |
| EvaluationEngine | `evaluation/evaluationEngine.ts` (من `routes/v2/evaluation.ts` و`webResearch.ts`) | anthropic ثابت | الادعاء + الأدلة المعلنة | كما أعلاه | يتجاهل | يرفض عند `privacyMode`/`taskId` مقيَّد؛ نتيجة `ran:false` بتعليل صريح |
| agentGenome (judge) | `evolution/agentGenome.ts` | anthropic ثابت | وصف الوكيل + system prompt + رسائل إخفاقات حديثة | كما أعلاه | يتجاهل | يرفض (403 `cloud_egress_denied`) إن كان `def.models` ∈ {LOCAL_ONLY, PRIVATE} |
| freshnessEngine (classifier + comparison + research) | `knowledge/freshnessEngine.ts` | anthropic ثابت + Gemini (بحث الويب في `refresh`) | محتوى عنصر الذاكرة | كما أعلاه | يتجاهل | يرفض (403) عند `privacyMode` مقيَّد قبل أي اتصال، بما فيه بحث Gemini |

لم أفحص إعادة المحاولة داخل المحوّلات (adapters) نفسها لهذه المسارات — **UNVERIFIED**.

## 2. الإصلاح (نقطة اختناق واحدة)

`src/security/cloudEgressGuard.ts` (جديد). النطاق **المقيَّد** = أي مما يلي: (أ) `privacyMode` ∈ {LOCAL_ONLY, PRIVATE} يرفقه المستدعي (حقل طلب يمكنه **التقييد فقط**)؛ (ب) وكيل معلَن `models` ∈ {LOCAL_ONLY, PRIVATE}؛ (ج) مهمة (`taskId`) سبق أن نفّذت استدعاء محادثة بوضع خصوصية أو بمزود محلي أساسي (يوسمها `chatService.runChatCompletion` **قبل** التوجيه). في النطاق المقيَّد: **رفض دائمًا — لا مسار موافقة** (D1.3 غير منفَّذ، انظر `D1.3-DESIGN.md`). كل رفض يُسجَّل في `audit_log` بالحقول `{purpose, provider, reason, taskId, decision}` + الطابع الزمني، **بلا أي محتوى** [تشغيل: `assertAuditHasNoContent` في الاختبارات].

التعديلات المرتبطة: `errors.ts` (رمز `cloud_egress_denied` بحالة 403 غير قابل لإعادة المحاولة)، `verifier.ts`, `evaluationEngine.ts`, `agentGenome.ts`, `freshnessEngine.ts`, `missionRunner.ts`/`councilRunner.ts` (تمرير `taskId`، ونص جولة التحقق في المجلس يميّز «مُنع» عن «غير مهيأ»)، `routes/v2/evaluation.ts` و`knowledgeFreshness.ts` (حقل اختياري `privacyMode`).

## 3. الأدلة المنفَّذة

| الفحص | الأمر (من `src-baseline/nexus-backend`) | النتيجة [تشغيل] |
|---|---|---|
| اختبارات إعادة إنتاج GAP-1 الخمسة | `npx tsx --test test/zz-repro-private-mode-fallback.test.ts` (النسخة المحفوظة في `evidence/`) | 5/5 تنجح |
| اختبارات GAP-1 المضافة | `npx tsx --test test/privateRoutingEgress.test.ts test/privateRoutingEgressRetry.test.ts` | 15/15 |
| اختبارات GAP-1B الجديدة | `npx tsx --test test/cloudEgressGuard.test.ts test/cloudEgressMission.test.ts` | 29/29 |
| الحزمة الكاملة | `npx tsx --test test/**/*.test.ts test/*.test.ts` | **546/546** (502 أساس أصلي + 15 اختبار GAP-1 = 517 في الجلسة السابقة، + 29 اختبار GAP-1B) |
| فحص الأنواع | `npx tsc -p tsconfig.json --noEmit` و`tsconfig.build.json` | exit 0 / exit 0 |
| e2e حقيقي (Chromium + خلفية حقيقية + مزودان وهميان) | `node e2e/gap1b-local-provider-unavailable-flow.mjs` | ACCEPTED (VALID 5/5، PS 8/8)؛ قبل إصلاح الواجهة: REJECTED (PS 6/8) |
| الطفرات | 13 طفرة موثّقة في `evidence/mutations/` | كل طفرة أُسقطت (≥1 اختبار يفشل)؛ الملفات استُعيدت متطابقة بايتًا |

مصفوفة الاختبارات: أُثبت أن لكل مسار **شاهد تحكّم** (control) يسجّل أن الطلب يصل إلى عدّاد الخروج حين يكون مسموحًا، وأن «0 طلبات» لا تعني عدّادًا أعمى.
اختبرتُ: فشل المزود المحلي + رفض السحابة (Verifier مع مهمة وُسمت بعد فشل محلي)، وفشل التحقق/التقييم (`ran:false`)، ومسارات الخطأ، ومحاولات التجاوز عبر API (حقول `allowCloud`/`cloudFallback`/`approved`… وترويسات `x-nexus-allow-cloud`)، وعدم الإفراط في المنع (مهمة سحابية تُتحقق كالمعتاد)، ومهمة فشل توجيهها قبل اختيار مزود (وُسمت بالنية).

## 4. اكتشافات جديدة (لم تكن في القائمة)

1. **عيب في الواجهة (مثبت بالتنفيذ، مُصلَح):** حدث SSE `error` من الخادم كانت الواجهة «تستأنف» بعده، فيعود بثّ فارغ وتُرجع `callClaude` رد نص فارغ **كأنه نجاح** (الخطأ يسجّل رقم الحدث قبل أن يُرمى، فيستأنف من بعده فلا يجد شيئًا). أثره على الخصوصية: مستخدم يطلب نموذجًا محليًا متوقفًا يرى ردًا فارغًا بدل رسالة الخطأ. الإصلاح: وسم خطأ الخادم `serverReported` وعدم استئنافه (سطران فعليان في `callClaude`). وهو عيب سابق للوجود (يمسّ كل أخطاء الخادم في البث) وليس خاصًا بالخصوصية.
2. **مسارات داخل المهمة لم أغيّرها (PENDING — قرار مالك):** في `agentDagRunner` استدعاءات `reflect` و`synthesize` تستعمل وضع الوكيل `supervisor` (حاليًا BEST) وتستلم مخرجات وكلاء قد يكونون LOCAL_ONLY/PRIVATE؛ و`planner` يرسل هدف المهمة إلى مزود BEST. أي أنه لا وجود لوضع خصوصية على مستوى المهمة نفسها. توسيع «التلوّث» ليمنع هذه الاستدعاءات سيغيّر سلوك المهام القائمة، فتركته قرارًا مستقلًا. **هذا يعني أن إغلاق مسارات المراجعة لا يجعل المهمة المختلطة آمنة للخصوصية.**
3. تأكدتُ أن `80c558a` سلف لـHEAD (`cbdc898` بعده بـ4 commits)؛ المرجع الفعلي HEAD.

## 5. الحالات (الكلمات المسموحة فقط)

| البند | الحالة | الأساس |
|---|---|---|
| منع الخروج السحابي في LOCAL_ONLY/PRIVATE لمسار المحادثة بما فيه الاحتياط وإعادة المحاولة (GAP-1) | VERIFIED ضمن النطاق: مزودون وهميون، نسخة مستعادة | اختبارات GAP-1 + طفرات |
| Verifier/EvaluationEngine/genome/freshness لا تتجاوز النطاق المقيَّد | VERIFIED ضمن النطاق نفسه | اختبارات GAP-1B + طفرات + اختبار mission/council حقيقي |
| وسم «تلوّث» المهمة | PARTIAL | في ذاكرة العملية فقط؛ يضيع عند إعادة التشغيل؛ مفتاحه `taskId`؛ لا يغطي ما لا `taskId` له |
| عناصر الذاكرة (freshness) | PARTIAL | لا وسم خصوصية للعنصر؛ لا يقيَّد إلا بإشارة المستدعي |
| reflect/synthesize/planner داخل المهمة | PENDING | قرار مالك (القسم 4-2) |
| مسارات مسمّاة صريحًا لمزود سحابي: `webResearch` (Gemini)، `embeddingsService`، `benchmarkTasks`، `planner` | PENDING | خارج نطاق الأربعة؛ `healthRegistry` بلا محتوى |
| D1.3 (سياسة المدير + موافقة المهمة) | PENDING | تصميم فقط؛ لا هوية/أدوار في المستودع |
| معالجة الواجهة لـ`local_provider_unavailable` | VERIFIED ضمن النطاق: Chromium 141 headless، خلفية حقيقية، مزودون وهميون | e2e (بعد الإصلاح) |
| مسار الخروج الشبكي الحقيقي (Ollama حقيقي / حظر شبكة فعلي) | UNVERIFIED | لم يُنفَّذ |
| تطبيق الرقعة على «المستودع المحلي الفعلي» | BLOCKED | لا وصول إلى مستودع المالك الحي من هذه الجلسة؛ الرقعة مطبَّقة على النسخة المستعادة فقط وتتطبّق على HEAD النقي (`git apply --check` OK) |
| اختبارات الواجهة vitest و14 سكربت e2e القائمة | UNVERIFIED | vitest غير مثبّت في البيئة؛ السكربتات القائمة لم تُشغَّل |
| «NEXUS آمن للخصوصية عمومًا» | **لا يُدّعى** | القسم 4-2 وبنود PENDING أعلاه |

## 6. تغييرات سلوك العقود (للمراجعة)

- `POST /v2/knowledge-freshness/items/:id/check` و`/checks/:id/refresh` أصبحا يقرآن جسم الطلب (اختياري). جسم JSON **مشوَّه** كان يُتجاهل سابقًا فصار 400 (حد جديد صغير). جسم غائب: كما كان (مُختبَر).
- `POST /v2/evolution/agents/:id/propose` قد يعيد 403 `cloud_egress_denied` لوكيل معلَن خصوصي (جديد).
- `POST /v2/evaluation/claim` يقبل `privacyMode` اختياريًا؛ عند التقييد يعيد 200 مع `ran:false` (لا خطأ).
- `Verifier.verify` / `EvaluationEngine.evaluate` / `checkFreshness` / `refreshStaleItem` / `scanForStaleness`: معامل اختياري أخير — متوافق للخلف.
- رد `/api/chat` عند فشل المحلي: 503 `local_provider_unavailable` (من GAP-1).

## 7. المخاطر المتبقية

وسم المهمة غير دائم؛ `audit_log` قابل للتقليم؛ لا تصنيف بيانات؛ الواجهة تقترح يدويًا «جرّب التبديل إلى <مزود>» بعد فشل (نص إرشادي لا يعيد الإرسال) وقد يكون المزود المقترح سحابيًا — ينبغي مراجعة هذا النص إن كان الهدف تجنب الدفع نحو السحابة؛ الواجهة تعيد المحاولة على 5xx (كلها محلية، لا ضرر خصوصية).
