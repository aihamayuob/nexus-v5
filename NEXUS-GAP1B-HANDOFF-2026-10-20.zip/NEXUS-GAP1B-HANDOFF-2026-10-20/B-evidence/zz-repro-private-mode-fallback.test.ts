// SCRATCH REPRO — not part of the repository, never to be committed.
// Question under test: in LOCAL_ONLY / PRIVATE routing mode, can a request that was
// meant to stay on a local provider be sent to a CLOUD provider when the local one fails?
import './helpers/setFallbackTestEnv.js';
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { createServer, type Server } from 'node:http';
import { createNexusServer } from '../src/gateway/server.js';
import { selectProviderForMode } from '../src/providers/routingModes.js';
import { runChatCompletion } from '../src/orchestrator/chatService.js';
import { TaskObservability } from '../src/observability/recorder.js';
import { ProviderRegistry } from '../src/config/providerRegistry.js';
import { startFakeAnthropicServer } from './helpers/fakeAnthropicServer.js';
import type { GatewayContext } from '../src/capability/permissionModel.js';

const ctx: GatewayContext = { authenticated: true, clientKey: 'repro', projectId: null, userId: null };

let nexus: Server;
let brokenLocal: Server;
let cloud: Awaited<ReturnType<typeof startFakeAnthropicServer>>;

function listen(s: Server): Promise<string> {
  return new Promise((resolve) =>
    s.listen(0, '127.0.0.1', () => {
      const a = s.address();
      resolve(`http://127.0.0.1:${typeof a === 'object' && a ? a.port : 0}`);
    })
  );
}

before(async () => {
  // Local provider (ollama): configured, but ALWAYS fails with a retryable 503.
  brokenLocal = createServer((_req, res) => {
    res.writeHead(503, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'local model server down' }));
  });
  process.env.NEXUS_OLLAMA_BASE_URL = await listen(brokenLocal);
  process.env.NEXUS_MODEL_OLLAMA = 'llama3.1';

  // Cloud provider (anthropic): healthy, and it RECORDS every request it receives.
  cloud = await startFakeAnthropicServer({ respond: () => ({ text: 'cloud answered', stopReason: 'end_turn' }) });
  process.env.NEXUS_ANTHROPIC_BASE_URL = cloud.url;
  process.env.NEXUS_ANTHROPIC_API_KEY = 'fake-anthropic-key';

  nexus = createNexusServer(); // initialises DB/repos exactly as the real suites do (not listening)
});

after(async () => {
  await Promise.all([
    new Promise((r) => brokenLocal.close(r)),
    new Promise((r) => cloud.server.close(r)),
    new Promise((r) => nexus.close(r)),
  ]);
});

for (const mode of ['LOCAL_ONLY', 'PRIVATE'] as const) {
  test(`[${mode}] the routed fallback chain contains ONLY local providers`, async () => {
    const routed = await selectProviderForMode({ mode });
    const nonLocalFallbacks = routed.fallbacks.filter((id) => !ProviderRegistry.resolve(id).capabilities.isLocal);
    console.log(`# [${mode}] primary=${routed.provider} fallbacks=${JSON.stringify(routed.fallbacks)} nonLocalFallbacks=${JSON.stringify(nonLocalFallbacks)}`);
    assert.equal(routed.provider, 'ollama');
    assert.deepEqual(nonLocalFallbacks, [], 'a privacy-restricted mode must never list a cloud provider as a fallback');
  });

  test(`[${mode}] end-to-end: when the local provider fails, NO request may reach a cloud provider`, async () => {
    const before = cloud.requestLog.length;
    let outcome = 'unknown';
    let provider = '';
    try {
      const r = await runChatCompletion(
        { mode, maxTokens: 50, messages: [{ role: 'user', content: 'CONFIDENTIAL-MARKER-7f3a: summarise this private note' }], route: 'chat', taskId: `repro-${mode}` },
        ctx,
        new TaskObservability(`repro-${mode}`, 'chat')
      );
      outcome = 'succeeded';
      provider = r.providerUsed;
    } catch (e) {
      outcome = `threw: ${(e as Error).message.slice(0, 80)}`;
    }
    const received = cloud.requestLog.slice(before) as Array<{ messages?: Array<{ content: unknown }> }>;
    const leaked = received.some((b) => JSON.stringify(b).includes('CONFIDENTIAL-MARKER-7f3a'));
    console.log(`# [${mode}] outcome=${outcome} providerUsed=${provider || '-'} cloudRequestsReceived=${received.length} markerReachedCloud=${leaked}`);
    assert.equal(received.length, 0, 'the cloud provider received a request that was supposed to stay local');
  });
}

// The realistic path: a user explicitly picks the LOCAL provider (USER_SELECTED) through the
// public chat endpoint the real frontend uses, for privacy reasons, while the local server is down.
test('[HTTP /api/chat provider=ollama] explicit local choice: when local is down, NO request may reach a cloud provider', async () => {
  const url = await listen(nexus);
  const before = cloud.requestLog.length;
  const res = await fetch(`${url}/api/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ provider: 'ollama', max_tokens: 50, messages: [{ role: 'user', content: 'CONFIDENTIAL-MARKER-9c1d: private note' }] }),
  });
  const received = cloud.requestLog.slice(before);
  const leaked = received.some((b) => JSON.stringify(b).includes('CONFIDENTIAL-MARKER-9c1d'));
  console.log(`# [HTTP provider=ollama] status=${res.status} cloudRequestsReceived=${received.length} markerReachedCloud=${leaked}`);
  assert.equal(received.length, 0, 'user explicitly chose a local provider, yet the cloud received the request');
});
