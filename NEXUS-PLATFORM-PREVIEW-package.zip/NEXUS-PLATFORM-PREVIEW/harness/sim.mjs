// SIMULATION HARNESS (not part of NEXUS source). Fake Ollama-protocol server = SIMULATION, not a real model.
import http from 'node:http';
import net from 'node:net';
import { spawn } from 'node:child_process';
import { readFile } from 'node:fs/promises';
import path from 'node:path';

import { fileURLToPath } from 'node:url'; export const W = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const freePort = () => new Promise((res) => { const s = net.createServer(); s.listen(0, '127.0.0.1', () => { const p = s.address().port; s.close(() => res(p)); }); });
export const listen = (s, port, host = '127.0.0.1') => new Promise((r) => s.listen(port, host, r));

export function startFakeOllama({ failMode } = {}) {
  const state = { hits: 0, bodies: [], mode: failMode || 'ok', delayMs: 0 };
  const server = http.createServer(async (req, res) => {
    const chunks = []; for await (const c of req) chunks.push(c);
    const raw = Buffer.concat(chunks).toString('utf8');
    state.hits++;
    if (req.url === '/api/tags') { res.writeHead(200, { 'content-type': 'application/json' }); return res.end(JSON.stringify({ models: [{ name: 'sim-model' }] })); }
    if (req.url === '/api/chat') {
      let body = {}; try { body = JSON.parse(raw); } catch {}
      state.bodies.push(body);
      if (state.mode === 'down') { res.writeHead(503, { 'content-type': 'application/json' }); return res.end('{"error":"sim down"}'); }
      if (state.delayMs) await new Promise((r) => setTimeout(r, state.delayMs));
      const last = (body.messages || []).filter((m) => m.role === 'user').pop();
      const userText = typeof last?.content === 'string' ? last.content : JSON.stringify(last?.content ?? '');
      const text = `[SIMULATION — fake local model] تم استلام: ${userText.slice(0, 80)}`;
      if (body.stream) {
        res.writeHead(200, { 'content-type': 'application/x-ndjson' });
        for (const part of text.match(/.{1,12}/gs)) res.write(JSON.stringify({ message: { role: 'assistant', content: part }, done: false }) + '\n');
        return res.end(JSON.stringify({ message: { role: 'assistant', content: '' }, done: true, prompt_eval_count: 11, eval_count: 7 }) + '\n');
      }
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ message: { role: 'assistant', content: text }, done: true, prompt_eval_count: 11, eval_count: 7 }));
    }
    res.writeHead(404); res.end();
  });
  return { server, state };
}

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.json': 'application/json', '.png': 'image/png', '.svg': 'image/svg+xml' };
export function startStatic(dir, htmlFile) {
  return http.createServer(async (req, res) => {
    try {
      const u = new URL(req.url, 'http://x'); let p = decodeURIComponent(u.pathname);
      if (p === '/') p = '/' + htmlFile;
      const fp = path.join(dir, p); if (!fp.startsWith(dir)) throw new Error('traversal');
      const b = await readFile(fp);
      res.writeHead(200, { 'content-type': MIME[path.extname(fp)] || 'application/octet-stream' }); res.end(b);
    } catch (e) { res.writeHead(404); res.end('not found'); }
  });
}

export async function startBackend({ port, env }) {
  const be = spawn('node', ['--experimental-sqlite', '--enable-source-maps', 'dist/index.js'], { cwd: W + '/backend', env: { ...process.env, NEXUS_PORT: String(port), ...env } });
  let log = ''; be.stdout.on('data', (d) => (log += d)); be.stderr.on('data', (d) => (log += d));
  for (let i = 0; i < 50; i++) { if (log.includes('listening')) break; await new Promise((r) => setTimeout(r, 200)); }
  return { proc: be, getLog: () => log };
}
