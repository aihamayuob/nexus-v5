// UI E2E scenario against the REAL frontend + REAL backend, with a SIMULATED local model (fake Ollama protocol server).
import { chromium, devices } from 'playwright';
import { startFakeOllama, startBackend, startStatic, freePort, listen, W } from './sim.mjs';
import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path';
const SHOTS = process.argv[2]; const OUT = process.argv[3];
const KEY = 'sim-ui-gateway-key-7Hq2Zx9LmP4vT8nB';
const SECRET = 'sim-SECRET-openai-key-DO-NOT-LEAK-5521'; const SECRET2 = 'sim-fake-anthropic-key-9931';
const HTML = 'neural_nexus_ai_agents-4-3-5-3.html';
const results = []; const t = (vp, name, ok, detail = '') => { results.push({ viewport: vp, name, ok: !!ok, detail: String(detail).slice(0, 300) }); console.log(`[${ok ? 'PASS' : 'FAIL'}] [${vp}] ${name}${detail ? ' — ' + String(detail).slice(0, 200) : ''}`); };
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'nexus-ui-'));
const fo = startFakeOllama(); const oport = await freePort(); await listen(fo.server, oport);
const cloud = { hits: [] }; const fakeCloud = (await import('node:http')).createServer(async (req, res) => { const ch = []; for await (const c of req) ch.push(c); const body = Buffer.concat(ch).toString('utf8'); cloud.hits.push({ url: req.url, hasUserText: body.includes('لخّص لي') || body.includes('سؤال ثان'), bytes: body.length }); res.writeHead(200, { 'content-type': 'application/json' }); res.end(JSON.stringify({ content: [{ type: 'text', text: '{"agent_ids":["general"],"reason":"[SIMULATION fake cloud router]"}' }], stop_reason: 'end_turn', usage: { input_tokens: 5, output_tokens: 5 } })); });
const cport = await freePort(); await listen(fakeCloud, cport);
const bport = await freePort(); const sport = await freePort();
const origin = `http://127.0.0.1:${sport}`; const beUrl = `http://127.0.0.1:${bport}`;
const st = startStatic(W + '/frontend', HTML); await listen(st, sport);
const be = await startBackend({ port: bport, env: { NEXUS_GATEWAY_KEYS: KEY, NEXUS_DB_PATH: path.join(tmp, 'ui.db'), NEXUS_CORS_ORIGINS: origin, NEXUS_OLLAMA_BASE_URL: `http://127.0.0.1:${oport}`, NEXUS_MODEL_OLLAMA: 'sim-model', NEXUS_OPENAI_API_KEY: SECRET, NEXUS_OPENAI_BASE_URL: 'http://127.0.0.1:1', NEXUS_ANTHROPIC_BASE_URL: `http://127.0.0.1:${cport}`, NEXUS_ANTHROPIC_API_KEY: 'sim-fake-anthropic-key-9931' } });
const browser = await chromium.launch();
const VPS = [
  ['desktop-1440x900', { viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 }],
  ['tablet-820x1180', { viewport: { width: 820, height: 1180 }, deviceScaleFactor: 1, hasTouch: true }],
  ['android-emulated-Pixel7', { ...devices['Pixel 7'] }],
];
const netBodies = [];
for (const [vp, opts] of VPS) {
  const ctx = await browser.newContext({ ...opts, locale: 'ar-SA' });
  const page = await ctx.newPage(); const errs = []; const consoleErrs = [];
  page.on('pageerror', (e) => errs.push(String(e))); page.on('console', (m) => { if (m.type() === 'error') consoleErrs.push(m.text()); });
  page.on('response', async (r) => { if (r.status() >= 400 && r.url().startsWith(beUrl)) console.log(`[INFO] [${vp}] backend ${r.status()} ${r.request().method()} ${r.url().replace(beUrl,'')}`); try { if (r.url().startsWith(beUrl)) netBodies.push(await r.text()); } catch {} });
  const shot = async (n) => { try { await page.screenshot({ path: `${SHOTS}/${vp}__${n}.png`, fullPage: false }); } catch (e) { console.log('shot fail', n, e.message); } };
  const mobileOverflow = () => page.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
  // 1. open platform
  await page.goto(origin + '/', { waitUntil: 'networkidle' }); await page.waitForTimeout(800);
  t(vp, '01 platform opens (title + lang/dir)', /Neural Nexus|NEXUS/i.test(await page.title()), `title="${await page.title()}" dir=${await page.evaluate(() => document.documentElement.dir)} lang=${await page.evaluate(() => document.documentElement.lang)}`);
  t(vp, '01b secure context (localhost)', await page.evaluate(() => window.isSecureContext));
  t(vp, '01c no horizontal overflow at this viewport', await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), await page.evaluate(() => `sw=${document.documentElement.scrollWidth} iw=${window.innerWidth}`));
  await shot('01-home');
  // 2. before connection: state shown
  await page.evaluate(() => { closeSideMenu?.(); openSettingsPanel(); }); await page.waitForTimeout(300);
  t(vp, '02 settings opens & shows connection mode', (await page.locator('#connectionModeLabel').innerText()).length > 0, await page.locator('#connectionModeLabel').innerText());
  await shot('02-settings-before');
  // 3. connect backend
  await page.fill('#backendUrlInput', beUrl); await page.fill('#gatewayKeyInput', KEY); await page.evaluate(() => saveBackendUrl()); await page.waitForTimeout(500);
  t(vp, '03 backend URL saved', (await page.evaluate(() => localStorage.getItem('nexus_backend_url'))) === beUrl);
  const keyInLS = await page.evaluate((k) => { const all = []; for (let i = 0; i < localStorage.length; i++) { const kk = localStorage.key(i); all.push(kk + '=' + localStorage.getItem(kk)); } for (let i = 0; i < sessionStorage.length; i++) { const kk = sessionStorage.key(i); all.push('S:' + kk + '=' + sessionStorage.getItem(kk)); } return all.join('\n').includes(k); }, KEY);
  t(vp, '03b gateway key storage location (INFO: where does the browser keep it)', true, `gateway key present in local/sessionStorage plaintext=${keyInLS}`);
  await page.evaluate(() => closeModal('settingsModal'));
  await page.evaluate(() => { if (typeof setSimpleMode === 'function') setSimpleMode(false); else if (typeof toggleSimpleMode === 'function') toggleSimpleMode(); });
  await page.waitForTimeout(300);
  // 4. choose local provider
  const hasSel = await page.locator('#chatModelSelect').count();
  if (hasSel) { await page.evaluate(() => { const s = document.getElementById('chatModelSelect'); s.value = 'ollama'; saveChatModelSetting(); }); await page.waitForTimeout(300); await page.evaluate(() => { const i = document.getElementById('localModelNameInput'); if (i) { i.value = 'sim-model'; saveLocalModelSetting(); } }); }
  t(vp, '04 provider ollama selected (local sovereignty badge)', (await page.evaluate(() => localStorage.getItem('nexus_chat_model'))) === 'ollama', await page.evaluate(() => `badgeDisplay=${document.getElementById('sovereigntyBadge')?.style.display}`));
  { const o = await mobileOverflow(); t(vp, '04b FINDING F-UI-2 probe: horizontal overflow in advanced mode with local provider selected', true, `scrollWidth=${o.sw} clientWidth=${o.cw} overflow=${o.sw > o.cw + 1}`); }
  await shot('03-advanced-local-selected');
  // 5-6. send message with DEFAULT auto-route ON (as shipped) while LOCAL provider selected
  const sendMsg = async (txt) => { await page.fill('#msgInput', txt); let how = 'click'; try { await page.click('#sendBtn', { timeout: 4000 }); } catch (e) { how = 'JS sendMessage() fallback (click intercepted)'; await page.evaluate(() => sendMessage()); } return how; };
  const cloudBefore = cloud.hits.length; const ollBefore = fo.state.hits;
  const how1 = await sendMsg('مرحبا، لخّص لي دور وكلاء نكسس'); await page.waitForTimeout(4500);
  const chat1 = await page.evaluate(() => document.getElementById('chatArea')?.innerText ?? '');
  t(vp, '05 user message rendered in chat', chat1.includes('لخّص لي'), `send via ${how1}`);
  const egress = cloud.hits.length - cloudBefore;
  t(vp, '05b FINDING F-UI-1 probe: with LOCAL provider selected + default auto-route, does the user text reach the CLOUD provider adapter?', true, `cloud-adapter requests=${egress} (userTextInBody=${cloud.hits.slice(cloudBefore).some(h => h.hasUserText)}); ollama hits=${fo.state.hits - ollBefore}; answer-has-SIMULATION=${chat1.includes('SIMULATION')}`);
  await shot('04a-chat-autoroute-local-selected');
  // now disable auto-route (advanced mode checkbox) -> single-agent path that uses chat model
  await page.evaluate(() => { const c = document.getElementById('autoRouteToggle'); if (c) { c.checked = false; c.dispatchEvent(new Event('change', { bubbles: true })); } });
  const cloudB2 = cloud.hits.length; const ollB2 = fo.state.hits;
  const how2 = await sendMsg('سؤال ثان: ما هو دور وكيل الدعم؟'); await page.waitForTimeout(4500);
  const chat2 = await page.evaluate(() => document.getElementById('chatArea')?.innerText ?? '');
  t(vp, '06 model answer rendered with auto-route OFF (SIMULATED local model)', chat2.includes('SIMULATION'), chat2.slice(-170).replace(/\n/g, ' '));
  t(vp, '06b request went backend→fake OLLAMA, zero cloud requests (auto-route off, local selected)', fo.state.hits > ollB2 && cloud.hits.length === cloudB2, `ollama +${fo.state.hits - ollB2}, cloud +${cloud.hits.length - cloudB2}; send via ${how2}`);
  await shot('04b-chat-result-local');
  // 7. ops / evidence
  await page.evaluate(() => { try { openNexusOps(); } catch (e) {} }); await page.waitForTimeout(800);
  t(vp, '07 NEXUS Ops Center opens', await page.locator('#nexusOpsModal').evaluate((el) => getComputedStyle(el).display !== 'none'));
  await shot('05-ops-center'); await page.evaluate(() => closeModal('nexusOpsModal'));
  await page.evaluate(() => { try { openWorkspace('overview'); } catch (e) {} }); await page.waitForTimeout(600); await shot('06-workspace'); await page.evaluate(() => closeModal('workspaceModal'));
  const panels = [['dashboard','openDashboard','dashboardModal'],['activity','openActivityPanel','activityModal'],['veto-audit','openVetoAuditLog','vetoAuditModal'],['schedules','openSchedulesPanel','schedulesModal'],['knowledge','openKnowledgePanel','knowledgeModal'],['custom-agents','openCustomAgentsPanel','customAgentsModal'],['dag-live','openDagModal','dagModal'],['agent-gallery','openAgentGallery','agentGalleryModal']];
  const panelState = {};
  for (const [name, fn, id] of panels) { await page.evaluate((fn) => { try { const r = window[fn] ? window[fn]() : eval(fn + '()'); return r; } catch (e) { return String(e); } }, fn).catch(() => {}); await page.waitForTimeout(700); const open = await page.locator('#' + id).evaluate((el) => getComputedStyle(el).display !== 'none').catch(() => false); panelState[name] = open; if (open) { await shot('panel-' + name); await page.evaluate((id) => closeModal(id), id).catch(() => {}); } }
  const dashOpen = panelState.dashboard, galOpen = panelState['agent-gallery'];
  t(vp, '07b optional panels reachable (INFO)', true, JSON.stringify(panelState));
  // 8-10 persistence across reload
  const before = await page.evaluate(() => ({ model: localStorage.getItem('nexus_chat_model'), url: localStorage.getItem('nexus_backend_url'), keys: Object.keys(localStorage).length }));
  await page.reload({ waitUntil: 'networkidle' }); await page.waitForTimeout(1200);
  const after = await page.evaluate(() => ({ model: localStorage.getItem('nexus_chat_model'), url: localStorage.getItem('nexus_backend_url'), keys: Object.keys(localStorage).length, chat: document.getElementById('chatArea')?.innerText ?? '' }));
  t(vp, '08 settings persist after reload', after.model === before.model && after.url === before.url, JSON.stringify({ b: before, a: { ...after, chat: undefined } }));
  t(vp, '09 conversation persists after reload (client storage)', after.chat.includes('لخّص لي') || after.chat.includes('SIMULATION') || after.chat.includes('سؤال ثان'), after.chat.slice(0, 120).replace(/\n/g, ' '));
  await shot('09-after-reload');
  // 11. security
  const dump = await page.evaluate(() => { const o = []; for (let i = 0; i < localStorage.length; i++) o.push(localStorage.getItem(localStorage.key(i))); return o.join('\n') + document.documentElement.outerHTML; });
  t(vp, '11a provider secrets (backend env) never reach browser storage/DOM', !dump.includes(SECRET) && !dump.includes(SECRET2));
  t(vp, '11b provider secrets never in any backend response seen by browser', !netBodies.join('\n').includes(SECRET) && !netBodies.join('\n').includes(SECRET2));
  t(vp, '11c no uncaught page errors', errs.length === 0, errs.join(' | '));
  console.log(`[INFO] [${vp}] console errors: ${consoleErrs.length} ${consoleErrs.slice(0, 3).join(' || ').slice(0, 300)}`);
  await ctx.close();
}
await browser.close(); fakeCloud.close(); st.close(); be.proc.kill('SIGTERM'); fo.server.close();
fs.writeFileSync(OUT, JSON.stringify(results, null, 2));
const p = results.filter((r) => r.ok).length; console.log(`SUMMARY ${p}/${results.length}`);
process.exit(0);
