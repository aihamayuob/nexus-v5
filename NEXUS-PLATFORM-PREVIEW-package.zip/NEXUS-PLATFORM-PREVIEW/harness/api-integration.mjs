import { startFakeOllama, startBackend, freePort, listen } from './sim.mjs';
import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path';
const results = []; const t = (name, ok, detail='') => { results.push({ name, ok: !!ok, detail }); console.log(`[${ok ? 'PASS' : 'FAIL'}] ${name}${detail ? ' — ' + String(detail).slice(0, 220) : ''}`); };
const KEY = 'sim-gateway-key-0001-xxxxxxxxxxxx';
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'nexus-int-')); const DB = path.join(tmp, 'n.db');
const fo = startFakeOllama(); const oport = await freePort(); await listen(fo.server, oport);
const bport = await freePort(); const base = `http://127.0.0.1:${bport}`;
const env = { NEXUS_GATEWAY_KEYS: KEY, NEXUS_DB_PATH: DB, NEXUS_OLLAMA_BASE_URL: `http://127.0.0.1:${oport}`, NEXUS_MODEL_OLLAMA: 'sim-model', NEXUS_CORS_ORIGINS: 'http://127.0.0.1:9', NEXUS_ANTHROPIC_BASE_URL: 'http://127.0.0.1:1', NEXUS_LMSTUDIO_BASE_URL: 'http://127.0.0.1:1', NEXUS_RATE_LIMIT_PER_MINUTE: '6000', NEXUS_RATE_LIMIT_BURST: '500' };
let be = await startBackend({ port: bport, env });
const H = { authorization: `Bearer ${KEY}`, 'content-type': 'application/json' };
const j = async (method, p, body, headers = H) => { const r = await fetch(base + p, { method, headers, body: body ? JSON.stringify(body) : undefined }); let b; const txt = await r.text(); try { b = JSON.parse(txt); } catch { b = txt; } return { status: r.status, body: b, headers: r.headers }; };

let r = await j('GET', '/v2/health', null, {}); t('health (no auth)', r.status === 200 && r.body.ok, JSON.stringify(r.body));
r = await j('GET', '/v2/models', null, {}); t('auth: /v2/models without token rejected', r.status === 401, r.status);
r = await j('GET', '/v2/models', null, { authorization: 'Bearer wrong' }); t('auth: wrong token rejected', r.status === 401 || r.status === 403, r.status);
r = await j('GET', '/v2/models'); t('models list', r.status === 200 && Array.isArray(r.body.providers), `providers=${r.body.providers?.map(p=>p.id).join(',')}`);
const leak = JSON.stringify(r.body); t('no API key / secret material in /v2/models', !leak.includes(KEY) && !/sk-|api[_-]?key"\s*:\s*"[^"]+/.test(leak));
r = await j('GET', '/v2/providers/health?probe=1'); const hs = {}; for (const p of r.body.providers || []) hs[p.id || p.provider] = p.state || p.status;
t('provider health states', r.status === 200, JSON.stringify(hs));
console.log('HEALTH_RAW', JSON.stringify(r.body).slice(0, 900));
for (const mode of ['BEST','CHEAPEST','FASTEST','LOCAL_ONLY','PRIVATE']) { r = await j('POST', '/v2/route', { mode }); t(`route mode ${mode}`, r.status === 200, JSON.stringify(r.body).slice(0, 160)); }
r = await j('POST', '/v2/route', { mode: 'USER_SELECTED', provider: 'ollama' }); t('route USER_SELECTED ollama', r.status === 200 && r.body.provider === 'ollama', JSON.stringify(r.body).slice(0,160));
r = await j('POST', '/v2/route', { mode: 'USER_SELECTED', provider: 'anthropic' }); t('route USER_SELECTED anthropic (no key) → NOT_CONFIGURED-style error', r.status >= 400, `${r.status} ${JSON.stringify(r.body).slice(0,160)}`);
r = await j('POST', '/v2/route', {}); t('route without mode → validation 400', r.status === 400, r.status);
// chat non-stream
r = await j('POST', '/api/chat', { provider: 'ollama', model: 'sim-model', max_tokens: 64, messages: [{ role: 'user', content: 'مرحبا نكسس' }] });
t('chat non-stream via sim ollama', r.status === 200 && JSON.stringify(r.body).includes('SIMULATION'), JSON.stringify(r.body).slice(0, 200));
r = await j('POST', '/api/chat', { provider: 'anthropic', max_tokens: 64, messages: [{ role: 'user', content: 'x' }] }); t('chat anthropic without key → clean 4xx (no cloud call)', r.status >= 400 && r.status < 500, `${r.status} ${JSON.stringify(r.body).slice(0,150)}`);
r = await j('POST', '/api/chat', { provider: 'bogus', max_tokens: 5, messages: [{ role: 'user', content: 'x' }] }); t('chat unknown provider → 400', r.status === 400, r.status);
r = await j('POST', '/api/chat', { provider: 'ollama', messages: [] }); t('chat invalid body → 400', r.status === 400, r.status);
// chat stream
{ const rs = await fetch(base + '/api/chat', { method: 'POST', headers: H, body: JSON.stringify({ provider: 'ollama', model: 'sim-model', max_tokens: 64, stream: true, messages: [{ role: 'user', content: 'بث' }] }) }); const txt = await rs.text(); t('chat SSE stream via sim ollama (token+usage+done events)', rs.status === 200 && /event: token/.test(txt) && /event: done/.test(txt), `status=${rs.status} len=${txt.length} head=${txt.slice(0,160).replace(/\n/g,'\\n')}`); console.log('SSE_SAMPLE', txt.slice(0, 500)); }
// provider down → error path
fo.state.mode = 'down'; r = await j('POST', '/api/chat', { provider: 'ollama', model: 'sim-model', max_tokens: 32, messages: [{ role: 'user', content: 'down?' }] }); t('provider down → structured error, no crash', r.status >= 400, `${r.status} ${JSON.stringify(r.body).slice(0,200)}`); fo.state.mode = 'ok';
r = await j('GET', '/v2/health', null, {}); t('backend still healthy after provider failure', r.status === 200);
// timeout path: slow provider with tiny timeout covered by unit tests; here just check slow ok
// tasks
{ const rs = await fetch(base + '/v2/tasks', { method: 'POST', headers: H, body: JSON.stringify({ input: 'لخص: نكسس منصة وكلاء', provider: 'ollama' }) }); const txt = await rs.text(); t('/v2/tasks SSE (agent runtime path) via sim', rs.status === 200 && /task_meta/.test(txt), `status=${rs.status}`); console.log('TASK_SSE', txt.slice(0, 900)); }
r = await j('POST', '/v2/tasks', { input: '', provider: 'ollama' }); t('/v2/tasks invalid → 400', r.status === 400, r.status);
// council / swarm / warden
r = await j('GET', '/v2/warden/status'); t('warden status', r.status === 200, JSON.stringify(r.body).slice(0,200));
r = await j('POST', '/v2/council', { topic: 'هل نعتمد خيار أ؟', mode: 'cross_exam', proposerAgentId: 'financial', criticAgentId: 'legal', supervisorAgentId: 'supervisor' }); t('council cross_exam (sim)', r.status < 300, `${r.status} ${JSON.stringify(r.body).slice(0,200)}`);
r = await j('POST', '/v2/council', { topic: '' }); t('council invalid → 400', r.status === 400, r.status);
const agents = await (async()=>{ r = await j('POST','/v2/swarm',{ topic: 'خطة إطلاق منتج', maxAgents: 3 }); t('swarm vague topic → fail-closed 400 (no fake swarm)', r.status === 400, `${r.status}`); r = await j('POST','/v2/swarm',{ topic: 'تحليل مالي وقانوني وتسويقي لعقد استثمار عقاري', maxAgents: 3 }); t('swarm formation with relevant topic (sim)', r.status < 300, `${r.status} ${JSON.stringify(r.body).slice(0,260)}`); return r; })();
r = await j('POST','/v2/warden/agents/legal/isolate',{ reason: 'integration test' }); t('warden isolate agent', r.status === 200, JSON.stringify(r.body).slice(0,120));
r = await j('GET','/v2/warden/agents/isolated'); t('warden lists isolated agent', r.status === 200 && JSON.stringify(r.body).includes('legal'), JSON.stringify(r.body).slice(0,160));
r = await j('POST','/v2/warden/agents/legal/deisolate',{ reason: 'done' }); t('warden de-isolate agent', r.status === 200, JSON.stringify(r.body).slice(0,120));
r = await j('GET', '/v2/observability?limit=5'); t('observability', r.status === 200, JSON.stringify(r.body).slice(0,120));
r = await j('GET', '/v2/budget'); t('budget', r.status === 200, JSON.stringify(r.body).slice(0,160));
r = await j('GET', '/v2/execution-receipts'); t('execution receipts list', r.status === 200, JSON.stringify(r.body).slice(0,120));
// persistence across restart
const obsBefore = (await j('GET', '/v2/observability?limit=200')).body; 
be.proc.kill('SIGTERM'); await new Promise((x) => setTimeout(x, 800));
be = await startBackend({ port: bport, env });
const obsAfter = (await j('GET', '/v2/observability?limit=200')).body;
const cnt = (o) => { const a = Array.isArray(o) ? o : (o.recent || o.items || o.records || o.rows || []); return Array.isArray(a) ? a.length : -1; };
t('SQLite persistence across backend restart (observability rows survive)', cnt(obsBefore) > 0 && cnt(obsAfter) >= cnt(obsBefore), `before=${cnt(obsBefore)} after=${cnt(obsAfter)} dbExists=${fs.existsSync(DB)}`);
// CORS
{ const rs = await fetch(base + '/v2/models', { method: 'OPTIONS', headers: { origin: 'http://evil.example', 'access-control-request-method': 'GET', 'access-control-request-headers': 'authorization' } }); t('CORS: disallowed origin gets no ACAO', !rs.headers.get('access-control-allow-origin') || rs.headers.get('access-control-allow-origin') !== 'http://evil.example', `ACAO=${rs.headers.get('access-control-allow-origin')} status=${rs.status}`);
  const ok = await fetch(base + '/v2/models', { method: 'OPTIONS', headers: { origin: 'http://127.0.0.1:9', 'access-control-request-method': 'GET', 'access-control-request-headers': 'authorization' } }); t('CORS: allowed origin echoed', ok.headers.get('access-control-allow-origin') === 'http://127.0.0.1:9', `ACAO=${ok.headers.get('access-control-allow-origin')}`); }
// untrusted input
r = await j('POST', '/api/chat', { provider: 'ollama', model: 'sim-model', max_tokens: 20, messages: [{ role: 'user', content: '<script>alert(1)</script>\u0000' + 'A'.repeat(100) }] }); t('untrusted input (script tag/NUL) handled without 5xx', r.status < 500, r.status);
{ const rs = await fetch(base + '/api/chat', { method: 'POST', headers: H, body: '{bad json' }); t('malformed JSON → 4xx', rs.status >= 400 && rs.status < 500, rs.status); }
{ const rs = await fetch(base + '/api/chat', { method: 'POST', headers: H, body: JSON.stringify({ provider: 'ollama', max_tokens: 5, messages: [{ role: 'user', content: 'x'.repeat(5_000_000) }] }) }); t('oversized body → 413/4xx', rs.status >= 400 && rs.status < 500, rs.status); }
be.proc.kill('SIGTERM'); await new Promise((x)=>setTimeout(x,600));
{ const env2 = { ...env }; delete env2.NEXUS_RATE_LIMIT_PER_MINUTE; delete env2.NEXUS_RATE_LIMIT_BURST; const rp = await freePort(); const b2 = await startBackend({ port: rp, env: env2 }); let n429 = 0; for (let i = 0; i < 60; i++) { const rr = await fetch(`http://127.0.0.1:${rp}/v2/models`, { headers: H }); if (rr.status === 429) n429++; } t('rate limiter trips under burst (default limits)', n429 > 0, `429s=${n429}/60`); b2.proc.kill('SIGTERM'); }
const logTxt = be.getLog(); t('backend log contains no gateway key', !logTxt.includes(KEY));
be.proc.kill('SIGTERM'); fo.server.close();
const passed = results.filter((x) => x.ok).length; console.log(`\nSUMMARY ${passed}/${results.length}`);
fs.writeFileSync(process.argv[2] || '/dev/null', JSON.stringify(results, null, 2));
process.exit(passed === results.length ? 0 : 1);
