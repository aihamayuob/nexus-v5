import { chromium, devices } from 'playwright';
const O = 'http://127.0.0.1:8787', KEY = 'preview-test-key-0123456789', SH = process.argv[2];
const res = []; const t = (n, ok, d = '') => { res.push({ name: n, ok: !!ok, detail: String(d).slice(0, 250) }); console.log(`[${ok ? 'PASS' : 'FAIL'}] ${n}${d ? ' — ' + String(d).slice(0, 220) : ''}`); };
const b = await chromium.launch();
const VPS = [['desktop', { viewport: { width: 1440, height: 900 } }], ['tablet', { viewport: { width: 820, height: 1180 }, hasTouch: true }], ['android-emulated', { ...devices['Pixel 7'] }]];
for (const [vp, o] of VPS) {
  const c = await b.newContext({ ...o, locale: 'ar-SA' }); const p = await c.newPage(); const errs = []; p.on('pageerror', (e) => errs.push(String(e)));
  await p.goto(O + '/preview', { waitUntil: 'networkidle' }); await p.waitForTimeout(500);
  t(`[${vp}] preview page: health READY + SIM banner`, (await p.locator('#healthChip').innerText()).includes('READY') && (await p.locator('#simBanner').innerText()).includes('محاكاة'));
  t(`[${vp}] preview page: no horizontal overflow`, await p.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1), await p.evaluate(() => `sw=${document.documentElement.scrollWidth} iw=${innerWidth}`));
  await p.fill('#gk', KEY); await p.click('#checkBtn'); await p.waitForTimeout(800);
  const provTxt = await p.locator('#provs').innerText(); t(`[${vp}] provider states shown (ollama READY, cloud NOT_CONFIGURED)`, /ollama[\s\S]*READY/.test(provTxt) && provTxt.includes('NOT_CONFIGURED'), provTxt.replace(/\n/g, ' '));
  await p.selectOption('#mode', 'PRIVATE'); await p.click('#routeBtn'); await p.waitForTimeout(500); const ro = await p.locator('#routeOut').innerText(); t(`[${vp}] route PRIVATE resolves to ollama`, /"provider": "ollama"/.test(ro), ro.replace(/\n/g, ' ').slice(0, 120));
  await p.screenshot({ path: `${SH}/preview-page__${vp}__ar.png`, fullPage: true });
  await p.click('#langBtn'); await p.waitForTimeout(200); t(`[${vp}] EN/LTR toggle`, (await p.evaluate(() => document.documentElement.dir)) === 'ltr'); await p.screenshot({ path: `${SH}/preview-page__${vp}__en.png`, fullPage: true });
  // real platform through the same-origin proxy
  await p.goto(O + '/', { waitUntil: 'networkidle' }); await p.waitForTimeout(600);
  await p.evaluate(() => { closeSideMenu?.(); openSettingsPanel(); }); await p.fill('#backendUrlInput', O + '/backend'); await p.fill('#gatewayKeyInput', KEY); await p.evaluate(() => saveBackendUrl()); await p.evaluate(() => closeModal('settingsModal'));
  await p.evaluate(() => { if (isSimpleMode()) toggleSimpleMode(); }); await p.waitForTimeout(300);
  await p.evaluate(() => { const s = document.getElementById('chatModelSelect'); s.value = 'ollama'; saveChatModelSetting(); }); await p.fill('#localModelNameInput', 'sim-model'); await p.locator('#localModelNameInput').dispatchEvent('change');
  await p.evaluate(() => { const c = document.getElementById('autoRouteToggle'); c.checked = false; c.dispatchEvent(new Event('change', { bubbles: true })); });
  await p.fill('#msgInput', 'اختبار عبر الوكيل'); try { await p.click('#sendBtn', { timeout: 4000 }); } catch { await p.evaluate(() => sendMessage()); } await p.waitForTimeout(3500);
  const chat = await p.evaluate(() => document.getElementById('chatArea').innerText); t(`[${vp}] real UI → proxy → backend → simulated local model (streamed)`, chat.includes('SIMULATION'), chat.slice(-110).replace(/\n/g, ' '));
  t(`[${vp}] no uncaught page errors`, errs.length === 0, errs.join('|'));
  await c.close();
}
await b.close(); const p = res.filter((r) => r.ok).length; console.log(`SUMMARY ${p}/${res.length}`);
