# NEXUS PLATFORM PREVIEW — تشغيل المعاينة / Running the preview

> **الحالة: PARTIAL.** نسخة معاينة معزولة من لقطة CLOSURE (VEL + G8 + G8.1 + G8.2 + إغلاق G8.2) — ليست المستودع الحي ولا نشرًا إنتاجيًا.
> المزوّد المحلي الافتراضي **محاكاة** (مُجيب Ollama وهمي) — ليس نموذجًا حقيقيًا. لا مزوّد سحابي مضبوط، فلا تكلفة ولا مكالمة مدفوعة.
> The default local provider is a **SIMULATION** (fake Ollama-protocol responder). No cloud provider is configured.

## المحتوى / Contents
| المسار | الوصف |
|---|---|
| `NEXUS-PLATFORM-PREVIEW.html` | صفحة المعاينة: حالة الخلفية الحيّة، فحص المزوّدين، اختبار التوجيه الحقيقي، خريطة حالة المكوّنات (AR/EN، فاتح/داكن) |
| `frontend/` | الواجهة الحقيقية **دون أي تعديل** (HTML + `modules/*.mjs` + `main.js` + `sw.js`) |
| `backend/` | الخلفية الحقيقية (Node ≥ 22.5، TypeScript، SQLite، صفر تبعيات تشغيل) |
| `preview/preview-server.mjs` | مُشغّل بأمر واحد: الخلفية + المحاكاة + منفذ واحد يخدم الواجهة ويمرّر `/backend/*` |
| `harness/` | اختبارات التكامل والواجهة المستخدمة (`api-integration.mjs`, `ui-scenario.mjs`, `preview-smoke.mjs`) |
| `evidence/`, `screenshots/` | سجلات التشغيل الخام ولقطات شاشة حقيقية من Chromium |
| `NEXUS-PREVIEW-REPORT-2026-11-11.md` | تقرير الاختبار وخريطة المكوّنات والنتائج والقيود |

## التشغيل / Run (Node ≥ 22.5)
```bash
cd backend && npm ci --ignore-scripts && npm run build && cd ..
node preview/preview-server.mjs            # localhost فقط / loopback only
# اختياري: --port 8787  --key <16+ chars>
# اختياري: --real-ollama --model <اسم نموذج مثبّت لديك>   (يتطلب Ollama حقيقيًا على 11434)
```
الطرفية تطبع رابط المنصة ومفتاح الدخول. افتح `http://localhost:8787/` ثم ⚙️ الإعدادات:
رابط الخلفية = `http://localhost:8787/backend` والمفتاح = المطبوع. ثم (وضع متقدم) اختر **Ollama (محلي)** واسم النموذج `sim-model`.
> مهم (F-UI-1): **عطّل «التوجيه الذكي»** عند اختبار الوضع المحلي — انظر التقرير.
> المفتاح يُحفظ في ذاكرة الصفحة فقط: بعد إعادة التحميل أعد إدخاله (قرار أمني B4).

## من هاتف أندرويد / From an Android phone
1. **الأفضل (سياق آمن):** USB + Chrome على الحاسوب `chrome://inspect` → Port forwarding `8787 → localhost:8787`، ثم على الهاتف `http://localhost:8787/`. (`localhost` سياق آمن فيعمل Service Worker.)
2. **شبكة محلية موثوقة:** `node preview/preview-server.mjs --lan` ثم `http://<IP-الحاسوب>:8787/` — HTTP عادي: المفتاح يمر دون تشفير، و**ليس سياقًا آمنًا** (لا Service Worker). لشبكة موثوقة فقط.
3. رابط HTTPS عام: **لم يُنشأ** (انظر التقرير: BLOCKED). لا تنشره للإنترنت دون قرار ونشر آمن منفصل.

## إعادة تشغيل الاختبارات
```bash
cd backend && npx tsc -p tsconfig.json --noEmit && npx tsx --test "test/**/*.test.ts"     # 620 اختبار (يلزم tsx)
cd ../frontend && npm ci --ignore-scripts && npx vitest run                               # 186 اختبار
cd .. && npm i playwright && npx playwright install chromium                              # للواجهة
node harness/api-integration.mjs out.json ; node harness/ui-scenario.mjs ./shots ui.json
```
