#!/usr/bin/env node
/**
 * NEXUS PLATFORM PREVIEW — one-command local runner (NOT part of the NEXUS source; a test/preview harness).
 *
 *   node preview/preview-server.mjs [--port 8787] [--lan] [--real-ollama --model <name>] [--key <>=16 chars>]
 *
 * What it starts (all on this machine):
 *   1. the REAL backend  (backend/dist/index.js, loopback-only, gateway-key protected, temp SQLite DB)
 *   2. a SIMULATED local model server speaking the Ollama protocol  (default)  — responses are labelled "[SIMULATION ...]".
 *      With --real-ollama it points the backend at a real Ollama on http://127.0.0.1:11434 instead (you must have pulled --model).
 *   3. ONE public-facing port that serves the REAL, UNMODIFIED frontend and reverse-proxies /backend/* to the loopback backend.
 *      Only this one port is ever exposed. With --lan it binds 0.0.0.0 (plain HTTP — trusted LAN only).
 * No cloud provider is configured: no paid call can happen. Nothing here is a production deployment.
 */
import http from 'node:http';
import crypto from 'node:crypto';
import net from 'node:net';
import os from 'node:os';
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const arg = (n, d) => { const i = process.argv.indexOf(n); return i < 0 ? d : (process.argv[i + 1] && !process.argv[i + 1].startsWith('--') ? process.argv[i + 1] : true); };
const PORT = Number(arg('--port', 8787));
const LAN = !!arg('--lan', false);
const REAL = !!arg('--real-ollama', false);
const MODEL = REAL ? String(arg('--model', '')) : 'sim-model';
if (REAL && (!MODEL || MODEL === 'true')) { console.error('--real-ollama requires --model <name of a model you pulled in Ollama>'); process.exit(2); }
const KEY = String(arg('--key', '')) || crypto.randomBytes(18).toString('base64url');
if (KEY.length < 16) { console.error('gateway key must be >= 16 chars'); process.exit(2); }
const free = () => new Promise((r) => { const s = net.createServer(); s.listen(0, '127.0.0.1', () => { const p = s.address().port; s.close(() => r(p)); }); });

// ---- SIMULATED local model (Ollama protocol) -------------------------------------------------------------------------------------------
function simOllama() {
  return http.createServer(async (req, res) => {
    const ch = []; for await (const c of req) ch.push(c);
    if (req.url === '/api/tags') { res.writeHead(200, { 'content-type': 'application/json' }); return res.end(JSON.stringify({ models: [{ name: 'sim-model' }] })); }
    if (req.url !== '/api/chat') { res.writeHead(404); return res.end(); }
    let b = {}; try { b = JSON.parse(Buffer.concat(ch).toString('utf8')); } catch {}
    const last = (b.messages || []).filter((m) => m.role === 'user').pop();
    const u = typeof last?.content === 'string' ? last.content : JSON.stringify(last?.content ?? '');
    const text = `[SIMULATION — fake local model, not a real LLM] تم استلام: ${u.slice(0, 120)}`;
    if (b.stream) {
      res.writeHead(200, { 'content-type': 'application/x-ndjson' });
      for (const part of text.match(/.{1,12}/gs)) res.write(JSON.stringify({ message: { role: 'assistant', content: part }, done: false }) + '\n');
      return res.end(JSON.stringify({ message: { role: 'assistant', content: '' }, done: true, prompt_eval_count: 11, eval_count: 7 }) + '\n');
    }
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ message: { role: 'assistant', content: text }, done: true, prompt_eval_count: 11, eval_count: 7 }));
  });
}

// ---- boot ------------------------------------------------------------------------------------------------------------------------------
const distIndex = path.join(ROOT, 'backend/dist/index.js');
if (!fs.existsSync(distIndex)) { console.error('backend/dist is missing. Run once:  cd backend && npm ci --ignore-scripts && npm run build'); process.exit(2); }
let ollamaUrl = 'http://127.0.0.1:11434';
if (!REAL) { const sim = simOllama(); const sp = await free(); await new Promise((r) => sim.listen(sp, '127.0.0.1', r)); ollamaUrl = `http://127.0.0.1:${sp}`; }
const bport = await free();
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'nexus-preview-'));
const env = { ...process.env, NEXUS_PORT: String(bport), NEXUS_HOST: '127.0.0.1', NEXUS_GATEWAY_KEYS: KEY, NEXUS_DB_PATH: path.join(tmp, 'nexus.db'), NEXUS_OLLAMA_BASE_URL: ollamaUrl, NEXUS_MODEL_OLLAMA: MODEL };
for (const k of Object.keys(env)) if (/^NEXUS_(ANTHROPIC|OPENAI|DEEPSEEK|GEMINI)_API_KEY$/.test(k)) delete env[k]; // preview never carries cloud keys
const be = spawn('node', ['--experimental-sqlite', '--enable-source-maps', distIndex], { cwd: path.join(ROOT, 'backend'), env, stdio: ['ignore', 'pipe', 'pipe'] });
let blog = ''; be.stdout.on('data', (d) => (blog += d)); be.stderr.on('data', (d) => (blog += d));
for (let i = 0; i < 60 && !blog.includes('listening'); i++) await new Promise((r) => setTimeout(r, 200));
if (!blog.includes('listening')) { console.error('backend failed to start:\n' + blog.slice(-1500)); process.exit(1); }

// ---- front door: static (real frontend, untouched) + /backend proxy + /preview ---------------------------------------------------------
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.json': 'application/json', '.png': 'image/png', '.svg': 'image/svg+xml', '.webmanifest': 'application/manifest+json' };
const FE = path.join(ROOT, 'frontend');
const server = http.createServer(async (req, res) => {
  try {
    const u = new URL(req.url, 'http://x'); const p = decodeURIComponent(u.pathname);
    if (p === '/backend' || p.startsWith('/backend/')) {
      const up = http.request({ host: '127.0.0.1', port: bport, method: req.method, path: (p.slice('/backend'.length) || '/') + u.search, headers: { ...req.headers, host: `127.0.0.1:${bport}` } }, (r) => { res.writeHead(r.statusCode, r.headers); r.pipe(res); r.on('error', () => res.destroy()); });
      up.on('error', () => { if (!res.headersSent) res.writeHead(502, { 'content-type': 'application/json' }); res.end(JSON.stringify({ error: { code: 'backend_unreachable' } })); });
      req.on('aborted', () => up.destroy()); res.on('close', () => up.destroy());
      return req.pipe(up);
    }
    if (p === '/preview-config.json') { res.writeHead(200, { 'content-type': 'application/json', 'cache-control': 'no-store' }); return res.end(JSON.stringify({ mode: REAL ? 'REAL-OLLAMA' : 'SIMULATION', model: MODEL, backendUrl: '/backend', keyHint: 'printed in the terminal that started this server' })); }
    if (p === '/preview' || p === '/preview/') { const b = await fs.promises.readFile(path.join(ROOT, 'NEXUS-PLATFORM-PREVIEW.html')); res.writeHead(200, { 'content-type': MIME['.html'] }); return res.end(b); }
    const rel = p === '/' ? 'neural_nexus_ai_agents-4-3-5-3.html' : p.slice(1);
    const fp = path.resolve(FE, rel); if (!fp.startsWith(FE + path.sep)) { res.writeHead(403); return res.end(); }
    const b = await fs.promises.readFile(fp); res.writeHead(200, { 'content-type': MIME[path.extname(fp)] || 'application/octet-stream' }); res.end(b);
  } catch { res.writeHead(404); res.end('not found'); }
});
server.listen(PORT, LAN ? '0.0.0.0' : '127.0.0.1', () => {
  const ips = Object.values(os.networkInterfaces()).flat().filter((i) => i && i.family === 'IPv4' && !i.internal).map((i) => i.address);
  console.log('\n=== NEXUS PLATFORM PREVIEW ===');
  console.log(REAL ? `Local model: REAL Ollama (${MODEL}) at ${ollamaUrl}` : 'Local model: *** SIMULATION *** (fake Ollama-protocol responder — not a real LLM)');
  console.log('Cloud providers: none configured (no paid calls possible)');
  console.log(`Platform:   http://localhost:${PORT}/`);
  console.log(`Preview:    http://localhost:${PORT}/preview`);
  console.log(`In ⚙️ Settings enter:  Backend URL = http://localhost:${PORT}/backend   (same origin as the page)`);
  console.log(`                       Gateway key = ${KEY}`);
  if (LAN) { console.log(`LAN (plain HTTP, trusted network only; NOT a secure context on a phone — see README): ${ips.map((i) => `http://${i}:${PORT}/`).join('  ')}`); console.log(`   backend URL on the phone = http://<that-ip>:${PORT}/backend`); }
  console.log('Ctrl+C to stop. Data lives in a temp DB: ' + tmp + '\n');
});
const stop = () => { try { be.kill('SIGTERM'); } catch {} server.close(); setTimeout(() => process.exit(0), 300); };
process.on('SIGINT', stop); process.on('SIGTERM', stop); be.on('exit', (c) => { console.error('backend exited', c); process.exit(1); });
